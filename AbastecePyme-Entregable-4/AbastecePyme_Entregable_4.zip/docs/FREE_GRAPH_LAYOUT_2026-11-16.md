# Movimiento libre y selección múltiple del grafo

Esta actualización permite organizar visualmente los cuadros de proveedores, insumos y productos en los grafos de AbastecePyme. Conserva colores, conexiones, pesos, zoom, cálculos y explicaciones.

> Esta página registra la primera entrega de movimiento libre. La ampliación posterior guarda las posiciones por cuenta: consulta [Distribución por usuario y movimiento continuo](USER_GRAPH_LAYOUTS_2026-11-16.md). Las notas de posiciones locales y activación sin reinicio describen únicamente aquella primera entrega.

## Uso

1. **Mover un cuadro:** arrástralo con el botón izquierdo hacia la posición que quieras.
2. **Elegir varios:** mantén **Ctrl** y haz clic en cada cuadro. Otro Ctrl + clic lo retira del grupo. En macOS también funciona **Cmd**.
3. **Mover el grupo:** suelta Ctrl y arrastra cualquiera de los cuadros marcados. Se mueven juntos, conservando su separación.
4. **Seleccionar por rectángulo:** activa **Seleccionar área** y arrastra sobre el fondo. También puedes usar **Shift + arrastrar** sobre el fondo. Ctrl permite agregar la nueva selección a la existente.
5. **Volver a explorar:** desactiva **Seleccionar área** pulsando nuevamente el botón y arrastra el fondo sin mover cuadros. Los botones de zoom, **Ajustar red** y **Tamaño legible** siguen disponibles.
6. **Restaurar distribución:** devuelve los cuadros a sus columnas iniciales. No elimina elementos ni relaciones.

**Teclado:** Ctrl/Cmd + Enter o Espacio alterna la selección del cuadro enfocado. Alt + flechas mueve el cuadro o grupo seleccionado 10 unidades del grafo; con Shift, 40. Las flechas sin Alt desplazan el lienzo. **Escape** cancela un arrastre en curso y limpia la selección; **Limpiar selección** retira las marcas sin deshacer los movimientos terminados.

Las posiciones son locales a la vista abierta: se conservan al enfocar conexiones o cambiar la opción de costo, pero no se guardan en MariaDB. Recargar, salir de la vista o recibir un catálogo actualizado restablece la distribución. En el tablero, alternar entre conexiones enfocadas y grafo completo conserva el acomodo de la misma red analizada.

La marca de selección para mover es diferente del resaltado de una opción económica/costosa o de un camino de impacto. El arrastre no cambia el producto consultado, la dirección de las flechas, sus cantidades o sus precios.

## Construcción

Se amplía el componente SVG compartido. La distribución inicial sigue siendo automática; un mapa local conserva las coordenadas manuales por identificador. Las curvas, pesos y límites del encuadre se recalculan desde esas coordenadas. No se agrega una biblioteca de grafos.

La interacción distingue pulsación, arrastre de nodos, rectángulo y desplazamiento del lienzo. Usa coordenadas SVG para que los movimientos correspondan al nivel de zoom; actualiza el dibujo por cuadros de animación y libera la captura del puntero cuando el gesto termina o se cancela. Las selecciones de presentación permanecen separadas de la selección que controla los costos y caminos de negocio.

La aplicación de esta actualización solo requiere recargar el navegador después de compilar la interfaz. No añade una migración ni necesita una nueva contraseña de conexión.

## Validación del 16 de noviembre de 2026

Se aprobaron **125 pruebas Python y 104 JavaScript (229)**. Las 16 pruebas nuevas cubren selección, rectángulos, traslación de grupos, coordenadas negativas, inmutabilidad, límites de curvas y selección por teclado. La compilación final procesó 59 módulos.

La comprobación en navegador utilizó datos sintéticos en memoria en el puerto 3018:

- Arrastre real con mouse de un cuadro y de un grupo elegido con Ctrl; ambos cuadros conservaron la misma separación.
- Selección de dos productos mediante un rectángulo y movimiento conjunto, con actualización de sus flechas.
- Arrastre con zoom, conservación de la vista y restauración exacta de las coordenadas iniciales.
- Selección múltiple por teclado: Alt + flecha movió solamente el grupo 10 unidades, aunque el detalle abierto correspondía a otro producto.
- Conservación de la posición de un insumo al alternar las opciones económica y costosa; costos de 70.000 y 80.000 COP y venta de 87.500 COP sin cambios.
- Tablero: coordenadas conservadas al alternar entre 6 nodos enfocados y 11 de la red completa, manteniendo el camino de Estante modular.
- Orden de producción y Análisis de impacto: movimiento desde teclado y conservación del resultado y camino consultados.
- Pantalla de 390 × 844: controles ajustados al ancho, sin desbordamiento horizontal (375 px visibles y desplazables). No se probó un dispositivo táctil físico.
- Cero errores de consola durante el recorrido.

La instalación habitual en **3001** respondió HTTP 200 y sirvió un `index.html` idéntico a la compilación actual. Las interacciones autenticadas se comprobaron en la instancia sintética, no con los datos de MariaDB. No se modificaron registros ni la semilla original. Recarga la aplicación con **Ctrl + F5** para cargar esta interfaz.

![Movimiento libre de proveedores e insumos seleccionados](media/free-graph-2026-11-16/01-group-movement.jpg)

[Controles en pantalla pequeña](media/free-graph-2026-11-16/02-mobile-controls.jpg).
