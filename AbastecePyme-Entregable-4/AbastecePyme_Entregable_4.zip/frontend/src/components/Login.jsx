import {useState} from 'react';
import {Api,SetSession} from '../Api.js';
import {Brand,Field,Notice,Icon} from './Common.jsx';
import {Preferences,PrepareSound,PlaySessionSound} from './Preferences.jsx';

export default function Login({OnSession}) {
  const [Busy,SetBusy]=useState(false);
  const [Error,SetError]=useState('');
  async function Submit(Event){
    Event.preventDefault();if(Busy)return;PrepareSound();SetBusy(true);SetError('');
    const Form=new FormData(Event.currentTarget);
    try{
      const Session=await Api('/api/auth/login',{method:'POST',body:{Username:Form.get('Username'),Password:Form.get('Password')}});
      SetSession(Session);OnSession(Session);PlaySessionSound('Login');window.location.hash='dashboard';
    }catch(Failure){SetError(Failure.message);}finally{SetBusy(false);}
  }
  return <div className="auth-page"><div className="auth-story"><Brand/><div><div className="auth-orbit" aria-hidden="true"><Icon Name="graph" Size={72}/></div><h1>Todo empieza con una buena conexión.</h1><p>Tu equipo, tus materiales y el siguiente paso de tu producción.</p></div><a href="#home">Volver al inicio</a></div><main className="auth-main" id="main"><form className="auth-form" onSubmit={Submit}><span className="badge">Acceso del equipo</span><h2>Qué bueno tenerte aquí.</h2><p>Inicia sesión en tu espacio de AbastecePyme.</p><Notice Text={Error} Error/>
    <Field Label="Usuario"><input name="Username" autoComplete="username" required minLength={1} maxLength={40} autoFocus/></Field>
    <Field Label="Contraseña"><input type="password" name="Password" required autoComplete="current-password" minLength={1} maxLength={128}/></Field>
    <button className="primary" disabled={Busy}>{Busy?'Iniciando sesión…':'Iniciar sesión'}<Icon Name="arrow"/></button>
    <p className="auth-switch">¿Necesitas una cuenta? Solicítala al administrador de tu equipo.</p><Preferences/>
  </form></main></div>;
}
