# Modelo relacional de AbastecePyme
Todas las tablas usan InnoDB y utf8mb4. Los identificadores globales de elementos usan ASCII sensible a mayúsculas.
- Elements: ElementId PK, Name, ElementType, Description, Version.
- Suppliers: ElementId PK/FK→Elements, Contact.
- Materials: ElementId PK/FK→Elements, UnitCode.
- Products: ElementId PK/FK→Elements.
- ProductPrices: ElementId PK/FK→Products; SalePrice DECIMAL(18,2)>=0, IsPriceReference BOOLEAN. Sin fila significa precio pendiente. Usa la versión de Elements y se elimina junto al producto.
- SupplierOffers: SupplierId+MaterialId PK y FKs→subtipos; UnitPrice DECIMAL(18,2)>=0, CurrencyCode COP, IsDemo, Version.
- ProductRequirements: MaterialId+ProductId PK y FKs→subtipos; Quantity DECIMAL(18,4)>0, IsDemo, Version.
- GeneralDependencies: SourceId+TargetId PK y FKs→Elements, Version.
- Roles: RoleId PK (Administrator,Editor,Viewer).
- Users: UUID UserId PK; Username único, DisplayName, Email, PasswordHash, RoleId FK, IsActive, Version, CreatedAt.
- Sessions: TokenHash PK SHA256 de token aleatorio, UserId FK, CsrfToken, ExpiresAt.
- ContactRequests: RequestId CHAR(36) PK; FullName VARCHAR(80), Email VARCHAR(254), Phone VARCHAR(25), Company VARCHAR(100), Subject VARCHAR(80), Message VARCHAR(2000), ConsentVersion VARCHAR(20), CreatedAt DATETIME y ReadAt DATETIME nullable. Phone y Company admiten cadena vacía; los demás campos de captura y CreatedAt son obligatorios. Índice compuesto (CreatedAt, RequestId) para ordenar y paginar las solicitudes. La API permite consultar y marcar como leído únicamente al Administrador; no envía respuestas por correo.
- Migrations: MigrationId PK, SourceHash y AppliedAt.

El DDL ejecutable está en backend/Schema.py. CREATE TABLE es idempotente; no se utiliza CREATE OR REPLACE ni se borran tablas.
MariaDB confirma DDL implícitamente: la creación del esquema y la transacción de importación son etapas separadas. Una importación parcial se revierte, aunque el esquema vacío puede permanecer.
Las altas de elementos insertan base y subtipo en una transacción. Las bajas eliminan relaciones, subtipo y elemento de forma atómica. Los IDs y tipos son estables.


RevisionClock: tabla técnica añadida durante revisión; ClockId PK=1 y CurrentValue BIGINT. El contador persistente asigna versiones no repetidas, incluso después de borrar y recrear IDs. Todas las mutaciones del catálogo adquieren primero su bloqueo. El contador y los datos se confirman/revierten juntos. Las columnas Version del catálogo son BIGINT dentro del rango entero exacto de JavaScript.


NewsletterSubscriptions: Email VARCHAR(254) PK, ConsentVersion VARCHAR(20) y CreatedAt DATETIME con valor inicial CURRENT_TIMESTAMP. Registra correos con consentimiento para futuras novedades; el envío de mensajes aún no está habilitado. Se añade con CREATE TABLE IF NOT EXISTS sin reemplazar tablas existentes. Feature 3 calcula resultados en memoria y no requiere tablas de orden o de ciclos.
