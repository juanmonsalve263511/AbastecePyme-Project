# Skills y referencias utilizadas

## Registro histórico anterior al 14 de noviembre de 2026

Instaladas para este proyecto:
- frontend-design: dirección visual, jerarquía, tipografía, paleta y revisión de pantallas.
- vercel-react-best-practices (carpeta react-best-practices): componentes, carga diferida del grafo/API/usuarios, estados derivados y búsquedas por índices.
- security-best-practices: autenticación, Argon2id, sesiones opacas, CSRF, validación, consultas parametrizadas y respuestas sin secretos.
- playwright: preparación de pruebas de navegador; Chrome CLI falló al iniciar. La comprobación visual continuó con el navegador integrado.

Skills de trabajo utilizadas: brainstorming (diseño aprobado), writing-plans (plan aprobado), executing-plans (ejecución directa), test-driven-development (pruebas y regresiones), systematic-debugging (diagnóstico), verification-before-completion y requesting-code-review (revisión final).
using-git-worktrees se consultó: el proyecto no es un repositorio Git; se mantuvo su respaldo verificado.

Referencias oficiales consultadas:
- React: https://react.dev/learn/build-a-react-app-from-scratch
- FastAPI: https://fastapi.tiangolo.com/tutorial/security/oauth2-jwt/
- MariaDB: https://mariadb.com/docs/server/server-usage/tables/create-table
- OWASP: https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html

## Feature 4 — 14 de noviembre de 2026

Esta entrega **reutilizó las skills ya disponibles; no instaló nuevas skills**. El listado inicial se conserva como registro histórico y no describe instalaciones realizadas el 14 de noviembre.

- **Planificación y alcance:** las guías de brainstorming y writing-plans apoyaron la definición aprobada del tablero y del cambio temporal de requisitos.
- **Interfaz:** frontend-design, vercel-react-best-practices y los criterios de web-design-guidelines ya incorporados al proyecto guiaron la integración con la marca azul y gris, la reutilización de componentes y el manejo de consultas sustituidas.
- **Pruebas y revisión:** test-driven-development, systematic-debugging, verification-before-completion y requesting-code-review apoyaron la aceptación repetible, el diagnóstico y la separación entre resultados observados y tareas pendientes.
- **Navegador y captura:** se evaluó Playwright CLI, pero Chrome/Chromium no pudo iniciarse por esa vía en este entorno. Se utilizó **computer-use/CUA y el navegador integrado** para la revisión visual y los fotogramas de la demostración. La grabación no se atribuye a Playwright.

La [aceptación de Feature 4](FEATURE4.md) registra las pruebas aisladas y la revisión del navegador. La demostración utiliza SQLite en memoria con datos sintéticos; no es una prueba de la base MariaDB operativa. El proceso anterior de 3001 requiere reinicio para cargar la ruta nueva, como se explica en el README y la guía.

El [documento del video](FEATURE4_VIDEO.md) distingue la preparación, la grabación y la comprobación del archivo final. Las guías utilizadas no certifican por sí mismas accesibilidad, seguridad o rendimiento de producción.

