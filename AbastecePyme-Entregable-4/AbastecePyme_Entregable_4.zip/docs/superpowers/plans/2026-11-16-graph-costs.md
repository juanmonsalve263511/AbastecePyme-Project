# Plan de implementación — grafo y costos

Diseño: [reglas acordadas](../specs/2026-11-16-graph-costs.md).

- [x] Servicio Python de costos y resúmenes del catálogo; aceptación aritmética y API.
- [x] Foco de impacto completo por defecto; alternancia de red y animación continua con pausa.
- [x] Panel compartido de costos en catálogo, grafo y producción; precio automático mínimo+25%.
- [x] Pruebas globales, compilación, revisión independiente y recorrido visual con datos aislados.
- [x] Documentación, paquete compartible y estado real del servidor operativo.

Se conserva el paquete verificado del 14 de noviembre como referencia anterior. No se alteran la semilla protegida ni las tablas del sistema MariaDB.

Verificación: 108 pruebas Python + 64 JavaScript; compilación de 53 módulos; revisión visual sintética de foco, costos, recálculo, pausa y móvil. El usuario confirmó el reinicio del servidor habitual. La comprobación posterior devolvió HTTP 200 en 3001 y una interfaz idéntica a frontend/dist; la ruta de costos devuelve 401 sin sesión. La comprobación funcional autenticada se realizó en la instancia sintética, no sobre MariaDB operativa.
