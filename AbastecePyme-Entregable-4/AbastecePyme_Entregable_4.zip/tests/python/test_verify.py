"""Verification must propagate failed checks and stop before subsequent work."""
import sys
import unittest
from contextlib import redirect_stderr, redirect_stdout
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory

import Verify


class VerificationTests(unittest.TestCase):
    def test_failed_check_stops_before_a_later_command(self):
        with TemporaryDirectory() as Folder:
            Steps = [
                ("Expected failure", [sys.executable, "-c", "raise SystemExit(7)"]),
                ("Must not run", [sys.executable, "-c", "from pathlib import Path; Path('later').touch()"]),
            ]
            with redirect_stdout(StringIO()), redirect_stderr(StringIO()):
                Result = Verify.RunSteps(Steps, Path(Folder))
            self.assertEqual(Result, 7)
            self.assertFalse((Path(Folder) / "later").exists())

    def test_success_runs_all_commands_in_the_project_directory(self):
        with TemporaryDirectory() as Folder:
            Steps = [
                ("First", [sys.executable, "-c", "from pathlib import Path; Path('marker').write_text('first')"]),
                ("Second", [sys.executable, "-c", "from pathlib import Path; p=Path('marker'); p.write_text(p.read_text()+' second')"]),
            ]
            with redirect_stdout(StringIO()), redirect_stderr(StringIO()):
                Result = Verify.RunSteps(Steps, Path(Folder))
            self.assertEqual(Result, 0)
            self.assertEqual((Path(Folder) / "marker").read_text(), "first second")
