"""Reproduce the synthetic backend research measurements from 2026-11-16.

Nothing runs on import. Use --run explicitly; --environment only reads machine
metadata. No real database, network, credentials or application writes are used.
Costs/payloads use three timed runs and report the median. SQL uses one measured
in-memory SQLite run per size, matching the original inline experiment.

From the project root:
  .venv/Scripts/python.exe -B -X utf8 tests/benchmarks/BenchmarkResearch2026.py --run
  .venv/Scripts/python.exe -B -X utf8 tests/benchmarks/BenchmarkResearch2026.py --environment

The original observed numbers are preserved separately in
docs/research/benchmark-research-2026.json. This script does not overwrite that evidence.
"""
import argparse
import ast
import contextlib
import gzip
import json
import os
import platform
import statistics
import sys
import time
from pathlib import Path


Root = Path(__file__).resolve().parents[2]


def ReadEnvironment():
    Result = {"Python": platform.python_version(), "Implementation": platform.python_implementation(),
              "Bits": 64 if sys.maxsize > 2**32 else 32, "Platform": platform.platform(),
              "Machine": platform.machine(), "LogicalProcessors": os.cpu_count(),
              "Processor": None, "PhysicalMemoryBytes": None}
    if sys.platform == "win32":
        import ctypes
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0") as Key:
            Result["Processor"] = winreg.QueryValueEx(Key, "ProcessorNameString")[0].strip()

        class MemoryStatus(ctypes.Structure):
            _fields_ = [("Length", ctypes.c_ulong), ("MemoryLoad", ctypes.c_ulong),
                        ("TotalPhysical", ctypes.c_ulonglong), ("AvailablePhysical", ctypes.c_ulonglong),
                        ("TotalPageFile", ctypes.c_ulonglong), ("AvailablePageFile", ctypes.c_ulonglong),
                        ("TotalVirtual", ctypes.c_ulonglong), ("AvailableVirtual", ctypes.c_ulonglong),
                        ("AvailableExtendedVirtual", ctypes.c_ulonglong)]

        Status = MemoryStatus()
        Status.Length = ctypes.sizeof(Status)
        if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(Status)):
            Result["PhysicalMemoryBytes"] = Status.TotalPhysical
    return Result


def SyntheticChain(Count, Other=False):
    Elements = [{"ElementId": "S1", "Name": "Synthetic supplier", "ElementType": "Supplier", "Version": 1},
                {"ElementId": "M1", "Name": "Synthetic material", "ElementType": "Material", "UnitCode": "unidad", "Version": 1}]
    Elements += [{"ElementId": f"P{Index:04}", "Name": f"Synthetic product {Index}", "ElementType": "Product",
                  "Version": 1, "SalePrice": None, "IsPriceReference": True} for Index in range(Count)]
    Relations = [{"SourceId": "S1", "TargetId": "M1", "RelationType": "Offer", "Value": "10.00", "IsDemo": True, "Version": 1},
                 {"SourceId": "M1", "TargetId": "P0000", "RelationType": "Requirement", "Value": "1.0000", "IsDemo": True, "Version": 1}]
    Relations += [{"SourceId": f"P{Index:04}", "TargetId": f"P{Index + 1:04}", "RelationType": "General",
                   "Value": None, "IsDemo": False, "Version": 1} for Index in range(Count - 1)]
    if Other:
        Elements += [{"ElementId": Id, "Name": Id, "ElementType": "Supplier", "Version": 1} for Id in ("SX", "SY")]
        Relations += [{"SourceId": "SX", "TargetId": "SY", "RelationType": "General", "Value": None, "IsDemo": False, "Version": 1}]
    return {"Elements": Elements, "Relations": Relations}


def Measure(Action, Repeats=3):
    Times = []
    for Repeat in range(Repeats):
        Start = time.perf_counter()
        Result = Action()
        Times.append((time.perf_counter() - Start) * 1000)
    return round(statistics.median(Times), 3), Result


def JsonBytes(Value):
    return json.dumps(Value, ensure_ascii=False, separators=(",", ":")).encode()


def BenchmarkCosts():
    from backend.ProductCosts import CalculateCatalogueCosts, CalculateProductCosts
    Results = []
    for Count in (100, 300, 1000):
        Normal, Unrelated = SyntheticChain(Count), SyntheticChain(Count, True)
        PlainTime, Plain = Measure(lambda: CalculateCatalogueCosts(**Normal))
        OtherTime, Other = Measure(lambda: CalculateCatalogueCosts(**Unrelated))
        assert Plain == Other
        DetailTime, Detail = Measure(lambda: CalculateProductCosts(f"P{Count - 1:04}", **Normal))
        Results.append({"Products": Count, "TypedMilliseconds": PlainTime, "UnrelatedGeneralMilliseconds": OtherTime,
                        "Ratio": round(OtherTime / PlainTime, 2), "SingleDetailMilliseconds": DetailTime, "OutputsIdentical": True})
    return Results


def BenchmarkPayloads():
    from backend.ProductCosts import CalculateCatalogueCosts
    from backend.Impact import AnalyzeImpact
    from backend.SupplyBoard import BuildSupplyBoard
    from backend.Models import SupplyBoardRequest
    Results = []
    for Count in (100, 500, 1000):
        Catalog = SyntheticChain(Count)
        Costs = CalculateCatalogueCosts(**Catalog)
        for Item in Catalog["Elements"]:
            if Item["ElementType"] == "Product":
                Item["ProductCosts"] = Costs[Item["ElementId"]]
        ImpactTime, Impact = Measure(lambda: AnalyzeImpact("S1", **Catalog))
        BoardTime, Board = Measure(lambda: BuildSupplyBoard(Catalog, SupplyBoardRequest(ElementId="S1")))
        SerializeTime, Encoded = Measure(lambda: JsonBytes(Board))
        CompressTime, Compressed = Measure(lambda: gzip.compress(Encoded, compresslevel=5, mtime=0))
        Results.append({"Products": Count, "CatalogBytes": len(JsonBytes(Catalog)), "ImpactMilliseconds": ImpactTime,
                        "ImpactPathEntries": sum(len(Item["Path"]) for Item in Impact["Visited"]),
                        "ImpactJsonBytes": len(JsonBytes(Impact)), "DashboardMilliseconds": BoardTime,
                        "DashboardJsonBytes": len(Encoded), "DashboardGzipBytes": len(Compressed),
                        "SerializationMilliseconds": SerializeTime, "GzipMilliseconds": CompressTime,
                        "BaseEqualsScenario": Board["Base"] == Board["Scenario"]})
    return Results


def BenchmarkSql():
    from types import SimpleNamespace
    from starlette.requests import Request
    from test_feature3_api import SqlAdapter
    from backend.Auth import CurrentUser, HashToken
    from backend.Catalog import ReadCatalogue
    from backend.ProductCosts import CalculateProductCosts

    class ProbeCursor:
        def __init__(self, Cursor, Database):
            self.Cursor, self.Database = Cursor, Database
            self.description = Cursor.description

        def fetchall(self):
            Rows = self.Cursor.fetchall()
            self.Database.Rows += len(Rows)
            return Rows

        def fetchone(self):
            Row = self.Cursor.fetchone()
            self.Database.Rows += int(Row is not None)
            return Row

    class ProbeDatabase(SqlAdapter):
        def __init__(self):
            super().__init__()
            self.Queries, self.Rows, self.Transactions = [], 0, 0

        @contextlib.contextmanager
        def Transaction(self):
            self.Transactions += 1
            with super().Transaction() as Connection:
                yield Connection

        def execute(self, Query, *Args):
            self.Queries.append(Query)
            return ProbeCursor(super().execute(Query, *Args), self)

    Results = []
    for Count in (100, 1000, 10000):
        Database = ProbeDatabase()
        Connection = Database.Connection
        try:
            Connection.executescript("""
                CREATE TABLE Elements(ElementId TEXT PRIMARY KEY,Name TEXT,ElementType TEXT,Description TEXT,Version INTEGER);
                CREATE TABLE Suppliers(ElementId TEXT PRIMARY KEY,Contact TEXT);
                CREATE TABLE Materials(ElementId TEXT PRIMARY KEY,UnitCode TEXT);
                CREATE TABLE Products(ElementId TEXT PRIMARY KEY);
                CREATE TABLE ProductPrices(ElementId TEXT PRIMARY KEY,SalePrice TEXT,IsPriceReference INTEGER);
                CREATE TABLE SupplierOffers(SupplierId TEXT,MaterialId TEXT,UnitPrice TEXT,IsDemo INTEGER,Version INTEGER);
                CREATE TABLE ProductRequirements(MaterialId TEXT,ProductId TEXT,Quantity TEXT,IsDemo INTEGER,Version INTEGER);
                CREATE TABLE GeneralDependencies(SourceId TEXT,TargetId TEXT,Version INTEGER);
                INSERT INTO Elements VALUES('S1','Synthetic supplier','Supplier','',1);
                INSERT INTO Elements VALUES('M1','Synthetic material','Material','',1);
                INSERT INTO Suppliers VALUES('S1','');
                INSERT INTO Materials VALUES('M1','unidad');
                INSERT INTO SupplierOffers VALUES('S1','M1','10.00',1,1);
            """)
            Connection.executemany("INSERT INTO Elements VALUES(?,?,'Product','',1)",
                                   [(f"P{Index:05}", f"Synthetic product {Index}") for Index in range(Count)])
            Connection.executemany("INSERT INTO Products VALUES(?)", [(f"P{Index:05}",) for Index in range(Count)])
            Connection.executemany("INSERT INTO ProductRequirements VALUES('M1',?,'1.0000',1,1)",
                                   [(f"P{Index:05}",) for Index in range(Count)])
            # Fixed placeholders are deliberately synthetic, local and ephemeral.
            # This is session lookup only: no login, password check or credential.
            Connection.execute("INSERT INTO Users(UserId,Username,DisplayName,PasswordHash,RoleId) VALUES(?,?,?,?,?)",
                               ("probe", "probe", "Synthetic probe", "unused", "Viewer"))
            Connection.execute("INSERT INTO Sessions VALUES(?,?,?,?)",
                               (HashToken("a" * 64), "probe", "synthetic-csrf", "2099-01-01"))
            Connection.commit()
            RequestValue = Request({"type": "http", "method": "GET",
                "headers": [(b"cookie", b"AbasteceSession=" + b"a" * 64)],
                "app": SimpleNamespace(state=SimpleNamespace(Database=Database))})
            Start = time.perf_counter()
            CurrentUser(RequestValue)
            Catalog = ReadCatalogue(Database, IncludeProductCosts=False)
            Result = CalculateProductCosts("P00000", **Catalog)
            Elapsed = (time.perf_counter() - Start) * 1000
            Results.append({"Products": Count, "SelectedRecipeNodes": len(Result["SourcingGraphs"]["Minimum"]["ElementIds"]),
                            "SqlSelects": sum(Query.lstrip().startswith("SELECT") for Query in Database.Queries),
                            "Transactions": Database.Transactions, "MaterializedRows": Database.Rows,
                            "CatalogElements": len(Catalog["Elements"]), "CatalogRelations": len(Catalog["Relations"]),
                            "InMemoryTotalMilliseconds": round(Elapsed, 3), "ExpectedCost": Result["MinimumCost"]})
        finally:
            Connection.close()
    return Results


def InspectLimiterAndTests():
    from backend.Auth import RateLimiter
    from fastapi import HTTPException
    Accepted, Blocked = 0, 0
    for Limiter in (RateLimiter(), RateLimiter()):
        for Attempt in range(11):
            try:
                Limiter.Check(("login", "synthetic-client"))
                Accepted += 1
            except HTTPException as Error:
                assert Error.status_code == 429
                Blocked += 1
    Inventory = []
    for File in sorted((Root / "tests/integration").glob("test_*.py")):
        Module = ast.parse(File.read_text(encoding="utf-8-sig"))
        Methods = [Node.name for Node in ast.walk(Module) if isinstance(Node, ast.FunctionDef) and Node.name.startswith("test_")]
        Inventory.append({"IntegrationFile": File.relative_to(Root).as_posix(), "DeclaredTestMethods": len(Methods),
                          "BackupOrRestoreTests": [Name for Name in Methods if any(Word in Name.lower()
                                                   for Word in ("backup", "restore", "restor", "respaldo"))]})
    return {"RateLimiterInstances": 2, "AcceptedForSameClientInOneMinute": Accepted, "Rejected": Blocked,
            "Note": "In-memory demonstration, no HTTP requests"}, Inventory


def Main():
    Parser = argparse.ArgumentParser(description=__doc__)
    Parser.add_argument("--run", action="store_true", help="Explicitly execute the synthetic experiments; print JSON to stdout.")
    Parser.add_argument("--environment", action="store_true", help="Only inspect local machine metadata; no benchmark execution.")
    Arguments = Parser.parse_args()
    if not Arguments.run and not Arguments.environment:
        Parser.print_help()
        return
    Environment = ReadEnvironment()
    if Arguments.environment and not Arguments.run:
        print(json.dumps(Environment, ensure_ascii=False, indent=2))
        return
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(Root))
    sys.path.insert(0, str(Root / "tests/python"))
    Costs = BenchmarkCosts()
    Payloads = BenchmarkPayloads()
    Sql = BenchmarkSql()
    Limiter, Inventory = InspectLimiterAndTests()
    print(json.dumps({"Environment": Environment,
        "Methodology": {"CostsAndPayloads": "Median of 3 runs; no explicit warm-up", "Sql": "One timed run per size; SQLite :memory:",
                        "Json": "Compact UTF-8, ensure_ascii=False", "Gzip": "Level 5, mtime=0", "Network": False,
                        "RealDatabase": False, "ApplicationWrites": False},
        "CostBenchmarks": Costs, "PayloadBenchmarks": Payloads, "SqlBenchmarks": Sql,
        "Limiter": Limiter, "IntegrationInventory": Inventory}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    Main()
