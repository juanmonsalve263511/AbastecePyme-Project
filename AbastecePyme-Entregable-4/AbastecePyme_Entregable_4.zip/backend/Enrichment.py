"""Explicit, one-time catalogue expansion with editable reference values."""
from decimal import Decimal
import hashlib
import json
from backend.Catalog import ElementQuery, ElementRows, ReadRelations, SetSalePrice
from backend.Production import BuildProductionPlan
from backend.Revisions import NextRevision

MigrationId = 'CatalogExpansion20261102'
Suppliers = [
    ('PROV-MADERAS-ANTIOQUIA','Maderas y Tableros de Antioquia','Tableros, madera y complementos para carpintería.'),
    ('PROV-HERRAJES-METRO','Herrajes Metropolitanos','Herrajes, accesorios y herramientas para muebles.'),
    ('PROV-TAPICERIA-OCCIDENTE','Tapicería de Occidente','Textiles, espumas y protectores para tapicería.'),
    ('PROV-ACABADOS-VALLE','Acabados del Valle de Aburrá','Acabados y adhesivos para procesos de ensamble.'),
    ('PROV-SUMINISTROS-ABURRA','Suministros Integrales Aburrá','Materiales y herramientas para la producción de muebles.')
]
Components = [
    ('COMP-ESTRUCTURA','Estructura de madera ensamblada','Base estructural preparada para integrar mesas y estantes.',
     [('INS-MADERA','2'),('INS-TORNILLOS','8')],['PROD-ESTANTE','PROD-MESA','PROD-MESA-COMEDOR'],'120000.00'),
    ('COMP-CAJON','Módulo de cajón completo','Cajón con correderas y tirador listo para integrar al mueble.',
     [('INS-MDF','1'),('INS-CORREDERAS','1'),('INS-TIRADORES','1')],['PROD-ESCRITORIO','PROD-COMODA','PROD-MESA-NOCHE'],'95000.00'),
    ('COMP-PUERTA','Puerta de mueble ensamblada','Puerta preparada con bisagras para la etapa de montaje.',
     [('INS-MELAMINA','1'),('INS-BISAGRAS','2')],['PROD-ARMARIO','PROD-ZAPATERO'],'85000.00')
]
ProductPrices = {
    'PROD-ARMARIO':'1290000.00','PROD-BANCO-RECIBIDOR':'390000.00','PROD-BANCO-TAPIZADO':'490000.00',
    'PROD-BIBLIOTECA':'690000.00','PROD-COMODA':'890000.00','PROD-ESCRITORIO':'790000.00',
    'PROD-ESTANTE':'450000.00','PROD-MESA-CENTRO':'320000.00','PROD-MESA-COMEDOR':'950000.00',
    'PROD-MESA-NOCHE':'280000.00','PROD-MESA':'590000.00','PROD-MUEBLE-TV':'850000.00',
    'PROD-SILLA-COMEDOR':'230000.00','PROD-ZAPATERO':'540000.00'
}

def BuildExpansion(Data):
    Mapping = {Item['ElementId']:Item for Item in Data['Elements']}
    NewIds = {Item[0] for Item in Suppliers+Components}
    if NewIds & Mapping.keys():
        raise ValueError('Un código reservado para la ampliación ya existe; revisa el catálogo antes de continuar.')
    Elements = [{'ElementId':Id,'Name':Name,'ElementType':'Supplier','Description':Description} for Id,Name,Description in Suppliers]
    Edges = []
    Prices = []
    for Item in sorted(Data['Elements'],key=lambda Value:Value['ElementId']):
        if Item['ElementType'] != 'Material':
            continue
        Id = Item['ElementId']
        Offers = [Edge for Edge in Data['Relations'] if Edge['RelationType']=='Offer' and Edge['TargetId']==Id]
        Existing = {Edge['SourceId'] for Edge in Offers}
        if Id in {'INS-MADERA','INS-MDF','INS-MELAMINA','INS-CONTRACHAPADO','INS-CANTO'}:
            Preferred = 'PROV-MADERAS-ANTIOQUIA'
        elif Id in {'INS-TELA','INS-ESPUMA','INS-FIELTRO'}:
            Preferred = 'PROV-TAPICERIA-OCCIDENTE'
        elif Id in {'INS-BARNIZ','INS-COLA'}:
            Preferred = 'PROV-ACABADOS-VALLE'
        else:
            Preferred = 'PROV-HERRAJES-METRO'
        Base = min((Decimal(Edge['Value']) for Edge in Offers),default=Decimal('18000' if 'METRO' in Id else '3500'))
        TargetCount = 3 if Id in {'INS-MADERA','INS-TORNILLOS'} else 2
        for Index, SupplierId in enumerate([Preferred,'PROV-SUMINISTROS-ABURRA']):
            if len(Existing) >= TargetCount:
                break
            if SupplierId in Existing:
                continue
            Price = (Base*Decimal('1.08' if Index==0 else '0.96')).quantize(Decimal('0.01'))
            Edges.append({'SourceId':SupplierId,'TargetId':Id,'RelationType':'Offer','Value':str(Price),'IsDemo':True})
            Existing.add(SupplierId)
    for Id,Name,Description,Inputs,Targets,Price in Components:
        Elements.append({'ElementId':Id,'Name':Name,'ElementType':'Product','Description':Description})
        Prices.append({'ElementId':Id,'SalePrice':Price,'IsPriceReference':True})
        for MaterialId,Quantity in Inputs:
            if MaterialId not in Mapping or Mapping[MaterialId]['ElementType']!='Material':
                raise ValueError('Falta un insumo necesario para la ampliación: '+MaterialId)
            Edges.append({'SourceId':MaterialId,'TargetId':Id,'RelationType':'Requirement','Value':Quantity,'IsDemo':True})
        for ProductId in Targets:
            if ProductId in Mapping and Mapping[ProductId]['ElementType']=='Product':
                Edges.append({'SourceId':Id,'TargetId':ProductId,'RelationType':'General','Value':None,'IsDemo':False})
    for Item in Data['Elements']:
        if Item['ElementType']=='Product' and Item.get('SalePrice') is None:
            Prices.append({'ElementId':Item['ElementId'],'SalePrice':ProductPrices.get(Item['ElementId'],'350000.00'),'IsPriceReference':True})
    Plan = BuildProductionPlan(Data['Elements']+Elements,Data['Relations']+Edges)
    if Plan['Status']=='Cycle':
        raise ValueError('La red contiene un ciclo; revisa sus dependencias antes de ampliar el catálogo.')
    return {'Elements':Elements,'Relations':Edges,'Prices':Prices}

def ApplyExpansion(Database):
    with Database.Transaction() as Connection:
        # Serialize with ordinary catalogue writes before inspecting the marker.
        Connection.execute('SELECT CurrentValue FROM RevisionClock WHERE ClockId=1 FOR UPDATE').fetchone()
        if Connection.execute('SELECT MigrationId FROM Migrations WHERE MigrationId=?',MigrationId).fetchone():
            return {'Applied':False,'Reason':'AlreadyApplied'}
        Data = {'Elements':ElementRows(Connection.execute(ElementQuery)),'Relations':ReadRelations(Connection)}
        Plan = BuildExpansion(Data)
        Revision = NextRevision(Connection)
        for Item in Plan['Elements']:
            Connection.execute('INSERT INTO Elements(ElementId,Name,ElementType,Description,Version) VALUES (?,?,?,?,?)',
                               Item['ElementId'],Item['Name'],Item['ElementType'],Item['Description'],Revision)
            Table = 'Suppliers' if Item['ElementType']=='Supplier' else 'Products'
            Connection.execute(f'INSERT INTO {Table}(ElementId) VALUES (?)',Item['ElementId'])
        Touched = set()
        for Edge in Plan['Relations']:
            if Edge['RelationType']=='General':
                Connection.execute('INSERT INTO GeneralDependencies(SourceId,TargetId,Version) VALUES (?,?,?)',Edge['SourceId'],Edge['TargetId'],Revision)
            else:
                Table,Left,Right,Weight = ('SupplierOffers','SupplierId','MaterialId','UnitPrice') if Edge['RelationType']=='Offer' else ('ProductRequirements','MaterialId','ProductId','Quantity')
                Connection.execute(f'INSERT INTO {Table}({Left},{Right},{Weight},IsDemo,Version) VALUES (?,?,?,?,?)',
                                   Edge['SourceId'],Edge['TargetId'],Edge['Value'],1,Revision)
            Touched.update((Edge['SourceId'],Edge['TargetId']))
        for Price in Plan['Prices']:
            SetSalePrice(Connection,Price['ElementId'],Price['SalePrice'],Price['IsPriceReference'])
            Touched.add(Price['ElementId'])
        for Id in sorted(Touched):
            Connection.execute('UPDATE Elements SET Version=? WHERE ElementId=?',Revision,Id)
        Digest = hashlib.sha256(json.dumps(Plan,sort_keys=True).encode()).hexdigest()
        Connection.execute('INSERT INTO Migrations(MigrationId,SourceHash) VALUES (?,?)',MigrationId,Digest)
        return {'Applied':True,'ElementsAdded':len(Plan['Elements']),'RelationsAdded':len(Plan['Relations']),'PricesAdded':len(Plan['Prices'])}
