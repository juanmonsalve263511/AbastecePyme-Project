import unittest
from fastapi import HTTPException
from pydantic import ValidationError
from backend.Catalog import CreateElement, EditElement, ReadCatalogue, DeleteElement
from backend.Models import ElementCreate, ElementEdit
from test_feature3_api import SqlAdapter


class SalePriceTests(unittest.TestCase):
    def setUp(self):
        self.Database = SqlAdapter()
        self.addCleanup(self.Database.Connection.close)
        self.Database.Connection.executescript('''
            PRAGMA foreign_keys=ON;
            CREATE TABLE RevisionClock(ClockId INTEGER PRIMARY KEY,CurrentValue INTEGER);
            INSERT INTO RevisionClock VALUES(1,1);
            CREATE TABLE Elements(ElementId TEXT PRIMARY KEY,Name TEXT,ElementType TEXT,Description TEXT,Version INTEGER);
            CREATE TABLE Suppliers(ElementId TEXT PRIMARY KEY,Contact TEXT);
            CREATE TABLE Materials(ElementId TEXT PRIMARY KEY,UnitCode TEXT);
            CREATE TABLE Products(ElementId TEXT PRIMARY KEY REFERENCES Elements(ElementId));
            CREATE TABLE ProductPrices(ElementId TEXT PRIMARY KEY REFERENCES Products(ElementId),SalePrice TEXT,IsPriceReference INTEGER);
            CREATE TABLE SupplierOffers(SupplierId TEXT,MaterialId TEXT,UnitPrice TEXT,IsDemo INTEGER,Version INTEGER);
            CREATE TABLE ProductRequirements(MaterialId TEXT,ProductId TEXT,Quantity TEXT,IsDemo INTEGER,Version INTEGER);
            CREATE TABLE GeneralDependencies(SourceId TEXT,TargetId TEXT,Version INTEGER);
        ''')

    def Product(self, **Fields):
        return CreateElement(self.Database, ElementCreate(ElementId='PROD-TEST',Name='Test product',ElementType='Product',**Fields))

    def test_exact_sale_price_round_trip_and_zero(self):
        Item = self.Product(SalePrice='9999999999999999.99',IsPriceReference=True)
        self.assertEqual(Item['SalePrice'],'9999999999999999.99')
        self.assertIs(Item['IsPriceReference'],True)
        Item = EditElement(self.Database,Item['ElementId'],ElementEdit(Version=Item['Version'],SalePrice='0',IsPriceReference=False))
        self.assertEqual(Item['SalePrice'],'0.00')
        self.assertIs(Item['IsPriceReference'],False)
        self.assertEqual(ReadCatalogue(self.Database)['Elements'][0]['SalePrice'],'0.00')

    def test_omission_preserves_price_but_explicit_null_clears_it(self):
        Item = self.Product(SalePrice='250000.50')
        Item = EditElement(self.Database,Item['ElementId'],ElementEdit(Version=Item['Version'],Name='Renamed product'))
        self.assertEqual(Item['SalePrice'],'250000.50')
        Item = EditElement(self.Database,Item['ElementId'],ElementEdit(Version=Item['Version'],SalePrice=None))
        self.assertIsNone(Item['SalePrice'])

    def test_reference_flag_edit_and_stale_price_revision(self):
        Item = self.Product(SalePrice='100')
        Edited = EditElement(self.Database,Item['ElementId'],ElementEdit(Version=Item['Version'],IsPriceReference=False))
        self.assertEqual(Edited['SalePrice'],'100.00')
        self.assertIs(Edited['IsPriceReference'],False)
        with self.assertRaises(HTTPException) as Failure:
            EditElement(self.Database,Item['ElementId'],ElementEdit(Version=Item['Version'],SalePrice='200'))
        self.assertEqual(Failure.exception.status_code,409)
        self.assertEqual(ReadCatalogue(self.Database)['Elements'][0]['SalePrice'],'100.00')

    def test_price_validation_and_nonproduct_rejection(self):
        for Value in ['-1','NaN','Infinity','1.001','10000000000000000',1.5,True]:
            with self.subTest(Value=Value), self.assertRaises(ValidationError):
                ElementCreate(ElementId='PP',Name='Product',ElementType='Product',SalePrice=Value)
        with self.assertRaises(ValidationError):
            ElementCreate(ElementId='MM',Name='Material',ElementType='Material',SalePrice='50')
        Item=CreateElement(self.Database,ElementCreate(ElementId='MM',Name='Material',ElementType='Material'))
        with self.assertRaises(HTTPException) as Failure:
            EditElement(self.Database,'MM',ElementEdit(Version=Item['Version'],SalePrice='50'))
        self.assertEqual(Failure.exception.status_code,422)
        self.assertEqual(ReadCatalogue(self.Database)['Elements'][0]['Version'],Item['Version'])

    def test_product_without_price_and_deletion_remove_price_row(self):
        Item=self.Product()
        self.assertIsNone(Item['SalePrice'])
        Item=EditElement(self.Database,Item['ElementId'],ElementEdit(Version=Item['Version'],SalePrice='500'))
        DeleteElement(self.Database,Item['ElementId'],Item['Version'])
        self.assertEqual(ReadCatalogue(self.Database)['Elements'],[])
        self.assertEqual(self.Database.execute('SELECT COUNT(*) FROM ProductPrices').fetchone()[0],0)
