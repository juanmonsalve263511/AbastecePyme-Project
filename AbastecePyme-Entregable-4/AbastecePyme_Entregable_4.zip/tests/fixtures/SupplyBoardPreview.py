"""Disposable browser acceptance server. All data lives in SQLite memory.

Run explicitly with Python from the project root. This is not the MariaDB
launcher: its synthetic account is for this loopback-only preview exclusively.
"""
import argparse
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
import sqlite3
import sys
import threading

Root = Path(__file__).resolve().parents[2]
if str(Root) not in sys.path:
    sys.path.insert(0, str(Root))

from backend import Auth
from backend.Catalog import CreateElement
from backend.Main import CreateApp
from backend.Models import ElementCreate, RelationCreate
from backend.Relations import ChangeRelation

PreviewUsername = "demo_editor"
PreviewPassword = "Feature4-Demo-Only!2026"


class PreviewDatabase:
    def __init__(self):
        self.Lock = threading.RLock()
        self.Connection = sqlite3.connect(":memory:", check_same_thread=False)
        self.Connection.executescript("""
            PRAGMA foreign_keys = ON;
            CREATE TABLE RevisionClock(ClockId INT PRIMARY KEY, CurrentValue INT);
            INSERT INTO RevisionClock VALUES(1,1);
            CREATE TABLE Elements(ElementId TEXT PRIMARY KEY,Name TEXT,ElementType TEXT,Description TEXT,Version INT);
            CREATE TABLE Suppliers(ElementId TEXT PRIMARY KEY,Contact TEXT);
            CREATE TABLE Materials(ElementId TEXT PRIMARY KEY,UnitCode TEXT);
            CREATE TABLE Products(ElementId TEXT PRIMARY KEY);
            CREATE TABLE ProductPrices(ElementId TEXT PRIMARY KEY,SalePrice TEXT,IsPriceReference INT);
            CREATE TABLE SupplierOffers(SupplierId TEXT,MaterialId TEXT,UnitPrice TEXT,IsDemo INT,Version INT,PRIMARY KEY(SupplierId,MaterialId));
            CREATE TABLE ProductRequirements(MaterialId TEXT,ProductId TEXT,Quantity TEXT,IsDemo INT,Version INT,PRIMARY KEY(MaterialId,ProductId));
            CREATE TABLE GeneralDependencies(SourceId TEXT,TargetId TEXT,Version INT,PRIMARY KEY(SourceId,TargetId));
            CREATE TABLE Users(UserId TEXT PRIMARY KEY,Username TEXT UNIQUE,DisplayName TEXT,Email TEXT DEFAULT '',PasswordHash TEXT,RoleId TEXT,IsActive INT DEFAULT 1,Version INT DEFAULT 1);
            CREATE TABLE Sessions(TokenHash TEXT PRIMARY KEY,UserId TEXT,CsrfToken TEXT,ExpiresAt TEXT);
            CREATE TABLE UserGraphLayouts(UserId TEXT NOT NULL,LayoutKey TEXT NOT NULL,PositionsJson TEXT NOT NULL,
                PRIMARY KEY(UserId,LayoutKey),FOREIGN KEY(UserId) REFERENCES Users(UserId) ON DELETE CASCADE);
            CREATE TABLE NewsletterSubscriptions(Email TEXT PRIMARY KEY,ConsentVersion TEXT,CreatedAt TEXT DEFAULT CURRENT_TIMESTAMP);
            CREATE TABLE ContactRequests(RequestId TEXT PRIMARY KEY,FullName TEXT,Email TEXT,Phone TEXT,Company TEXT,Subject TEXT,Message TEXT,ConsentVersion TEXT,CreatedAt TEXT,ReadAt TEXT);
        """)

    @contextmanager
    def Transaction(self):
        with self.Lock:
            try:
                yield self
                self.Connection.commit()
            except BaseException:
                self.Connection.rollback()
                raise

    def execute(self, Query, *Arguments):
        Sql = Query.replace(" FOR UPDATE", "").replace("UTC_TIMESTAMP()", "CURRENT_TIMESTAMP")
        Sql = Sql.replace("INSERT IGNORE", "INSERT OR IGNORE")
        Sql = Sql.replace("ON DUPLICATE KEY UPDATE PositionsJson=VALUES(PositionsJson)",
                          "ON CONFLICT(UserId,LayoutKey) DO UPDATE SET PositionsJson=excluded.PositionsJson")
        Parameters = tuple(Value.isoformat(" ") if isinstance(Value, datetime) else Value for Value in Arguments)
        return self.Connection.execute(Sql, Parameters)

    def Close(self):
        self.Connection.close()


def CreatePreviewDatabase():
    Database = PreviewDatabase()
    for ElementId, Name, ElementType in [
        ("PROV-NORTE", "Maderas del Norte", "Supplier"),
        ("INS-TABLERO", "Tablero de madera", "Material"),
        ("PROD-PANEL", "Panel preparado", "Product"),
        ("PROD-ESTANTE", "Estante modular", "Product"),
        ("PROD-AISLADO", "Producto independiente", "Product"),
    ]:
        CreateElement(Database, ElementCreate(ElementId=ElementId, Name=Name, ElementType=ElementType,
                                              Description="Conjunto sintético para aceptación de Feature 4."))
    for SourceId, TargetId, Value in [
        ("PROV-NORTE", "INS-TABLERO", "35000.00"),
        ("INS-TABLERO", "PROD-PANEL", "2.0000"),
    ]:
        ChangeRelation(Database, RelationCreate(SourceId=SourceId, TargetId=TargetId, Value=Value, IsDemo=True), "create")
    Auth.CreateUser(Database, PreviewUsername, "Equipo de demostración", PreviewPassword, "Editor")
    return Database


def Main():
    Parser = argparse.ArgumentParser(description=__doc__)
    Parser.add_argument("--port", type=int, default=3014)
    Arguments = Parser.parse_args()
    if not 1024 <= Arguments.port <= 65535:
        Parser.error("El puerto debe estar entre 1024 y 65535.")
    import uvicorn
    Database = CreatePreviewDatabase()
    print(f"Demostración aislada: http://127.0.0.1:{Arguments.port}/ — datos sintéticos en memoria.", flush=True)
    print("La cuenta de prueba está documentada en docs/FEATURE4_VIDEO.md. No se conecta a MariaDB.", flush=True)
    try:
        uvicorn.run(CreateApp(Database, Arguments.port), host="127.0.0.1", port=Arguments.port,
                    access_log=False, proxy_headers=False, log_level="warning")
    finally:
        Database.Close()


if __name__ == "__main__":
    Main()
