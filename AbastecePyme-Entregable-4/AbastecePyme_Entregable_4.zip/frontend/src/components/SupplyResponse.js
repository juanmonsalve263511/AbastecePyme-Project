// Resolve shared response records without running any graph analysis in the client.
export function ExpandSupplyResponse(Result){
  if(Result.ResponseFormat!=='Compact')return Result;
  const Lookup=new Map(Result.Catalog.Elements.map(Item=>[Item.ElementId,Item]));
  function ExpandGraph(Graph){return {Elements:Graph.ElementIds.map(Id=>Lookup.get(Id)),Relations:Graph.Relations};}
  function ExpandScenario(Scenario){
    const {Impact,Production}=Scenario;
    return {Impact:{...Impact,Reached:Impact.Visited.slice(1),Graph:ExpandGraph(Impact.Graph)},
      Production:{...Production,Graph:ExpandGraph(Production.Graph)}};
  }
  const Base=ExpandScenario(Result.Base);
  return {...Result,Base,Scenario:Result.Scenario?ExpandScenario(Result.Scenario):Base};
}

export function GetImpactPath(Visited,SelectedId){
  const Selected=Visited.get(SelectedId);
  if(!Selected)return [];
  if(Array.isArray(Selected.Path))return Selected.Path;
  // Python has already selected one predecessor per node. Format that one chain
  // only when requested, instead of materializing every possible display path.
  const Path=[];
  let Current=Selected,ExpectedDepth=Selected.Depth;
  while(Current&&Path.length<Visited.size){
    if(Current.Depth!==ExpectedDepth)return [];
    Path.push(Current.ElementId);
    if(Current.ParentId===null)return ExpectedDepth===0?Path.reverse():[];
    ExpectedDepth-=1;
    Current=Visited.get(Current.ParentId);
  }
  return [];
}
