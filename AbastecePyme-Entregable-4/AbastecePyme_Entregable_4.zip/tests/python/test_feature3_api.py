"""Real HTTP/auth/model behavior, using an isolated SQLite SQL adapter only."""
from contextlib import contextmanager
import sqlite3
import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
from backend.Main import CreateApp
from backend.Auth import Hasher, HashToken, VerifyPassword
from test_production import Element, Edge


class SqlAdapter:
    def __init__(self):
        self.Connection = sqlite3.connect(":memory:", check_same_thread=False)
        self.Connection.executescript("""
            CREATE TABLE Users(UserId TEXT PRIMARY KEY, Username TEXT UNIQUE, DisplayName TEXT,
                Email TEXT DEFAULT '', PasswordHash TEXT, RoleId TEXT, IsActive INT DEFAULT 1,
                Version INT DEFAULT 1);
            CREATE TABLE Sessions(TokenHash TEXT PRIMARY KEY,UserId TEXT,CsrfToken TEXT,ExpiresAt TEXT);
            CREATE TABLE UserGraphLayouts(UserId TEXT NOT NULL,LayoutKey TEXT NOT NULL,PositionsJson TEXT NOT NULL,
                PRIMARY KEY(UserId,LayoutKey),FOREIGN KEY(UserId) REFERENCES Users(UserId) ON DELETE CASCADE);
            CREATE TABLE NewsletterSubscriptions(Email TEXT PRIMARY KEY,ConsentVersion TEXT,
                CreatedAt TEXT DEFAULT CURRENT_TIMESTAMP);
        """)

    @contextmanager
    def Transaction(self):
        try:
            yield self
            self.Connection.commit()
        except Exception:
            self.Connection.rollback()
            raise

    def execute(self, Query, *Args):
        Query = Query.replace("UTC_TIMESTAMP()", "CURRENT_TIMESTAMP").replace(" FOR UPDATE", "")
        Query = Query.replace("INSERT IGNORE", "INSERT OR IGNORE")
        Query = Query.replace("ON DUPLICATE KEY UPDATE PositionsJson=VALUES(PositionsJson)",
                              "ON CONFLICT(UserId,LayoutKey) DO UPDATE SET PositionsJson=excluded.PositionsJson")
        return self.Connection.execute(Query, Args)


class Feature3ApiTests(unittest.TestCase):
    def setUp(self):
        self.Database = SqlAdapter()
        self.App = CreateApp(self.Database)
        self.Client = TestClient(self.App, base_url="http://127.0.0.1:3000")
        self.addCleanup(self.Client.close)
        self.addCleanup(self.Database.Connection.close)
        self.Data = {"Elements": [Element("AA"), Element("BB")], "Relations": [Edge("AA", "BB")]}
        self.Catalog = patch("backend.Catalog.ReadCatalogue", return_value=self.Data)
        self.Catalog.start()
        self.addCleanup(self.Catalog.stop)

    def Authenticate(self, Role="Administrator"):
        self.Database.execute("INSERT INTO Users(UserId,Username,DisplayName,PasswordHash,RoleId) VALUES (?,?,?,?,?)",
                              "actor", "actor", "Test actor", Hasher.hash("OnlyAnEphemeralTest123!"), Role)
        self.Database.execute("INSERT INTO Sessions(TokenHash,UserId,CsrfToken,ExpiresAt) VALUES (?,?,?,?)",
                              HashToken("a" * 64), "actor", "csrf-test", "2099-01-01")
        self.Client.cookies.set("AbasteceSession", "a" * 64)
        self.Client.headers.update({"Origin": "http://127.0.0.1:3000", "X-CSRF-Token": "csrf-test"})

    def NewAccount(self):
        return {"Username": "new_colleague", "DisplayName": "New Colleague",
                "Password": "EphemeralAccount123!", "RoleName": "Editor", "Email": "team@example.com"}

    def test_public_registration_is_not_a_creation_endpoint(self):
        Response = self.Client.post("/api/auth/register", json=self.NewAccount(), headers={"Origin": "http://127.0.0.1:3000"})
        self.assertEqual(Response.status_code, 404)
        self.assertEqual(self.Database.execute("SELECT COUNT(*) FROM Users").fetchone()[0], 0)

    def test_admin_creates_user_with_hash_and_keeps_own_session(self):
        self.Authenticate()
        Response = self.Client.post("/api/users", json=self.NewAccount())
        self.assertEqual(Response.status_code, 201, Response.text)
        self.assertEqual(Response.json()["RoleName"], "Editor")
        self.assertEqual(Response.json()["Email"], "team@example.com")
        self.assertNotIn("PasswordHash", Response.json())
        Stored = self.Database.execute("SELECT PasswordHash FROM Users WHERE Username=?", "new_colleague").fetchone()[0]
        self.assertTrue(VerifyPassword(Stored, "EphemeralAccount123!"))
        self.assertNotEqual(Stored, "EphemeralAccount123!")
        self.assertEqual(self.Client.get("/api/auth/session").json()["UserId"], "actor")
        self.Client.cookies.clear()
        Login = self.Client.post("/api/auth/login", json={"Username": "new_colleague", "Password": "EphemeralAccount123!"})
        self.assertEqual(Login.status_code, 200, Login.text)
        self.assertEqual(Login.json()["RoleName"], "Editor")

    def test_viewer_and_editor_cannot_create_accounts(self):
        self.Authenticate("Viewer")
        for Role in ["Viewer", "Editor"]:
            self.Database.execute("UPDATE Users SET RoleId=? WHERE UserId='actor'", Role)
            self.assertEqual(self.Client.post("/api/users", json=self.NewAccount()).status_code, 403)

    def test_admin_creation_requires_csrf_and_valid_fields(self):
        self.Authenticate()
        self.assertEqual(self.Client.post("/api/users", json=self.NewAccount(), headers={"X-CSRF-Token": "wrong"}).status_code, 403)
        for Change in [{"RoleName": "Root"}, {"Password": "short"}, {"Email": "bad"}, {"DisplayName": "   "}]:
            self.assertEqual(self.Client.post("/api/users", json={**self.NewAccount(), **Change}).status_code, 422)

    def test_production_requires_login_and_uses_fresh_catalogue(self):
        self.assertEqual(self.Client.get("/api/production").status_code, 401)
        self.Authenticate("Viewer")
        self.assertEqual(self.Client.get("/api/production").json()["Order"], ["AA", "BB"])
        self.Data["Relations"].append(Edge("BB", "AA"))
        Result = self.Client.get("/api/production").json()
        self.assertEqual(Result["Status"], "Cycle")
        self.assertEqual(Result["Order"], [])
        self.assertEqual(self.Client.get("/api/production?ProductId=UNKNOWN").status_code, 404)
        self.assertEqual(self.Client.get("/api/production?ProductId=bad!").status_code, 422)

    def test_newsletter_requires_email_consent_and_is_idempotent(self):
        self.Client.headers.update({"Origin": "http://127.0.0.1:3000"})
        for Body in [{"Email": "bad", "Consent": True}, {"Email": "a@example.com", "Consent": False}, {"Email": "a@example.com"}]:
            self.assertEqual(self.Client.post("/api/subscriptions", json=Body).status_code, 422)
        for Email in ["Team@Example.com", " team@example.com "]:
            Response = self.Client.post("/api/subscriptions", json={"Email": Email, "Consent": True})
            self.assertEqual(Response.status_code, 200, Response.text)
        self.assertEqual(self.Database.execute("SELECT COUNT(*) FROM NewsletterSubscriptions").fetchone()[0], 1)
        self.assertEqual(self.Database.execute("SELECT Email FROM NewsletterSubscriptions").fetchone()[0], "team@example.com")
        self.assertEqual(self.Client.post("/api/subscriptions", json={"Email": "a@example.com", "Consent": True}, headers={"Origin": "https://example.com"}).status_code, 403)

    def test_catalogue_writes_reject_viewers_and_missing_csrf(self):
        self.Authenticate("Viewer")
        Body = {"ElementId": "NEW", "Name": "New product", "ElementType": "Product"}
        self.assertEqual(self.Client.post("/api/elements", json=Body).status_code, 403)
        self.Database.execute("UPDATE Users SET RoleId='Editor' WHERE UserId='actor'")
        self.assertEqual(self.Client.post("/api/elements", json=Body, headers={"X-CSRF-Token": "wrong"}).status_code, 403)
