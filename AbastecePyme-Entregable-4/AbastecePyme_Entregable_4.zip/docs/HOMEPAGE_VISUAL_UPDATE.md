# Imágenes de portada y datos de contacto

Actualización: 3 de noviembre de 2026.

Se sustituyó la ilustración de montañas en «Una mirada local» por una escena de planificación de mobiliario. La tarjeta de ubicación de la portada incorpora una vista urbana conceptual inspirada en Medellín. No es una fotografía documental de One Plaza. Ambas imágenes usan las apariciones y el desplazamiento suave existentes y respetan el movimiento reducido.

El teléfono visible ahora es **+57 311 335 2866** y su tamaño principal pasa de 26 a 22 px. El enlace de llamadas conserva `tel:+573113352866`.

Las notificaciones por correo se aplazaron por decisión del propietario. No se configuró SMTP ni se modificó el almacenamiento del formulario.

## Recursos incluidos

- `frontend/public/images/production-team-{640,960,1536}.webp`: escena del equipo de diseño y planificación.
- `frontend/public/images/medellin-business-{640,960,1536}.webp`: vista urbana de acompañamiento para la ubicación. Desde la revisión del 6 de noviembre de 2026, el navegador elige entre estas variantes según la pantalla.

Imágenes nuevas generadas mediante la herramienta integrada **imagegen**, sin fotografías de referencia ni CLI. Se conservan los originales y se incluyen copias en el proyecto. La imagen urbana es conceptual y la escena de trabajo no documenta empleados o instalaciones reales.

## Prompts utilizados

### Equipo de producción

Generate a premium editorial business photograph for AbastecePyme, a Colombian small-business supply and production planning platform. Landscape 1536x1024. A credible contemporary furniture design studio in Medellin, seen diagonally across a broad oak planning table. Two Colombian adult colleagues, a woman operations planner and a man furniture designer in tasteful slate-blue and charcoal workwear, collaborate over precise paper assembly drawings (no readable words), small wood and textile swatches, a well-made small furniture model and an unbranded closed laptop. Their faces natural, unposed, focused on practical work, physically correct hands. Tall windows with softly blurred green mountains and brick city background; tidy shelving, pale concrete, soft daylight. Commercial editorial photography, elegant but attainable small enterprise, compelling composition, rich oak and pale blue/navy/gray palette, room to breathe, detailed tactile materials, realistic rather than glossy stock-photo handshake. All key subjects comfortably inside the central 80% for responsive cropping. No logos, text overlays, typography, watermarks, grids, collages, or rounded borders. Conceptual image, not a claim to represent actual company employees or premises.

### Vista urbana

Generate a premium architectural editorial photograph-like image, landscape 1536x1024, for the location section of a Colombian B2B business website AbastecePyme. A sophisticated urban view inspired by El Poblado in Medellin: elevated eye-level view over a leafy avenue and a harmonious arrangement of modern glass business buildings and warm brick mid-rise architecture nestled in a lush green Andean valley, layered mountains softly visible in the distance, gentle morning sunlight, calm blue-gray sky, clean architectural lines. Sophisticated navy blue reflections, pale blue, soft gray, vibrant but restrained greens, excellent depth and natural realism. Horizontal composition suitable for a shallow website card banner; important buildings and mountains within middle band, no extreme skyscrapers, no skyline fantasy, no recognizable copyrighted building design copied, no logos, no text, no people close up, no watermarks, no illustration or infographic, no UI. This is a conceptual Medellin city scene, NOT a documentary photograph of One Plaza or of a specific office.

## Comprobaciones

Compilación de producción correcta, recursos servidos por el servidor local con HTTP 200, revisión visual de las dos secciones, tamaño de teléfono de 22 px y animación EditorialDrift en las imágenes. Se conserva la alternativa de movimiento reducido.

