export const GraphLayoutKeys=Object.freeze(['Graph','Impact','Production','SupplyBoard']);
const IdPattern=/^[A-Z][A-Z0-9_-]{1,39}$/;
let ChangeCounter=0;
function NewChangeId(){return globalThis.crypto?.randomUUID?.()||Date.now().toString(36)+'-'+(++ChangeCounter)+'-'+Math.random().toString(36).slice(2);}

export function NormalizeLayoutPayload(Value){
  if(!Value||!Array.isArray(Value.Positions)||Value.Positions.length>1000)throw new Error('La distribución admite hasta 1000 nodos movidos.');
  const Seen=new Set(),Positions=[];
  for(const Item of Value.Positions){
    if(!Item||typeof Item.ElementId!=='string'||!IdPattern.test(Item.ElementId)||Seen.has(Item.ElementId)||typeof Item.X!=='number'||typeof Item.Y!=='number'||!Number.isFinite(Item.X)||!Number.isFinite(Item.Y)||Math.abs(Item.X)>1e6||Math.abs(Item.Y)>1e6)throw new Error('La distribución contiene un nodo o una posición no válida.');
    Seen.add(Item.ElementId);Positions.push({ElementId:Item.ElementId,X:Item.X,Y:Item.Y});
  }
  Positions.sort((A,B)=>A.ElementId===B.ElementId?0:A.ElementId<B.ElementId?-1:1);
  return {Positions};
}
function ToMap(Body){return new Map(Body.Positions.map(({ElementId,X,Y})=>[ElementId,{X,Y}]));}
function FromMap(Positions){return NormalizeLayoutPayload({Positions:[...Positions].map(([ElementId,Point])=>({ElementId,X:Point?.X,Y:Point?.Y}))});}
export function LayoutDraftKey(UserId,LayoutKey){
  if(!GraphLayoutKeys.includes(LayoutKey)||typeof UserId!=='string'||!UserId)throw new Error('Vista de distribución inválida.');
  return 'AbastecePyme.GraphLayoutDraft.v1.'+encodeURIComponent(UserId)+'.'+LayoutKey;
}

export class GraphLayoutStore{
  constructor({UserId,Request,Storage}){
    LayoutDraftKey(UserId,'Graph');
    this.UserId=UserId;this.Request=Request;this.Storage=Storage;this.Entries=new Map();this.Closed=false;
  }
  Entry(Key){
    LayoutDraftKey(this.UserId,Key);
    if(!this.Entries.has(Key))this.Entries.set(Key,{Ready:false,Positions:new Map(),Body:{Positions:[]},Status:'Loading',Error:'',Pending:false,Revision:0,ChangeId:'',DraftStored:false,Listeners:new Set(),LoadTask:null,WriteTask:null,LoadController:null,WriteController:null,Snapshot:null});
    return this.Entries.get(Key);
  }
  GetSnapshot(Key){
    const Entry=this.Entry(Key);
    Entry.Snapshot??={Ready:Entry.Ready,Positions:Entry.Positions,Status:Entry.Status,Error:Entry.Error,CanRetry:Entry.Status==='Error'&&(!Entry.Ready||Entry.Pending)};
    return Entry.Snapshot;
  }
  Publish(Key,Entry){Entry.Snapshot=null;this.GetSnapshot(Key);for(const Listener of Entry.Listeners)Listener();}
  Subscribe(Key,Listener){const Entry=this.Entry(Key);Entry.Listeners.add(Listener);return()=>Entry.Listeners.delete(Listener);}
  ReadDraft(Key){
    const Name=LayoutDraftKey(this.UserId,Key);
    try{
      const Text=this.Storage?.getItem(Name);if(!Text)return null;
      const Value=JSON.parse(Text);
      if(Value.Version!==1||Value.UserId!==this.UserId||Value.LayoutKey!==Key||typeof Value.ChangeId!=='string'||!Value.ChangeId)throw new Error('Invalid draft');
      return {...NormalizeLayoutPayload(Value),ChangeId:Value.ChangeId};
    }catch{
      try{this.Storage?.removeItem(Name);}catch{/* The server remains available when browser storage is disabled. */}
      return null;
    }
  }
  WriteDraft(Key,Entry){
    try{
      if(!this.Storage)return false;
      this.Storage.setItem(LayoutDraftKey(this.UserId,Key),JSON.stringify({Version:1,UserId:this.UserId,LayoutKey:Key,ChangeId:Entry.ChangeId,...Entry.Body}));
      return true;
    }catch{return false;}
  }
  ClearDraft(Key,ChangeId){
    try{
      const Name=LayoutDraftKey(this.UserId,Key),Draft=JSON.parse(this.Storage?.getItem(Name)||'null');
      if(Draft?.Version===1&&Draft.UserId===this.UserId&&Draft.LayoutKey===Key&&Draft.ChangeId===ChangeId)this.Storage.removeItem(Name);
    }catch{/* Never remove a newer or unreadable draft on an older acknowledgement. */}
  }
  Load(Key){
    const Entry=this.Entry(Key);
    if(this.Closed||Entry.Ready)return Promise.resolve();
    if(Entry.LoadTask)return Entry.LoadTask;
    const Draft=this.ReadDraft(Key);
    if(Draft){Entry.Body={Positions:Draft.Positions};Entry.Positions=ToMap(Entry.Body);Entry.Pending=true;Entry.ChangeId=Draft.ChangeId;Entry.Revision+=1;Entry.DraftStored=true;}
    Entry.Status='Loading';Entry.Error='';Entry.LoadController=new AbortController();this.Publish(Key,Entry);
    Entry.LoadTask=(async()=>{
      try{
        const Response=await this.Request(Key,{method:'GET',signal:Entry.LoadController.signal});
        if(this.Closed)return;
        const Body=NormalizeLayoutPayload(Response);
        if(!Entry.Pending&&JSON.stringify(Body)!==JSON.stringify(Entry.Body)){Entry.Body=Body;Entry.Positions=ToMap(Body);}
        Entry.Ready=true;Entry.Status=Entry.Pending?'Saving':'Saved';Entry.Error='';this.Publish(Key,Entry);
        if(Entry.Pending)this.Pump(Key);
      }catch(Failure){
        if(this.Closed)return;
        Entry.Status='Error';Entry.Error='No se pudo cargar tu distribución. '+Failure.message;this.Publish(Key,Entry);
      }
    })().finally(()=>{Entry.LoadTask=null;Entry.LoadController=null;});
    return Entry.LoadTask;
  }
  Commit(Key,Positions){
    const Entry=this.Entry(Key);
    if(this.Closed||!Entry.Ready)return false;
    let Body;
    try{Body=FromMap(Positions);}catch(Failure){Entry.Status='Error';Entry.Error=Failure.message;this.Publish(Key,Entry);return false;}
    if(!Entry.Pending&&JSON.stringify(Body)===JSON.stringify(Entry.Body)){if(Entry.Status==='Error'){Entry.Status='Saved';Entry.Error='';this.Publish(Key,Entry);}return true;}
    Entry.Body=Body;Entry.Positions=ToMap(Body);Entry.Revision+=1;Entry.ChangeId=NewChangeId();Entry.Pending=true;Entry.Error='';
    Entry.DraftStored=this.WriteDraft(Key,Entry);Entry.Status='Saving';this.Publish(Key,Entry);this.Pump(Key);return true;
  }
  Pump(Key){
    const Entry=this.Entry(Key);
    if(this.Closed||!Entry.Ready||!Entry.Pending)return Promise.resolve();
    if(Entry.WriteTask)return Entry.WriteTask;
    Entry.WriteTask=(async()=>{
      while(!this.Closed&&Entry.Pending){
        const Revision=Entry.Revision,ChangeId=Entry.ChangeId,Body=Entry.Body;
        Entry.WriteController=new AbortController();Entry.Status='Saving';Entry.Error='';this.Publish(Key,Entry);
        try{
          const Response=await this.Request(Key,{method:'PUT',body:Body,signal:Entry.WriteController.signal});
          if(this.Closed)return;
          const Normalized=NormalizeLayoutPayload(Response);
          if(Entry.Revision===Revision){
            if(JSON.stringify(Normalized)!==JSON.stringify(Entry.Body)){Entry.Positions=ToMap(Normalized);Entry.Body=Normalized;}
            Entry.Pending=false;Entry.Status='Saved';Entry.Error='';this.ClearDraft(Key,ChangeId);this.Publish(Key,Entry);
          }
        }catch(Failure){
          if(this.Closed)return;
          Entry.Status='Error';Entry.Error='No se pudo guardar tu distribución. '+(Entry.DraftStored?'El cambio queda pendiente en este navegador. ':'Mantén esta página abierta para conservar el cambio. ')+Failure.message;
          this.Publish(Key,Entry);break;
        }finally{Entry.WriteController=null;}
      }
    })().finally(()=>{Entry.WriteTask=null;if(!this.Closed&&Entry.Pending&&Entry.Status==='Saving')this.Pump(Key);});
    return Entry.WriteTask;
  }
  Retry(Key){const Entry=this.Entry(Key);return Entry.Ready?this.Pump(Key):this.Load(Key);}
  async Flush(){
    while(!this.Closed){
      const Tasks=[...this.Entries.values()].flatMap(Entry=>[Entry.LoadTask,Entry.WriteTask].filter(Boolean));
      if(!Tasks.length)return;
      await Promise.allSettled(Tasks);
    }
  }
  Dispose(){
    this.Closed=true;
    for(const Entry of this.Entries.values()){Entry.LoadController?.abort();Entry.WriteController?.abort();Entry.Listeners.clear();}
  }
}
