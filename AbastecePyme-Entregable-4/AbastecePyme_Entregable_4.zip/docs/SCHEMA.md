# Modelo relacional de AbastecePyme
Todas las tablas usan InnoDB y utf8mb4. Los identificadores globales de elementos usan ASCII sensible a mayúsculas.
- Elements: ElementId PK, Name, ElementType, Description, Version.
- Suppliers: ElementId PK/FK→Elements, Contact.
- Materials: ElementId PK/FK→Elements, UnitCode.
- Products: ElementId PK/FK→Elements.
- ProductPrices: ElementId PK/FK→Products; SalePrice DECIMAL(18,2)>=0, IsPriceReference BOOLEAN. Conserva el precio manual anterior para compatibilidad API. Sin fila significa que ese precio manual no está definido. Usa la versión de Elements y se elimina junto al producto; no almacena el precio calculado del 16 de noviembre.
- SupplierOffers: SupplierId+MaterialId PK y FKs→subtipos; UnitPrice DECIMAL(18,2)>=0, CurrencyCode COP, IsDemo, Version.
- ProductRequirements: MaterialId+ProductId PK y FKs→subtipos; Quantity DECIMAL(18,4)>0, IsDemo, Version.
- GeneralDependencies: SourceId+TargetId PK y FKs→Elements, Version.
- Roles: RoleId PK (Administrator,Editor,Viewer).
- Users: UUID UserId PK; Username único, DisplayName, Email, PasswordHash, RoleId FK, IsActive, Version, CreatedAt.
- Sessions: TokenHash PK SHA256 de token aleatorio, UserId FK, CsrfToken, ExpiresAt.
- UserGraphLayouts: PK compuesta UserId + LayoutKey; UserId CHAR(36) FK→Users con ON DELETE CASCADE, LayoutKey VARCHAR(20) ASCII sensible a mayúsculas, PositionsJson MEDIUMTEXT. Guarda coordenadas visuales por usuario y sección, con claves Graph, Impact, Production y SupplyBoard. No contiene contraseñas, sesiones o datos de costos. No consume versiones de RevisionClock.
- ContactRequests: RequestId CHAR(36) PK; FullName VARCHAR(80), Email VARCHAR(254), Phone VARCHAR(25), Company VARCHAR(100), Subject VARCHAR(80), Message VARCHAR(2000), ConsentVersion VARCHAR(20), CreatedAt DATETIME y ReadAt DATETIME nullable. Phone y Company admiten cadena vacía; los demás campos de captura y CreatedAt son obligatorios. Índice compuesto (CreatedAt, RequestId) para ordenar y paginar las solicitudes. La API permite consultar y marcar como leído únicamente al Administrador; no envía respuestas por correo.
- Migrations: MigrationId PK, SourceHash y AppliedAt.

El DDL ejecutable está en backend/Schema.py. CREATE TABLE es idempotente; no se utiliza CREATE OR REPLACE ni se borran tablas.
Para una instalación previa completa, añadir `UserGraphLayouts` valida primero la huella de la semilla y crea sólo esta tabla, sin ejecutar la importación ni actualizar el catálogo. El arranque siguiente vuelve al camino de sólo lectura. [Uso del guardado por cuenta](USER_GRAPH_LAYOUTS_2026-11-16.md).
MariaDB confirma DDL implícitamente: la creación del esquema y la transacción de importación son etapas separadas. Una importación parcial se revierte, aunque el esquema vacío puede permanecer.
Las altas de elementos insertan base y subtipo en una transacción. Las bajas eliminan relaciones, subtipo y elemento de forma atómica. Los IDs y tipos son estables.


RevisionClock: tabla técnica añadida durante revisión; ClockId PK=1 y CurrentValue BIGINT. El contador persistente asigna versiones no repetidas, incluso después de borrar y recrear IDs. Todas las mutaciones del catálogo adquieren primero su bloqueo. El contador y los datos se confirman/revierten juntos. Las columnas Version del catálogo son BIGINT dentro del rango entero exacto de JavaScript.


NewsletterSubscriptions: Email VARCHAR(254) PK, ConsentVersion VARCHAR(20) y CreatedAt DATETIME con valor inicial CURRENT_TIMESTAMP. Registra correos con consentimiento para futuras novedades; el envío de mensajes aún no está habilitado. Se añade con CREATE TABLE IF NOT EXISTS sin reemplazar tablas existentes. Feature 3 calcula resultados en memoria y no requiere tablas de orden o de ciclos.

## Costos derivados — 16 de noviembre de 2026

Esta ampliación no añade tablas ni columnas de costos. `ProductCosts` es un resumen calculado que se adjunta a cada producto en las respuestas del catálogo; no es una tabla ni modifica `ProductPrices`, `Elements.Version` o `RevisionClock` al consultar.

El cálculo usa las cantidades de `ProductRequirements`, las ofertas de `SupplierOffers` y las relaciones de `GeneralDependencies` cuyos dos extremos son productos. Para estas últimas se aplica la regla acordada de **una unidad del componente de origen por cada dependencia**; la relación almacenada sigue sin tener un campo de cantidad. Otras dependencias generales sin costo/cantidad interpretable dejan incompleto el cálculo del producto al que afectan.

Los materiales directos e indirectos se agregan por identificador antes de calcular importes. Cada subtotal se redondea con HALF_UP a dos decimales; el total mínimo/máximo suma esos subtotales y el precio derivado es mínimo × 1,25, redondeado a dos decimales. Los resultados `Incomplete` o `Cycle` conservan los tres importes finales como `null`.

`Elements[i].SalePrice` conserva el precio manual histórico; `Elements[i].ProductCosts.SalePrice` y el `SalePrice` de `/estimate` son valores derivados. Consultar el nuevo cálculo no actualiza el primero. El [contrato detallado](GRAPH_COSTS_2026-11-16.md) describe la respuesta y los límites del modelo.
