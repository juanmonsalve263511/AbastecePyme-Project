import test from 'node:test';
import assert from 'node:assert/strict';
import {BuildApiRequest} from '../frontend/src/ApiRequests.js';

test('updates preserve optimistic version and target one selected element',()=>{
  assert.deepEqual(BuildApiRequest('EditElement',{ElementId:'MAT-WOOD'},'{"Name":"Wood","Version":42}'),{
    Method:'PATCH',Path:'/api/elements/MAT-WOOD',Body:{Name:'Wood',Version:42},Writes:true
  });
});
test('element deletion uses the selected snapshot version',()=>{
  assert.deepEqual(BuildApiRequest('DeleteElement',{ElementId:'MAT-WOOD',Version:37},''),{
    Method:'DELETE',Path:'/api/elements/MAT-WOOD?Version=37',Writes:true
  });
});
test('rejects malformed JSON and missing mutation selection before execution',()=>{
  for(const Body of ['{','null','[]','"text"'])assert.throws(()=>BuildApiRequest('CreateElement',{},Body));
  assert.throws(()=>BuildApiRequest('DeleteElement',{},''));
  assert.throws(()=>BuildApiRequest('ReadSecrets',{},''));
});
test('production uses optional product scope and impact preserves direction',()=>{
  assert.equal(BuildApiRequest('Production',{},'').Path,'/api/production');
  assert.equal(BuildApiRequest('Production',{ProductId:'PROD-MESA'},'').Path,'/api/production?ProductId=PROD-MESA');
  assert.equal(BuildApiRequest('Impact',{ElementId:'MAT',Direction:'Requirements'},'').Path,'/api/impact/MAT?Direction=Requirements');
});
test('relation creation and deletion have explicit methods and JSON bodies',()=>{
  const Body='{"SourceId":"AA","TargetId":"BB","Version":2,"Value":null,"IsDemo":false}';
  assert.equal(BuildApiRequest('CreateRelation',{},Body).Method,'POST');
  assert.equal(BuildApiRequest('DeleteRelation',{},Body).Method,'DELETE');
  assert.equal(BuildApiRequest('DeleteRelation',{},Body).Body.Version,2);
});
