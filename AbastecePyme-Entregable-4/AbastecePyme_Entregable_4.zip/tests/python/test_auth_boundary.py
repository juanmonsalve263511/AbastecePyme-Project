"""Session validation rejects malformed client tokens without server errors."""
from types import SimpleNamespace
import unittest
from fastapi import HTTPException, Request
from backend.Auth import CurrentUser, HashToken
from test_feature3_api import SqlAdapter


class AuthBoundaryTests(unittest.TestCase):
    def setUp(self):
        self.Database = SqlAdapter()
        self.addCleanup(self.Database.Connection.close)
        self.Database.execute(
            "INSERT INTO Users(UserId,Username,DisplayName,PasswordHash,RoleId) VALUES (?,?,?,?,?)",
            "actor", "actor", "Test actor", "unused", "Editor")
        self.Database.execute(
            "INSERT INTO Sessions(TokenHash,UserId,CsrfToken,ExpiresAt) VALUES (?,?,?,?)",
            HashToken("a" * 64), "actor", "csrf-test", "2099-01-01")
        self.Database.Connection.commit()

    def Request(self, Csrf):
        return Request({"type": "http", "method": "POST",
                        "app": SimpleNamespace(state=SimpleNamespace(Database=self.Database)),
                        "headers": [(b"cookie", b"AbasteceSession=" + b"a" * 64),
                                    (b"x-csrf-token", Csrf)]})

    def test_non_ascii_csrf_is_forbidden_instead_of_an_internal_error(self):
        with self.assertRaises(HTTPException) as Failure:
            CurrentUser(self.Request(b"invalid-\xe9"))
        self.assertEqual(Failure.exception.status_code, 403)

    def test_ascii_csrf_still_requires_an_exact_match(self):
        self.assertEqual(CurrentUser(self.Request(b"csrf-test"))["UserId"], "actor")
        for Token in (b"", b"csrf-Test", b"csrf-test "):
            with self.subTest(Token=Token), self.assertRaises(HTTPException) as Failure:
                CurrentUser(self.Request(Token))
            self.assertEqual(Failure.exception.status_code, 403)
