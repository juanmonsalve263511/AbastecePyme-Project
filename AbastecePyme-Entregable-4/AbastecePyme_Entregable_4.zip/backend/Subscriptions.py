"""Local newsletter consent capture. No email delivery or external service."""


def Subscribe(Database, Body):
    with Database.Transaction() as Connection:
        Connection.execute(
            "INSERT IGNORE INTO NewsletterSubscriptions(Email,ConsentVersion) VALUES (?,?)",
            Body.Email, "2026-11-02")
    # Same response for new/existing addresses; do not expose the subscriber list.
    return {"Detail": "Solicitud registrada. Tu correo quedó guardado para futuras novedades. El envío de boletines aún no está habilitado."}
