import {useCallback,useEffect,useLayoutEffect,useRef,useState} from 'react';
import {KeyboardMoveIds,MoveNodePositions,NodesInRectangle,SelectNodeIds} from './GraphInteraction.js';
import {RevealGraphNode} from './GraphLayout.js';

export default function useGraphInteraction({Svg,Context,BaseLayout,Viewport,ResetKey,UpdateView,OnActivate,SavedPositions,PositionsReady=true,OnPositionsCommit}){
  const [Positions,SetPositions]=useState(()=>SavedPositions||new Map());
  const [Selection,SetSelection]=useState(()=>new Set());
  const [AreaMode,SetAreaMode]=useState(false),[Rectangle,SetRectangle]=useState(null),[Dragging,SetDragging]=useState(false);
  const PositionsRef=useRef(Positions),SelectionRef=useRef(Selection),Gesture=useRef(null),Frame=useRef(null),Pending=useRef(null),Scope=useRef(ResetKey);
  const StorePositions=useCallback(Value=>{PositionsRef.current=Value;SetPositions(Value);},[]);
  const CommitPositions=useCallback(Value=>{
    if(!PositionsReady||OnPositionsCommit?.(Value)===false){StorePositions(SavedPositions||new Map());return false;}
    return true;
  },[PositionsReady,OnPositionsCommit,SavedPositions,StorePositions]);
  const StoreSelection=useCallback(Value=>{SelectionRef.current=Value;SetSelection(Value);},[]);
  const StopFrame=useCallback(()=>{if(Frame.current!==null)cancelAnimationFrame(Frame.current);Frame.current=null;Pending.current=null;},[]);
  const Release=useCallback(Current=>{if(Current?.Element?.hasPointerCapture(Current.PointerId))Current.Element.releasePointerCapture(Current.PointerId);},[]);
  const CancelGesture=useCallback((Restore=true)=>{
    const Current=Gesture.current;Gesture.current=null;StopFrame();Release(Current);
    if(!Restore)return;
    if(Current?.Moved){
      if(Current.Mode==='Nodes')StorePositions(Current.Positions);
      if(Current.Mode==='Pan')UpdateView(()=>Current.Box);
      StoreSelection(Current.Selection);
    }
    SetRectangle(null);SetDragging(false);
  },[Release,StopFrame,StorePositions,StoreSelection,UpdateView]);
  const ClearSelection=useCallback(()=>{CancelGesture();StoreSelection(new Set());},[CancelGesture,StoreSelection]);
  const Reset=useCallback(()=>{
    if(!PositionsReady)return;
    CancelGesture();const Next=new Map();if(!CommitPositions(Next))return;
    StorePositions(Next);StoreSelection(new Set());SetAreaMode(false);
  },[CancelGesture,CommitPositions,PositionsReady,StorePositions,StoreSelection]);
  const RestorePositions=useCallback(()=>{if(!PositionsReady)return;CancelGesture();const Next=new Map();if(CommitPositions(Next))StorePositions(Next);},[CancelGesture,CommitPositions,PositionsReady,StorePositions]);
  const ToggleAreaMode=useCallback(()=>{CancelGesture();SetAreaMode(Value=>!Value);},[CancelGesture]);

  useLayoutEffect(()=>{
    if(Scope.current!==ResetKey){Scope.current=ResetKey;CancelGesture();StorePositions(SavedPositions||new Map());StoreSelection(new Set());SetAreaMode(false);}
  },[ResetKey,SavedPositions,CancelGesture,StorePositions,StoreSelection]);
  useLayoutEffect(()=>{if(SavedPositions&&SavedPositions!==PositionsRef.current){CancelGesture();StorePositions(SavedPositions);}},[SavedPositions,CancelGesture,StorePositions]);
  useLayoutEffect(()=>{CancelGesture();},[BaseLayout,Viewport,CancelGesture]);
  useEffect(()=>{
    function Blur(){CancelGesture();}
    window.addEventListener('blur',Blur);
    return()=>{window.removeEventListener('blur',Blur);CancelGesture(false);};
  },[CancelGesture]);

  const ProcessPoint=useCallback(Point=>{
    const Current=Gesture.current;if(!Current||!Point)return;
    const Distance=Math.hypot(Point.X-Current.Client.X,Point.Y-Current.Client.Y);
    if(!Current.Moved&&Distance<4)return;
    if(!Current.Moved){
      Current.Moved=true;SetDragging(true);
      if(Current.Mode==='Nodes'&&!Current.Selection.has(Current.NodeId))StoreSelection(new Set([Current.NodeId]));
    }
    const End=new DOMPoint(Point.X,Point.Y).matrixTransform(Current.Matrix);
    const Delta={X:End.x-Current.Start.X,Y:End.y-Current.Start.Y};
    if(Current.Mode==='Nodes')StorePositions(MoveNodePositions(Current.Layout,Current.Ids,Delta,Current.Positions));
    else if(Current.Mode==='Pan')UpdateView(()=>({...Current.Box,X:Current.Box.X-Delta.X,Y:Current.Box.Y-Delta.Y}));
    else if(Current.Mode==='Area')SetRectangle({Start:Current.Start,End:{X:End.x,Y:End.y}});
    Current.End={X:End.x,Y:End.y};
  },[StorePositions,StoreSelection,UpdateView]);
  const Flush=useCallback(()=>{Frame.current=null;const Point=Pending.current;Pending.current=null;ProcessPoint(Point);},[ProcessPoint]);
  const OnPointerDown=useCallback(Event=>{
    if(Event.button!==0||Gesture.current)return;
    const Element=Svg.current,State=Context.current,Transform=Element?.getScreenCTM();
    if(!Element||!State||!Transform)return;
    const NodeElement=Event.target.closest('[data-node-id]'),NodeId=NodeElement?.getAttribute('data-node-id');
    if(NodeId&&!State.DisplayLayout.Map.has(NodeId))return;
    const Matrix=Transform.inverse(),Point=new DOMPoint(Event.clientX,Event.clientY).matrixTransform(Matrix);
    const Mode=NodeId?(PositionsReady?'Nodes':'Inspect'):AreaMode||Event.shiftKey?'Area':'Pan';
    const Current={Element,PointerId:Event.pointerId,Mode,NodeId,Matrix,Client:{X:Event.clientX,Y:Event.clientY},
      Start:{X:Point.x,Y:Point.y},End:{X:Point.x,Y:Point.y},Layout:State.DisplayLayout,Box:State.Box,
      Positions:PositionsRef.current,Selection:SelectionRef.current,Ids:SelectionRef.current.has(NodeId)?SelectionRef.current:new Set([NodeId]),
      Additive:Event.ctrlKey||Event.metaKey,Moved:false};
    Gesture.current=Current;
    Event.preventDefault();Element.setPointerCapture(Event.pointerId);
    (NodeElement||Element).focus({preventScroll:true});
    // Freeze the viewport before the first node position changes.
    UpdateView(Value=>({...Value}));
    if(Mode==='Area')SetRectangle({Start:Current.Start,End:Current.Start});
  },[Svg,Context,AreaMode,PositionsReady,UpdateView]);
  const OnPointerMove=useCallback(Event=>{
    if(!Gesture.current||Gesture.current.PointerId!==Event.pointerId)return;
    Pending.current={X:Event.clientX,Y:Event.clientY};
    if(Frame.current===null)Frame.current=requestAnimationFrame(Flush);
  },[Flush]);
  const OnPointerUp=useCallback(Event=>{
    const Current=Gesture.current;if(!Current||Current.PointerId!==Event.pointerId)return;
    StopFrame();ProcessPoint({X:Event.clientX,Y:Event.clientY});
    Gesture.current=null;SetRectangle(null);SetDragging(false);Release(Current);
    if(Current.Mode==='Area'){
      const Found=NodesInRectangle(Current.Layout.Nodes,Current.Start,Current.End);
      StoreSelection(Current.Additive?new Set([...Current.Selection,...Found]):Found);
    }else if((Current.Mode==='Nodes'||Current.Mode==='Inspect')&&!Current.Moved){
      StoreSelection(SelectNodeIds(SelectionRef.current,Current.NodeId,Current.Additive));
      if(!Current.Additive)OnActivate(Current.NodeId);
    }else if(Current.Mode==='Nodes'&&Current.Moved)CommitPositions(PositionsRef.current);
  },[StopFrame,ProcessPoint,Release,StoreSelection,OnActivate,CommitPositions]);
  const OnPointerCancel=useCallback(Event=>{if(Gesture.current?.PointerId===Event.pointerId)CancelGesture();},[CancelGesture]);
  const ActivateNode=useCallback((Id,Toggle=false)=>{
    StoreSelection(SelectNodeIds(SelectionRef.current,Id,Toggle));
    if(!Toggle)OnActivate(Id);
  },[StoreSelection,OnActivate]);
  const MoveSelection=useCallback((Delta,FocusedId,DetailId)=>{
    if(!PositionsReady)return;
    const PreviousGesture=Gesture.current;
    CancelGesture();
    const State=Context.current;if(!State)return;
    const Layout=PreviousGesture?.Layout||State.DisplayLayout;
    const Ids=KeyboardMoveIds(SelectionRef.current,FocusedId,DetailId);
    if(!Ids.size)return;
    const Next=MoveNodePositions(Layout,Ids,Delta,PositionsRef.current);
    if(Next===PositionsRef.current)return;
    if(!CommitPositions(Next))return;
    StoreSelection(Ids);StorePositions(Next);
    const Id=FocusedId||[...Ids][0],Node=Layout.Map.get(Id),Position=Next.get(Id);
    UpdateView(Value=>Node&&Position?RevealGraphNode(Value,{...Node,...Position}):{...Value});
  },[Context,CancelGesture,StoreSelection,StorePositions,UpdateView,PositionsReady,CommitPositions]);
  const Escape=useCallback(()=>{ClearSelection();SetAreaMode(false);},[ClearSelection]);
  const IsPointerActive=useCallback(()=>Gesture.current!==null,[]);
  return {Positions,Selection,AreaMode,Rectangle,Dragging,OnPointerDown,OnPointerMove,OnPointerUp,OnPointerCancel,
    ActivateNode,MoveSelection,ClearSelection,RestorePositions,Reset,CancelGesture,ToggleAreaMode,Escape,IsPointerActive};
}
