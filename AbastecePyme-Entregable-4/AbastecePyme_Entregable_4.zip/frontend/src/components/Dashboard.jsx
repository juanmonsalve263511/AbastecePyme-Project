import SectionVisual from './SectionVisual.jsx';
import {useMemo} from 'react';
import { Heading, Icon } from './Common.jsx';
import {BuildCatalogIndex,WriteCatalogOptions} from './CatalogFilters.js';
import './SupplyBoard.css';
import './Catalog.css';

const Categories = [
  { Type: 'Supplier', Label: 'Proveedores', IconName: 'users' },
  { Type: 'Material', Label: 'Insumos', IconName: 'box' },
  { Type: 'Product', Label: 'Productos', IconName: 'catalog' },
];
const Tasks = [
  { Route: 'catalog-Supplier', IconName: 'catalog', Title: 'Organiza tu catálogo', Description: 'Proveedores, insumos y productos en un mismo lugar.' },
  { Route: 'relations', IconName: 'relations', Title: 'Conecta precios y cantidades', Description: 'Revisa tus ofertas y los requisitos de cada producto.' },
  { Route: 'impact', IconName: 'search', Title: 'Anticipa el impacto', Description: 'Sigue los caminos que conectan tu producción.' },
  { Route: 'production', IconName: 'order', Title: 'Prepara el siguiente paso', Description: 'Ordena las etapas y detecta dependencias circulares.' },
];
const ReviewGroups=[
  {Filter:'Incomplete',Type:'Product',Title:'Productos con costo incompleto',Description:'Faltan ofertas o requisitos cuantificados.'},
  {Filter:'Cycle',Type:'Product',Title:'Productos con ciclos',Description:'Sus dependencias impiden completar el cálculo.'},
  {Filter:'NoOffers',Type:'Material',Title:'Insumos sin ofertas',Description:'Todavía no tienen un precio de proveedor registrado.'},
  {Filter:'Reference',Type:'Product',Title:'Productos con datos de referencia',Description:'Incluyen precios o cantidades marcados como referencia.'}
];

export default function Dashboard({ Data, Session }) {
  const Index=useMemo(()=>BuildCatalogIndex(Data),[Data]);
  const Counts = Object.fromEntries(Categories.map(({ Type }) => [Type, Index.ByType[Type].length]));
  const Pending=ReviewGroups.filter(Group=>Index.Attention[Group.Filter].length>0);
  return <>
    <Heading Title="Tu red de abastecimiento" Description={'Hola, ' + Session.DisplayName + '. Una visión clara para organizar tu próximo paso.'}/>
    <a className="supply-dashboard-link" href="#supply-board"><div><strong>Tablero de abastecimiento</strong><span>Simula una falta, sigue sus consecuencias y compara un cambio de dependencia antes de decidir.</span></div><Icon Name="arrow" Size={28}/></a>
    <div className="overview-strip">{Categories.map(({ Type, Label, IconName }) =>
      <a href={'#catalog-' + Type} key={Type}><Icon Name={IconName}/><div><strong>{Counts[Type]}</strong><span>{Label}</span></div><Icon Name="arrow"/></a>
    )}<a href="#relations"><Icon Name="relations"/><div><strong>{Data.Relations.length}</strong><span>Relaciones</span></div><Icon Name="arrow"/></a></div>
    {Pending.length>0&&<section className="surface dashboard-attention" aria-labelledby="CatalogAttention"><header><h2 id="CatalogAttention">Datos que conviene revisar</h2><p>Abre cada grupo para consultar sus registros. Un producto puede aparecer en más de un grupo.</p></header><ul>{Pending.map(({Filter,Type,Title,Description})=>{const Items=Index.Attention[Filter];return <li key={Filter}><a href={'#catalog-'+Type+'?'+WriteCatalogOptions(Type,{Filter})}><span className="attention-count">{Items.length}</span><div><strong>{Title}</strong><p>{Description}</p><small>{Items.slice(0,3).map(Item=>Item.Name).join(' · ')}{Items.length>3?' · y '+(Items.length-3)+' más':''}</small></div><span className="attention-action">Ver registros <Icon Name="arrow" Size={17}/></span></a></li>;})}</ul></section>}
    <section className="dashboard-actions" aria-labelledby="DailyTasks">
      <div className="section-heading"><div><p className="section-note">Tu operación, conectada</p><h2 id="DailyTasks">¿Por dónde quieres empezar?</h2></div><span>Del catálogo a la producción</span></div>
      <div className="task-grid">{Tasks.map(({ Route, IconName, Title, Description }, Index) =>
        <a className="task-card" href={'#' + Route} key={Route}>
          <span className="task-card-icon"><Icon Name={IconName}/></span><span className="task-number" aria-hidden="true">0{Index + 1}</span>
          <h3>{Title}</h3><p>{Description}</p><span className="task-card-link">Abrir sección <Icon Name="arrow" Size={18}/></span>
        </a>
      )}</div>
    </section>
    <section className="dashboard-feature"><div><span className="badge light">Una perspectiva completa</span><h2>Visualiza lo que conecta tu negocio.</h2><p>Acércate a cada elemento, compara sus conexiones y sigue el recorrido de tus materiales.</p><a className="button light-button" href="#graph">Explorar el grafo <Icon Name="arrow"/></a></div><div className="flow-illustration" aria-hidden="true"><div><Icon Name="users" Size={32}/><span>Proveedores</span></div><span className="flow-connector"/><div><Icon Name="box" Size={32}/><span>Insumos</span></div><span className="flow-connector"/><div><Icon Name="catalog" Size={32}/><span>Productos</span></div></div></section>
    <div className="workspace-tip"><Icon Name="relations"/><p><strong>Una red útil empieza con datos al día.</strong> Revisa precios, cantidades y unidades antes de preparar tu producción.</p><a href="#relations">Revisar valores <Icon Name="arrow" Size={16}/></a></div>
    <SectionVisual/>
    <a className="developer-link" href="#api"><Icon Name="api"/><span>Explorador de API</span><span>Consulta y gestiona registros con tus permisos.</span><Icon Name="arrow" Size={18}/></a>
  </>;
}
