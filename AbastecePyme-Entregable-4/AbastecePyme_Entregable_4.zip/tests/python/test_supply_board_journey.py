"""Feature 4 customer acceptance through real API/auth against an isolated SQL adapter."""
import copy
import unittest
from fastapi.testclient import TestClient
from backend.Main import CreateApp
from tests.fixtures.SupplyBoardPreview import CreatePreviewDatabase, PreviewUsername, PreviewPassword


class SupplyBoardJourneyTests(unittest.TestCase):
    def setUp(self):
        self.Database = CreatePreviewDatabase()
        self.addCleanup(self.Database.Close)
        self.Client = TestClient(CreateApp(self.Database), base_url="http://127.0.0.1:3000")
        self.addCleanup(self.Client.close)
        self.Client.headers["Origin"] = "http://127.0.0.1:3000"
        Login = self.Client.post("/api/auth/login", json={"Username": PreviewUsername, "Password": PreviewPassword})
        self.assertEqual(Login.status_code, 200, Login.text)
        self.Client.headers["X-CSRF-Token"] = Login.json()["CsrfToken"]

    def RegisterDependency(self):
        Response = self.Client.post("/api/relations", json={"SourceId": "PROD-PANEL", "TargetId": "PROD-ESTANTE", "Value": None, "IsDemo": False})
        self.assertEqual(Response.status_code, 201, Response.text)

    def Analyze(self, **Changes):
        return self.Client.post("/api/dashboard/analyze", json={"ElementId": "PROV-NORTE", "ProductId": "PROD-ESTANTE", **Changes})

    def test_acceptance_valid_chain_registers_dependency_explains_impact_and_orders(self):
        self.RegisterDependency()
        Result = self.Analyze()
        self.assertEqual(Result.status_code, 200, Result.text)
        Data = Result.json()
        self.assertEqual(Data["Base"]["Production"]["Order"], ["PROV-NORTE", "INS-TABLERO", "PROD-PANEL", "PROD-ESTANTE"])
        Estante = next(Row for Row in Data["Base"]["Impact"]["Reached"] if Row["ElementId"] == "PROD-ESTANTE")
        self.assertEqual(Estante["Path"], ["PROV-NORTE", "INS-TABLERO", "PROD-PANEL", "PROD-ESTANTE"])
        self.assertEqual(Data["Base"], Data["Scenario"])

    def test_acceptance_missing_element_is_distinct_from_existing_isolated_element(self):
        self.assertEqual(self.Analyze(ElementId="MISSING").status_code, 404)
        Response = self.Analyze(ElementId="PROD-AISLADO")
        self.assertEqual(Response.status_code, 200, Response.text)
        self.assertEqual(Response.json()["Base"]["Impact"]["Status"], "NoReachable")

    def test_acceptance_invalid_data_returns_422_without_changing_catalogue(self):
        Before = self.Client.get("/api/catalog").json()
        Response = self.Analyze(Change={"Operation": "Add", "SourceId": "bad!", "TargetId": "PROD-ESTANTE"})
        self.assertEqual(Response.status_code, 422, Response.text)
        self.assertEqual(self.Client.get("/api/catalog").json(), Before)

    def test_acceptance_cycle_has_no_false_order_and_change_can_be_discarded(self):
        self.RegisterDependency()
        Before = copy.deepcopy(self.Client.get("/api/catalog").json())
        Response = self.Analyze(Change={"Operation": "Add", "SourceId": "PROD-ESTANTE", "TargetId": "PROD-PANEL"})
        self.assertEqual(Response.status_code, 200, Response.text)
        Result = Response.json()
        self.assertEqual(Result["Base"]["Production"]["Status"], "Ready")
        Plan = Result["Scenario"]["Production"]
        self.assertEqual(Plan["Status"], "Cycle")
        self.assertEqual(Plan["Order"], [])
        self.assertEqual(Plan["Stages"], [])
        self.assertEqual(Plan["Cycle"][0], Plan["Cycle"][-1])
        self.assertEqual(self.Client.get("/api/catalog").json(), Before)
        self.assertEqual(self.Analyze().json()["Scenario"]["Production"]["Status"], "Ready")

    def test_changed_requirement_compares_removed_consequences_without_persisting(self):
        self.RegisterDependency()
        Before = self.Client.get("/api/catalog").json()
        Response = self.Analyze(Change={"Operation": "Remove", "SourceId": "PROD-PANEL", "TargetId": "PROD-ESTANTE"})
        self.assertEqual(Response.status_code, 200, Response.text)
        Result = Response.json()
        self.assertEqual(Result["Comparison"]["RemovedReached"], ["PROD-ESTANTE"])
        self.assertEqual(Result["Scenario"]["Production"]["Order"], ["PROD-ESTANTE"])
        self.assertEqual(self.Client.get("/api/catalog").json(), Before)
