export function IsGeneralDependency(Source,Target){
  if(!Source||!Target)return false;
  return !(Source.ElementType==='Supplier'&&Target.ElementType==='Material')&&!(Source.ElementType==='Material'&&Target.ElementType==='Product');
}

export function BuildSupplyRequest(Selection,Catalog){
  const Lookup=new Map(Catalog.Elements.map(Item=>[Item.ElementId,Item]));
  const Origin=Lookup.get(Selection.ElementId);
  if(!Origin||!['Supplier','Material'].includes(Origin.ElementType))throw new Error('Selecciona un proveedor o insumo del catálogo para simular su indisponibilidad.');
  const ProductId=Selection.ProductId||null;
  if(ProductId&&Lookup.get(ProductId)?.ElementType!=='Product')throw new Error('Selecciona un producto existente o analiza toda la red.');
  let Change=null;
  if(Selection.Operation!=='None'){
    if(!['Add','Remove'].includes(Selection.Operation))throw new Error('Selecciona un cambio temporal válido.');
    const Source=Lookup.get(Selection.SourceId),Target=Lookup.get(Selection.TargetId);
    if(!Source||!Target)throw new Error('Selecciona el requisito y el dependiente del cambio temporal.');
    const Existing=Catalog.Relations.some(Edge=>Edge.SourceId===Source.ElementId&&Edge.TargetId===Target.ElementId);
    if(Selection.Operation==='Add'){
      if(!IsGeneralDependency(Source,Target))throw new Error('La simulación añade dependencias generales. Los precios y cantidades se gestionan en Relaciones.');
      if(Existing)throw new Error('Esa dependencia ya existe. Elige otra conexión o retira una existente.');
    }else if(!Existing)throw new Error('La relación que deseas retirar ya no existe. Actualiza el catálogo.');
    Change={Operation:Selection.Operation,SourceId:Source.ElementId,TargetId:Target.ElementId};
  }
  return {ElementId:Origin.ElementId,ProductId,Change};
}

export function BuildScenarioGraph(Catalog,Change){
  if(!Change)return Catalog;
  const Relations=Change.Operation==='Remove'
    ?Catalog.Relations.filter(Edge=>Edge.SourceId!==Change.SourceId||Edge.TargetId!==Change.TargetId)
    :[...Catalog.Relations,{SourceId:Change.SourceId,TargetId:Change.TargetId,RelationType:'General',Value:null,IsDemo:false,Version:null,IsSimulation:true}];
  return {Elements:Catalog.Elements,Relations};
}
