"""Dashboard scenarios are coherent, deterministic, and never mutate their source."""
import copy
import unittest
from fastapi import HTTPException
from pydantic import ValidationError
from backend.Models import SupplyBoardRequest
from backend.SupplyBoard import BuildSupplyBoard


def Fixture():
    return {
        "Elements": [
            {"ElementId": Id, "Name": Name, "ElementType": Kind, "Version": 1}
            for Id, Name, Kind in (("SUP", "Proveedor", "Supplier"), ("MAT", "Material", "Material"),
                                   ("PROD", "Producto", "Product"), ("FREE", "Aislado", "Product"),
                                   ("EXTRA", "Otro material", "Material"))
        ],
        "Relations": [
            {"SourceId": "SUP", "TargetId": "MAT", "RelationType": "Offer", "Value": "10.00", "IsDemo": True, "Version": 1},
            {"SourceId": "MAT", "TargetId": "PROD", "RelationType": "Requirement", "Value": "2.0000", "IsDemo": True, "Version": 1},
        ],
    }


class SupplyBoardTests(unittest.TestCase):
    def setUp(self):
        self.Data = Fixture()

    def Analyze(self, **Changes):
        return BuildSupplyBoard(self.Data, SupplyBoardRequest(ElementId="SUP", **Changes))

    def test_valid_chain_combines_catalogue_impact_and_product_order(self):
        Before = copy.deepcopy(self.Data)
        Result = self.Analyze(ProductId="PROD")
        self.assertEqual(Result["Catalog"], Before)
        self.assertEqual(Result["Base"]["Impact"]["Meaning"], "PotentialImpact")
        self.assertEqual([Item["ElementId"] for Item in Result["Base"]["Impact"]["Reached"]], ["MAT", "PROD"])
        self.assertEqual(Result["Base"]["Production"]["Order"], ["SUP", "MAT", "PROD"])
        self.assertEqual(Result["Base"], Result["Scenario"])
        self.assertIsNone(Result["Change"])
        self.assertEqual(Result["Comparison"], {"AddedReached": [], "RemovedReached": [],
                                               "ProductionStatusBefore": "Ready", "ProductionStatusAfter": "Ready"})
        self.assertEqual(self.Data, Before)

    def test_add_general_dependency_exposes_new_impact_without_persisting_it(self):
        Change = {"Operation": "Add", "SourceId": "PROD", "TargetId": "FREE"}
        Before = copy.deepcopy(self.Data)
        Result = self.Analyze(Change=Change)
        self.assertEqual(Result["Change"], Change)
        self.assertEqual(Result["Comparison"]["AddedReached"], ["FREE"])
        self.assertEqual(Result["Comparison"]["RemovedReached"], [])
        self.assertEqual(Result["Base"]["Production"]["Summary"]["Relations"], 2)
        self.assertEqual(Result["Scenario"]["Production"]["Summary"]["Relations"], 3)
        Added = next(Edge for Edge in Result["Scenario"]["Production"]["Graph"]["Relations"]
                     if Edge["SourceId"] == "PROD" and Edge["TargetId"] == "FREE")
        self.assertEqual(Added["RelationType"], "General")
        self.assertIsNone(Added["Value"])
        self.assertIsNone(Added["Version"])
        self.assertTrue(Added["IsSimulation"])
        self.assertEqual(Result["Catalog"], Before)
        self.assertEqual(self.Data, Before)
        self.assertEqual(self.Analyze()["Scenario"]["Production"]["Summary"]["Relations"], 2)

    def test_temporary_cycle_returns_witness_and_no_false_order(self):
        Result = self.Analyze(ProductId="PROD", Change={"Operation": "Add", "SourceId": "PROD", "TargetId": "SUP"})
        self.assertEqual(Result["Base"]["Production"]["Order"], ["SUP", "MAT", "PROD"])
        Plan = Result["Scenario"]["Production"]
        self.assertEqual(Plan["Status"], "Cycle")
        self.assertEqual(Plan["Cycle"], ["MAT", "PROD", "SUP", "MAT"])
        self.assertEqual(Plan["Order"], [])
        self.assertEqual(Plan["Stages"], [])
        self.assertEqual(Result["Comparison"]["ProductionStatusBefore"], "Ready")
        self.assertEqual(Result["Comparison"]["ProductionStatusAfter"], "Cycle")

    def test_removing_offer_or_requirement_is_temporary_and_preserves_other_edges(self):
        for Source, Target, Removed, Order in (
            ("SUP", "MAT", ["MAT", "PROD"], ["MAT", "PROD"]),
            ("MAT", "PROD", ["PROD"], ["PROD"]),
        ):
            with self.subTest(Source=Source, Target=Target):
                Before = copy.deepcopy(self.Data)
                Result = self.Analyze(ProductId="PROD", Change={"Operation": "Remove", "SourceId": Source, "TargetId": Target})
                self.assertEqual(Result["Comparison"]["RemovedReached"], Removed)
                self.assertEqual(Result["Comparison"]["AddedReached"], [])
                self.assertEqual(Result["Scenario"]["Production"]["Order"], Order)
                self.assertEqual(Result["Catalog"], Before)
                self.assertEqual(self.Data, Before)

    def test_unknown_elements_and_nonproduct_scope_have_distinct_errors(self):
        for Body, Status in (
            ({"ElementId": "UNKNOWN"}, 404),
            ({"ElementId": "SUP", "ProductId": "UNKNOWN"}, 404),
            ({"ElementId": "SUP", "ProductId": "MAT"}, 422),
            ({"ElementId": "SUP", "Change": {"Operation": "Add", "SourceId": "UNKNOWN", "TargetId": "PROD"}}, 404),
            ({"ElementId": "SUP", "Change": {"Operation": "Remove", "SourceId": "PROD", "TargetId": "UNKNOWN"}}, 404),
        ):
            with self.subTest(Body=Body), self.assertRaises(HTTPException) as Failure:
                BuildSupplyBoard(self.Data, SupplyBoardRequest(**Body))
            self.assertEqual(Failure.exception.status_code, Status)

    def test_duplicate_missing_and_weighted_additions_are_rejected_without_changes(self):
        Before = copy.deepcopy(self.Data)
        for Change, Status in (
            ({"Operation": "Add", "SourceId": "SUP", "TargetId": "MAT"}, 409),
            ({"Operation": "Remove", "SourceId": "PROD", "TargetId": "FREE"}, 404),
            ({"Operation": "Add", "SourceId": "SUP", "TargetId": "EXTRA"}, 422),
            ({"Operation": "Add", "SourceId": "EXTRA", "TargetId": "PROD"}, 422),
        ):
            with self.subTest(Change=Change), self.assertRaises(HTTPException) as Failure:
                self.Analyze(Change=Change)
            self.assertEqual(Failure.exception.status_code, Status)
            self.assertEqual(self.Data, Before)

    def test_self_dependency_can_be_demonstrated_and_removed_again(self):
        Result = self.Analyze(Change={"Operation": "Add", "SourceId": "SUP", "TargetId": "SUP"})
        self.assertEqual(Result["Scenario"]["Production"]["Cycle"], ["SUP", "SUP"])
        self.assertEqual(self.Analyze()["Scenario"]["Production"]["Status"], "Ready")

    def test_isolated_origin_is_a_valid_empty_impact(self):
        Result = BuildSupplyBoard(self.Data, SupplyBoardRequest(ElementId="FREE"))
        self.assertEqual(Result["Base"]["Impact"]["Status"], "NoReachable")
        self.assertEqual(Result["Scenario"]["Impact"]["Reached"], [])
        self.assertEqual(Result["Scenario"]["Production"]["Status"], "Ready")

    def test_snapshot_tracks_catalogue_content_not_request_or_iteration_order(self):
        Initial = self.Analyze()["SnapshotId"]
        self.assertRegex(Initial, r"^[a-f0-9]{64}$")
        ChangedScenario = self.Analyze(Change={"Operation": "Add", "SourceId": "PROD", "TargetId": "FREE"})
        self.assertEqual(ChangedScenario["SnapshotId"], Initial)
        self.Data["Elements"].reverse()
        self.Data["Relations"].reverse()
        self.assertEqual(self.Analyze(ProductId="PROD")["SnapshotId"], Initial)
        self.Data["Elements"][0]["Version"] = 2
        self.assertNotEqual(self.Analyze()["SnapshotId"], Initial)

    def test_returned_catalogue_does_not_share_mutable_records_with_input(self):
        Before = copy.deepcopy(self.Data)
        Result = self.Analyze()
        Result["Catalog"]["Elements"][0]["Name"] = "Changed only in output"
        Result["Catalog"]["Relations"].clear()
        self.assertEqual(self.Data, Before)

    def test_strict_request_rejects_missing_bad_and_unexpected_fields(self):
        for Body in ({}, {"ElementId": "bad!"}, {"ElementId": 1}, {"ElementId": "SUP", "ProductId": ""},
                     {"ElementId": "SUP", "Persist": True}, {"ElementId": "SUP", "Change": {}},
                     {"ElementId": "SUP", "Change": {"Operation": "Replace", "SourceId": "SUP", "TargetId": "MAT"}},
                     {"ElementId": "SUP", "Change": {"Operation": "Add", "SourceId": "SUP", "TargetId": "bad!"}},
                     {"ElementId": "SUP", "Change": {"Operation": "Add", "SourceId": "SUP", "TargetId": "MAT", "Value": "3"}}):
            with self.subTest(Body=Body), self.assertRaises(ValidationError):
                SupplyBoardRequest(**Body)
