# Readability, filters and measured performance

**Goal:** Apply the approved readability, catalog filtering and performance recommendations while preserving the blue/gray palette and all existing functions.
**Architecture:** Keep React, FastAPI and MariaDB. Reuse the existing styles and graph renderer. Introduce an opt-in compact dashboard response; the default public API response remains compatible. Python still chooses reachability, predecessor trees, production orders, cycles and costs.
**Spec:** [Approved recommendations](../../RECOMMENDATIONS_2026-11-16.md), R01/R04/R05/R06/R08/R09/R10/R11 within the user's selected scope.

## Constraints and review focus

- Preserve exact decimal amounts, zero values, incomplete/cycle statuses, minimum +25% and one unit per component.
- Preserve authorization, CRUD, animation pause/reduced motion, focus and supplier highlighting.
- Never change the catalog seed, real database or credentials for these changes.
- Existing API consumers retain expanded dashboard results unless they request the compact format.
- Verify unrelated and connected general dependencies, large decimals, null costs, no filter matches, Viewer permissions, scenario cycles and changing selections rapidly.

## Work and ownership

- [x] Backend costs: index products affected by unusual dependencies; add regression/equivalence cases and a repeatable measured comparison. Owner: backend agent, ProductCosts.py and related tests.
- [x] Catalog: exact decimal sorting, cost/status/reference/no-offer filters, result count, reset and permission-aware empty states; actionable summary links. Owner: frontend agent, Catalog/Dashboard and helpers/tests. Root passes route query to Catalog.
- [x] Graph: useful readable framing, explicit overview and reading controls, responsive detail layout while preserving all graph actions. Owner: visual agent, Graph/Layout/ProductCosts and their styles/tests.
- [x] Dashboard: optional compact response avoids duplicated paths, element bodies and unchanged scenarios. Reconstruct only the selected predecessor chain for presentation; no graph search or business calculation moves to JavaScript. Root owns Impact/SupplyBoard/Models and SupplyResponse.js plus tests.
- [x] Verify full suite/build, compare original versus optimized payload/time, then inspect desktop/mobile flows using an isolated database fixture.
- [x] Independent review, documentation, updated source archive and restart validation. No Git commit: this project is not a Git repository.

## Compact dashboard contract

Request `ResponseFormat: "Compact"` opts in; omitted/default `"Expanded"` preserves the old contract. Compact responses carry `ResponseFormat`, one Catalog, Base and optional Scenario. Each Impact includes Visited with ParentId/Depth chosen by Python, without all Paths or the duplicate Reached list. Graphs refer to catalog elements by ElementIds and retain their scoped relations. The client resolves these references once and formats a selected chain from ParentId. A missing Scenario with no Change aliases Base. SnapshotId and request cancellation continue to isolate scenarios.

Tests compare every reconstructed path, both graph memberships, statuses, cycle witnesses, summary and change comparison against expanded results. An invalid predecessor chain produces no path, rather than looping. Benchmark uses synthetic data only and preserves the original measurement files.
