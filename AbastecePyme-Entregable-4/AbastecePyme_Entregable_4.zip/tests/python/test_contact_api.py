"""Contact messages remain private and are persisted only with consent."""
import unittest
from fastapi.testclient import TestClient
from backend.Main import CreateApp
import test_feature3_api as Fixtures


class ContactApiTests(unittest.TestCase):
    def setUp(self):
        self.Database = Fixtures.SqlAdapter()
        self.Database.Connection.execute("""CREATE TABLE ContactRequests (
            RequestId TEXT PRIMARY KEY, FullName TEXT, Email TEXT, Phone TEXT, Company TEXT,
            Subject TEXT, Message TEXT, ConsentVersion TEXT, CreatedAt TEXT, ReadAt TEXT)""")
        self.App = CreateApp(self.Database)
        self.Client = TestClient(self.App, base_url="http://127.0.0.1:3000")
        self.Client.headers.update({"Origin": "http://127.0.0.1:3000"})
        self.addCleanup(self.Client.close)
        self.addCleanup(self.Database.Connection.close)

    def Body(self):
        return {"FullName": "  Ana Pérez  ", "Email": " ANA@example.invalid ", "Phone": "+57 311 000 0000",
                "Company": "Mi taller", "Subject": "Organizar mi producción", "Message": "Quiero conocer las opciones para mi taller.", "Consent": True}

    def Send(self):
        Response = self.Client.post("/api/contact-requests", json=self.Body())
        self.assertEqual(Response.status_code, 201, Response.text)
        return Response.json()["RequestId"]

    def test_public_submission_saves_normalized_values_without_exposing_them(self):
        RequestId = self.Send()
        Stored = self.Database.execute("SELECT FullName,Email,Message,ReadAt FROM ContactRequests WHERE RequestId=?", RequestId).fetchone()
        self.assertEqual(Stored[:3], ("Ana Pérez", "ana@example.invalid", self.Body()["Message"]))
        self.assertIsNone(Stored[3])
        self.assertEqual(self.Client.get("/api/contact-requests").status_code, 401)

    def test_admin_inbox_pagination_and_mark_read(self):
        RequestId = self.Send()
        self.Send()
        Fixtures.Feature3ApiTests.Authenticate(self)
        Result = self.Client.get("/api/contact-requests?Limit=1&Offset=0").json()
        self.assertEqual(Result["Total"], 2)
        self.assertEqual(len(Result["Items"]), 1)
        Second = self.Client.get("/api/contact-requests?Limit=1&Offset=1").json()
        self.assertNotEqual(Result["Items"][0]["RequestId"], Second["Items"][0]["RequestId"])
        for _ in range(2):
            self.assertEqual(self.Client.patch(f"/api/contact-requests/{RequestId}/read", json={}).status_code, 200)
        self.assertIsNotNone(self.Database.execute("SELECT ReadAt FROM ContactRequests WHERE RequestId=?", RequestId).fetchone()[0])
        self.assertEqual(self.Client.patch("/api/contact-requests/00000000-0000-0000-0000-000000000000/read", json={}).status_code, 404)

    def test_inbox_excludes_viewers_editors_and_requires_csrf(self):
        RequestId = self.Send()
        Fixtures.Feature3ApiTests.Authenticate(self, "Viewer")
        for Role in ("Viewer", "Editor"):
            self.Database.execute("UPDATE Users SET RoleId=?", Role)
            self.assertEqual(self.Client.get("/api/contact-requests").status_code, 403)
            self.assertEqual(self.Client.patch(f"/api/contact-requests/{RequestId}/read", json={}).status_code, 403)
        self.Database.execute("UPDATE Users SET RoleId='Administrator'")
        self.assertEqual(self.Client.patch(f"/api/contact-requests/{RequestId}/read", json={}, headers={"X-CSRF-Token":"wrong"}).status_code, 403)

    def test_invalid_fields_consent_and_cross_origin_do_not_store(self):
        for Change in ({"FullName":" "},{"Email":"wrong"},{"Phone":"<script>"},{"Consent":False},{"Consent":"true"},
                       {"Message":"short"},{"Message":"x"*2001},{"Subject":" "},{"Extra":"ignored?"}):
            self.assertEqual(self.Client.post("/api/contact-requests", json={**self.Body(),**Change}).status_code, 422)
        self.assertEqual(self.Client.post("/api/contact-requests", json=self.Body(), headers={"Origin":"https://untrusted.example"}).status_code, 403)
        self.assertEqual(self.Database.execute("SELECT COUNT(*) FROM ContactRequests").fetchone()[0], 0)

    def test_contact_endpoint_limits_submission_rate(self):
        for _ in range(10):
            self.Send()
        self.assertEqual(self.Client.post("/api/contact-requests", json=self.Body()).status_code, 429)
        self.assertEqual(self.Database.execute("SELECT COUNT(*) FROM ContactRequests").fetchone()[0], 10)
