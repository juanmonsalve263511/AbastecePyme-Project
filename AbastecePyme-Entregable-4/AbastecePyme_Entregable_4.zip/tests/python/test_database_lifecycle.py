"""Connection initialization failures must release the underlying connection."""
import sqlite3
import unittest
from unittest.mock import patch
from backend.Database import Database


class SetupConnection:
    def __init__(self):
        self.Connection = sqlite3.connect(":memory:")

    def execute(self, Query):
        # SQLite rejects the MySQL session statement, reproducing setup failure
        # with a real allocated database resource and without a network service.
        return self.Connection.execute(Query)

    def close(self):
        self.Connection.close()


class DatabaseLifecycleTests(unittest.TestCase):
    def test_failed_session_setup_releases_connection_and_preserves_error(self):
        Connection = SetupConnection()
        self.addCleanup(Connection.close)
        with patch("backend.Database.pyodbc.connect", return_value=Connection):
            with self.assertRaises(sqlite3.OperationalError):
                Database("ephemeral-test-value").Connect()
        with self.assertRaises(sqlite3.ProgrammingError):
            Connection.Connection.execute("SELECT 1")
