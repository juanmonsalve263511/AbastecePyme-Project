# Ampliación de catálogo y presentación — 2026-11-02

Se aplicaron textos de marca profesionales y etiquetas de referencia en lugar de demostración. Se añadió ProductPrices con importes exactos, validación, control de versiones y edición por catálogo/API. La ampliación autorizada agregó 5 proveedores, 3 componentes, 21 ofertas, 7 requisitos y 8 dependencias generales: 48 elementos y 128 relaciones, sin ciclos. Todos los insumos tienen al menos dos proveedores y los 17 productos tienen precio. Los datos anteriores se conservaron y la repetición no duplica ni sobrescribe registros. Respaldo de catálogo y fuentes en work/, excluido del paquete público. Ver docs/CATALOG_UPDATE_2026.md para uso, contrato y pruebas.

# Bitácora de asistencia de IA — Feature 1

Fecha: 6 de octubre de 2026. Herramienta: Codex. Alcance: análisis y construcción de la primera entrega del caso AbastecePyme.

## Solicitudes del usuario

1. Analizar el brief completo desde la aplicación práctica de teoría de grafos, considerando entregas parciales.
2. Inicialmente limitarse al análisis y al plan para el Feature 1.
3. Tras revisar el plan, proceder con su ejecución.

## Trabajo realizado con asistencia

- Lectura del brief proporcionado por el usuario.
- Propuesta de dirección requisito → dependiente y listas de adyacencia.
- Implementación de catálogo, API HTTP, persistencia local, interfaz SVG y datos sintéticos.
- Elaboración y ejecución de 21 pruebas automáticas de dominio, persistencia y API.
- Verificación de interacciones reales en el navegador y revisión del estado vacío y de diferentes tamaños de pantalla.
- Preparación de README, trazabilidad de requisitos, casos de aceptación y paquete de entrega.

## Decisiones y límites declarados

Se eligió Node.js sin dependencias externas. Los datos se conservan en un archivo JSON local, con un solo proceso por archivo. Se normalizan ID a mayúsculas. Se admiten ciclos y autorrelaciones para su tratamiento en el Feature 3. No se implementaron recorridos de impacto ni ordenamiento topológico.

La IA produjo el código y los documentos iniciales y ejecutó las comprobaciones registradas. No se atribuye al estudiante una revisión o una ejecución que no haya realizado. No se consultaron fuentes externas para definir requisitos: se trabajó con el brief entregado y las decisiones explícitas del plan.

## Por completar por el equipo antes de entregar

- Integrantes y responsabilidades.
- Revisión personal del código y comprensión del modelo.
- Cambios propios sobre esta versión y su justificación.
- Resultados de la ejecución en el equipo del estudiante.
- Declaración de uso de IA conforme a las reglas del curso.

Esta bitácora se incluye como base para mantener trazabilidad desde la primera entrega; la documentación integral de IA se solicita expresamente en el Feature 4.

## Ampliación solicitada del catálogo

A petición del usuario se añadieron doce productos acordes con un fabricante de muebles, cinco proveedores, doce insumos y 83 relaciones. Se preservaron los registros existentes, incluido «Metro 20 M», y se actualizó el ejemplo distribuible. Se verificaron integridad del grafo, persistencia y consulta en la interfaz. Los nombres de proveedores y las dependencias constituyen un escenario sintético para el taller.


## 2 de noviembre de 2026 — Feature 3 y acceso administrado

Se leyó la guía completa y se implementaron Kahn y DFS iterativos propios en Python. La dirección requisito → dependiente se conservó. Las pruebas se escribieron antes del código: inicialmente fallaron por funciones/rutas ausentes y luego pasaron. Se eliminó el registro público y se añadió creación de cuentas por administradores. Se amplió el explorador API con mutaciones revisables y se renovaron portada, subpáginas, preferencias y suscripción local.

La conexión SQL funcionaba, pero SHOW GRANTS no incluía UPDATE; el usuario volvió a concederlo y se verificó antes de las pruebas reales. Se agregó solo la tabla de suscripciones. No se intervinieron las tablas del sistema ni gym_admin_management.

Validación: 40 pruebas Python y 33 JavaScript; 15 pruebas MariaDB aprobadas y 1 omitida para proteger la cuenta administradora permanente. Revisión independiente sin hallazgos accionables. Los casos de navegador con cambios usaron una base temporal en memoria. Referencias y skills en GUIA_ACTUALIZACION_2026.md; detalle de aceptación en FEATURE3.md.
# Corrección de acceso a Orden de producción — 2026-11-02

- Incidente: la interfaz mostraba «No se pudo completar la solicitud» al consultar Estante modular.
- Evidencia: GET /api/production en el puerto 3000 devolvía 404 con `detail: Not Found`; en 3001 devolvía 401 sin sesión, por lo que la ruta sí estaba registrada. La instancia anterior seguía ejecutando rutas antiguas.
- Corrección operativa: acceso local Abrir.url dirigido a 3001. El usuario inició sesión allí y confirmó que el orden se muestra. La instancia antigua de 3000 no fue detenida desde esta sesión.
- Corrección del cliente: reconoce Detail y detail, explica el reinicio necesario cuando falta una ruta y conserva los mensajes de productos inexistentes.
- Validación de cálculo: lectura del catálogo real y pruebas de rutas en un cliente aislado, con identidad de prueba, para los 14 productos y toda la red. Estante modular devuelve 7 elementos, 6 relaciones y 3 etapas. Esa comprobación aislada no prueba autenticación HTTP real; el funcionamiento en el navegador fue confirmado por el usuario.
- No se modificaron registros ni permisos de MariaDB. Se añadieron cuatro pruebas de respuesta del cliente; dos reproducían el error antes de la corrección.

