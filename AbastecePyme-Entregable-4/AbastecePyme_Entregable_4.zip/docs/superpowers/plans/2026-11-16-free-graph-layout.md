# Free graph layout and multiple selection

**Goal:** Let users freely move supplier, material and product cards, individually or together, in every shared graph view.
**Architecture:** Extend the existing SVG/React graph without a graph library. Keep view state separate from business selection, temporary move selection and local node positions. Python analysis, relations, cost traces and stored data remain unchanged.
**Approved interaction:** Direct node drag; Ctrl/Cmd click toggles group membership; mouse rectangle selection through an explicit area-selection mode or Shift-drag on the background. The ordinary background drag continues to pan.

## Constraints and acceptance

- Retain zoom/fit/readable controls, weights, animation/pause, reduced motion, keyboard access and cost/path highlighting.
- Node movement uses graph coordinates, so zoom does not change the actual movement scale. Group movement preserves offsets and updates attached arrows/weights continuously.
- A completed drag cannot trigger a click, open another product or clear a cost explanation. Keyboard focus must not shift the viewport while a pointer gesture is active.
- Multi-selection and active detail selection are separate. Moving several elements never implies editing relations or costs.
- Coordinates live in the graph instance. Switching its focus or displayed cost option retains positions; restoring layout, refreshing the source or leaving the view clears the local arrangement. The supply dashboard retains positions when toggling focus/full for one snapshot/version.
- Empty graphs, canceled/lost pointer capture, leaving the page, right-click, touch and narrow viewports must not leave an active drag.
- Preserve palette. Use visible selection outlines, a selected count, concise controls/instructions and keyboard equivalents. Hide column headings when manual positions would make them misleading.

## Work

- [x] Pure selection/rectangle/translation helpers and position-aware layout bounds; test immutability, group offsets, zoom-independent coordinates, negative positions and curve bounds.
- [x] SVG interactions and controls with pointer capture, drag threshold, frame-limited updates and cleanup; preserve current detail selection and viewBox.
- [x] Stable interaction identity for SupplyBoard when its visible graph changes; verify existing scenarios and highlights.
- [x] Full tests/build and isolated desktop/mobile browser checks for individual/group drag, Ctrl toggling, rectangle selection, pan/zoom, restore and cost/path preservation.
- [x] Independent review, guide/README/update notes and refreshed source package. Frontend only: reload the browser after compilation; no MariaDB credential or server restart should be needed.

Ownership: frontend agent Graph component/styles/hook; geometry agent helper/layout/tests; root integration, browser QA and documentation; review agent read-only independent review.
