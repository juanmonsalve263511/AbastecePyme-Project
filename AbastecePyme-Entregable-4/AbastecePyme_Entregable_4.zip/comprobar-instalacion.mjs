// Compatibility entry point: verification now targets the current application.
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('.', import.meta.url));
const python = join(root, '.venv', process.platform === 'win32' ? 'Scripts/python.exe' : 'bin/python');
if (!existsSync(python)) {
  console.error('Ejecuta primero Instalar.cmd.');
  process.exitCode = 1;
} else {
  // --sin-http remains accepted; the unified checks never require a live server.
  const args = process.argv.slice(2).filter(value => value !== '--sin-http');
  const child = spawn(python, [join(root, 'Verify.py'), ...args], { cwd: root, stdio: 'inherit' });
  child.on('error', error => { console.error(error.message); process.exitCode = 1; });
  child.on('exit', code => { process.exitCode = code ?? 1; });
}
