# User graph layouts and continuous homepage motion

**Goal:** Restore each user's node positions after reload or login and keep the homepage supply flow moving continuously.
**Architecture:** Keep React/SVG interactions; persist only completed node coordinates through authenticated FastAPI to MariaDB. Use independent fixed layout keys Graph, Impact, Production and SupplyBoard. Keep account identity server-derived and preserve existing authorization, business data, graph costs and selection. Use a browser pending draft for interrupted saves, not as the final account store.
**Design choice:** Account storage satisfies reload/login and another browser; browser-only storage would not follow the account. Positions are visual preferences, available to all authenticated roles. Last completed write wins for concurrent tabs. Restore distribution saves an empty layout for that view. Unknown/deleted element IDs never create business entities and are ignored in the visible graph.
**Homepage diagnosis:** Modern.css currently sets SupplyFlow to one four-second ease-out iteration. Replace it with a seamless linear repeating dash loop, retain reduced-motion preferences and provide a pause control.

## Contract and constraints

- GET/PUT /api/account/graph-layouts/{LayoutKey}, four fixed keys, body/response Positions: [{ElementId,X,Y}]. No client UserId.
- At most 1000 unique IDs, finite numeric coordinates within ±1000000, existing ID syntax, strict extra-field rejection.
- Origin and CSRF validation on writes, no role escalation; separate per user and section. Layout endpoint limit 131072 bytes, other request limit remains 32768.
- Non-destructive new UserGraphLayouts table. Existing installed databases add only that table after the protected seed check; no catalog or permission-table changes.
- Prevent initial empty writes and stale session responses. Serialize saves, retain a private pending browser draft on connection failure, surface saving/errors and retry. No network writes during every animation frame.
- A reload/login must recover saved positions. Group movement, zoom, focus, cost highlighting, restore and keyboard remain functional.
- No new graph libraries/dependencies, preserve palette, use English identifiers and Spanish UI.

## Work

- [x] Backend contracts, schema migration, isolated-account persistence and validation tests.
- [x] Frontend account-scoped queue/provider, completion-triggered saves and restore, error/retry and session-safe behavior tests.
- [x] Homepage indefinite seamless animation, pause/reduced-motion behavior.
- [x] Independent review; full verification/build; browser reload/login, user isolation, reset and motion beyond multiple cycles.
- [x] Update usage/README/validation and shareable source package; activate server changes through normal private password prompt.

## Review focus

Immediate reload or logout after dragging; failed save with later retry; stale response after account switch; a filtered graph must not erase hidden positions; restoring must persist empty state; migration must not update existing catalog; reduced motion must override continuous animation.

Ownership: backend agent backend/migration/tests, frontend agent graph persistence/provider/tests, motion agent Home/Modern.css, root integration/browser/docs/package and final review.
