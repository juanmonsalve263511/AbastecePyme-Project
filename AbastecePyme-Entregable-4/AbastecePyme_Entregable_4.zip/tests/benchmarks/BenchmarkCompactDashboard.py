"""Compare expanded/compact read-only dashboards, without MariaDB or network."""
import argparse
import gzip
import json
import sys
import tracemalloc
from pathlib import Path

Root = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(Root))
from tests.benchmarks.BenchmarkResearch2026 import SyntheticChain, Measure, JsonBytes, ReadEnvironment
from backend.Models import SupplyBoardRequest
from backend.SupplyBoard import BuildSupplyBoard
from backend.ProductCosts import CalculateCatalogueCosts


def Run():
    Rows = []
    for Count in (100, 500, 1000):
        Catalog = SyntheticChain(Count)
        Costs = CalculateCatalogueCosts(**Catalog)
        for Item in Catalog['Elements']:
            if Item['ElementType'] == 'Product':
                Item['ProductCosts'] = Costs[Item['ElementId']]
        Row = {'Products': Count}
        for Format in ('Expanded', 'Compact'):
            Body = SupplyBoardRequest(ElementId='S1', ResponseFormat=Format)
            BuildTime, Board = Measure(lambda: BuildSupplyBoard(Catalog, Body))
            SerializeTime, Encoded = Measure(lambda: JsonBytes(Board))
            GzipTime, Zipped = Measure(lambda: gzip.compress(Encoded, compresslevel=5, mtime=0))
            # Separate, untimed run: tracemalloc otherwise distorts timing.
            tracemalloc.start()
            Probe = BuildSupplyBoard(Catalog, Body)
            ProbeBytes = JsonBytes(Probe)
            _, Peak = tracemalloc.get_traced_memory()
            tracemalloc.stop()
            del Probe, ProbeBytes
            Row[Format] = {'BuildMilliseconds': BuildTime, 'JsonBytes': len(Encoded),
                           'SerializationMilliseconds': SerializeTime, 'GzipBytes': len(Zipped),
                           'GzipMilliseconds': GzipTime, 'BuildAndJsonPeakPythonBytes': Peak}
        Rows.append(Row)
    return {'Environment': ReadEnvironment(), 'Method': 'Median of 3 timed runs; separate one-run tracemalloc peak; synthetic chain; no database or network. Both formats use optimized unchanged-scenario calculation.', 'Results': Rows}


if __name__ == '__main__':
    Parser = argparse.ArgumentParser(description=__doc__)
    Parser.add_argument('--run', action='store_true')
    Arguments = Parser.parse_args()
    if not Arguments.run:
        Parser.error('Use --run to measure explicitly.')
    print(json.dumps(Run(), ensure_ascii=False, indent=2))
