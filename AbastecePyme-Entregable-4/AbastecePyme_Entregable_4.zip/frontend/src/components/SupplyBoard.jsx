import {useCallback,useEffect,useMemo,useRef,useState} from 'react';
import {Api,TypeLabels} from '../Api.js';
import {LatestRequest} from '../LatestRequest.js';
import {Empty,Field,Heading,Icon,Notice} from './Common.jsx';
import Graph from './Graph.jsx';
import {ProductionResult} from './Production.jsx';
import {BuildSupplyRequest,IsGeneralDependency} from './SupplyBoardModel.js';
import {GetSupplyGraph} from './SupplyGraph.js';
import {ExpandSupplyResponse,GetImpactPath} from './SupplyResponse.js';
import './SupplyBoard.css';

const InitialQuery={ElementId:'',ProductId:'',Operation:'None',SourceId:'',TargetId:''};
const StatusLabels={Ready:'Orden estructural válido',Cycle:'Ciclo detectado',Empty:'Sin elementos'};
const RelationLabels={Offer:'Precio de proveedor',Requirement:'Cantidad de insumo',General:'Dependencia general'};

export default function SupplyBoard({Data,CanEdit,OnChange,InitialElementId=''}){
  const [Query,SetQuery]=useState(()=>({...InitialQuery,ElementId:Data.Elements.some(Item=>Item.ElementId===InitialElementId&&['Supplier','Material'].includes(Item.ElementType))?InitialElementId:''}));
  const [Search,SetSearch]=useState('');
  const [Result,SetResult]=useState(null);
  const [Version,SetVersion]=useState('Base');
  const [SelectedId,SetSelectedId]=useState('');
  const [GraphMode,SetGraphMode]=useState('Impact');
  const [Focused,SetFocused]=useState(true);
  const [Error,SetError]=useState('');
  const [Busy,SetBusy]=useState(false);
  const [Refreshing,SetRefreshing]=useState(false);
  const Gate=useRef(new LatestRequest());
  const GraphSection=useRef(null);
  const ClearResult=useCallback(()=>{Gate.current.Cancel();SetResult(null);SetError('');SetBusy(false);SetSelectedId('');SetGraphMode('Impact');SetFocused(true);},[]);

  useEffect(()=>()=>Gate.current.Cancel(),[]);
  useEffect(()=>{
    ClearResult();
    SetQuery(Current=>({...InitialQuery,
      ElementId:Data.Elements.some(Item=>Item.ElementId===Current.ElementId&&['Supplier','Material'].includes(Item.ElementType))?Current.ElementId:'',
      ProductId:Data.Elements.some(Item=>Item.ElementId===Current.ProductId&&Item.ElementType==='Product')?Current.ProductId:''
    }));
  },[Data,ClearResult]);

  const CatalogLookup=useMemo(()=>new Map(Data.Elements.map(Item=>[Item.ElementId,Item])),[Data.Elements]);
  const Lookup=useMemo(()=>Result?new Map(Result.Catalog.Elements.map(Item=>[Item.ElementId,Item])):CatalogLookup,[Result,CatalogLookup]);
  const SearchText=Search.trim().toLocaleLowerCase();
  const Origins=useMemo(()=>Data.Elements.filter(Item=>['Supplier','Material'].includes(Item.ElementType)&&(Item.ElementId===Query.ElementId||(Item.Name+' '+Item.ElementId).toLocaleLowerCase().includes(SearchText))),[Data.Elements,Query.ElementId,SearchText]);
  const Products=useMemo(()=>Data.Elements.filter(Item=>Item.ElementType==='Product'),[Data.Elements]);
  const Targets=useMemo(()=>Data.Elements.filter(Item=>!Query.SourceId||IsGeneralDependency(CatalogLookup.get(Query.SourceId),Item)),[Data.Elements,Query.SourceId,CatalogLookup]);
  const Current=Result?.[Version];
  const Impact=Current?.Impact;
  const Production=Current?.Production;
  const Visited=useMemo(()=>new Map((Impact?.Visited||[]).map(Item=>[Item.ElementId,Item])),[Impact]);
  const Selected=Visited.get(SelectedId);
  const ShowingCycle=GraphMode==='Cycle'&&Production?.Status==='Cycle';
  const SelectedPath=useMemo(()=>GetImpactPath(Visited,SelectedId),[Visited,SelectedId]);
  const Path=ShowingCycle?Production.Cycle:SelectedPath;
  const GraphData=useMemo(()=>GetSupplyGraph(Result,Version,Focused,ShowingCycle),[Result,Version,Focused,ShowingCycle]);
  const Origin=CatalogLookup.get(Query.ElementId);
  const Source=CatalogLookup.get(Query.SourceId),Target=CatalogLookup.get(Query.TargetId);
  const DisplayCatalog=Result?.Catalog||Data;

  function ChangeQuery(Patch){ClearResult();SetQuery(Current=>({...Current,...Patch}));}
  const SelectPath=useCallback(Id=>{SetSelectedId(Id);SetGraphMode('Impact');},[]);
  const FocusGraph=useCallback(()=>{GraphSection.current?.focus({preventScroll:true});GraphSection.current?.scrollIntoView({block:'start'});},[]);
  const ShowCycle=useCallback(()=>{SetGraphMode('Cycle');FocusGraph();},[FocusGraph]);
  function ShowPath(Id){SelectPath(Id);FocusGraph();}
  function SelectVersion(Value){
    SetVersion(Value);SetGraphMode('Impact');
    SetSelectedId(CurrentId=>Result[Value].Impact.Visited.some(Item=>Item.ElementId===CurrentId)?CurrentId:Result[Value].Impact.Origin.ElementId);
  }
  function SelectDifference(Id,Value){SetVersion(Value);ShowPath(Id);}
  async function Refresh(){
    ClearResult();SetRefreshing(true);
    try{await OnChange();}catch(Failure){SetError(Failure.message);}finally{SetRefreshing(false);}
  }
  async function Analyze(Event){
    Event.preventDefault();if(Busy||Refreshing)return;
    ClearResult();
    let Body;
    try{Body=BuildSupplyRequest(Query,Data);}catch(Failure){SetError(Failure.message);return;}
    SetBusy(true);
    await Gate.current.Run(Signal=>Api('/api/dashboard/analyze',{method:'POST',body:{...Body,ResponseFormat:'Compact'},signal:Signal}),Raw=>{
      const Value=ExpandSupplyResponse(Raw);
      const ActiveVersion=Value.Change?'Scenario':'Base';
      const ActiveImpact=Value[ActiveVersion].Impact;
      SetResult(Value);SetVersion(ActiveVersion);
      SetSelectedId(ActiveImpact.Reached.find(Item=>Item.ElementType==='Product')?.ElementId||ActiveImpact.Reached[0]?.ElementId||ActiveImpact.Origin.ElementId);
      SetBusy(false);
    },Failure=>{SetError((Failure.Status?Failure.Status+' · ':'')+Failure.message);SetBusy(false);});
  }

  return <div className="supply-board">
    <Heading Title="Tablero de abastecimiento" Description="De una posible falta a sus consecuencias y a la secuencia de preparación." Children={<button type="button" onClick={Refresh} disabled={Busy||Refreshing}><Icon Name="catalog"/>{Refreshing?'Actualizando…':'Actualizar catálogo'}</button>}/>
    <div className="supply-catalog-bar"><p><strong>{DisplayCatalog.Elements.length} elementos</strong><span>{DisplayCatalog.Relations.length} relaciones en tu catálogo</span></p><div className="actions"><a href="#catalog-Supplier">Abrir catálogo</a><a href="#relations">{CanEdit?'Registrar dependencia':'Consultar relaciones'}</a></div></div>
    <form onSubmit={Analyze} className="surface supply-query">
      <fieldset disabled={Busy||Refreshing}>
        <div className="supply-query-grid">
          <section className="supply-origin" aria-labelledby="SupplyOriginTitle">
            <div className="supply-section-heading"><Icon Name="search"/><div><h2 id="SupplyOriginTitle">¿Qué pasa si falta…?</h2><p>Elige un proveedor o insumo del catálogo.</p></div></div>
            <Field Label="Buscar en el catálogo"><input type="search" value={Search} onChange={Event=>SetSearch(Event.target.value)} placeholder="Nombre o código"/></Field>
            <Field Label="Elemento no disponible"><select required value={Query.ElementId} onChange={Event=>ChangeQuery({ElementId:Event.target.value})}><option value="">Selecciona un proveedor o insumo</option>{['Supplier','Material'].map(Type=><optgroup key={Type} label={Type==='Supplier'?'Proveedores':'Insumos'}>{Origins.filter(Item=>Item.ElementType===Type).map(Item=><option key={Item.ElementId} value={Item.ElementId}>{Item.Name} · {Item.ElementId}</option>)}</optgroup>)}</select></Field>
            {Origin&&<div className="supply-origin-detail"><span className="badge">{TypeLabels[Origin.ElementType]}</span><p><strong>{Origin.Name}</strong><span>{Origin.ElementId}{Origin.UnitCode?' · Unidad: '+Origin.UnitCode:''}</span></p></div>}
            <Field Label="Alcance del orden estructural" Hint="Las consecuencias se consultan en toda la red. Este filtro solo limita el orden de preparación."><select value={Query.ProductId} onChange={Event=>ChangeQuery({ProductId:Event.target.value})}><option value="">Toda la red de abastecimiento</option>{Products.map(Item=><option key={Item.ElementId} value={Item.ElementId}>{Item.Name} · {Item.ElementId}</option>)}</select></Field>
          </section>
          <section className="supply-change" aria-labelledby="SupplyChangeTitle">
            <div className="supply-section-heading"><Icon Name="relations"/><div><h2 id="SupplyChangeTitle">Probar un cambio temporal</h2><p>Compara otra configuración sin guardar modificaciones.</p></div></div>
            <Field Label="Cambio de dependencia"><select value={Query.Operation} onChange={Event=>ChangeQuery({Operation:Event.target.value,SourceId:'',TargetId:''})}><option value="None">Sin cambio de dependencias</option><option value="Add">Agregar una dependencia general</option><option value="Remove">Retirar una relación existente</option></select></Field>
            {Query.Operation==='Add'&&<>
              <Field Label="Origen: requisito"><select required value={Query.SourceId} onChange={Event=>ChangeQuery({SourceId:Event.target.value,TargetId:''})}><option value="">Selecciona el requisito</option>{Data.Elements.map(Item=><option key={Item.ElementId} value={Item.ElementId}>{Item.Name} · {TypeLabels[Item.ElementType]} · {Item.ElementId}</option>)}</select></Field>
              <Field Label="Destino: dependiente" Hint="Solo dependencias generales, sin precio ni cantidad. Los precios de proveedor y cantidades de insumo se gestionan en Relaciones."><select required value={Query.TargetId} onChange={Event=>ChangeQuery({TargetId:Event.target.value})}><option value="">Selecciona el dependiente</option>{Targets.map(Item=><option key={Item.ElementId} value={Item.ElementId}>{Item.Name} · {TypeLabels[Item.ElementType]} · {Item.ElementId}</option>)}</select></Field>
            </>}
            {Query.Operation==='Remove'&&<Field Label="Relación que se retiraría" Hint="La prueba conserva todos los elementos y no cambia tu catálogo."><select required value={Query.SourceId?Query.SourceId+'>'+Query.TargetId:''} onChange={Event=>{const [SourceId='',TargetId='']=Event.target.value.split('>');ChangeQuery({SourceId,TargetId});}}><option value="">Selecciona una relación</option>{Data.Relations.map(Edge=><option key={Edge.SourceId+'>'+Edge.TargetId} value={Edge.SourceId+'>'+Edge.TargetId}>{CatalogLookup.get(Edge.SourceId)?.Name} → {CatalogLookup.get(Edge.TargetId)?.Name} · {RelationLabels[Edge.RelationType]}</option>)}</select></Field>}
            {Source&&Target&&<div className="supply-change-description"><span className="badge">{Query.Operation==='Add'?'Se añadiría':'Se retiraría'}</span><p>Para preparar <strong>{Target.Name}</strong>, necesito <strong>{Source.Name}</strong>.</p></div>}
            {Query.Operation==='None'&&<div className="supply-change-empty"><Icon Name="graph" Size={32}/><p>Primero revisa la red actual. Después puedes probar cómo cambia el alcance al añadir o retirar una conexión.</p></div>}
            {Query.Operation!=='None'&&<button className="supply-discard" type="button" onClick={()=>ChangeQuery({Operation:'None',SourceId:'',TargetId:''})}>Descartar cambio temporal</button>}
          </section>
        </div>
        <div className="supply-run"><p><Icon Name="graph"/>Simulación de lectura. La indisponibilidad no elimina el elemento.</p><button className="primary" disabled={!Query.ElementId||Busy||Refreshing}><Icon Name="search"/>{Busy?'Analizando…':Query.Operation==='None'?'Simular indisponibilidad':'Comparar escenario'}</button></div>
      </fieldset>
    </form>
    <Notice Text={Error} Error/>
    {Busy&&<p className="supply-loading" role="status">Calculando las consecuencias y el orden de preparación de la misma red…</p>}
    {!Result&&!Busy&&!Error&&<div className="supply-start"><Icon Name="graph" Size={34}/><div><h2>Una consulta, la cadena completa.</h2><p>Selecciona qué podría faltar para ver su impacto potencial y revisar si las dependencias permiten un orden.</p></div></div>}
    {Result&&<>
      <section className="supply-result-heading" aria-live="polite"><div><span className="badge">Indisponibilidad simulada</span><h2>Si falta {Impact.Origin.Name}</h2><p><strong>{Impact.Summary.Products} {Impact.Summary.Products===1?'producto podría':'productos podrían'} verse afectados</strong> a través de {Impact.Summary.Total} {Impact.Summary.Total===1?'elemento alcanzado':'elementos alcanzados'}. El origen no se cuenta en esos totales.</p></div>{Result.Change&&<div className="supply-version-switch" role="group" aria-label="Red mostrada"><button type="button" aria-pressed={Version==='Base'} onClick={()=>SelectVersion('Base')}>Red actual</button><button type="button" aria-pressed={Version==='Scenario'} onClick={()=>SelectVersion('Scenario')}>Escenario temporal</button></div>}</section>
      <p className="supply-meaning"><Icon Name="message"/>El impacto es potencial: puede haber otros proveedores o existencias. El orden describe precedencias, no confirma que puedas producir con esta falta.</p>
      {Result.Change&&<section className="surface supply-comparison" aria-labelledby="SupplyComparisonTitle"><header><h2 id="SupplyComparisonTitle">Qué cambia en el escenario</h2><p>{Result.Change.Operation==='Add'?'Se añade':'Se retira'} la conexión <strong>{Lookup.get(Result.Change.SourceId)?.Name}</strong> → <strong>{Lookup.get(Result.Change.TargetId)?.Name}</strong>. Tu catálogo permanece igual.</p></header><div className="table-scroll"><table><caption className="sr-only">Comparación de consecuencias y orden estructural</caption><thead><tr><th scope="col">Resultado</th><th scope="col">Red actual</th><th scope="col">Escenario temporal</th></tr></thead><tbody><tr><th scope="row">Elementos alcanzados</th><td>{Result.Base.Impact.Summary.Total}</td><td>{Result.Scenario.Impact.Summary.Total}</td></tr><tr><th scope="row">Productos alcanzados</th><td>{Result.Base.Impact.Summary.Products}</td><td>{Result.Scenario.Impact.Summary.Products}</td></tr><tr><th scope="row">Orden estructural</th><td>{StatusLabels[Result.Base.Production.Status]}</td><td>{StatusLabels[Result.Scenario.Production.Status]}</td></tr><tr><th scope="row">Etapas válidas</th><td>{Result.Base.Production.Status==='Cycle'?'No hay un orden válido':Result.Base.Production.Summary.Stages}</td><td>{Result.Scenario.Production.Status==='Cycle'?'No hay un orden válido':Result.Scenario.Production.Summary.Stages}</td></tr></tbody></table></div><div className="supply-differences"><div><h3>Ahora alcanzados <span>{Result.Comparison.AddedReached.length}</span></h3>{Result.Comparison.AddedReached.length?<ul>{Result.Comparison.AddedReached.map(Id=><li key={Id}><button type="button" onClick={()=>SelectDifference(Id,'Scenario')}>{Lookup.get(Id)?.Name||Id}<span>Ver camino</span></button></li>)}</ul>:<p>No aparecen nuevos elementos alcanzados.</p>}</div><div><h3>Dejan de estar alcanzados <span>{Result.Comparison.RemovedReached.length}</span></h3>{Result.Comparison.RemovedReached.length?<ul>{Result.Comparison.RemovedReached.map(Id=><li key={Id}><button type="button" onClick={()=>SelectDifference(Id,'Base')}>{Lookup.get(Id)?.Name||Id}<span>Ver camino anterior</span></button></li>)}</ul>:<p>No se retiran elementos del alcance.</p>}</div></div></section>}
      <section ref={GraphSection} tabIndex={-1} className={'supply-graph'+(ShowingCycle?' supply-cycle-graph':'')} aria-labelledby="SupplyGraphTitle">
        <div className="supply-graph-heading"><div><h2 id="SupplyGraphTitle">{Version==='Scenario'?'La red del escenario':'La red actual'}</h2><p>{ShowingCycle?'El trazo rojo recorre la dependencia que cierra el ciclo.':'El origen tiene contorno discontinuo. El trazo ámbar explica el camino seleccionado.'}{Version==='Scenario'&&Result.Change?.Operation==='Add'?' La conexión temporal usa una línea discontinua.':''}</p></div><div className="actions"><button type="button" aria-pressed={!ShowingCycle} onClick={()=>SetGraphMode('Impact')}>Ver impacto</button>{Production.Status==='Cycle'&&<button type="button" aria-pressed={ShowingCycle} onClick={()=>SetGraphMode('Cycle')}>Ver ciclo</button>}</div></div>
        <div className="supply-graph-scope"><div className="actions" role="group" aria-label="Alcance visible del grafo"><button type="button" aria-pressed={Focused} onClick={()=>SetFocused(true)}>Enfocar conexiones</button><button type="button" aria-pressed={!Focused} onClick={()=>SetFocused(false)}>Mostrar grafo completo</button></div><p>{Focused?(ShowingCycle?'Solo los elementos y conexiones del ciclo detectado.':'El origen y toda su cadena de consecuencias, incluidos los elementos más lejanos.'):'Todos los elementos de esta versión de la red.'}</p></div>
        <Graph LayoutKey="SupplyBoard" key={Result.SnapshotId+':'+Version+':'+Impact.Origin.ElementId} Data={GraphData} InteractionKey={Result.SnapshotId+':'+Version} InitialFocus={Impact.Origin.ElementId} WholeGraph Embedded HighlightPath={Path} SelectedId={SelectedId} OnSelect={SetSelectedId}/>
        {ShowingCycle?<div className="supply-path"><strong>Ciclo:</strong><ol>{Production.Cycle.map((Id,Index)=><li key={Index}>{Index>0&&<span aria-hidden="true">→</span>}{Lookup.get(Id)?.Name||Id}</li>)}</ol><p>La cadena vuelve al mismo elemento. No existe un orden válido para el alcance seleccionado.</p></div>:Selected?<div className="supply-path"><strong>{Selected.Depth===0?'Origen de la simulación':'Camino hasta '+Selected.Name}</strong><ol>{SelectedPath.map((Id,Index)=><li key={Id}>{Index>0&&<span aria-hidden="true">→</span>}{Lookup.get(Id)?.Name||Id}</li>)}</ol><p>{Selected.Depth===0?'Este es el elemento marcado como no disponible.':'Una explicación con el menor número de relaciones; no representa un costo ni un orden de fabricación.'}</p></div>:<p className="supply-path-note">Selecciona un elemento alcanzado para explicar su conexión con la falta simulada.</p>}
      </section>
      <div className="supply-results-grid">
        <section className="surface supply-consequences" aria-labelledby="SupplyConsequencesTitle"><header><h2 id="SupplyConsequencesTitle">Consecuencias potenciales</h2><p>{Impact.Summary.Direct} directas · {Impact.Summary.Indirect} indirectas</p></header>{Impact.Reached.length?<ul>{Impact.Reached.map(Item=><li key={Item.ElementId}><div><span className="badge">{TypeLabels[Item.ElementType]}</span><strong>{Item.Name}</strong><small>{Item.ElementId} · {Item.Depth===1?'Conexión directa':Item.Depth+' relaciones desde el origen'}</small></div><button type="button" aria-pressed={SelectedId===Item.ElementId&&!ShowingCycle} aria-label={'Ver camino de '+Item.Name} onClick={()=>ShowPath(Item.ElementId)}>Ver camino</button></li>)}</ul>:<Empty Text="El elemento existe, pero no tiene otros dependientes alcanzables en esta red."/>}</section>
        <section className="supply-production" aria-labelledby="SupplyProductionTitle"><header><h2 id="SupplyProductionTitle">Orden estructural</h2><p>{Production.Scope==='Product'?'Requisitos de '+(Lookup.get(Production.ProductId)?.Name||Production.ProductId):'Toda la red de abastecimiento'}. La falta simulada no elimina requisitos.</p></header><ProductionResult Result={Production} CanEdit={CanEdit&&Version==='Base'} ShowGraph={false} OnShowCycle={ShowCycle} Simulation Compact/></section>
      </div>
    </>}
  </div>;
}
