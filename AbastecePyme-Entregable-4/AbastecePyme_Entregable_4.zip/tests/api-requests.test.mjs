import test from 'node:test';
import assert from 'node:assert/strict';
import {BuildApiRequest,GetOperationSettings,Operations} from '../frontend/src/ApiRequests.js';

test('updates preserve optimistic version and target one selected element',()=>{
  assert.deepEqual(BuildApiRequest('EditElement',{ElementId:'MAT-WOOD'},'{"Name":"Wood","Version":42}'),{
    Method:'PATCH',Path:'/api/elements/MAT-WOOD',Body:{Name:'Wood',Version:42},Writes:true
  });
});
test('element deletion uses the selected snapshot version',()=>{
  assert.deepEqual(BuildApiRequest('DeleteElement',{ElementId:'MAT-WOOD',Version:37},''),{
    Method:'DELETE',Path:'/api/elements/MAT-WOOD?Version=37',Writes:true
  });
});
test('rejects malformed JSON and missing mutation selection before execution',()=>{
  for(const Body of ['{','null','[]','"text"'])assert.throws(()=>BuildApiRequest('CreateElement',{},Body));
  assert.throws(()=>BuildApiRequest('DeleteElement',{},''));
  assert.throws(()=>BuildApiRequest('ReadSecrets',{},''));
});
test('production uses optional product scope and impact preserves direction',()=>{
  assert.equal(BuildApiRequest('Production',{},'').Path,'/api/production');
  assert.equal(BuildApiRequest('Production',{ProductId:'PROD-MESA'},'').Path,'/api/production?ProductId=PROD-MESA');
  assert.equal(BuildApiRequest('Impact',{ElementId:'MAT',Direction:'Requirements'},'').Path,'/api/impact/MAT?Direction=Requirements');
});
test('relation creation and deletion have explicit methods and JSON bodies',()=>{
  const Body='{"SourceId":"AA","TargetId":"BB","Version":2,"Value":null,"IsDemo":false}';
  assert.equal(BuildApiRequest('CreateRelation',{},Body).Method,'POST');
  assert.equal(BuildApiRequest('DeleteRelation',{},Body).Method,'DELETE');
  assert.equal(BuildApiRequest('DeleteRelation',{},Body).Body.Version,2);
});

test('supply board analysis uses a POST JSON body while remaining read-only',()=>{
  assert.deepEqual(BuildApiRequest('SupplyBoard',{},'{"ElementId":"SUP-A","ProductId":null,"Change":null}'),{
    Method:'POST',Path:'/api/dashboard/analyze',Body:{ElementId:'SUP-A',ProductId:null,Change:null},Writes:false
  });
});

test('temporary dependency changes and invalid domain values reach the analysis endpoint without becoming writes',()=>{
  const Body='{"ElementId":"MISSING","ProductId":"PROD-A","Change":{"Operation":"Add","SourceId":"AA","TargetId":"BB"}}';
  const Request=BuildApiRequest('SupplyBoard',{},Body);
  assert.equal(Request.Writes,false);
  assert.equal(Request.Body.ElementId,'MISSING');
  assert.deepEqual(Request.Body.Change,{Operation:'Add',SourceId:'AA',TargetId:'BB'});
  for(const Invalid of ['{','null','[]','"text"'])assert.throws(()=>BuildApiRequest('SupplyBoard',{},Invalid));
});

test('all catalogue mutations retain write classification and therefore require confirmation',()=>{
  const Cases=[
    ['CreateElement',{},'{"ElementId":"AA","Name":"New element","ElementType":"Product"}'],
    ['EditElement',{ElementId:'AA'},'{"Name":"Changed name","Version":2}'],
    ['DeleteElement',{ElementId:'AA',Version:2},''],
    ['CreateRelation',{},'{"SourceId":"AA","TargetId":"BB","Value":null}'],
    ['EditRelation',{},'{"SourceId":"AA","TargetId":"BB","Value":null,"Version":2}'],
    ['DeleteRelation',{},'{"SourceId":"AA","TargetId":"BB","Version":2}']
  ];
  for(const [Operation,Selection,Body] of Cases)assert.equal(BuildApiRequest(Operation,Selection,Body).Writes,true,Operation);
});

test('a viewer can choose analytical POST with a body while catalogue mutations remain excluded',()=>{
  const ReadOnly=Object.keys(Operations).filter(Operation=>!GetOperationSettings(Operation).Writes);
  assert.deepEqual(ReadOnly,['Catalog','Graph','Impact','Estimate','Production','SupplyBoard']);
  assert.equal(GetOperationSettings('SupplyBoard').HasBody,true);
  assert.equal(GetOperationSettings('Catalog').HasBody,false);
  assert.equal(GetOperationSettings('DeleteElement').HasBody,false);
});
