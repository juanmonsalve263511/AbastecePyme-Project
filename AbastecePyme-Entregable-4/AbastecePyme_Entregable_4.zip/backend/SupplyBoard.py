"""Read-only scenario comparison using the existing BFS, Kahn and iterative DFS.

Unavailability means potential impact, not deletion of a prerequisite or a
claim about inventory. Dependency changes live only in this call's copy.
"""
import hashlib
import json
from fastapi import HTTPException
from backend.Impact import AnalyzeImpact
from backend.Production import BuildProductionPlan


def AnalyzeScenario(Elements, Relations, ElementId, ProductId, IncludePaths=True):
    try:
        Production = BuildProductionPlan(Elements, Relations, ProductId)
    except ValueError:
        raise HTTPException(422, "Revisa la validez de los elementos y las dependencias del catálogo.") from None
    return {"Impact": AnalyzeImpact(ElementId, Elements, Relations, "Consequences", IncludePaths=IncludePaths),
            "Production": Production}


def CompactScenario(Scenario):
    """Share catalog element bodies and Python's predecessor tree on the wire."""
    Impact = {Key: Value for Key, Value in Scenario["Impact"].items() if Key != "Reached"}
    Production = dict(Scenario["Production"])
    for Analysis in (Impact, Production):
        Graph = Analysis["Graph"]
        Analysis["Graph"] = {"ElementIds": [Item["ElementId"] for Item in Graph["Elements"]],
                             "Relations": Graph["Relations"]}
    return {"Impact": Impact, "Production": Production}


def BuildSupplyBoard(Data, Body):
    Catalog = {"Elements": [dict(Item) for Item in Data["Elements"]],
               "Relations": [dict(Edge) for Edge in Data["Relations"]]}
    Mapping = {Item["ElementId"]: Item for Item in Catalog["Elements"]}
    if Body.ElementId not in Mapping:
        raise HTTPException(404, "Elemento no encontrado. Actualiza el catálogo y vuelve a simular.")
    if Body.ProductId is not None:
        if Body.ProductId not in Mapping:
            raise HTTPException(404, "Producto no encontrado. Actualiza el catálogo.")
        if Mapping[Body.ProductId]["ElementType"] != "Product":
            raise HTTPException(422, "Selecciona un producto para organizar su preparación.")

    ScenarioRelations = [dict(Edge) for Edge in Catalog["Relations"]]
    Change = Body.Change.model_dump() if Body.Change is not None else None
    if Change is not None:
        SourceId, TargetId = Change["SourceId"], Change["TargetId"]
        if SourceId not in Mapping or TargetId not in Mapping:
            raise HTTPException(404, "Un extremo de la dependencia no existe. Actualiza el catálogo.")
        Exists = any(Edge["SourceId"] == SourceId and Edge["TargetId"] == TargetId for Edge in ScenarioRelations)
        if Change["Operation"] == "Add":
            if Exists:
                raise HTTPException(409, "La dependencia ya existe en el catálogo.")
            Pair = (Mapping[SourceId]["ElementType"], Mapping[TargetId]["ElementType"])
            if Pair in (("Supplier", "Material"), ("Material", "Product")):
                raise HTTPException(422, "Esta conexión requiere un precio o una cantidad. La simulación solo añade dependencias generales.")
            ScenarioRelations.append({"SourceId": SourceId, "TargetId": TargetId,
                                      "RelationType": "General", "Value": None, "IsDemo": False,
                                      "Version": None, "IsSimulation": True})
        else:
            if not Exists:
                raise HTTPException(404, "La dependencia que quieres retirar no existe en el catálogo.")
            ScenarioRelations = [Edge for Edge in ScenarioRelations
                                 if (Edge["SourceId"], Edge["TargetId"]) != (SourceId, TargetId)]

    Compact = Body.ResponseFormat == "Compact"
    Base = AnalyzeScenario(Catalog["Elements"], Catalog["Relations"], Body.ElementId, Body.ProductId, IncludePaths=not Compact)
    Scenario = (AnalyzeScenario(Catalog["Elements"], ScenarioRelations, Body.ElementId, Body.ProductId, IncludePaths=not Compact)
                if Change is not None else Base)
    BaseReached = {Item["ElementId"] for Item in Base["Impact"]["Reached"]}
    ScenarioReached = {Item["ElementId"] for Item in Scenario["Impact"]["Reached"]}
    Canonical = {"Elements": sorted(Catalog["Elements"], key=lambda Item: Item["ElementId"]),
                 "Relations": sorted(Catalog["Relations"], key=lambda Edge: (Edge["SourceId"], Edge["TargetId"]))}
    SnapshotId = hashlib.sha256(json.dumps(Canonical, sort_keys=True, ensure_ascii=False,
                                          separators=(",", ":")).encode("utf-8")).hexdigest()
    Result = {"Catalog": Catalog, "Base": Base, "Scenario": Scenario, "Change": Change,
            "Comparison": {"AddedReached": sorted(ScenarioReached - BaseReached),
                           "RemovedReached": sorted(BaseReached - ScenarioReached),
                           "ProductionStatusBefore": Base["Production"]["Status"],
                           "ProductionStatusAfter": Scenario["Production"]["Status"]},
            "SnapshotId": SnapshotId}
    if Compact:
        Result.update(ResponseFormat="Compact", Base=CompactScenario(Base),
                      Scenario=CompactScenario(Scenario) if Change is not None else None)
    return Result
