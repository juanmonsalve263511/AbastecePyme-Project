# Catálogo, precios y presentación — 2 de noviembre de 2026

## Cambios visibles

- Se retiraron los avisos académicos y de demostración de la interfaz, el pie de página y las subpáginas. La portada muestra **Red de producción**.
- Las relaciones usan **Precio de referencia** y **Cantidad de referencia**. Los valores introducidos como no referenciales se muestran como registrados. Se conserva internamente `IsDemo` por compatibilidad con la API existente.
- **Catálogo → Productos** incluye **Precio (COP)**. Editor y Administrador pueden cambiarlo desde **Editar → Precio de venta (COP)**, o mediante la API. El precio de venta es independiente de la estimación del costo de materiales.
- Un campo vacío significa **Por definir**; cero es un precio válido y se muestra como cero. Los importes inventados solicitados por el usuario se identifican como precios de referencia.

## Ampliación aplicada

Se agregaron 5 proveedores, 21 ofertas alternativas, 3 componentes de fabricación, 7 requisitos de insumos y 8 dependencias generales. El catálogo queda con 48 elementos y 128 relaciones: 14 proveedores, 17 insumos y 17 productos/componentes. Todos los insumos tienen al menos dos proveedores; madera y tornillos tienen tres. Los 17 productos tienen precios de venta en COP.

Las dependencias generales indican que una estructura, un módulo de cajón o una puerta ensamblada deben estar preparados antes del producto que los necesita. No llevan cantidades ni precios. La red completa es acíclica y produce cuatro etapas. Las ofertas son alternativas de compra, no una obligación de comprar a todos los proveedores.

Los registros y pesos anteriores se conservaron. El archivo inicial `data/catalogo.json` mantiene sus bytes y su huella originales. La ampliación se aplica en una transacción con un registro de migración: ejecutarla otra vez no duplica datos ni reemplaza las ediciones posteriores.

## Instalar esta ampliación en otra copia

Después de instalar y configurar la base, ejecuta **AmpliarCatalogo.cmd**. Solicita la contraseña de MariaDB de forma oculta y no la guarda. El arranque normal no agrega registros automáticamente. Si ya aplicaste la ampliación, informa `AlreadyApplied`.

Después de actualizar el código, vuelve a iniciar la aplicación con **Iniciar.cmd --port 3001** en esta instalación. En otras instalaciones puedes usar el puerto predeterminado 3000. Recarga el navegador para obtener la interfaz actualizada.

## Contrato del precio

`POST /api/elements` admite `SalePrice` (cadena decimal o null) e `IsPriceReference` (booleano) únicamente para productos. `PATCH /api/elements/{ElementId}` admite esos campos y exige `Version` actual. Omitir `SalePrice` conserva el valor; enviarlo como null lo elimina. Los importes admiten hasta 16 dígitos enteros y 2 decimales, sin conversión a número binario en el cliente. Los errores y permisos siguen el contrato del resto del catálogo.

`ProductPrices` guarda una fila por producto con FK a `Products`. La versión del elemento controla conjuntamente sus datos y su precio. La eliminación del producto también elimina su precio dentro de la misma transacción.

## Verificación

48 pruebas Python, 37 pruebas Node y 15 pruebas de integración con MariaDB aprobadas; una prueba de último administrador se omite para no alterar la cuenta permanente. Se verificaron importes exactos, edición, borrado del precio, conflictos de versión, perfiles, conservación de datos y repetición de la ampliación. La API en ejecución respondió 200 al catálogo y al orden de Estante modular; un usuario Consulta recibió 403 al intentar editar un precio. Las cuentas temporales de prueba se eliminaron.

El navegador se comprobó con una copia en memoria del catálogo: columna y formulario de precio, guardado y etiquetas de relaciones. Las pruebas de esa copia no modifican MariaDB. La portada se verifica además en la aplicación real.

Skills aplicadas: planificación y ejecución de cambios; desarrollo guiado por pruebas; `vercel-react-best-practices` para mantener patrones de React; `computer-use` para revisión visual; revisión de código y verificación antes de completar. Se utilizaron las skills ya disponibles, sin instalar dependencias nuevas.
