# Contacto y experiencia visual

Actualización: 2 de noviembre de 2026.

## Cómo usar Contacto

Desde la portada, abre **Contacto**. Completa nombre, correo, tema y un mensaje de 20 a 2.000 caracteres. Celular y empresa son opcionales. Autoriza el almacenamiento de tus datos y pulsa **Enviar solicitud**. Los tres indicadores muestran tu avance. Los términos se abren en otra pestaña para conservar el formulario.

La confirmación muestra una referencia única después de guardar correctamente. Si ocurre un error, el formulario conserva los valores para corregirlos o reintentar. No se envían correos, mensajes de texto ni notificaciones externas.

## Consultar las solicitudes

Inicia sesión con un administrador y abre **Solicitudes de contacto** en el menú lateral. Selecciona un mensaje para ver nombre, correo, celular, empresa y solicitud. Puedes marcarlo como leído; esto no envía una respuesta. La bandeja muestra 20 solicitudes por página, de más recientes a más antiguas. Las fechas se presentan en hora de Colombia. Los perfiles Editor y Consulta no tienen acceso.

La nueva tabla `ContactRequests` se crea automáticamente al iniciar el servidor actualizado. Guarda un identificador, los campos del formulario, la versión del consentimiento, fecha UTC de creación y fecha de lectura. No modifica el catálogo ni las cuentas existentes. Los datos personales no se incluyen en el paquete para GitHub.

## Ubicación y canales

Centro de Negocios One Plaza, Torre Norte, piso 3. Carrera 43A #5A-113, El Poblado, Medellín, Colombia. Celular: **311 335 2866**. Se muestran en Contacto, la portada, Locaciones y el pie de las páginas públicas. El celular abre la aplicación de llamadas; el mapa abre otra pestaña solo al pulsarlo.

La dirección de calle se contrastó con el [directorio del Centro Empresarial One Plaza](https://es.cybo.com/CO-biz/centro-empresarial-one-plaza) y la [referencia de un establecimiento del edificio](https://directoriomedellin.com.co/medellin/establecimiento-comercial/blankfactor/). Torre, piso de atención y teléfono corresponden a la información suministrada por el propietario del proyecto.

Para cambiar los datos compartidos por estas páginas, edita `frontend/src/BusinessInfo.js`; la descripción complementaria de Locaciones está en `PublicPages.jsx`.

## Imágenes y movimiento

La portada incorpora escenas de fabricación y abastecimiento, aparición de secciones al entrar en pantalla y un desplazamiento fotográfico suave en navegadores compatibles. Contacto y Resumen reutilizan estos recursos. No se añadieron bibliotecas de animación ni algoritmos de grafos externos.

Los efectos respetan la preferencia de movimiento reducido del sistema y el control **Reducir movimiento** al pie de la página. Las imágenes se cargan de forma diferida y conservan dimensiones explícitas para evitar saltos. Sin soporte de IntersectionObserver, el contenido sigue visible. No hay fotografías remotas ni mapas incrustados que carguen terceros automáticamente.

Las dos fotografías conceptuales se generaron con la herramienta integrada de generación de imágenes, en modo de creación nueva. No representan las instalaciones reales de One Plaza. Archivos incluidos:

- `frontend/public/images/workshop-{640,960,1536}.webp`: taller de mobiliario con artesano y estructura de madera.
- `frontend/public/images/materials-{640,960,1536}.webp`: área organizada de maderas, herrajes y textiles. Las variantes WebP sustituyen la entrega PNG desde la revisión del 6 de noviembre de 2026.

Dirección visual de ambos prompts: fotografía editorial profesional, azul oscuro, azul pálido, gris y madera natural; luz arquitectónica, materiales creíbles, sin marcas, texto ni logotipos. El primer prompt solicitó un taller colombiano contemporáneo con un artesano revisando una estructura de roble; el segundo, una zona de abastecimiento sin personas, con estantes azules y líneas de profundidad. No se utilizaron fotografías de referencia.

## API

- `POST /api/contact-requests`: público, JSON, mismo origen y consentimiento obligatorio. Crea una solicitud y devuelve solo referencia y confirmación.
- `GET /api/contact-requests?Limit=20&Offset=0`: solo administradores; incluye total y registros de la página. Límite máximo: 100.
- `PATCH /api/contact-requests/{RequestId}/read`: solo administradores con sesión y protección CSRF. Marcado idempotente.

Los campos se validan en Python; se rechazan propiedades desconocidas y valores inválidos. El envío tiene un límite de diez intentos válidos por minuto y dirección de cliente. Los textos se muestran como texto, nunca como HTML.

## Verificación

Se comprobaron el guardado real en MariaDB, lectura restringida, marcado como leído, limpieza de registros de prueba, envío completo en navegador aislado, vista de celular y compilación de producción. Las pruebas automáticas incluyen validación, consentimiento, aislamiento de permisos, CSRF, paginación y límite de solicitudes. Las pruebas temporales no dejan usuarios ni mensajes en la base del usuario. Resultado: 53 pruebas Python, 37 JavaScript y 15 de integración MariaDB aprobadas; una prueba de último administrador se omite en la base con administrador permanente. Se verificó además el flujo HTTP real de contacto y las dos imágenes. Revisión visual a 390 px sin desbordamiento horizontal; movimiento reducido deja todo el contenido visible y desactiva la animación de las imágenes.

Skills utilizadas para esta actualización: brainstorming (definición del alcance), frontend-design (composición visual), imagegen (imágenes originales), vercel-react-best-practices (componentes y carga diferida), verification-before-completion (comprobación del resultado), requesting-code-review (revisión independiente) y computer-use (validación visual y funcional).
