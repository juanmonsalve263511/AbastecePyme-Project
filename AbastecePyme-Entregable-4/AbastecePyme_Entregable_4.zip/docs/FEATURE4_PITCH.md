# Pitch — AbastecePyme, Feature 4

Fecha: **14 de noviembre de 2026**. Duración prevista al leerlo con pausas: **60–90 segundos**.

## Texto para presentar

Cuando un proveedor se retrasa, una pequeña fábrica necesita responder tres preguntas: qué depende de él, qué productos podrían verse afectados y por dónde empezar a preparar la producción.

AbastecePyme reúne esas respuestas en un tablero. Primero registramos una dependencia y explicamos su dirección: para preparar el producto, necesito su requisito. Después elegimos un proveedor o insumo y simulamos su indisponibilidad. La aplicación muestra las consecuencias potenciales y destaca el camino que conecta el origen con cada resultado.

En el mismo análisis vemos un orden de preparación que respeta los requisitos. Si las relaciones se contradicen, aparece el ciclo que provoca el problema y no se ofrece una secuencia falsa.

También podemos comparar un cambio temporal: añadir o retirar una dependencia y observar cómo varían el impacto y el orden, sin guardar ese ensayo en el catálogo.

El alcance es concreto: organizamos dependencias; no afirmamos conocer inventario, disponibilidad real ni fechas de entrega. Los precios de referencia conservan su identificación.

La demostración incluye una cadena válida, un elemento inexistente, un dato inválido y un ciclo. El resultado es una explicación revisable para que compras y producción decidan con mayor claridad.

## Apoyo para la presentación

- [Presentación visual del pitch](media/Feature4-Pitch.html).
- [Recorrido de la aplicación](media/Feature4-Recorrido.webm).
- [Criterios de aceptación y límites](FEATURE4.md).

Para abrir la presentación, descarga o descomprime el proyecto y abre **docs/media/Feature4-Pitch.html** con tu navegador. Si GitHub muestra su código al pulsar el enlace, utiliza el archivo descargado. El video se entrega como archivo WebM independiente.

El texto anterior es el guion terminado. La existencia y validación de los archivos de apoyo se registran por separado en [la evidencia del video](FEATURE4_VIDEO.md); el guion no sustituye una grabación.
