import {useEffect,useRef} from 'react';

// Visible by default: an unavailable observer must never conceal content.
export default function Reveal({children,ClassName='',As:Tag='div'}){
  const Ref=useRef(null);
  useEffect(()=>{
    const Element=Ref.current;
    if(!Element||!window.IntersectionObserver)return;
    const Preference=window.matchMedia('(prefers-reduced-motion: reduce)');
    if(Preference.matches||document.documentElement.dataset.reducedMotion==='true')return;
    if(Element.getBoundingClientRect().top<window.innerHeight*.94)return;
    const Observer=new IntersectionObserver(Entries=>{
      if(Entries.some(Entry=>Entry.isIntersecting)){
        Element.dataset.reveal='visible';Observer.disconnect();
      }
    },{threshold:0,rootMargin:'0px 0px -32px 0px'});
    Element.dataset.reveal='pending';Observer.observe(Element);
    return()=>{Observer.disconnect();delete Element.dataset.reveal;};
  },[]);
  return <Tag ref={Ref} className={'reveal '+ClassName}>{children}</Tag>;
}
