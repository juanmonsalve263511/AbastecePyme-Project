import test from 'node:test';
import assert from 'node:assert/strict';
import {BuildCatalogIndex,SelectCatalogItems,ReadCatalogOptions,WriteCatalogOptions,CompareDecimalValues} from '../frontend/src/components/CatalogFilters.js';

const Product=(ElementId,Costs)=>Object.freeze({ElementId,Name:ElementId,ElementType:'Product',ProductCosts:Costs});
const Data=Object.freeze({Elements:Object.freeze([
  {ElementId:'S1',Name:'Proveedor',ElementType:'Supplier'},
  {ElementId:'M1',Name:'Insumo con oferta gratuita',ElementType:'Material'},
  {ElementId:'M2',Name:'Insumo sin oferta',ElementType:'Material'},
  Product('READY',{Status:'Ready',IsComplete:true,MinimumCost:'0.00',SalePrice:'0.00',IsDemo:false}),
  Product('REFERENCE',{Status:'Ready',IsComplete:true,MinimumCost:'10.00',SalePrice:'12.50',IsDemo:true}),
  Product('PENDING',{Status:'Incomplete',IsComplete:false,MinimumCost:null,SalePrice:null,IsDemo:true}),
  Product('CYCLE',{Status:'Cycle',IsComplete:false,MinimumCost:null,SalePrice:null,IsDemo:false}),
  Product('UNAVAILABLE',undefined)
]),Relations:Object.freeze([{SourceId:'S1',TargetId:'M1',RelationType:'Offer',Value:'0.00'},{SourceId:'M1',TargetId:'READY',RelationType:'Requirement',Value:'1.0000'}])});
const Ids=Items=>Items.map(Item=>Item.ElementId);

test('catalogue filters distinguish incomplete costs, cycles, reference data and materials without offers',()=>{
  const Index=BuildCatalogIndex(Data);
  assert.deepEqual(Ids(SelectCatalogItems(Index,'Product',{Filter:'Incomplete'})),['PENDING','UNAVAILABLE']);
  assert.deepEqual(Ids(SelectCatalogItems(Index,'Product',{Filter:'Cycle'})),['CYCLE']);
  assert.deepEqual(Ids(SelectCatalogItems(Index,'Product',{Filter:'Reference'})),['PENDING','REFERENCE']);
  assert.deepEqual(Ids(SelectCatalogItems(Index,'Material',{Filter:'NoOffers'})),['M2']);
  assert.equal(Index.RelationCounts.get('READY'),1);
  assert.equal(Index.ByType.Product.length,5);
  assert.deepEqual(Ids(Index.Attention.NoOffers),['M2']);
});

test('name and code search combine with a filter and keep source lists unchanged',()=>{
  const Index=BuildCatalogIndex(Data),Before=Ids(Data.Elements);
  assert.deepEqual(Ids(SelectCatalogItems(Index,'Product',{Filter:'Reference',Search:'  refER  '})),['REFERENCE']);
  assert.deepEqual(Ids(SelectCatalogItems(Index,'Product',{Filter:'Cycle',Search:'READY'})),[]);
  assert.deepEqual(Ids(SelectCatalogItems(Index,'Product',{Sort:'NameDesc'})),['UNAVAILABLE','REFERENCE','READY','PENDING','CYCLE']);
  assert.deepEqual(Ids(Data.Elements),Before);
});

test('decimal ordering preserves large amounts, leading zeros and fractional differences without Number coercion',()=>{
  assert.equal(CompareDecimalValues('9999999999999999.98','9999999999999999.99'),-1);
  assert.equal(CompareDecimalValues('00012.5000','12.5'),0);
  assert.equal(CompareDecimalValues('0.0001','0.00009'),1);
  assert.equal(CompareDecimalValues('9.99','10.00'),-1);
  assert.equal(CompareDecimalValues(null,'0.00'),1);
  assert.equal(CompareDecimalValues(null,'0.00',true),1);
});

test('cost and sale sorting keep zero valid and absent totals last in either direction',()=>{
  const Entries=[Product('MISSING',{MinimumCost:null,SalePrice:null}),Product('HIGH',{MinimumCost:'9999999999999999.99',SalePrice:'10.02'}),Product('LOW',{MinimumCost:'9999999999999999.98',SalePrice:'10.01'}),Product('ZERO',{MinimumCost:'0.00',SalePrice:'0.00'})];
  const Index=BuildCatalogIndex({Elements:Entries,Relations:[]});
  assert.deepEqual(Ids(SelectCatalogItems(Index,'Product',{Sort:'CostAsc'})),['ZERO','LOW','HIGH','MISSING']);
  assert.deepEqual(Ids(SelectCatalogItems(Index,'Product',{Sort:'CostDesc'})),['HIGH','LOW','ZERO','MISSING']);
  assert.deepEqual(Ids(SelectCatalogItems(Index,'Product',{Sort:'SaleDesc'})),['HIGH','LOW','ZERO','MISSING']);
});

test('dashboard filter links round-trip through validated query options and invalid routes fall back safely',()=>{
  for(const [Type,Filter] of [['Product','Incomplete'],['Product','Cycle'],['Product','Reference'],['Material','NoOffers']]){
    const Query=WriteCatalogOptions(Type,{Filter});
    assert.deepEqual(ReadCatalogOptions(Type,Query),{Filter,Sort:'NameAsc'});
  }
  assert.deepEqual(ReadCatalogOptions('Supplier','filter=Cycle&sort=CostDesc'),{Filter:'All',Sort:'NameAsc'});
  assert.deepEqual(ReadCatalogOptions('Product','filter=NoOffers&sort=unknown'),{Filter:'All',Sort:'NameAsc'});
  assert.deepEqual(ReadCatalogOptions('Product','filter=Reference&sort=SaleAsc'),{Filter:'Reference',Sort:'SaleAsc'});
  assert.equal(WriteCatalogOptions('Product',{Filter:'All',Sort:'NameAsc'}),'');
});
