import {useEffect,useState} from 'react';
let SoundContext;
function ReadPreference(Key){try{return localStorage.getItem('AbastecePyme.'+Key)==='true';}catch{return false;}}
export function PrepareSound(){
  if(!ReadPreference('Sound'))return;
  try{const Audio=window.AudioContext||window.webkitAudioContext;if(Audio){SoundContext??=new Audio();SoundContext.resume().catch(()=>{});}}catch{/* Audio support is optional. */}
}
export function PlaySessionSound(Action){
  if(!ReadPreference('Sound')||SoundContext?.state!=='running')return;
  const Notes=Action==='Login'?[523.25,659.25]:[659.25,523.25];
  Notes.forEach((Frequency,Index)=>{
    const Oscillator=SoundContext.createOscillator();const Gain=SoundContext.createGain();
    const Start=SoundContext.currentTime+Index*.09;
    Oscillator.type='sine';Oscillator.frequency.value=Frequency;
    Gain.gain.setValueAtTime(0,Start);Gain.gain.linearRampToValueAtTime(.035,Start+.025);Gain.gain.exponentialRampToValueAtTime(.0001,Start+.23);
    Oscillator.connect(Gain);Gain.connect(SoundContext.destination);Oscillator.start(Start);Oscillator.stop(Start+.25);
    Oscillator.onended=()=>{Oscillator.disconnect();Gain.disconnect();};
  });
}
export function Preferences(){
  const [Sound,SetSound]=useState(()=>ReadPreference('Sound'));
  const [Motion,SetMotion]=useState(()=>ReadPreference('ReducedMotion'));
  useEffect(()=>{document.documentElement.dataset.reducedMotion=String(Motion);},[Motion]);
  function Change(Key,Value){try{localStorage.setItem('AbastecePyme.'+Key,String(Value));}catch{/* Preference still works for this view. */}if(Key==='Sound'){SetSound(Value);if(Value){PrepareSound();}}else SetMotion(Value);}
  return <div className="experience-settings" aria-label="Preferencias de experiencia"><button type="button" aria-pressed={Sound} onClick={()=>Change('Sound',!Sound)}>Sonidos: {Sound?'activados':'desactivados'}</button><button type="button" aria-pressed={Motion} onClick={()=>Change('ReducedMotion',!Motion)}>Reducir movimiento: {Motion?'sí':'no'}</button></div>;
}
