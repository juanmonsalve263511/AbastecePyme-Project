const Names=new Intl.Collator('es',{sensitivity:'base',numeric:true});
export const CatalogFilterOptions={
  Supplier:[['All','Todos los proveedores']],
  Material:[['All','Todos los insumos'],['NoOffers','Sin ofertas de proveedor']],
  Product:[['All','Todos los productos'],['Incomplete','Costo incompleto'],['Cycle','Con ciclo de dependencias'],['Reference','Con datos de referencia']]
};
const NameSorts=[['NameAsc','Nombre: A a Z'],['NameDesc','Nombre: Z a A']];
export function CatalogSortOptions(Type){
  return Type==='Product'?[...NameSorts,['CostAsc','Costo: menor a mayor'],['CostDesc','Costo: mayor a menor'],['SaleAsc','Venta: menor a mayor'],['SaleDesc','Venta: mayor a menor']]:NameSorts;
}
function NormalizeOptions(Type,{Filter='All',Sort='NameAsc'}={}){
  return {Filter:CatalogFilterOptions[Type]?.some(([Value])=>Value===Filter)?Filter:'All',Sort:CatalogSortOptions(Type).some(([Value])=>Value===Sort)?Sort:'NameAsc'};
}
export function ReadCatalogOptions(Type,QueryString=''){
  const Params=new URLSearchParams(QueryString);
  return NormalizeOptions(Type,{Filter:Params.get('filter'),Sort:Params.get('sort')});
}
export function WriteCatalogOptions(Type,Options){
  const {Filter,Sort}=NormalizeOptions(Type,Options),Params=new URLSearchParams();
  if(Filter!=='All')Params.set('filter',Filter);
  if(Sort!=='NameAsc')Params.set('sort',Sort);
  return Params.toString();
}
function CompareNames(Left,Right){return Names.compare(Left.Name,Right.Name)||Names.compare(Left.ElementId,Right.ElementId);}

export function BuildCatalogIndex(Data){
  const ByType={Supplier:[],Material:[],Product:[]},RelationCounts=new Map(),OfferTargets=new Set();
  const Attention={Incomplete:[],Cycle:[],Reference:[],NoOffers:[]};
  for(const Relation of Data.Relations){
    RelationCounts.set(Relation.TargetId,(RelationCounts.get(Relation.TargetId)||0)+1);
    if(Relation.RelationType==='Offer')OfferTargets.add(Relation.TargetId);
  }
  for(const Item of Data.Elements){
    ByType[Item.ElementType]?.push(Item);
    if(Item.ElementType==='Product'){
      if(!Item.ProductCosts||Item.ProductCosts.Status==='Incomplete')Attention.Incomplete.push(Item);
      if(Item.ProductCosts?.Status==='Cycle')Attention.Cycle.push(Item);
      if(Item.ProductCosts?.IsDemo)Attention.Reference.push(Item);
    }else if(Item.ElementType==='Material'&&!OfferTargets.has(Item.ElementId))Attention.NoOffers.push(Item);
  }
  for(const Items of Object.values(Attention))Items.sort(CompareNames);
  return {ByType,RelationCounts,Attention};
}

// API amounts are nonnegative decimal strings. Compare digits without rounding.
export function CompareDecimalValues(Left,Right,Descending=false){
  if(Left==null)return Right==null?0:1;
  if(Right==null)return -1;
  const [LeftInteger,LeftFraction='']=String(Left).split('.');
  const [RightInteger,RightFraction='']=String(Right).split('.');
  const A=LeftInteger.replace(/^0+(?=\d)/,''),B=RightInteger.replace(/^0+(?=\d)/,'');
  let Comparison=A.length===B.length?(A===B?0:A<B?-1:1):(A.length<B.length?-1:1);
  if(!Comparison){
    const Length=Math.max(LeftFraction.length,RightFraction.length),AF=LeftFraction.padEnd(Length,'0'),BF=RightFraction.padEnd(Length,'0');
    Comparison=AF===BF?0:AF<BF?-1:1;
  }
  return Descending?-Comparison:Comparison;
}

export function SelectCatalogItems(Index,Type,Options={}){
  const {Filter,Sort}=NormalizeOptions(Type,Options),Query=(Options.Search||'').trim().toLocaleLowerCase();
  const Source=Filter==='All'?Index.ByType[Type]:Index.Attention[Filter];
  const Items=(Source||[]).filter(Item=>(Item.Name+' '+Item.ElementId).toLocaleLowerCase().includes(Query));
  const Field=Sort.startsWith('Cost')?'MinimumCost':Sort.startsWith('Sale')?'SalePrice':null;
  const Descending=Sort.endsWith('Desc');
  return Items.sort((Left,Right)=>Field
    ?CompareDecimalValues(Left.ProductCosts?.[Field],Right.ProductCosts?.[Field],Descending)||CompareNames(Left,Right)
    :(Descending?-1:1)*CompareNames(Left,Right));
}
