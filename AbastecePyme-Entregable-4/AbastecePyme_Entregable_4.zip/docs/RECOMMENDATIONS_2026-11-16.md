# Propuestas de mejora de AbastecePyme — 16 de noviembre de 2026

**Estado actualizado: alcance de legibilidad, filtros y rendimiento aprobado.** La implementación de ese alcance se documenta en [Cambios y mediciones](READABILITY_PERFORMANCE_2026-11-16.md). El resto de propuestas sigue pendiente. Las observaciones y cifras de este informe conservan su condición de línea base anterior a la implementación.

La recomendación es conservar la identidad azul y gris, facilitar las decisiones cotidianas y medir el trabajo innecesario antes de ampliar la tecnología. Se contrastaron **18 fuentes oficiales de 12 dominios**, consultadas el **16 de noviembre de 2026**. No todas fueron publicadas en 2026: el rediseño citado de Linear es del 12 de marzo de 2026; el sistema de movimiento de Material procede de mayo de 2025; la versión normativa de WCAG consultada está fechada el 12 de diciembre de 2024. La documentación de Odoo citada corresponde expresamente a su versión 19.0.

## Alcance y límites de la evidencia

- Las capturas de portada y contacto corresponden a la instalación local habitual. Se inspeccionaron escritorio y portada móvil; no se envió una solicitud de contacto como parte de esta revisión visual.
- Las comprobaciones de catálogo, costos y grafos utilizaron datos sintéticos en una instancia aislada. No prueban los costos de la base MariaDB del negocio.
- En la portada móvil se observó un viewport de 390 × 844 y un área de contenido de 375 píxeles: `scrollWidth == clientWidth == 375` en esa vista. Esto demuestra ausencia de desborde horizontal en el caso observado, no en todas las pantallas posibles.
- No se ha realizado una auditoría WCAG completa, una medición de Core Web Vitals con usuarios reales, un estudio de conversión ni una prueba de carga de producción.
- Las cifras del backend de este documento son mediciones sintéticas. No representan latencia de MariaDB, de la red o de una sesión real.
- Los esfuerzos son estimaciones iniciales para una persona familiarizada con el proyecto, incluyendo revisión y comprobaciones pertinentes. No son compromisos de plazo y no deben sumarse sin considerar dependencias.

## Recorrido visual observado

### 1. Entender el producto desde la portada

La marca, los colores, la tipografía y el dibujo de conexiones forman una identidad coherente. La portada explica el concepto de una red de abastecimiento y ofrece acceso a la sesión. La ilustración es conceptual: no permite ver todavía cómo se selecciona un producto, se compara su costo o se detecta un ciclo en la herramienta real.

![Portada de escritorio: identidad azul y gris e ilustración conceptual de la red](media/review-2026-11-16/01-home-desktop.jpg)

**Propuesta R02:** añadir una vista breve de la aplicación con datos sintéticos identificados como ejemplo, una leyenda sencilla y un recorrido de tres acciones. Puede ocupar una sección posterior al encabezado; no exige sustituir la ilustración ni añadir video automático. La utilidad se comprobaría pidiendo a personas ajenas al proyecto que expliquen qué podrán hacer después de verla. No se presupone una mejora de conversión.

### 2. Encontrar dónde solicitar ayuda

La página de contacto mantiene la identidad y presenta una introducción amplia. En la captura de escritorio, el encabezado y los espacios iniciales desplazan los primeros campos del formulario por debajo del área inicialmente visible. Esto añade desplazamiento antes de empezar, aunque la sección de ayuda se alcanza con facilidad al continuar.

![Contacto de escritorio: encabezado amplio antes del formulario](media/review-2026-11-16/02-contact-desktop.jpg)

**Propuesta R03:** reducir la altura introductoria y acercar el inicio del formulario, conservando la ubicación y el teléfono publicados. Mantener visibles los campos obligatorios, el consentimiento y el resultado del envío. No eliminar contenido necesario ni prometer respuesta por correo: el envío automático de correos sigue fuera del alcance actual.

### 3. Completar el formulario

La captura cercana muestra etiquetas claras, campos obligatorios identificados y un foco visual destacado. Son bases que conviene preservar al compactar la página. La captura no demuestra por sí sola navegación completa por teclado, anuncio de errores o calidad del flujo de envío.

![Formulario de contacto: etiquetas visibles y foco en el campo de nombre](media/review-2026-11-16/03-contact-form.jpg)

La aceptación de R03 debe comprobar que una persona pueda encontrar el primer campo, corregir un dato inválido y comprender el estado final, sin perder información al reorganizar el diseño. El indicador visual de etapas debe corresponder claramente a la organización real del formulario.

### 4. Leer y navegar desde un teléfono

La portada se reorganiza sin desborde horizontal en el caso medido. El título y las llamadas a la acción conservan jerarquía. Los enlaces superiores tienen una presencia visual pequeña; hace falta medir su área táctil y observar uso real antes de calificarlos como un problema de accesibilidad.

![Portada móvil: contenido adaptado al ancho y navegación superior compacta](media/review-2026-11-16/04-home-mobile.jpg)

En el grafo con datos sintéticos se observó un panel lateral con desplazamiento propio y textos de nodos que se reducen al mostrar más red. **Propuesta R04:** evaluar tamaño útil, zoom, separación entre gráfico y detalle y continuidad del foco. La observación no constituye un incumplimiento WCAG demostrado. Se deben conservar selección, camino, pesos, pausa y preferencia de movimiento reducido.

## Matriz de propuestas

P1 significa primera fase recomendada tras aprobación; P2, mejora posterior; P3, ampliación de negocio. Todas las filas están pendientes de aprobación. R02–R04 son propuestas derivadas de las capturas; R09–R10 incorporan evidencia sintética del código.

| ID / prioridad | Estado actual | Propuesta | Valor esperado | Esfuerzo estimado | Riesgos y condiciones |
|---|---|---|---|---|---|
| R01 · P1 | Identidad coherente; variables y ajustes visuales repartidos entre hojas de estilo. | Consolidar colores, tamaños, espacios y estados; unificar encabezados y acciones. | Consistencia y menos regresiones al modificar pantallas. | 1–3 días | Mantener azul/gris y contraste; evitar otra capa de estilos sobre las existentes. |
| R02 · P1 | La portada explica la idea mediante una ilustración. | Añadir una vista real de la herramienta y un recorrido breve con datos de ejemplo. | Comprender la utilidad antes de iniciar sesión. | 1–2 días | No mostrar datos privados ni presentar ejemplos como resultados comerciales. |
| R03 · P1 | Contacto con introducción alta; etiquetas y foco claros. | Acercar los primeros campos y simplificar la presentación del recorrido. | Menos desplazamiento y mayor claridad para empezar. | 0,5–2 días | Conservar consentimiento, mensajes, errores y estados; no prometer correo automático. |
| R04 · P1 | Portada móvil sin desborde observado; grafo con zoom y panel de detalle desplazable. | Revisar navegación táctil y lectura del grafo/detalle en móvil y escritorio. | Menor esfuerzo para consultar una receta o un costo. | 2–4 días | Medir antes de cambiar; preservar caminos y controles accesibles. |
| R05 · P1 | Catálogo con búsqueda por nombre/código; mensaje vacío compartido. | Filtros por costo incompleto, ciclo y referencia; ordenamiento y mensajes según contexto/permisos. | Encontrar y corregir datos relevantes con menos búsqueda manual. | 2–4 días | Ordenar importes con precisión; distinguir cero de ausencia; no sugerir crear a quien sólo consulta. |
| R06 · P1 | Resumen con conteos, accesos y orientación general. | Añadir listas breves de productos incompletos e insumos sin oferta, enlazadas a su corrección. | Convertir el resumen en una lista de trabajo verificable. | 2–4 días | Definir qué cuenta cada indicador; no inventar ventas, disponibilidad, utilidad o ahorro real. |
| R07 · P2 | Ofertas con precio, referencia y versión; sin condiciones logísticas ni historial consultable. | Diseñar vigencia, plazos e historial; evaluar después cantidades mínimas y condiciones de compra. | Saber qué tan vigente y aplicable es una comparación. | 1–3 semanas | Migración y reglas nuevas; condiciones conjuntas pueden invalidar la selección independiente por insumo. |
| R08 · P1 | Foco, teclado, pausa y movimiento reducido ya presentes. | Revisión dirigida de contraste, objetivos, lectura, errores, zoom y foco en paneles. | Mayor facilidad de uso y evidencia reproducible. | 1–3 días | No anunciar cumplimiento integral sin evaluar todo el alcance. |
| R09 · P1 | Una dependencia general ajena puede activar cálculo estructural para todos los productos. | Localizar cuándo hace falta esa comprobación y evitar trabajo para productos no afectados. | Evitar la degradación sintética observada sin cambiar resultados. | 1–3 días | Conservar detección de ciclos y dependencias no cuantificadas; comparar salidas completas. |
| R10 · P1 | El tablero repite información de redes y recorridos en su respuesta. | Medir y reducir repetición; diseñar una respuesta compacta o detalle solicitado bajo demanda. | Menos memoria, serialización, transferencia y análisis de JSON. | 3–6 días | Cambio de contrato; mantener caminos, comparación y exportación coherentes con un mismo catálogo. |
| R11 · P1 | Carga diferida, WebP, caché estática, compresión y layout memorizado existentes. | Establecer una línea base de carga/interacción y optimizar sólo los cuellos comprobados. | Priorizar mejoras con beneficio observable. | 1–3 días de medición | No confundir desarrollo con producción ni un benchmark con experiencia real. |
| R12 · P3 | Dependencias y costos de materiales; sin inventario ni órdenes de compra. | Definir un módulo separado de existencias, necesidades y reposición con revisión humana. | Pasar del análisis estructural al seguimiento operativo. | Varias semanas | Requiere movimientos, demanda, unidades, plazos, permisos y decisiones de negocio. |

## Fundamento y fuentes aplicables

### Identidad y jerarquía: R01–R04

Linear publicó en marzo de 2026 un ajuste centrado en consistencia y jerarquía: la navegación reduce su protagonismo y las acciones aparecen de forma más predecible. Es una referencia apropiada para priorizar el contenido de trabajo de AbastecePyme conservando su marca. [1. Linear: A calmer interface for a product in motion](https://linear.app/now/behind-the-latest-design-refresh).

Figma documenta variables reutilizables para mantener decisiones de diseño. La aplicación concreta propuesta es consolidar variables CSS y estados comunes; no exige contratar Figma ni instalar un sistema de componentes. [2. Figma: Guide to variables](https://help.figma.com/hc/en-us/articles/15339657135383-Guide-to-variables-in-Figma).

Material ofrece esquemas de movimiento estándar y expresivo. Su existencia no convierte el movimiento ornamental en una necesidad para esta herramienta: aquí la prioridad es explicar dirección y cambios sin distraer. No se propone sustituir las flechas aprobadas por rebotes o transiciones largas. [3. Material 3: Motion](https://m3.material.io/styles/motion).

### Catálogo, filtros y mensajes: R05–R06

Shopify describe tablas adaptables a listas en pantallas pequeñas y formatos numéricos alineados a la derecha. Sugiere considerar paginación alrededor de 50–100 filas; es orientación para su contexto, no una regla universal. Antes de paginar AbastecePyme se debe observar volumen y tarea. [4. Shopify Polaris: Table](https://shopify.dev/docs/api/app-home/latest/web-components/layout-and-structure/table).

Atlassian presenta ordenamiento y paginación como capacidades de su tabla dinámica. Son patrones útiles para consultar catálogos crecientes, sin necesidad de adoptar su biblioteca. [5. Atlassian: Dynamic table](https://atlassian.design/components/dynamic-table/).

Stripe recomienda filtros visibles por atributos y una acción para retirarlos. En AbastecePyme, estado del costo y valores de referencia son candidatos porque ya existen en los datos. [6. Stripe: Filter controls](https://docs.stripe.com/stripe-apps/patterns/filter-controls).

Stripe también distingue entre no tener datos y no encontrar coincidencias. R05 propone esa distinción y una acción coherente con los permisos: limpiar búsqueda, consultar detalles o crear el primer elemento cuando corresponda. [7. Stripe: Empty state](https://docs.stripe.com/stripe-apps/patterns/empty-state).

### Accesibilidad y movimiento: R04 y R08

WCAG 2.2 permite comprobar contraste, teclado, foco no completamente oculto y tamaño de objetivos. El criterio AA de objetivos establece 24 × 24 píxeles CSS con excepciones; 44 × 44 corresponde al criterio mejorado AAA. La revisión propuesta debe cubrir tareas y estados, no sólo capturas. [8. W3C: WCAG 2.2](https://www.w3.org/TR/WCAG22/).

Para contenido que se mueve automáticamente durante más de cinco segundos junto a otro contenido, W3C exige un mecanismo para pausar, detener u ocultar, salvo su excepción de actividad esencial. La pausa existente de las flechas debe conservarse y verificarse al cambiar la vista. [9. W3C: Pause, Stop, Hide](https://www.w3.org/WAI/WCAG22/Understanding/pause-stop-hide).

La preferencia del sistema `prefers-reduced-motion` permite adaptar movimiento a quienes solicitan reducirlo. Ya existe en el grafo: una mejora visual debe respetarla también en estados nuevos. [10. web.dev: prefers-reduced-motion](https://web.dev/articles/prefers-reduced-motion).

### Medición y optimización: R09–R11

Los objetivos de Core Web Vitals son LCP ≤ 2,5 segundos, INP ≤ 200 milisegundos y CLS ≤ 0,1, evaluados al percentil 75 y separados por móvil/escritorio. Son metas de referencia; este informe no presenta valores medidos de AbastecePyme. Una prueba local o una puntuación de laboratorio no sustituye datos de uso real. [11. web.dev: Web Vitals](https://web.dev/articles/vitals).

React Profiler permite identificar el tiempo de renderizado de árboles de componentes. Añade sobrecarga y requiere configuración específica para perfiles de producción. R11 propone medir seleccionar producto, escribir en búsqueda, resaltar una opción y cambiar alcance. [12. React: Profiler](https://react.dev/reference/react/Profiler).

React plantea `useMemo` como optimización, no como condición de funcionamiento. El proyecto ya memoriza layout y dibujo; conviene medir antes de añadir más memorización, virtualización o herramientas de compilación. [13. React: useMemo](https://react.dev/reference/react/useMemo).

FastAPI ejecuta las operaciones declaradas con `def` en un conjunto de hilos y contempla ese patrón para bibliotecas bloqueantes. Cambiar ODBC a `async def` sin cambiar cómo se realiza la operación no resuelve por sí mismo un problema de rendimiento. [14. FastAPI: Concurrency and async/await](https://fastapi.tiangolo.com/async/).

MariaDB permite contrastar estimaciones con filas y tiempos reales mediante `ANALYZE FORMAT=JSON`, que ejecuta la sentencia analizada. Una futura evaluación debe utilizar consultas y entornos autorizados. No se propone añadir índices sin un plan observado, especialmente cuando el catálogo necesita leer todas sus filas. [15. MariaDB: ANALYZE FORMAT=JSON](https://mariadb.com/docs/server/reference/sql-statements/administrative-sql-statements/analyze-and-explain-statements/analyze-format-json).

### Datos de compra y alcance empresarial: R07 y R12

Odoo documenta ofertas de proveedores con precio, cantidad mínima y plazo de entrega. Son referencias para ampliar los datos, pero requieren un contrato de cálculo: descuentos conjuntos, portes, mínimos o límites de capacidad pueden hacer que elegir la oferta menor de cada material deje de producir la combinación global menor. [16. Odoo 19: Vendor pricelists](https://www.odoo.com/documentation/19.0/applications/inventory_and_mrp/purchase/products/pricelist.html).

Odoo distingue costos previstos y reales de fabricación e incorpora componentes y operaciones. AbastecePyme calcula materiales según ofertas registradas. Debe conservarse la explicación de exclusiones; el 25 % actual es un recargo sobre el costo mínimo y no demuestra utilidad neta ni ahorro obtenido. [17. Odoo 19: Manufacturing order costs](https://www.odoo.com/documentation/19.0/applications/inventory_and_mrp/manufacturing/basic_setup/mo_costs.html).

Las reglas de reposición de Odoo dependen de existencias previstas, mínimos, máximos y rutas de compra o fabricación. También permiten revisión manual. AbastecePyme necesita esos datos antes de sugerir reposición operativa; una cadena de dependencias no demuestra falta de inventario. [18. Odoo 19: Reordering rules](https://www.odoo.com/documentation/19.0/applications/inventory_and_mrp/inventory/warehouses_storage/replenishment/reordering_rules.html).

Las referencias sustentan patrones y límites, no aseguran que sus resultados se reproduzcan aquí. Parte del contenido de Material y Atlassian se consultó mediante su texto oficial indexado; las aperturas directas de Odoo agotaron la espera, pero la búsqueda devolvió el contenido de su documentación oficial. No se utilizaron recomendaciones de blogs de tendencias para justificar las propuestas.

## Hallazgos sintéticos del backend

La [línea base de rendimiento](PERFORMANCE_BASELINE_2026-11-16.md) reúne la metodología, las condiciones y los artefactos para reproducir estas mediciones. Los resultados justifican las propuestas R09 y R10; no equivalen a cambios aplicados.

### R09: una dependencia desconectada dispara trabajo repetido

El cálculo de un catálogo sintético de 1.000 productos tardó **8,05 ms** en su caso base y **944,79 ms** después de añadir una dependencia general **proveedor → proveedor desconectada**. Las salidas comparadas fueron idénticas. Son medianas de tres ejecuciones, no mediciones de MariaDB.

La ruta observada es la condición global `self.OtherDependencies` de [ProductCosts.py](../backend/ProductCosts.py): cuando existe alguna dependencia general de otro tipo, cada producto puede pasar por el análisis estructural completo. La propuesta es determinar qué productos requieren esa comprobación y reutilizar trabajo cuando proceda. Esta optimización aún no estaba aplicada al registrar la línea base; su implementación posterior está documentada en el enlace de actualización del inicio.

**Aceptación propuesta:** conservar exactamente estados, ciclos, problemas, importes y trazas para casos válidos, incompletos y cíclicos; probar dependencias extrañas conectadas y desconectadas, componentes compartidos y productos ajenos a un ciclo. Comparar tamaños crecientes con el mismo entorno. El objetivo es eliminar trabajo ajeno al producto sin omitir dependencias relevantes; no prometer un factor de aceleración fijo.

### R10: el tablero devuelve información repetida

En un escenario sintético de tablero con una cadena de 1.000 productos, sin cambio temporal, la respuesta produjo **18.592.323 bytes de JSON** y **336.660 bytes comprimidos con gzip**. La serialización tardó **82,744 ms** y la compresión **26,058 ms**, como medianas de tres ejecuciones.

La compresión reduce transferencia, pero el servidor y el navegador siguen construyendo o interpretando la representación expandida. La propuesta es revisar la repetición de catálogos, redes y caminos entre resultados base y temporales; considerar referencias compartidas o detalle solicitado cuando el usuario abre un recorrido. Deben conservarse todos los datos necesarios para explicar impacto, orden y comparación. En esta línea base aún no había cambiado ese contrato; la implementación posterior conserva el formato anterior y añade uno compacto opcional.

**Aceptación propuesta:** mismo resultado funcional para los recorridos actuales, reducción verificable del JSON sin comprimir, comparación de tiempos y memoria, y ausencia de respuestas mezcladas al cambiar rápidamente de elemento o escenario. Se necesita comprobar el cliente y la API juntos.

### Condiciones de medición

Se utilizó **CPython 3.14.7 de 64 bits**, Windows 11 build 26300, Ryzen 9 9955HX de 16 núcleos/32 procesadores lógicos y aproximadamente 31,18 GiB de memoria física visible. Los casos de costos y respuesta utilizan medianas de tres ejecuciones. Los experimentos SQL independientes del análisis técnico utilizaron una medición por tamaño; este documento no los presenta como medianas ni como resultados de MariaDB.

No se incluyen tiempo de red, carga de usuarios concurrentes ni interacción de navegador en estas cifras. Antes de elegir una solución conviene separar conexión, consultas, cálculo Python, serialización, descarga, interpretación de JSON y renderizado.

## Correspondencia con el código

| Área | Evidencia inspeccionada | Relación con las propuestas |
|---|---|---|
| Catálogo | [Catalog.jsx](../frontend/src/components/Catalog.jsx): búsqueda por nombre/código y mensaje vacío compartido. | R05: filtros, ordenamiento y permisos. |
| Resumen | [Dashboard.jsx](../frontend/src/components/Dashboard.jsx): conteos y accesos. | R06: listas de acciones derivadas de datos disponibles. |
| Estilos | [Styles.css](../frontend/src/Styles.css), [Modern.css](../frontend/src/Modern.css), [Refinement.css](../frontend/src/Refinement.css). | R01: consolidación, conservando identidad. |
| Carga de vistas | [App.jsx](../frontend/src/App.jsx): secciones cargadas bajo demanda. | R11: mejora ya existente que debe medirse y conservarse. |
| Grafo | [Graph.jsx](../frontend/src/components/Graph.jsx) y [GraphLayout.js](../frontend/src/components/GraphLayout.js): foco, pausa, movimiento reducido y layout memorizado. | R04, R08 y R11: evaluar tareas y escala, sin duplicar algoritmos de negocio en el navegador. |
| Catálogo y costos | [Catalog.py](../backend/Catalog.py), [ProductCosts.py](../backend/ProductCosts.py). | R09: cálculo de resúmenes desde el catálogo leído. |
| Tablero | [SupplyBoard.py](../backend/SupplyBoard.py). | R10: estructura y repetición de la respuesta. |
| Modelo de datos | [Schema.py](../backend/Schema.py): precio, cantidad, referencia y versión. | R07 y R12: condiciones logísticas e inventario todavía requieren ampliar el modelo. |

## Cambios que no deben aplicarse automáticamente

- Sustituir la marca, añadir modo oscuro, transparencias o animación decorativa sólo porque aparecen en otro producto.
- Migrar a Polaris, Material, Atlaskit, Next.js u otra biblioteca para conseguir los patrones descritos.
- Convertir todas las operaciones a código asíncrono, activar memorización general, añadir índices, caché de costos o virtualización sin medir y definir invalidación.
- Mostrar métricas de ventas, utilidad, disponibilidad o ahorro real que los datos actuales no respaldan.
- Alterar las reglas aprobadas de una unidad por dependencia de componente, agregación por material, redondeo y mínimo +25 %.
- Introducir compras automáticas, correos, asistentes de IA o cambios de inventario como consecuencia de esta revisión.

## Fases concretas para aprobar

1. **Fase A — Claridad y control de datos:** R01, R02, R03, R05 y R06. Entregar comparación visual antes/después y recorridos por perfil; preservar marca, permisos y cálculos. Revisar R04 y R08 en las pantallas afectadas. Esta fase mejora comprensión y trabajo cotidiano sin introducir inventario.
2. **Fase B — Rendimiento medido:** R11 como línea base, seguido de R09 y R10 por separado. Aprobar cada cambio con equivalencia de resultados, mediciones reproducibles y revisión de la respuesta de la API. Las pruebas sintéticas justifican investigar; no reemplazan una evaluación posterior del entorno de uso.
3. **Fase C — Condiciones de compra y trazabilidad:** definir R07 antes de modificar esquema o fórmulas. Acordar vigencia, historial, unidades y efecto de cada condición sobre los mínimos/máximos.
4. **Fase D — Operación de inventario:** tratar R12 como un alcance independiente, con entradas/salidas, demanda, recepción y aprobación humana. No iniciar por una alerta visual de existencias que aún no se calculan.

El usuario aprobó las mejoras de legibilidad, filtros y rendimiento, conservando colores y funcionalidades. Se aplicaron las partes relacionadas de R01, R04, R05, R06, R08, R09, R10 y R11. La nueva portada/contacto, condiciones de compra e inventario no forman parte de esta actualización. El informe enlazado al inicio distingue lo implementado de lo pendiente.
