export function GetSourcingOption(Result,Kind){
  if(!Result?.IsComplete||!['Minimum','Maximum'].includes(Kind))return null;
  const Graph=Result.SourcingGraphs?.[Kind];
  if(!Graph?.ElementIds?.includes(Result.ProductId)||!Graph.Relations?.length)return null;
  return {ProductId:Result.ProductId,Kind,Graph};
}

export function GetCurrentSourcing(Selection,ProductId,Data){
  return Selection?.ProductId===ProductId&&Selection.Data===Data?Selection:null;
}
