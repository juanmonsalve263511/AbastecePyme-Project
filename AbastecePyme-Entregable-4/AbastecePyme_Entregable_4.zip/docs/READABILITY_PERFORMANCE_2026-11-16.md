# Legibilidad, filtros y rendimiento — 16 de noviembre de 2026

Se aplicó el alcance aprobado de legibilidad, filtros y rendimiento, conservando la paleta azul/gris y las funciones existentes. Esta es una actualización posterior al resaltado de costos. No cambia fórmulas, permisos, esquema ni datos de MariaDB.

## Qué cambió y cómo usarlo

### Catálogo y resumen

- **Mostrar** filtra productos con costo incompleto, con ciclo o con datos de referencia. En Insumos permite encontrar los que no tienen ofertas de proveedor. Una oferta de cero es válida y no se confunde con ausencia de oferta.
- **Ordenar por** ofrece nombre y, para productos, costo o venta en ambos sentidos. Los importes pendientes quedan al final. La comparación conserva todos los dígitos de los importes decimales.
- El contador muestra registros visibles y total. **Limpiar filtros** restablece búsqueda, filtro y orden. Los enlaces conservan filtro y orden; la búsqueda escrita no se guarda en el enlace.
- Se distinguen una categoría vacía y una búsqueda sin coincidencias. El perfil Consulta recibe indicaciones acordes con sus permisos.
- **Resumen → Datos que conviene revisar** reúne esos grupos y abre directamente el filtro correspondiente. No representa falta de existencias ni indicadores de ventas.
- Los importes se alinean para compararlos; las acciones se apilan y permanecen visibles en el ancho de escritorio revisado. En móvil, la tabla conserva desplazamiento horizontal accesible por teclado.

![Catálogo con filtros y orden por costo](media/readability-2026-11-16/01-catalog-filters.jpg)

### Grafo y costos

- Nodos y textos mayores, encuadre basado en los elementos y curvas reales, y controles con áreas de interacción más amplias.
- **Ajustar red** muestra toda la red visible. **Tamaño legible** acerca el nodo seleccionado para leerlo; en pantallas pequeñas puede ser necesario desplazarse para ver las otras columnas. El porcentaje representa la escala de visualización.
- Se conservan zoom, desplazamiento, flechas animadas, pausa, movimiento reducido, pesos, enfoque y resaltados. Las flechas del teclado desplazan el lienzo; al recorrer los nodos con teclado, el encuadre revela el nodo enfocado.
- El panel se coloca junto al grafo cuando hay espacio suficiente y debajo cuando no lo hay. Se retiró su barra interna de desplazamiento.
- El precio calculado queda visible antes del desglose. Las alternativas económica y costosa aparecen en paralelo cuando caben; sus botones siguen resaltando exactamente los proveedores, insumos, componentes y conexiones correspondientes.

![Grafo y alternativas de costo con datos sintéticos](media/readability-2026-11-16/02-graph-readable.jpg)

[Catálogo móvil](media/readability-2026-11-16/03-catalog-mobile.jpg) · [Lectura del grafo móvil](media/readability-2026-11-16/04-graph-mobile.jpg) · [Costos dentro de producción](media/readability-2026-11-16/05-production-costs.jpg).

Las capturas funcionales utilizan un catálogo sintético aislado, no los precios ni datos reales de la instalación MariaDB.

## Rendimiento medido

### Costos: evitar revisar productos ajenos a una dependencia

Antes, cualquier dependencia general no cuantificada disparaba una revisión estructural completa por producto, incluso si estaba desconectada. Ahora cada cálculo indexa una vez los productos que podrían verse afectados. Las ramas conectadas y los ciclos conservan la comprobación original; no hay caché global que pueda quedar obsoleta después de una edición.

| Cadena sintética | Antes, con dependencia ajena | Después | Resultados |
|---|---:|---:|---|
| 100 productos | 9,602 ms | 0,847 ms | Idénticos |
| 300 productos | 71,412 ms | 2,484 ms | Idénticos |
| 1.000 productos | 885,558 ms | 8,394 ms | Idénticos |

En el último caso las llamadas al análisis estructural bajaron de 1.000 a cero. Esto acelera ese caso concreto aproximadamente 105 veces; no significa que toda la aplicación sea 105 veces más rápida. Se conservaron los hashes de resúmenes y detalle de los tres tamaños. Las regresiones cubren dependencias conectadas, desconectadas, ciclos y componentes compartidos.

Mediciones: [antes](research/benchmark-product-costs-r09-before.json) y [después](research/benchmark-product-costs-r09-after.json). La [línea base original](PERFORMANCE_BASELINE_2026-11-16.md) permanece sin sobrescribir.

### Tablero: entregar una sola representación de los datos compartidos

La página solicita una respuesta compacta. Se entrega un catálogo común; los grafos identifican sus elementos por código, y los caminos usan el árbol de predecesores calculado por Python. El navegador presenta solo el camino seleccionado, sin realizar una nueva búsqueda del grafo. Cuando no hay cambio temporal, se calcula una sola versión del análisis.

Comparación de formatos sobre la misma cadena sintética de 1.000 productos:

| Medida | Expandido | Compacto |
|---|---:|---:|
| JSON sin comprimir | 18.592.323 bytes | 759.328 bytes |
| JSON con gzip, nivel 5 | 336.660 bytes | 44.881 bytes |
| Construcción de respuesta | 20,986 ms | 5,367 ms |
| Serialización JSON | 86,959 ms | 3,538 ms |
| Compresión | 22,393 ms | 1,256 ms |
| Pico de asignaciones Python en construcción + JSON | 43.345.757 bytes | 3.188.156 bytes |

El JSON sin comprimir se reduce **95,9 %**. Las duraciones son medianas de tres ejecuciones; el pico corresponde a una ejecución separada con `tracemalloc`, para evitar alterar las mediciones de tiempo. Se mide memoria asignada por Python, no toda la memoria del proceso o del navegador. Ambos formatos aprovechan el cálculo único del escenario sin cambios. No hay red, MariaDB ni usuarios concurrentes en este experimento.

[Resultados y entorno](research/benchmark-dashboard-compact-2026.json) · [Script reproducible](../tests/benchmarks/BenchmarkCompactDashboard.py).

```powershell
.\.venv\Scripts\python.exe -B -X utf8 tests/benchmarks/BenchmarkCompactDashboard.py --run
```

### Compatibilidad de la API

`POST /api/dashboard/analyze` conserva la respuesta expandida por defecto. Se puede solicitar `"ResponseFormat": "Expanded"` explícitamente, o `"ResponseFormat": "Compact"` para la representación ligera. La autenticación, CSRF, lectura de un único catálogo, `SnapshotId`, comparaciones, órdenes y ciclos son iguales. `/api/impact` conserva sus caminos expandidos.

En formato compacto:

- `Base.Impact.Visited` incluye `ElementId`, nombre, tipo, profundidad y `ParentId`, sin un `Path` repetido por registro. `Reached` se obtiene como los visitados excepto el origen.
- `Graph.ElementIds` referencia cuerpos de elementos de `Catalog.Elements`; `Graph.Relations` mantiene las relaciones de ese alcance o escenario.
- `Scenario` es `null` cuando `Change` es `null`; representa el mismo análisis que `Base`.
- Los caminos completos se formatean solo al seleccionarlos, siguiendo los predecesores elegidos por Python. El cliente no deduce costos ni modifica la búsqueda o la detección de ciclos.

La carga diferida de vistas y los controles contra respuestas antiguas se conservan. No se añadieron bibliotecas, índices ni migraciones de datos. El recurso JavaScript principal compilado es de aproximadamente 241,5 kB, 75,7 kB comprimidos; esta entrega no se presenta como una reducción del archivo principal ni como una medición de Core Web Vitals.

## Verificación y activación

- **125 pruebas Python + 88 JavaScript: 213 aprobadas**, sintaxis y compilación de 57 módulos.
- Comparación automática de todos los caminos reconstruidos, pertenencia de grafos, escenarios, resumen, orden y testigos de ciclo con el contrato expandido; tamaños de respuesta lineales en las cadenas probadas.
- Navegador con SQLite en memoria: filtros incompleto/ciclo/referencia/sin ofertas, orden con cero y pendientes, limpiar/búsqueda sin resultados, caminos de impacto, grafo completo, escenario temporal con ciclo y regreso a red actual, producción y resaltados económico/costoso.
- En el escritorio revisado, la tabla ocupó 925 px sin desplazamiento horizontal adicional. En móvil de 390 × 844, catálogo y grafo mantuvieron `clientWidth == scrollWidth == 375` para la página; la tabla conserva su desplazamiento interno.
- Pausa verificada con posiciones idénticas de las flechas; al reanudar cambian. Movimiento reducido ocultó las flechas animadas. La navegación con teclado desplazó el encuadre. Sin errores de consola en el recorrido.
- Instancia temporal 3018 detenida al finalizar; no se modificó MariaDB operativa. La semilla original se conserva.
- El usuario confirmó el nuevo reinicio. **3001 respondió HTTP 200** y el `index.html` servido coincidió exactamente con la compilación actual. La ruta de estimaciones respondió **401 sin sesión**, como corresponde. No se consultaron costos autenticados de MariaDB: la validación funcional se hizo en la instancia aislada.

No es una auditoría completa de WCAG ni una prueba de carga. La consolidación completa de estilos globales, rediseño de portada/contacto, condiciones de compra e inventario quedan fuera de esta actualización. Se aplicaron las partes pertinentes de R01/R04/R05/R06/R08/R09/R10/R11, no todas las propuestas del [informe](RECOMMENDATIONS_2026-11-16.md).
