# Compartir AbastecePyme — 16 de noviembre de 2026

Descomprime el ZIP y sube los archivos dentro de AbastecePyme/ a tu repositorio.
No subas el ZIP como sustituto del código fuente. Incluye MANIFEST.sha256.

Lee README.md, docs/SETUP.md y docs/USER_GRAPH_LAYOUTS_2026-11-16.md.
Incluye distribución guardada por usuario y animación continua de la portada con otro 20 % de velocidad, además de movimiento libre, selección múltiple, legibilidad, filtros y rendimiento. El resto de propuestas de docs/RECOMMENDATIONS_2026-11-16.md queda pendiente. Instalar.cmd prepara las dependencias
y compila la interfaz. Cada instalación configura sus propias credenciales MariaDB
y su administrador. No se distribuyen bases reales, sesiones, mensajes de contacto,
contraseñas operativas, dependencias instaladas ni respaldos privados.

La cuenta pública de tests/fixtures/SupplyBoardPreview.py existe únicamente en una
instancia sintética SQLite en memoria; no permite iniciar sesión en la instalación real.
Los medios de docs/media/ usan datos sintéticos y son compartibles. El video de
Feature 4 conserva su fecha del 14; las capturas de grafos y costos son del 16.

Si ya activaste el guardado por cuenta, el último ajuste de velocidad solo cambia
la interfaz: compila y recarga con Ctrl+F5, sin reiniciar. Si actualizas una versión
anterior al guardado por cuenta, reinicia también AbastecePyme con Iniciar.cmd --port 3001;
introduce la contraseña MariaDB únicamente en su aviso oculto. La preparación añade
la tabla UserGraphLayouts sin reescribir el catálogo en una instalación actualizada.
En una instalación nueva, sigue README.md: Instalar.cmd, preparación de MariaDB,
ConfigurarAdministrador.cmd y finalmente Iniciar.cmd con el puerto elegido.

Esta entrega escucha solo en 127.0.0.1; no publica el aplicativo en Internet.
La semilla data/catalogo.json mantiene sus bytes y su huella originales.
