import {lazy,Suspense,useCallback,useEffect,useRef,useState} from 'react';
import {Api,SetSession,RoleLabels} from './Api.js';
import {LatestRequest} from './LatestRequest.js';
import {Brand,Icon,Notice} from './components/Common.jsx';
import Home from './components/Home.jsx';
import {PublicRoutes} from './components/PublicLayout.jsx';
import {Preferences,PrepareSound,PlaySessionSound} from './components/Preferences.jsx';
const PublicPages=lazy(()=>import('./components/PublicPages.jsx'));
const Production=lazy(()=>import('./components/Production.jsx'));
import Login from './components/Login.jsx';
const Dashboard=lazy(()=>import('./components/Dashboard.jsx'));
const Catalog=lazy(()=>import('./components/Catalog.jsx'));
const Relations=lazy(()=>import('./components/Relations.jsx'));
const Impact=lazy(()=>import('./components/Impact.jsx'));
const Graph=lazy(()=>import('./components/Graph.jsx'));
const ApiExplorer=lazy(()=>import('./components/ApiExplorer.jsx'));
const Users=lazy(()=>import('./components/Users.jsx'));
const ContactInbox=lazy(()=>import('./components/ContactInbox.jsx'));
const Account=lazy(()=>import('./components/Account.jsx'));
const EmptyData={Elements:[],Relations:[]};
const Navigation=[['dashboard','Resumen','dashboard'],['catalog-Supplier','Catálogo','catalog'],['relations','Relaciones','relations'],['graph','Grafo de abastecimiento','graph'],['impact','Análisis de impacto','search'],['production','Orden de producción','order'],['api','Explorador de API','api']];
export default function App(){
  const [Route,SetRoute]=useState(()=>window.location.hash.slice(1)||'home');
  const [Session,UpdateSession]=useState(null);const [Ready,SetReady]=useState(false);const [Data,SetData]=useState(EmptyData);const [Loaded,SetLoaded]=useState(false);const [Error,SetError]=useState('');const [Menu,SetMenu]=useState(false);
  const CatalogRequest=useRef(new LatestRequest());const SessionIdentity=useRef(null);
  const ChangeSession=useCallback((Value,Expected)=>{if(Expected&&SessionIdentity.current!==Expected.UserId+':'+Expected.CsrfToken)return;const Identity=Value?Value.UserId+':'+Value.CsrfToken:null;if(SessionIdentity.current!==Identity){CatalogRequest.current.Cancel();SetData(EmptyData);SetLoaded(false);SetError('');SessionIdentity.current=Identity;}SetSession(Value);UpdateSession(Value);},[]);
  const Load=useCallback(async()=>{if(!SessionIdentity.current)return;await CatalogRequest.current.Run(Signal=>Api('/api/catalog',{signal:Signal}),Value=>{SetData(Value);SetLoaded(true);SetError('');},Failure=>SetError(Failure.message));},[]);
  useEffect(()=>{const Controller=new AbortController();Api('/api/auth/session',{signal:Controller.signal}).then(Value=>{if(!Controller.signal.aborted)ChangeSession(Value);}).catch(Failure=>{if(Failure.Status!==401&&!Controller.signal.aborted)SetError(Failure.message);}).finally(()=>{if(!Controller.signal.aborted)SetReady(true);});return()=>Controller.abort();},[ChangeSession]);
  useEffect(()=>{if(Session)Load();return()=>CatalogRequest.current.Cancel();},[Session?.UserId,Session?.CsrfToken,Load]);
  useEffect(()=>{function Navigate(){SetRoute(window.location.hash.slice(1)||'home');window.scrollTo(0,0);SetMenu(false);SetError('');}function Expired(){ChangeSession(null);window.location.hash='login';}window.addEventListener('hashchange',Navigate);window.addEventListener('session-expired',Expired);return()=>{window.removeEventListener('hashchange',Navigate);window.removeEventListener('session-expired',Expired);};},[ChangeSession]);
  async function Logout(){PrepareSound();try{await Api('/api/auth/logout',{method:'POST'});PlaySessionSound('Logout');ChangeSession(null);window.location.hash='home';}catch(Failure){SetError(Failure.message);}}
  if(!Ready)return <main className="loading" role="status">Preparando tu espacio…</main>;
  if(Route==='home')return <Home Session={Session}/>;
  if(PublicRoutes.includes(Route))return <Suspense fallback={<main className="loading" role="status">Cargando página…</main>}><PublicPages Route={Route} Session={Session}/></Suspense>;
  if(Route==='login'||Route==='register'||!Session)return <Login key={Route} OnSession={ChangeSession}/>;
  const Page=Route.split('?')[0];const Focus=new URLSearchParams(Route.split('?')[1]||'').get('focus')||'';
  const CanEdit=Session.RoleName==='Administrator'||Session.RoleName==='Editor';
  const RequiresCatalog=Page!=='account'&&!(Session.RoleName==='Administrator'&&['users','contact-requests'].includes(Page));
  return <div className="app-layout"><a className="skip-link" href="#main" onClick={E=>{E.preventDefault();document.getElementById('main').focus();}}>Saltar al contenido</a><aside className={'sidebar'+(Menu?' open':'')}><Brand/><p className="nav-caption">Espacio de trabajo</p><nav id="WorkspaceNavigation" aria-label="Navegación principal" onClick={()=>SetMenu(false)}>{Navigation.map(([Key,Label,Name])=><a key={Key} href={'#'+Key} className={(Page===Key||(Key.startsWith('catalog')&&Page.startsWith('catalog')))?'active':''} aria-current={(Page===Key||(Key.startsWith('catalog')&&Page.startsWith('catalog')))?'page':undefined}><Icon Name={Name}/>{Label}</a>)}{Session.RoleName==='Administrator'&&<a href="#contact-requests" className={Page==='contact-requests'?'active':''} aria-current={Page==='contact-requests'?'page':undefined}><Icon Name="message"/>Solicitudes de contacto</a>}{Session.RoleName==='Administrator'&&<a href="#users" className={Page==='users'?'active':''} aria-current={Page==='users'?'page':undefined}><Icon Name="users"/>Usuarios y perfiles</a>}</nav><div className="sidebar-bottom"><a href="#home"><Icon Name="home"/>Página de inicio</a><div className="sidebar-note"><Icon Name="graph"/><p>Una red organizada.<br/>Decisiones más claras.</p></div></div></aside><div className="workspace"><header className="workspace-top"><button className="menu-toggle" aria-label={Menu?'Cerrar navegación':'Abrir navegación'} aria-expanded={Menu} aria-controls="WorkspaceNavigation" onClick={()=>SetMenu(!Menu)}>☰</button><p>Mi empresa <span>/</span> AbastecePyme</p><div className="user-tools"><a className="user-profile" href="#account"><span className="avatar">{Session.DisplayName.slice(0,1).toUpperCase()}</span><span>{Session.DisplayName}<small>{RoleLabels[Session.RoleName]}</small></span></a><button className="icon-button" onClick={Logout} aria-label="Cerrar sesión"><Icon Name="logout"/></button></div></header><main id="main" className="workspace-main" tabIndex={-1}><Notice Text={Error} Error/>{RequiresCatalog&&!Loaded?<div className="loading"><p>{Error?'No se pudo cargar el catálogo.':'Cargando catálogo…'}</p>{Error&&<button onClick={Load}>Reintentar</button>}</div>:<Suspense fallback={<p role="status">Cargando sección…</p>}>
      {Page.startsWith('catalog-')?<Catalog key={Page} Data={Data} Type={['Supplier','Material','Product'].includes(Page.slice(8))?Page.slice(8):'Supplier'} CanEdit={CanEdit} OnChange={Load}/>:Page==='relations'?<Relations Data={Data} CanEdit={CanEdit} OnChange={Load}/>:Page==='graph'?<Graph key={Focus} Data={Data} InitialFocus={Focus}/>:Page==='impact'?<Impact Data={Data}/>:Page==='production'?<Production Data={Data} CanEdit={CanEdit}/>:Page==='api'?<ApiExplorer Data={Data} CanEdit={CanEdit} OnChange={Load}/>:Page==='users'&&Session.RoleName==='Administrator'?<Users Session={Session} OnSession={ChangeSession}/>:Page==='contact-requests'&&Session.RoleName==='Administrator'?<ContactInbox/>:Page==='account'?<Account Session={Session} OnSession={ChangeSession}/>:<Dashboard Data={Data} Session={Session}/>}
    </Suspense>}</main><footer className="workspace-footer"><span>© 2026 AbastecePyme</span><Preferences/></footer></div></div>;
}

