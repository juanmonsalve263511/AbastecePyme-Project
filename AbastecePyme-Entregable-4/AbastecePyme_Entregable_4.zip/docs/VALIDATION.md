# Registro de validación
Fecha local: 25 de octubre de2026 (America/Bogota).

- Hostname confirmado: Juan_Tavera.
- Red concedida para la sesión de implementación.
- Pruebas originales Node:21/21.
- Python puro inicial:5/5.
- API/SQL sobre MariaDB:20/20 antes de configurar el administrador permanente.
- Grafo:2/2; fallos reales de inicialización y desplazamiento reproducidos y corregidos.
- React/Vite: compilación de producción correcta; npm install auditó sin vulnerabilidades.
- Catálogo original:40 elementos y92 parejas exactas; importación repetible; rollback ante fallo de importación y transacción.
- Autenticación: cookies HttpOnly/SameSite, rechazo de elevación pública, CSRF/origen, sesiones vencidas/logout, permisos por rol, cambio real de contraseña, limitación de intentos.
- Concurrencia: conflicto de versiones y dos administradores intentando degradarse; solo una operación puede completarse.
- Navegador integrado: login con cuenta temporal, crear/editar proveedor, cancelar eliminación conservándolo, grafo y zoom. Revisión móvil y de API en curso.
- Playwright CLI no pudo abrir Chrome por un fallo de Crashpad; se usó el navegador integrado mediante computer use.
- Los registros de pruebas son temporales; la limpieza final y la revisión independiente se registran al cerrar la validación.


## Revisión final
26 pruebas Node (21 originales +5 nuevas),6 Python y23 API/SQL:55 aprobadas,0 fallidas. La integración emite un aviso de deprecación de Starlette respecto a httpx; no afecta el resultado actual.
Se corrigieron y probaron los tres hallazgos importantes de la revisión independiente: versiones no repetidas al recrear registros, representación decimal exacta y respuestas de estimación tardías. También se corrigió la invalidación de vistas previas de los vecinos al eliminar un elemento.
La tabla técnica RevisionClock serializa las escrituras del catálogo para asignar revisiones persistentes crecientes. Es apropiada para esta demostración local; una instalación de gran concurrencia requeriría revisar esa estrategia.
En navegador se verificaron perfiles Administrador/Consulta/Editor, alta y edición de proveedor temporal, cancelación de eliminación, grafo100%→125%→100%, enfoque11 elementos/10 relaciones, consultas API200, estimación de Mesa de comedor43750.00 COP y navegación móvil sin desbordamiento horizontal de página.
Las cuentas/registros temporales de navegador se eliminaron; el catálogo vuelve a40 elementos/92 relaciones. El servidor nuevo se reinició en3001 y usa MariaDB persistente.
La cuenta inicial permanente se crea mediante ConfigurarAdministrador.cmd con contraseña elegida por el usuario. No hay contraseña de administrador predeterminada.

Decisiones de ejecución: se trabajó sobre el proyecto respaldado sin Git; las relaciones también usan versiones; la vista previa usa3001 porque3000 pertenece a la versión anterior; el navegador integrado sustituyó Chrome CLI después del fallo de Crashpad. No se publicaron servicios fuera de127.0.0.1.

Cierre del26 de octubre de2026: el usuario confirmó que creó el administrador. La consulta SQL posterior de confirmación fue bloqueada por la revisión automática de ejecución, incluso después de conceder nuevamente acceso de red para la sesión. No se afirma una verificación SQL posterior a esa creación. Las55 pruebas registradas corresponden a la ejecución anterior, antes del administrador permanente.

## Feature 4 — 14 de noviembre de 2026

Este apartado registra la nueva entrega. Las cifras y decisiones de octubre que aparecen arriba conservan su fecha y no se presentan como pruebas del tablero actual.

### Pruebas automáticas

`Verify.py` completo aprobó **88 pruebas Python y 59 JavaScript (147 en total)**, además de la compilación Vite de **49 módulos**. La ejecución incluye cinco casos de `test_supply_board_journey.py` y cuatro de `test_supply_board_api.py`; esos subconjuntos no se suman otra vez al total.

Los cinco casos de recorrido verificaron registro de dependencia, cadena válida, elemento inexistente frente a uno aislado, dato inválido, ciclo sin orden falso y retirada temporal. Los cuatro de API verificaron sesión, perfiles, origen/CSRF, lectura única del catálogo y ausencia de escrituras del análisis. Utilizaron la API y autenticación reales con un adaptador SQLite en memoria, sin MariaDB.

Se observaron avisos de deprecación de Starlette/httpx y del adaptador de fechas de SQLite en la prueba de Feature 3, sin fallos. La revisión independiente del frontend no encontró hallazgos accionables. Esta ejecución final incluye la operación analítica del Explorador de API y sus pruebas nuevas.

Se verificó además una extracción de prueba del ZIP en una carpeta nueva: **Verify.py --skip-build** aprobó **88 Python + 59 JavaScript = 147 pruebas**. Se usaron el intérprete y las dependencias existentes del proyecto. No fue una instalación limpia ni una prueba de MariaDB; el código fuente coincidía con el que ya había superado la compilación.

### Navegador

Sobre la instancia sintética de demostración se comprobó:

- Registro de Panel preparado → Estante modular con respuesta `201`.
- Impacto potencial desde el proveedor, camino hasta Estante y cuatro etapas de ese conjunto de prueba.
- Comparación con ciclo, resaltado rojo del ciclo, vuelta a la red base válida y descarte del ensayo conservando el catálogo.
- Desde el Explorador de API, análisis de MISSING con `404`, bad! con `422` referido a `ElementId`, y PROD-AISLADO con `200` y `NoReachable`. El catálogo sintético conservó sus tres relaciones después de las consultas.
- Viewport móvil de **390 × 844**; ancho de contenido y ancho desplazable de **375 px** en la medición, sin desbordamiento horizontal de la página.
- Zoom de **100 % a 125 %** y consola sin errores ni advertencias durante el recorrido observado.

Estas comprobaciones están acotadas a los datos, recorrido y tamaños indicados. No constituyen una auditoría completa de accesibilidad ni de carga de producción.

Playwright CLI estaba disponible, pero su arranque de Chrome/Chromium falló en este entorno. Se utilizó **computer-use/CUA con el navegador integrado** para la revisión y la captura real de capítulos. No se instalaron nuevas skills; se reutilizaron las descritas en [SKILLS.md](SKILLS.md).

### Estado operativo y archivos de demostración

El proceso real de **3001** seguía ejecutando el servidor anterior: `POST /api/dashboard/analyze` devolvía `404`. La instancia aislada de **3014** reconocía la ruta y respondía `401` sin sesión. El servidor operativo no se reinició desde esta entrega y no se afirma que Feature 4 ya haya sido probado contra MariaDB actual.

En el cierre del 14 de noviembre se dejó pendiente reiniciar la ventana anterior de AbastecePyme con **Ctrl+C** y ejecutar **Iniciar.cmd --port 3001**, introduciendo la contraseña de MariaDB en la entrada oculta. Era una acción operativa sin modificación de datos de negocio; el estado posterior se registra en el apartado del 16 de noviembre.

Tras la revisión se detuvieron los servidores temporales de **3014 y 3015**. No se intervino el proceso operativo de 3001.

El video entregado es un montaje de capítulos de interacción real, capturados mediante CUA a aproximadamente cuatro capturas por segundo, con títulos y sin voz. El archivo WebM usa VP9, **1280 × 816**, **25 fps** por repetición de **473 capturas originales**, dura **135 segundos** y pesa **5.313.461 bytes**. La decodificación completa de **3.375 fotogramas** terminó sin errores. El navegador lo reprodujo completo: `currentTime=135`, `duration=135`, `ended=true`, `error=null`. Se incluyó un SRT de textos y tiempos.

El pitch HTML tiene **seis diapositivas** revisadas y ajuste comprobado a **720 px de altura**; el avance automático pasó de la primera a la cuarta durante la comprobación y se pausó después. Los archivos y la evidencia están en [FEATURE4_VIDEO.md](FEATURE4_VIDEO.md); [FEATURE4.md](FEATURE4.md) enlaza las capturas de tablero, ciclo y móvil de la instancia sintética. El guion ampliado de tres minutos se distingue del video real de **2:15**. En aquel cierre del 14 de noviembre, el reinicio de 3001 era la única activación pendiente; no describe el estado actual.

## Grafos y costos — 16 de noviembre de 2026

### Verificación automática

La ejecución completa aprobó **108 pruebas Python y 64 JavaScript: 172 en total**, con compilación Vite de **53 módulos**. Se actualizó `frontend/dist`. Los casos nuevos comprueban costos mínimo/máximo, componentes, multiplicidad de usos, redondeo, estados incompletos/cíclicos y conservación de precios manuales, además del enfoque del grafo.

La regla acordada es una unidad por dependencia producto → producto, suma de cantidades por material, HALF_UP a dos decimales por subtotal y suma de esos subtotales. El precio calculado es mínimo × 1,25, también con HALF_UP. Los detalles están en [GRAPH_COSTS_2026-11-16.md](GRAPH_COSTS_2026-11-16.md).

### Navegador sobre datos sintéticos

La revisión utilizó la instancia aislada de **3016**, con datos en memoria; no accedió a MariaDB operativa.

| Caso | Evidencia observada |
|---|---|
| Costo inicial de Estante | Mínimo 70.000 COP con Maderas del Norte, máximo 80.000 COP con el proveedor alternativo y venta 87.500 COP; una unidad de Panel preparado como componente. |
| Pantallas integradas | Catálogo, Grafo de abastecimiento y Orden de producción mostraron el mismo cálculo. |
| Foco por defecto | Cuatro nodos/tres relaciones frente a seis nodos/cuatro relaciones del grafo completo; selección de Estante y camino de tres relaciones conservados. |
| Flechas continuas | Las posiciones cambiaron entre lecturas después de varios ciclos. |
| Pausa y movimiento reducido | Posiciones idénticas al pausar; al activar movimiento reducido, elementos animados ocultos y control inhabilitado. Se observaron posiciones y estado de la interfaz. |
| Cambio de oferta | Editar y guardar la oferta de Norte de 35.000 a 36.000 COP actualizó el componente y Estante: mínimo 72.000 COP y venta 90.000 COP. |
| Móvil | Viewport 390 × 844; ancho visible y ancho desplazable de 375 px, sin desbordamiento horizontal en esa medición. |
| Consola | Sin errores durante el recorrido. |

[graph-costs-2026-11-16.jpg](media/graph-costs-2026-11-16.jpg) muestra el estado **inicial** de 70.000/80.000/87.500 COP. [catalog-costs-2026-11-16.jpg](media/catalog-costs-2026-11-16.jpg) muestra el estado **posterior a editar la oferta**, con 72.000/90.000 COP. La diferencia es intencional y pertenece a datos sintéticos, no a una variación de precios comerciales.

El navegador de comprobación se cerró y se restauró el tamaño de escritorio después de la revisión. La prueba está acotada al recorrido y tamaños indicados; no constituye una auditoría completa de accesibilidad ni de carga de producción. El video y las cifras del 14 de noviembre conservan su fecha y no prueban estas novedades.

### Instalación habitual

El **16 de noviembre**, el usuario confirmó el reinicio de la aplicación. Después se verificó **HTTP 200 en 127.0.0.1:3001** y coincidencia exacta de los bytes del `index.html` servido con `frontend/dist/index.html`. La consulta de estimación sin sesión devolvió **401**, conforme al control de autenticación.

No se dispuso de una sesión autenticada en la instalación habitual y no se consultaron sus costos directamente en MariaDB. La validación funcional continúa siendo la de la instancia sintética; HTTP 200 y la coincidencia de la interfaz no se presentan como una prueba SQL de los cálculos. El servidor temporal de **3016** se detuvo tras la revisión.

El reinicio está confirmado y ya no queda pendiente. Para futuras actualizaciones del servidor se mantiene el procedimiento de **Ctrl+C → Iniciar.cmd --port 3001**, con MySQL iniciado y contraseña introducida en la entrada oculta. Este estado sustituye la activación pendiente registrada en el cierre histórico del 14 de noviembre.


## Selección de opciones de costo — segunda actualización del 16 de noviembre

La suite completa pasó **115 pruebas Python y 68 JavaScript (183)** y compiló **54 módulos**. La comparación de la entrega anterior (172 pruebas) permanece como historia. Se verificó en navegador el resaltado económico/costoso, componentes indirectos, limpieza de selección, red completa, producto incompleto, Orden de producción y móvil; sin errores de consola. [Evidencia del recorrido](COST_SELECTION_2026-11-16.md).

El usuario confirmó un nuevo reinicio para esta ampliación. Después se observó **HTTP 200 en 3001**, con `index.html` idéntico al build actualizado; la ruta de costos respondió **401 sin sesión**. Las comprobaciones funcionales autenticadas corresponden a SQLite en memoria en 3017, no a MariaDB operativa. Las [mediciones sintéticas de rendimiento](PERFORMANCE_BASELINE_2026-11-16.md) son investigación independiente y no significan que se hayan aplicado sus propuestas.

El servidor de prueba temporal de 3017 se detuvo al terminar. La instancia habitual de 3001 se conservó.


## Legibilidad, filtros y rendimiento — tercera actualización del 16 de noviembre

Verificación completa: **125 pruebas Python + 88 JavaScript = 213**, compilación de **57 módulos** y actualización de `frontend/dist`. Se mantienen los resultados históricos de las otras entregas. La revisión independiente de filtros, grafo y respuesta compacta no encontró bloqueos.

La [evidencia y las mediciones](READABILITY_PERFORMANCE_2026-11-16.md) describen los filtros, orden exacto de decimales, costos cero y pendientes, zoom/foco/pausa, móvil, caminos reconstruidos desde predecesores Python y comparación temporal con ciclo. El recorrido autenticado usó SQLite sintético en memoria en **3018**; se detuvo al terminar. No se modificó MariaDB ni la semilla original. Se observaron cero errores de consola. No se afirma una auditoría WCAG o de carga completa.

Tras la confirmación del nuevo reinicio por el usuario, **3001 respondió HTTP 200**, con `index.html` idéntico al build actual; la estimación sin sesión respondió **401**. No se dispuso de una sesión autenticada sobre MariaDB para validar datos operativos.

## Movimiento libre y selección múltiple — cuarta actualización del 16 de noviembre

La suite completa aprobó **125 pruebas Python + 104 JavaScript = 229**, con compilación de **59 módulos** y actualización de `frontend/dist`. Incluye 16 pruebas nuevas de geometría e interacción, además de una revisión independiente del componente compartido. La revisión independiente detectó y permitió corregir la elección de grupo al mover desde teclado con el foco en el lienzo; la regresión quedó cubierta por pruebas y por el navegador.

La [guía y evidencia de movimiento libre](FREE_GRAPH_LAYOUT_2026-11-16.md) registran arrastre individual y de grupo con mouse, Ctrl, selección por rectángulo, zoom, restauración exacta, teclado y conservación de costos/caminos. Se comprobó el componente en Grafo de abastecimiento, Tablero, Orden de producción y Análisis de impacto. La revisión adaptable a 390 × 844 no mostró desbordamiento horizontal; no se prueba aquí un dispositivo táctil físico ni se afirma una auditoría completa de accesibilidad.

Las interacciones autenticadas utilizaron SQLite sintético en memoria en **3018**. Se observaron cero errores de consola. La instalación habitual en **3001** respondió HTTP 200 y sirvió los mismos bytes de `index.html` que la compilación final. No se consultaron ni modificaron datos de MariaDB. La huella SHA-256 de la semilla original se mantuvo en `2c12fa86ff146bc947a1f0c10a0e5cfe2a1db88a16d9704e87a6f6b186d21797`.

Esta ampliación sólo cambia la interfaz: se activa con **Ctrl + F5**, sin reinicio del servidor. Las posiciones son locales a la vista, no datos persistentes.

## Distribución por usuario y portada continua — quinta actualización del 16 de noviembre

Esta entrega sustituye la limitación de posiciones locales de la cuarta actualización: guarda coordenadas en `UserGraphLayouts`, por cuenta y sección. La suite completa aprobó **141 pruebas Python + 117 JavaScript = 258** y compiló **61 módulos**. Las pruebas cubren las cuatro claves, todos los perfiles, aislamiento, Origin/CSRF, límites y valores inválidos, reset, persistencia entre sesiones, integridad del catálogo, creación aditiva de la tabla y orden de escrituras/borradores. Revisión independiente sin bloqueos pendientes.

La [guía y evidencia](USER_GRAPH_LAYOUTS_2026-11-16.md) registran arrastre individual/grupal real, recarga exacta, cuenta de consulta independiente, nueva sesión con almacenamiento de origen separado, reset persistente y controles adaptables. La portada mantiene movimiento después de tres ciclos; pausa, reanudación y preferencia reducida comprobadas. Cero errores de consola. Se usó SQLite sintético en memoria en **3019**; no se modificaron registros de MariaDB en estas pruebas.

Tras el reinicio confirmado por el usuario, **3001 respondió HTTP 200**, sirvió `index.html` idéntico a la compilación final y reconoció `/api/account/graph-layouts/Graph`, que devolvió **401 sin sesión**. Esto comprueba la activación de las rutas, no una escritura autenticada de preferencias en MariaDB. La huella de `data/catalogo.json` se mantuvo intacta.
