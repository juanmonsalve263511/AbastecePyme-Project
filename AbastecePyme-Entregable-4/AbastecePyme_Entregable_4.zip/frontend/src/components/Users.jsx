import {useCallback,useEffect,useRef,useState} from 'react';
import {Api,RoleLabels} from '../Api.js';
import {LatestRequest} from '../LatestRequest.js';
import {Heading,Field,Modal,Notice,Icon} from './Common.jsx';

function CreateUserForm({OnClose,OnCreated}){
  const [Busy,SetBusy]=useState(false);const [Error,SetError]=useState('');
  async function Submit(Event){
    Event.preventDefault();if(Busy)return;SetBusy(true);SetError('');
    const Form=Event.currentTarget;const Values=new FormData(Form);
    if(Values.get('Password')!==Values.get('ConfirmPassword')){SetError('Las contraseñas no coinciden.');SetBusy(false);return;}
    try{
      await Api('/api/users',{method:'POST',body:{Username:Values.get('Username'),DisplayName:Values.get('DisplayName'),Email:Values.get('Email'),Password:Values.get('Password'),RoleName:Values.get('RoleName')}});
      Form.reset();await OnCreated();OnClose();
    }catch(Failure){SetError(Failure.message);}finally{SetBusy(false);}
  }
  return <Modal Title="Crear usuario" OnClose={()=>!Busy&&OnClose()}><form onSubmit={Submit}><p>La cuenta se crea con el perfil que elijas. Tu sesión de administrador continúa abierta.</p><Notice Text={Error} Error/>
    <Field Label="Nombre completo"><input name="DisplayName" required minLength={2} maxLength={80} autoComplete="off"/></Field>
    <div className="form-grid"><Field Label="Usuario" Hint="Entre 3 y 40 letras, números, guiones o guion bajo."><input name="Username" required pattern="[A-Za-z0-9_\-]{3,40}" maxLength={40} autoComplete="off"/></Field><Field Label="Perfil"><select name="RoleName" defaultValue="Viewer">{Object.entries(RoleLabels).map(([Key,Label])=><option key={Key} value={Key}>{Label}</option>)}</select></Field></div>
    <Field Label="Correo (opcional)"><input name="Email" type="email" maxLength={254} autoComplete="off"/></Field>
    <Field Label="Contraseña inicial" Hint="Usa entre 12 y 128 caracteres. La persona puede cambiarla en Mi cuenta."><input name="Password" type="password" required minLength={12} maxLength={128} autoComplete="new-password"/></Field>
    <Field Label="Confirmar contraseña"><input name="ConfirmPassword" type="password" required minLength={12} maxLength={128} autoComplete="new-password"/></Field>
    <div className="form-actions"><button type="button" disabled={Busy} onClick={OnClose}>Cancelar</button><button className="primary" disabled={Busy}>{Busy?'Creando cuenta…':'Crear usuario'}</button></div>
  </form></Modal>;
}
export default function Users({Session,OnSession}){
  const [Rows,SetRows]=useState([]);const [Error,SetError]=useState('');const [Editing,SetEditing]=useState(null);const [Creating,SetCreating]=useState(false);const [Busy,SetBusy]=useState(false);const [Message,SetMessage]=useState('');
  const [Loading,SetLoading]=useState(true);const Gate=useRef(new LatestRequest());
  const Load=useCallback(async()=>{SetLoading(true);SetError('');await Gate.current.Run(Signal=>Api('/api/users',{signal:Signal}),Value=>{SetRows(Value);SetLoading(false);},Failure=>{SetError(Failure.message);SetLoading(false);});},[]);
  useEffect(()=>{Load();return()=>Gate.current.Cancel();},[Load]);
  async function Save(Event){
    Event.preventDefault();if(Busy)return;SetBusy(true);SetError('');const Form=new FormData(Event.currentTarget);
    try{await Api('/api/users/'+Editing.UserId,{method:'PATCH',body:{RoleName:Form.get('RoleName'),IsActive:Form.get('IsActive')==='on',Version:Editing.Version}});SetEditing(null);if(Editing.UserId===Session.UserId){OnSession(null,Session);window.location.hash='login';}else await Load();}
    catch(Failure){SetError(Failure.message);}finally{SetBusy(false);}
  }
  return <><Heading Title="Usuarios y perfiles" Description="Un espacio compartido, con el acceso adecuado para cada persona." Children={<button className="primary" onClick={()=>{SetMessage('');SetCreating(true);}}><Icon Name="plus"/>Crear usuario</button>}/><Notice Text={Error} Error/><Notice Text={Message}/>
    <div className="context-note"><Icon Name="users"/><p>Solo los administradores crean cuentas. Consulta permite leer; Editor permite gestionar el catálogo; Administrador también gestiona usuarios. Cambiar un acceso cierra las sesiones de esa cuenta.</p></div>
    <section className="surface" aria-busy={Loading}>{Loading&&<p role="status">Cargando usuarios…</p>}{Error&&<button onClick={Load} disabled={Loading}>Reintentar carga</button>}<div className="table-scroll"><table><thead><tr><th>Persona</th><th>Usuario</th><th>Perfil</th><th>Estado</th><th>Acciones</th></tr></thead><tbody>{Rows.map(User=><tr key={User.UserId}><td><strong>{User.DisplayName}</strong><small className="block">{User.Email}</small></td><td>{User.Username}</td><td>{RoleLabels[User.RoleName]}</td><td><span className="badge">{User.IsActive?'Activo':'Desactivado'}</span></td><td><button onClick={()=>SetEditing(User)}>Editar acceso</button></td></tr>)}</tbody></table></div></section>
    {Creating&&<CreateUserForm OnClose={()=>SetCreating(false)} OnCreated={async()=>{await Load();SetMessage('Usuario creado. Ya puede iniciar sesión con sus credenciales.');}}/>}
    {Editing&&<Modal Title={'Acceso de '+Editing.DisplayName} OnClose={()=>!Busy&&SetEditing(null)}><form onSubmit={Save}><Notice Text={Error} Error/><Field Label="Perfil"><select name="RoleName" defaultValue={Editing.RoleName}>{Object.entries(RoleLabels).map(([Key,Label])=><option key={Key} value={Key}>{Label}</option>)}</select></Field><label className="checkbox"><input type="checkbox" name="IsActive" defaultChecked={!!Editing.IsActive}/>Cuenta activa</label><div className="form-actions"><button type="button" onClick={()=>SetEditing(null)} disabled={Busy}>Cancelar</button><button className="primary" disabled={Busy}>Guardar acceso</button></div></form></Modal>}
  </>;
}
