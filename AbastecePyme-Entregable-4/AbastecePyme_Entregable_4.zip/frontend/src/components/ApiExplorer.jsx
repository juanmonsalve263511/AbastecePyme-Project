import {useEffect,useRef,useState} from 'react';
import {Api,TypeLabels} from '../Api.js';
import {BuildApiRequest,GetOperationSettings,Operations} from '../ApiRequests.js';
import {LatestRequest} from '../LatestRequest.js';
import {Heading,Icon,Field,Notice,Modal} from './Common.jsx';

const InitialElement={ElementId:'PROD-NUEVO',Name:'Nuevo producto',ElementType:'Product',Description:''};
const InitialRelation={SourceId:'',TargetId:'',Value:null,IsDemo:true};
export default function ApiExplorer({Data,CanEdit,OnChange}){
  const [Operation,SetOperation]=useState('Catalog');
  const [ElementId,SetElementId]=useState('');const [ProductId,SetProductId]=useState('');
  const [RelationKey,SetRelationKey]=useState('');const [Direction,SetDirection]=useState('Consequences');
  const [BodyText,SetBodyText]=useState('');const [Result,SetResult]=useState(null);
  const [Busy,SetBusy]=useState(false);const [Error,SetError]=useState('');const [Pending,SetPending]=useState(null);
  const Gate=useRef(new LatestRequest());useEffect(()=>()=>Gate.current.Cancel(),[]);
  const Item=Data.Elements.find(Value=>Value.ElementId===ElementId);
  const {Writes,HasBody}=GetOperationSettings(Operation);
  function Reset(){Gate.current.Cancel();SetResult(null);SetError('');SetBusy(false);SetPending(null);}
  function ChooseOperation(Value){
    Reset();SetOperation(Value);SetElementId('');SetRelationKey('');
    const InitialBody=Value==='CreateElement'?InitialElement:Value==='CreateRelation'?InitialRelation:Value==='SupplyBoard'?{ElementId:Data.Elements.find(Entry=>['Supplier','Material'].includes(Entry.ElementType))?.ElementId||'',ProductId:null,Change:null}:null;
    SetBodyText(InitialBody?JSON.stringify(InitialBody,null,2):'');
  }
  function ChooseElement(Value){
    Reset();SetElementId(Value);const Selected=Data.Elements.find(Entry=>Entry.ElementId===Value);
    if(Operation==='EditElement'&&Selected)SetBodyText(JSON.stringify({Name:Selected.Name,Description:Selected.Description,Version:Selected.Version,...(Selected.ElementType==='Supplier'?{Contact:Selected.Contact}:Selected.ElementType==='Material'?{UnitCode:Selected.UnitCode}:{})},null,2));
  }
  function ChooseRelation(Value){
    Reset();SetRelationKey(Value);const Selected=Data.Relations.find(Entry=>Entry.SourceId+'>'+Entry.TargetId===Value);
    SetBodyText(Selected?JSON.stringify({SourceId:Selected.SourceId,TargetId:Selected.TargetId,Value:Selected.Value,IsDemo:!!Selected.IsDemo,Version:Selected.Version},null,2):'');
  }
  let Request;
  try{Request=BuildApiRequest(Operation,{ElementId,ProductId,Direction,Version:Item?.Version},BodyText);}catch{/* Show actionable validation on submission. */}
  async function Execute(Snapshot){
    SetBusy(true);SetError('');SetPending(null);const Start=performance.now();
    await Gate.current.Run(async Signal=>{const Value=await Api(Snapshot.Path,{method:Snapshot.Method,body:Snapshot.Body,ReturnMeta:true,...(Snapshot.Writes?{}:{signal:Signal})});if(Snapshot.Writes)await OnChange();return Value;},
      Value=>{SetResult({...Value,Request:Snapshot,Duration:Math.round(performance.now()-Start)});SetBusy(false);if(Snapshot.Writes){SetElementId('');SetRelationKey('');if(Operation!=='CreateElement'&&Operation!=='CreateRelation')SetBodyText('');}},
      Failure=>{SetError((Failure.Status?Failure.Status+' · ':'')+Failure.message);SetBusy(false);});
  }
  async function Submit(Event){
    Event.preventDefault();if(Busy)return;SetError('');SetResult(null);
    try{
      const Snapshot=BuildApiRequest(Operation,{ElementId,ProductId,Direction,Version:Item?.Version},BodyText);
      if(!Snapshot.Writes){await Execute(Snapshot);return;}
      if(!CanEdit)throw new Error('Tu perfil solo permite consultar.');
      if(Operation==='DeleteElement'){
        SetBusy(true);
        await Gate.current.Run(Signal=>Api('/api/elements/'+encodeURIComponent(ElementId)+'/deletion-preview',{signal:Signal}),
          Preview=>{SetBusy(false);if(Preview.Version!==Item.Version){SetError('El elemento cambió. Recarga el catálogo antes de eliminarlo.');return;}SetPending({Request:Snapshot,Preview});},
          Failure=>{SetError(Failure.message);SetBusy(false);});
      }else SetPending({Request:Snapshot});
    }catch(Failure){SetError(Failure.message);SetBusy(false);}
  }
  return <><Heading Title="Explorador de API" Description="Consulta y gestiona tu red con solicitudes claras, verificables y protegidas."/>
    <div className="api-layout"><form className="surface api-query" onSubmit={Submit}>
      <span className="badge">{CanEdit?'Consulta y edición':'Perfil de consulta'}</span><h2>Prepara tu solicitud</h2>
      <fieldset disabled={Busy}><Field Label="Operación"><select value={Operation} onChange={Event=>ChooseOperation(Event.target.value)}>{Object.entries(Operations).filter(([Key])=>CanEdit||!GetOperationSettings(Key).Writes).map(([Key,[Label,Method]])=><option key={Key} value={Key}>{Method} · {Label}</option>)}</select></Field>
      {['Impact','EditElement','DeleteElement'].includes(Operation)&&<Field Label="Elemento"><select required value={ElementId} onChange={Event=>ChooseElement(Event.target.value)}><option value="">Selecciona un elemento</option>{Data.Elements.map(Entry=><option key={Entry.ElementId} value={Entry.ElementId}>{Entry.Name} · {TypeLabels[Entry.ElementType]}</option>)}</select></Field>}
      {['Estimate','Production'].includes(Operation)&&<Field Label="Producto"><select required={Operation==='Estimate'} value={ProductId} onChange={Event=>{Reset();SetProductId(Event.target.value);}}><option value="">{Operation==='Production'?'Toda la red':'Selecciona un producto'}</option>{Data.Elements.filter(Entry=>Entry.ElementType==='Product').map(Entry=><option key={Entry.ElementId} value={Entry.ElementId}>{Entry.Name}</option>)}</select></Field>}
      {Operation==='Impact'&&<Field Label="Dirección"><select value={Direction} onChange={Event=>{Reset();SetDirection(Event.target.value);}}><option value="Consequences">Consecuencias potenciales</option><option value="Requirements">Requisitos</option></select></Field>}
      {['EditRelation','DeleteRelation'].includes(Operation)&&<Field Label="Relación"><select required value={RelationKey} onChange={Event=>ChooseRelation(Event.target.value)}><option value="">Selecciona una relación</option>{Data.Relations.map(Entry=><option key={Entry.SourceId+'>'+Entry.TargetId} value={Entry.SourceId+'>'+Entry.TargetId}>{Entry.SourceId} → {Entry.TargetId}</option>)}</select></Field>}
      {HasBody&&<Field Label="Datos de la solicitud (JSON)" Hint={Operation==='SupplyBoard'?'ElementId indica el origen. ProductId limita el orden a un producto; null analiza toda la red. Change: null mantiene las dependencias actuales.':'Edita los valores entre comillas. Conserva Version al actualizar. Los pesos se escriben como texto decimal.'}><textarea className="json-editor" rows={12} required spellCheck={false} value={BodyText} onChange={Event=>{Reset();SetBodyText(Event.target.value);}}/></Field>}
      {Operation==='SupplyBoard'&&<p className="quiet">Para comparar, usa en Change un objeto con Operation: "Add" o "Remove", SourceId y TargetId. Agregar admite dependencias generales sin peso; retirar requiere una relación existente. El cambio es temporal.</p>}
      {['CreateElement','EditElement'].includes(Operation)&&<p className="quiet">Los productos muestran un precio de venta calculado: costo mínimo de insumos y componentes + 25 %. Cambia las ofertas o cantidades de sus relaciones para actualizarlo.</p>}
      {Operation==='CreateRelation'&&<p className="quiet">SourceId es el requisito; TargetId es su dependiente. Value: precio para proveedor → insumo, cantidad para insumo → producto, null para dependencia general.</p>}
      <div className="endpoint"><b>{Operations[Operation][1]}</b><code>{Request?.Path||'Completa los datos de la solicitud'}</code></div>
      <button className={Operation.startsWith('Delete')?'danger':'primary'} disabled={Busy}>{Busy?'Procesando…':Writes?'Revisar cambio':Operation==='SupplyBoard'?'Analizar escenario':'Consultar información'}<Icon Name="arrow"/></button></fieldset>
      <Notice Text={Error} Error/><p className="quiet">{Operation==='SupplyBoard'?'Análisis de solo lectura disponible para todos los perfiles. No modifica el catálogo ni necesita confirmar un guardado.':'Usa tus permisos de sesión. Los cambios se guardan en la base de datos al confirmarlos.'}</p>
    </form><section className="surface api-result"><div className="table-toolbar"><h2>Respuesta</h2>{Result&&<div className="actions"><span className="badge success">{Result.Status} Correcto</span><span className="quiet">{Result.Duration} ms</span></div>}</div>
      {Result?<><p className="result-path">{Result.Request.Method} {Result.Request.Path}</p>{Result.Request.Writes&&<Notice Text="Cambio guardado. El catálogo se ha solicitado de nuevo para reflejarlo."/>}<pre tabIndex={0} aria-label="Resultado de la solicitud">{JSON.stringify(Result.Data,null,2)}</pre></>:<div className="api-empty"><Icon Name="api" Size={48}/><h3>Cada solicitud, a la vista.</h3><p>Selecciona una operación. Podrás revisar los cambios antes de guardarlos.</p></div>}
    </section></div>
    {Pending&&<Modal Title={Pending.Request.Method==='DELETE'?'Confirmar eliminación':'Confirmar cambio en el catálogo'} OnClose={()=>SetPending(null)}>
      <p>Se ejecutará esta solicitud en tu base de AbastecePyme.</p>
      {Pending.Preview&&<Notice Error Text={'Se eliminará '+Pending.Preview.Name+' y sus '+Pending.Preview.RelationshipCount+' relaciones. Esta acción no se puede deshacer desde la página.'}/>}
      {Pending.Request.Method==='DELETE'&&!Pending.Preview&&<p>Se elimina la relación indicada. Los elementos se conservan.</p>}
      <div className="endpoint"><b>{Pending.Request.Method}</b><code>{Pending.Request.Path}</code></div>
      {Pending.Request.Body&&<pre className="request-preview">{JSON.stringify(Pending.Request.Body,null,2)}</pre>}
      <div className="form-actions"><button onClick={()=>SetPending(null)}>Cancelar</button><button className={Pending.Request.Method==='DELETE'?'danger':'primary'} onClick={()=>Execute(Pending.Request)}>Confirmar y ejecutar</button></div>
    </Modal>}
  </>;
}
