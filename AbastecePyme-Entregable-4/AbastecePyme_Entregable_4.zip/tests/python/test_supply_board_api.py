"""The dashboard keeps existing authentication and reads one catalogue snapshot."""
import unittest
from unittest.mock import patch
from fastapi.testclient import TestClient
from backend.Catalog import ReadCatalogue
from backend.Main import CreateApp
from tests.fixtures.SupplyBoardPreview import CreatePreviewDatabase, PreviewUsername, PreviewPassword


class SupplyBoardApiTests(unittest.TestCase):
    def setUp(self):
        self.Database = CreatePreviewDatabase()
        self.addCleanup(self.Database.Close)
        self.Client = TestClient(CreateApp(self.Database), base_url="http://127.0.0.1:3000")
        self.addCleanup(self.Client.close)
        self.Client.headers["Origin"] = "http://127.0.0.1:3000"
        self.Body = {"ElementId": "PROV-NORTE", "ProductId": "PROD-PANEL"}

    def Login(self):
        Response = self.Client.post("/api/auth/login", json={"Username": PreviewUsername, "Password": PreviewPassword})
        self.assertEqual(Response.status_code, 200, Response.text)
        self.Client.headers["X-CSRF-Token"] = Response.json()["CsrfToken"]

    def test_requires_a_session_before_reading_catalogue(self):
        with patch("backend.Catalog.ReadCatalogue", wraps=ReadCatalogue) as ReadSnapshot:
            Response = self.Client.post("/api/dashboard/analyze", json=self.Body)
        self.assertEqual(Response.status_code, 401, Response.text)
        self.assertEqual(ReadSnapshot.call_count, 0)

    def test_all_roles_can_simulate_with_one_snapshot_and_no_database_changes(self):
        self.Login()
        for Role in ("Viewer", "Editor", "Administrator"):
            with self.subTest(Role=Role):
                with self.Database.Transaction() as Connection:
                    Connection.execute("UPDATE Users SET RoleId=? WHERE Username=?", Role, PreviewUsername)
                Before = self.Database.Connection.total_changes
                with patch("backend.Catalog.ReadCatalogue", wraps=ReadCatalogue) as ReadSnapshot:
                    Response = self.Client.post("/api/dashboard/analyze", json={**self.Body,
                        "Change": {"Operation": "Add", "SourceId": "PROD-PANEL", "TargetId": "PROD-ESTANTE"}})
                self.assertEqual(Response.status_code, 200, Response.text)
                self.assertEqual(ReadSnapshot.call_count, 1)
                self.assertEqual(self.Database.Connection.total_changes, Before)
                Data = Response.json()
                self.assertEqual(len(Data["Catalog"]["Relations"]), 2)
                self.assertEqual(Data["Comparison"]["AddedReached"], ["PROD-ESTANTE"])
                self.assertRegex(Data["SnapshotId"], r"^[a-f0-9]{64}$")
                self.assertEqual(Response.headers["cache-control"], "no-store")

    def test_simulations_require_same_origin_and_valid_csrf(self):
        self.Login()
        Before = self.Database.Connection.total_changes
        for Headers in ({"X-CSRF-Token": "wrong"}, {"Origin": "https://example.invalid"}):
            with self.subTest(Headers=Headers):
                Response = self.Client.post("/api/dashboard/analyze", json=self.Body, headers=Headers)
                self.assertEqual(Response.status_code, 403, Response.text)
        self.assertEqual(self.Database.Connection.total_changes, Before)

    def test_compact_is_opt_in_authenticated_and_read_only(self):
        self.Login()
        Before = self.Database.Connection.total_changes
        Response = self.Client.post('/api/dashboard/analyze', json={**self.Body, 'ResponseFormat': 'Compact'})
        self.assertEqual(Response.status_code, 200, Response.text)
        Result = Response.json()
        self.assertEqual(Result['ResponseFormat'], 'Compact')
        self.assertIsNone(Result['Scenario'])
        self.assertNotIn('Path', Result['Base']['Impact']['Visited'][0])
        self.assertEqual(self.Database.Connection.total_changes, Before)
        self.assertEqual(self.Client.post('/api/dashboard/analyze', json={**self.Body, 'ResponseFormat': 'Invalid'}).status_code, 422)

    def test_request_validation_rejects_unknown_fields_and_change_operations(self):
        self.Login()
        for Body in ({**self.Body, "Save": True},
                     {**self.Body, "Change": {"Operation": "Replace", "SourceId": "PROD-PANEL", "TargetId": "PROD-ESTANTE"}},
                     {**self.Body, "Change": {"Operation": "Add", "SourceId": "PROD-PANEL", "TargetId": "PROD-ESTANTE", "Value": "1"}}):
            with self.subTest(Body=Body), patch("backend.Catalog.ReadCatalogue", wraps=ReadCatalogue) as ReadSnapshot:
                Response = self.Client.post("/api/dashboard/analyze", json=Body)
                self.assertEqual(Response.status_code, 422, Response.text)
                self.assertEqual(ReadSnapshot.call_count, 0)
