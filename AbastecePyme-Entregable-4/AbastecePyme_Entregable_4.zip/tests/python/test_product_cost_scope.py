"""Structural validation must cover affected products without unrelated scans."""
import copy
import json
from pathlib import Path
import unittest
from unittest.mock import patch

from backend.ProductCosts import ProductCostCalculator
from backend.Production import BuildProductionPlan
from test_product_costs import Element, Edge


def BuildScopeCases():
    Elements = [Element(Id, "Supplier") for Id in ("S1", "S2", "SX", "SY")]
    Elements += [Element(Id, "Material") for Id in ("M1", "M2", "MX")]
    Elements += [Element(Id, "Product") for Id in ("CC", "PP", "QQ")]
    Relations = [Edge("S1", "M1", "Offer", "10"), Edge("S2", "M2", "Offer", "2"),
                 Edge("M1", "CC", "Requirement", "2"), Edge("CC", "PP", "General"),
                 Edge("M2", "PP", "Requirement", "3"), Edge("M2", "QQ", "Requirement", "1")]
    Additions = {
        "Disconnected": [Edge("SX", "SY", "General")],
        "DirectProduct": [Edge("SX", "PP", "General")],
        "ViaSupplier": [Edge("SX", "S1", "General")],
        "ViaMaterial": [Edge("MX", "M1", "General")],
        "OutgoingOnly": [Edge("PP", "SY", "General")],
        "DisconnectedCycle": [Edge("SX", "SY", "General"), Edge("SY", "SX", "General")],
        "ComponentCycle": [Edge("PP", "CC", "General"), Edge("SX", "SY", "General")],
        "StructuralCycle": [Edge("CC", "S1", "General")],
        "ViaSeveralKinds": [Edge("CC", "SX", "General"), Edge("SX", "SY", "General"), Edge("SY", "M2", "Offer", "5")],
    }
    Cases = {Name: {"Elements": copy.deepcopy(Elements), "Relations": copy.deepcopy(Relations + Extra)}
             for Name, Extra in Additions.items()}
    Shared = {"Elements": copy.deepcopy(Elements) + [Element(Id, "Product") for Id in ("AA", "BB")],
              "Relations": [copy.deepcopy(Relation) for Relation in Relations if (Relation["SourceId"], Relation["TargetId"]) != ("CC", "PP")]}
    Shared["Relations"] += [Edge("CC", "AA", "General"), Edge("CC", "BB", "General"),
                            Edge("AA", "PP", "General"), Edge("BB", "PP", "General"), Edge("SX", "SY", "General")]
    Cases["SharedComponents"] = Shared
    return Cases


class ProductCostScopeTests(unittest.TestCase):
    def CalculateCase(self, Name):
        Data = BuildScopeCases()[Name]
        Calculator = ProductCostCalculator(**Data)
        with patch("backend.ProductCosts.BuildProductionPlan", wraps=BuildProductionPlan) as Planner:
            Results = {Id: Calculator.Calculate(Id) for Id in Calculator.ProductIds}
        return Data, Results, [Call.args[2] for Call in Planner.call_args_list]

    def test_all_fields_match_captured_preoptimization_results(self):
        File = Path(__file__).resolve().parents[1] / "fixtures/product-cost-scope-baseline.json"
        Expected = json.loads(File.read_text(encoding="utf-8"))["Cases"]
        for Name, Data in BuildScopeCases().items():
            with self.subTest(Case=Name):
                Before = copy.deepcopy(Data)
                Calculator = ProductCostCalculator(**Data)
                Results = {Id: Calculator.Calculate(Id) for Id in Calculator.ProductIds}
                self.assertEqual(Results, Expected[Name])
                self.assertEqual(Data, Before)

    def test_disconnected_dependency_cycle_and_outgoing_edges_need_no_product_scan(self):
        for Name in ("Disconnected", "DisconnectedCycle", "OutgoingOnly", "SharedComponents"):
            with self.subTest(Case=Name):
                Data, Results, Checked = self.CalculateCase(Name)
                self.assertEqual(Checked, [])
                self.assertTrue(all(Result["IsComplete"] for Result in Results.values()))

    def test_only_products_downstream_of_general_dependency_receive_full_validation(self):
        for Name, Expected in (("DirectProduct", ["PP"]), ("ViaSupplier", ["CC", "PP"]),
                               ("ViaMaterial", ["CC", "PP"]), ("ViaSeveralKinds", ["PP", "QQ"])):
            with self.subTest(Case=Name):
                Data, Results, Checked = self.CalculateCase(Name)
                self.assertEqual(Checked, Expected)
                for Id, Result in Results.items():
                    self.assertEqual(Result["Status"], "Incomplete" if Id in Expected else "Ready")
                    if Id in Expected:
                        self.assertIsNone(Result["SalePrice"])
                        self.assertTrue(any(Issue["Code"] == "UnquantifiedDependency" for Issue in Result["Issues"]))

    def test_component_and_mixed_cycles_keep_the_exact_existing_witness(self):
        for Name in ("ComponentCycle", "StructuralCycle"):
            with self.subTest(Case=Name):
                Data, Results, Checked = self.CalculateCase(Name)
                self.assertEqual(Checked, ["CC", "PP"])
                self.assertEqual(Results["QQ"]["Status"], "Ready")
                for Id in ("CC", "PP"):
                    self.assertEqual(Results[Id]["Status"], "Cycle")
                    self.assertEqual(Results[Id]["Cycle"], BuildProductionPlan(**Data, ProductId=Id)["Cycle"])
                    self.assertEqual(Results[Id]["SourcingGraphs"]["Minimum"]["ElementIds"], [])

    def test_affected_scope_does_not_leak_between_calculator_snapshots(self):
        Cases = BuildScopeCases()
        Connected = ProductCostCalculator(**Cases["ViaSupplier"])
        Disconnected = ProductCostCalculator(**Cases["Disconnected"])
        self.assertEqual(Connected.Calculate("PP")["Status"], "Incomplete")
        self.assertEqual(Disconnected.Calculate("PP")["Status"], "Ready")
        self.assertEqual(Connected.Calculate("PP")["Status"], "Incomplete")

    def test_shared_components_keep_quantities_costs_and_both_sourcing_branches(self):
        Data, Results, Checked = self.CalculateCase("SharedComponents")
        Product = Results["PP"]
        self.assertEqual(Product["MinimumCost"], "46.00")
        self.assertEqual(Product["Materials"][0]["Quantity"], "4.0000")
        Relations = {(Edge["SourceId"], Edge["TargetId"]) for Edge in Product["SourcingGraphs"]["Minimum"]["Relations"]}
        self.assertTrue({("CC", "AA"), ("CC", "BB"), ("AA", "PP"), ("BB", "PP")} <= Relations)


if __name__ == "__main__":
    unittest.main()
