import {GraphGeometry} from './GraphLayout.js';

function FinitePoint(Point){return Number.isFinite(Point?.X)&&Number.isFinite(Point?.Y);}

export function SelectNodeIds(CurrentIds,Id,Toggle=false){
  const Next=new Set(CurrentIds);
  if(typeof Id!=='string'||!Id)return Next;
  if(!Toggle)return new Set([Id]);
  if(Next.has(Id))Next.delete(Id);else Next.add(Id);
  return Next;
}

export function KeyboardMoveIds(CurrentIds,FocusedId,DetailId){
  const Current=CurrentIds instanceof Set?CurrentIds:new Set(CurrentIds);
  if(typeof FocusedId==='string'&&FocusedId)return Current.has(FocusedId)?Current:new Set([FocusedId]);
  if(Current.size)return Current;
  return typeof DetailId==='string'&&DetailId?new Set([DetailId]):Current;
}

export function NodesInRectangle(Nodes,Start,End){
  const Selected=new Set();
  if(!FinitePoint(Start)||!FinitePoint(End))return Selected;
  const Left=Math.min(Start.X,End.X),Right=Math.max(Start.X,End.X);
  const Top=Math.min(Start.Y,End.Y),Bottom=Math.max(Start.Y,End.Y);
  for(const Node of Nodes){
    if(!FinitePoint(Node))continue;
    if(Node.X<=Right&&Node.X+GraphGeometry.NodeWidth>=Left&&Node.Y<=Bottom&&Node.Y+GraphGeometry.NodeHeight>=Top)Selected.add(Node.ElementId);
  }
  return Selected;
}

export function MoveNodePositions(Layout,Ids,Delta,Positions=new Map()){
  // Layout and Positions belong to the start of this gesture. Delta is already
  // in SVG coordinates, so zoom never changes the relative group offsets.
  if(!FinitePoint(Delta)||(Delta.X===0&&Delta.Y===0))return Positions;
  const Updates=[];
  for(const Id of Ids){
    const Node=Layout.Map.get(Id);if(!Node)continue;
    const Stored=Positions.get(Id),Start=FinitePoint(Stored)?Stored:Node;
    const Next={X:Start.X+Delta.X,Y:Start.Y+Delta.Y};
    // Reject the whole translation if it would overflow, preserving the group.
    if(!FinitePoint(Next))return Positions;
    Updates.push([Id,Next]);
  }
  if(!Updates.length)return Positions;
  const Next=new Map(Positions);
  for(const [Id,Position] of Updates)Next.set(Id,Position);
  return Next;
}
