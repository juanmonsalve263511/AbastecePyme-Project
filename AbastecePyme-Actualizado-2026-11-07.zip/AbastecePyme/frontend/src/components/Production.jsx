import {useEffect,useMemo,useRef,useState} from 'react';
import {Api,TypeLabels} from '../Api.js';
import {LatestRequest} from '../LatestRequest.js';
import {Heading,Field,Icon,Notice} from './Common.jsx';
import Graph from './Graph.jsx';

export default function Production({Data,CanEdit}) {
  const [ProductId,SetProductId]=useState('');
  const [Result,SetResult]=useState(null);
  const [Busy,SetBusy]=useState(false);
  const [Error,SetError]=useState('');
  const Gate=useRef(new LatestRequest());
  useEffect(()=>()=>Gate.current.Cancel(),[]);
  useEffect(()=>{Gate.current.Cancel();SetResult(null);SetError('');SetBusy(false);SetProductId(Current=>Data.Elements.some(Item=>Item.ElementId===Current&&Item.ElementType==='Product')?Current:'');},[Data]);
  const Mapping=useMemo(()=>new Map((Result?.Graph.Elements||[]).map(Item=>[Item.ElementId,Item])),[Result]);
  const RequirementsById=useMemo(()=>{const Lookup=new Map();for(const Edge of Result?.Graph.Relations||[]){if(!Lookup.has(Edge.TargetId))Lookup.set(Edge.TargetId,[]);Lookup.get(Edge.TargetId).push(Edge);}return Lookup;},[Result]);
  function Reset(Value){Gate.current.Cancel();SetProductId(Value);SetResult(null);SetError('');SetBusy(false);}
  async function Analyze(Event){
    Event.preventDefault();if(Busy)return;SetBusy(true);SetError('');SetResult(null);
    await Gate.current.Run(Signal=>Api('/api/production'+(ProductId?'?ProductId='+encodeURIComponent(ProductId):''),{signal:Signal}),
      Value=>{SetResult(Value);SetBusy(false);},Failure=>{SetError(Failure.message);SetBusy(false);});
  }
  return <>
    <Heading Title="Orden de producción" Description="Primero los requisitos. Después, lo que depende de ellos."/>
    <form className="surface production-query" onSubmit={Analyze}>
      <Field Label="Qué quieres organizar" Hint="Revisa toda la red o solo los requisitos de un producto.">
        <select value={ProductId} onChange={Event=>Reset(Event.target.value)}>
          <option value="">Toda la red de abastecimiento</option>
          {Data.Elements.filter(Item=>Item.ElementType==='Product').map(Item=><option key={Item.ElementId} value={Item.ElementId}>{Item.Name}</option>)}
        </select>
      </Field>
      <button className="primary" disabled={Busy}><Icon Name="order"/>{Busy?'Revisando dependencias…':'Generar orden'}</button>
    </form>
    <Notice Text={Error} Error/>
    <div className="context-note"><Icon Name="relations"/><p>Las flechas van del requisito a su dependiente. El orden respeta todas las relaciones registradas; no calcula inventario, duración ni disponibilidad de proveedores. Las ofertas son alternativas: este orden no obliga a comprar a todos los proveedores.</p></div>
    {!Result&&!Busy&&<div className="production-empty surface"><Icon Name="order" Size={42}/><h2>Un siguiente paso, con fundamento.</h2><p>Genera un orden para conocer qué preparar primero y detectar dependencias que se contradicen.</p></div>}
    {Busy&&<p role="status">Calculando el orden de la red actual…</p>}
    {Result?.Status==='Empty'&&<Notice Text="Tu catálogo está vacío. Agrega elementos para organizar su preparación."/>}
    {Result?.Status==='Ready'&&<section aria-label="Orden válido de preparación">
      <div className="production-summary"><div><span className="badge success">Dependencias compatibles</span><h2>Tu preparación, paso a paso.</h2><p>{Result.Summary.Elements} elementos en {Result.Summary.Stages} etapas. Dentro de cada etapa puedes elegir el orden.</p></div><Icon Name="order" Size={42}/></div>
      <ol className="production-stages">{Result.Stages.map((Stage,Index)=><li key={Index} className="production-stage"><div className="stage-index"><span>{Index+1}</span><h3>Etapa {Index+1}</h3><p>{Index===0?'Sin requisitos previos':'Después de las etapas anteriores'}</p></div><ul>{Stage.map(Id=>{const Item=Mapping.get(Id);const Requirements=(RequirementsById.get(Id)||[]);return <li key={Id}><span className={'type-symbol '+Item.ElementType}><Icon Name={Item.ElementType==='Supplier'?'users':Item.ElementType==='Material'?'box':'catalog'}/></span><div><strong>{Item.Name}</strong><small>{TypeLabels[Item.ElementType]} · {Id}</small>{Requirements.length>0&&<details><summary>{Requirements.length} {Requirements.length===1?'requisito previo':'requisitos previos'}</summary><p>{Requirements.map(Edge=>Mapping.get(Edge.SourceId).Name).join(', ')}</p></details>}</div></li>;})}</ul></li>)}</ol>
      <details className="surface production-details"><summary>Ver el orden completo y la red analizada</summary><ol className="compact-order">{Result.Order.map(Id=><li key={Id}>{Mapping.get(Id).Name}</li>)}</ol><Graph Data={Result.Graph} WholeGraph Embedded/></details>
    </section>}
    {Result?.Status==='Cycle'&&<section aria-label="Ciclo detectado">
      <div className="cycle-alert" role="alert"><span className="badge danger-badge">Ciclo detectado</span><h2>Estas dependencias no permiten un orden válido.</h2><p>Un elemento termina dependiendo de sí mismo. Revisa el ciclo señalado; no se muestra ningún orden parcial como si fuera una solución.</p></div>
      <div className="surface cycle-details"><h3>El camino que cierra el ciclo</h3><p className="cycle-chain">{Result.Cycle.map((Id,Index)=><span key={Index}>{Index>0&&<Icon Name="arrow"/>}<strong>{Mapping.get(Id).Name}<small>{Id}</small></strong></span>)}</p><ul>{Result.CycleRelations.map(Edge=><li key={Edge.SourceId+'>'+Edge.TargetId}>Para preparar <strong>{Mapping.get(Edge.TargetId).Name}</strong>, necesito <strong>{Mapping.get(Edge.SourceId).Name}</strong>.</li>)}</ul><p>Revisa cuál de estas relaciones está invertida o no corresponde al proceso. Pueden existir otros ciclos; vuelve a analizar después de corregir uno.</p>{CanEdit&&<a className="button" href="#relations">Revisar relaciones</a>}</div>
      <Graph Data={Result.Graph} WholeGraph Embedded HighlightPath={Result.Cycle}/>
      <details className="surface production-details"><summary>{Result.Unresolved.length} elementos pendientes en el alcance analizado</summary><p>Incluye elementos del ciclo, otros posibles ciclos y sus dependientes. Estar pendiente no significa pertenecer al ciclo mostrado.</p><ul>{Result.Unresolved.map(Id=><li key={Id}>{Mapping.get(Id).Name}</li>)}</ul></details>
    </section>}
  </>;
}
