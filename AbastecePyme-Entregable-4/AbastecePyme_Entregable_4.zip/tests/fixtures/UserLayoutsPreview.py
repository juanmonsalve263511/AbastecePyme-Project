"""Loopback browser fixture for account layouts; synthetic SQLite memory only."""
import argparse

from ReadabilityPreview import CreateReadabilityDatabase, CreateApp
from backend.Auth import CreateUser


def Main():
    Parser = argparse.ArgumentParser(description=__doc__)
    Parser.add_argument("--port", type=int, default=3019)
    Arguments = Parser.parse_args()
    if not 1024 <= Arguments.port <= 65535:
        Parser.error("Puerto fuera de rango.")
    import uvicorn
    Database = CreateReadabilityDatabase()
    CreateUser(Database, "demo_viewer", "Consulta de prueba", "Layout-Demo-Only!2026", "Viewer")
    try:
        print(f"QA de preferencias: http://127.0.0.1:{Arguments.port}/ — SQLite en memoria.", flush=True)
        uvicorn.run(CreateApp(Database, Arguments.port), host="127.0.0.1", port=Arguments.port,
                    access_log=False, proxy_headers=False, log_level="warning")
    finally:
        Database.Close()


if __name__ == "__main__":
    Main()
