# Feature 4 — Implementation Plan

**Goal:** entregar el tablero integrado, aceptación repetible y material de demostración solicitado.

**Architecture:** una única lectura del catálogo alimenta BFS y Kahn/DFS existentes para base y escenario; React muestra resultados de esa respuesta. Los cambios temporales no llegan a MariaDB.

**Tech Stack:** React, FastAPI, Python, MariaDB/ODBC, SVG propio, unittest, Node test runner y navegador integrado (Playwright CLI no pudo iniciar su navegador).

**Spec:** [Diseño y alcance autorizado](../specs/2026-11-14-supply-board-design.md).

## Restricciones

- Código propio inglés/PascalCase; interfaz y documentación en español.
- Ninguna biblioteca resuelve grafos. Reusar AnalyzeImpact y BuildProductionPlan.
- Conservar autenticación y permisos; nunca guardar simulaciones implícitamente.
- Mantener intacta la semilla protegida y los registros reales durante aceptación.
- Todo medio y resultado debe distinguir ejecución real de propuesta y datos de prueba de datos operativos.

## Foco de revisión

- Respuestas tardías o catálogo actualizado no muestran un resultado anterior como vigente.
- Una relación nueva con peso obligatorio se rechaza en el simulador general.
- Un ciclo fuera del alcance de producto no invalida ese producto; un ciclo dentro sí.
- Un dependiente bloqueado no se presenta como integrante del ciclo.
- Perfil Consulta puede simular pero no persistir cambios.

## Tareas

- [x] Backend: pruebas fallidas primero; nuevo servicio puro `backend/SupplyBoard.py`, modelos y ruta POST `/api/dashboard/analyze`; contrato exacto en el diseño. Probar los cuatro casos, copias intactas, autenticación/CSRF, duplicados, alcance y una única lectura.
- [x] Frontend: nueva ruta, acceso desde Resumen, componente y CSS limitados al tablero; selección, comparación, resultados y resaltado SVG. Probar helpers relevantes y compilar.
- [x] Aceptación: servidor aislado para navegador con datos preparados, sin dependencia de MariaDB ni cuentas reales; comprobar CRUD de dependencia, impacto, orden, cambio y ciclo, 404/422, móvil y errores de consola.
- [x] Medios: grabar recorrido reproducible de la aplicación y producir pitch visual de 60–90 segundos con guion; inspeccionar video y capturas.
- [x] Documentación: README, guía, FEATURE4, bitácora, guiones, habilidades y evidencia fechada.
- [x] Verificación: ejecutar verificador completo, aceptar casos Feature4, revisar código por otro agente y corregir hallazgos. Registrar resultados actuales, sin reciclar cifras históricas.
- [x] Entrega: compilar distribución, verificar la ruta del servidor actual si está iniciado, empaquetar código/documentación/medios y validar manifest, exclusión de secretos y enlaces.

No hay repositorio Git activo en esta carpeta. Se conserva un respaldo de código previo; no se crean commits ni se publica remotamente.

## Cierre de implementación — 14 de noviembre de 2026

- Verificación completa: 88 pruebas Python y 59 JavaScript, 147 aprobadas; compilación de 49 módulos correcta.
- Recorrido real de navegador sobre SQLite aislado: alta de dependencia, impacto, camino, orden, comparación con ciclo, descarte y errores 404/422. Revisión móvil y zoom sin desbordamiento horizontal.
- Video de 2:15 con títulos, sin narración; 3375 fotogramas decodificados sin errores. Pitch HTML de seis diapositivas y guion oral.
- El servidor operativo de 3001 mantiene un proceso anterior y requiere reinicio privado con la contraseña MariaDB. No se ha detenido ese proceso ni accedido a sus credenciales o datos.
- No hay migraciones nuevas ni cambios en el catálogo real para Feature 4.
