# AbastecePyme: diseño de la actualización

Fecha: 25 de octubre de 2026. Estado: propuesta para aprobación antes de implementar.

## Objetivo y decisiones confirmadas

Actualizar la aplicación universitaria existente con React, una API Python/FastAPI y una base MariaDB independiente llamada AbastecePyme. El usuario confirmó esta arquitectura, los precios y cantidades de demostración en COP, tres perfiles (administrador, editor y consulta) y registro público limitado a consulta.

El código nuevo, comentarios e identificadores estarán en inglés. Se aplicará PascalCase conforme a la descripción del usuario, respetando los identificadores que exijan Python, React, HTML o bibliotecas. La interfaz estará en español. No se utilizarán bibliotecas que implementen grafos, sus algoritmos, su distribución o su dibujo.

## Estado verificado y conservación

Equipo: Juan_Tavera.
Instalación: la carpeta del proyecto.

El catálogo contiene 9 proveedores, 17 insumos, 14 productos y 92 relaciones. Se conservarán los 40 IDs, nombres, tipos y parejas dirigidas, incluido Metro 20 M. No hay duplicados ni extremos inexistentes.

SHA-256 del catálogo original: 2c12fa86ff146bc947a1f0c10a0e5cfe2a1db88a16d9704e87a6f6b186d21797.

Se creó un respaldo adicional del catálogo y del código en respaldos/pre-react-python-20261025-202930. El catálogo respaldado coincide por hash. La migración será repetible sin duplicaciones. El JSON original se conserva como respaldo; después de migrar, MariaDB será la fuente operativa.

## Enfoques considerados

1. **React + FastAPI + MariaDB, elegido por el usuario:** Python concentra validaciones, cálculos y persistencia. Sirve también la compilación de React, de modo que API e interfaz comparten origen.
2. **React + Node + procesos Python:** conserva el servidor antiguo, pero agrega coordinación y puntos de validación. El usuario prefirió la primera alternativa.

El código anterior y sus 21 pruebas permanecerán disponibles como referencia. Pasarlas no se presentará como validación suficiente de la nueva aplicación.

## Navegación y presentación

- **Inicio público:** presentación provisional de la marca y sus servicios de organización de abastecimiento. Accesos a iniciar sesión y registrarse. No se inventarán teléfonos, direcciones ni clientes.
- **Resumen:** cantidades reales y accesos a las tareas frecuentes.
- **Catálogo:** subsecciones Proveedores, Insumos y Productos, búsqueda, creación, edición y eliminación confirmada.
- **Relaciones:** precios de proveedores, cantidades de insumos por producto y dependencias generales.
- **Grafo:** exploración visual de nodos, relaciones y pesos.
- **API:** selección de recurso y parámetros, botón Consultar, respuesta legible, estado y duración. No es una consola SQL ni permite URLs arbitrarias.
- **Usuarios:** perfiles y activación/desactivación de cuentas, solo para administradores.
- **Mi cuenta:** datos básicos, cambio de contraseña y cierre de sesión.

Dirección visual: navegación azul marino, superficie de trabajo gris clara, tablas legibles y paneles de detalle. El grafo será el elemento visual distintivo. Paleta: #17324D, #315E83, #DCEAF4, #F4F7FA, #516174 y #FFFFFF. Tipografía local Segoe UI con alternativas de sistema; texto base mínimo de 16 px.

Se comprobarán adaptación a móvil, contraste, foco visible, teclado, etiquetas, estados vacíos, mensajes específicos y preferencia de movimiento reducido. Los estados usarán texto e iconos además de color.

## Grafo, unidades y pesos

Se conserva la orientación requisito → dependiente. Las estructuras y recorridos necesarios se programan directamente con diccionarios, conjuntos, listas y colas.

El dibujo será SVG propio en React, sin React Flow, D3, NetworkX ni equivalentes. Incluirá zoom por botones y rueda sobre el lienzo, arrastre para desplazamiento, Ajustar vista, Restablecer, selección por teclado y detalle contextual. La disposición por tipos tendrá ordenación propia para reducir cruces, sin anunciarla como orden topológico.

- Proveedor → insumo: precio por unidad de compra, moneda COP y marca de demostración.
- Insumo → producto: cantidad de la unidad del insumo necesaria para fabricar una unidad del producto.

Las unidades y valores sintéticos iniciales quedarán identificados como demostración y serán editables. Precio decimal no negativo y cantidad decimal estrictamente positiva. Se rechazan valores no finitos y fuera del rango o precisión admitidos.

**Propuesta semántica para aprobación:** si hay varios proveedores de un insumo, sus precios representan opciones de compra y no se suman. Los insumos de un producto sí son requisitos acumulativos. La documentación explicará esta evolución del modelo anterior.

El detalle del producto incluirá una estimación de materiales calculada en Python con Decimal: suma de cantidad requerida por el menor precio disponible de cada insumo. Se indicarán los proveedores elegidos y el carácter de demostración. Si faltan precios o hay dependencias generales no incluidas, el resultado se marcará incompleto. No se presentará como costo total de fabricación: excluye trabajo, impuestos, transporte y margen.

Las demás dependencias, ciclos y autorrelaciones se conservarán sin inventar pesos. El análisis de impacto transitivo y el orden de producción de los Features 2 y 3 quedan fuera de esta actualización.

## Modelo relacional

Base independiente, InnoDB, utf8mb4, consultas parametrizadas y transacciones para operaciones de varias tablas.

| Tabla | Contenido y claves |
|---|---|
| Elements | ElementId como PK global, Name, ElementType, Description y Version. |
| Suppliers | ElementId como PK/FK a Elements, contacto opcional. |
| Materials | ElementId como PK/FK y UnitCode. |
| Products | ElementId como PK/FK e información descriptiva. |
| SupplierOffers | PK SupplierId–MaterialId; FK a subtipos, UnitPrice DECIMAL(18,2), CurrencyCode e IsDemo. |
| ProductRequirements | PK MaterialId–ProductId; FK a subtipos, Quantity DECIMAL(18,4) e IsDemo. |
| GeneralDependencies | PK SourceId–TargetId; FK a Elements para relaciones distintas de las ponderadas. |
| Roles | RoleId como PK y nombres Administrator, Editor y Viewer. |
| Users | UUID como PK, Username único, DisplayName, correo opcional, PasswordHash, RoleId, estado y fechas. |
| Sessions | Hash de token opaco, FK a Users, expiración y datos de protección de solicitudes. |
| Migrations | Versión de esquema y huella de importación para impedir duplicados. |

Las claves foráneas impiden extremos huérfanos. El servidor verifica consistencia de subtipos y unicidad global. El ID y el tipo de un elemento existente serán estables en la primera versión; los demás campos permitidos se podrán editar.

Antes de eliminar un elemento se mostrará la cantidad de relaciones afectadas y se pedirá confirmación. La eliminación será atómica. Las versiones de edición impedirán sobreescribir cambios concurrentes sin advertencia. Dinero y cantidades se intercambian como cadenas decimales.

## Autenticación y perfiles

Las contraseñas del sitio se guardarán con Argon2id y sal individual, nunca en texto plano ni en respuestas. Son independientes de la cuenta ODBC usuario_python3.

Sesiones opacas con cookie HttpOnly y SameSite, vencimiento e invalidación al cerrar sesión. Protección CSRF y verificación de origen en escrituras. Secure se habilita con HTTPS; la demostración HTTP local debe funcionar. La autorización se aplica en el servidor y no depende de controles ocultos en la interfaz.

| Perfil | Permisos |
|---|---|
| Consulta | Lectura del catálogo, relaciones, grafo y API; edición de datos básicos propios y contraseña. |
| Editor | Lo anterior y creación, edición y eliminación de catálogo y relaciones. |
| Administrador | Lo anterior y administración de usuarios y perfiles. |

El registro público asigna siempre Consulta y rechaza intentos de elegir otro perfil. Se limitan intentos de login y se evitan mensajes que revelen cuentas existentes. No se permite desactivar ni degradar al último administrador.

El administrador inicial se crea mediante un procedimiento local con contraseña elegida por el usuario y entrada oculta. No habrá contraseña predeterminada ni creación de administradores desde el formulario público.

La contraseña MariaDB se utiliza solo en memoria. El iniciador la pide mediante entrada oculta; los archivos contienen únicamente configuración no secreta. El navegador no puede cambiar servidor, base o controlador.

## API y operación local

FastAPI organizará autenticación, usuarios, catálogo, relaciones, grafo y estimaciones. Los campos e identificadores propios estarán en inglés/PascalCase; las rutas serán coherentes y en inglés. Los mensajes de usuario estarán en español. Se rechazan campos desconocidos, entradas inválidas y cuerpos excesivos.

El acceso ODBC síncrono se ejecutará en rutas síncronas o en un pool, sin bloquear el bucle asíncrono ni compartir conexiones entre hilos. Cada operación de varias tablas confirma o revierte una transacción.

React se compila con Vite. Para uso normal, Python sirve la compilación y la API en http://127.0.0.1:3000/. El iniciador detectará un puerto ocupado. Las dependencias Python se aislarán dentro del proyecto y se fijarán las versiones de dependencias de ambos lenguajes.

## Verificación

1. Comparar los 40 elementos y las 92 relaciones durante la migración; repetirla no duplica datos.
2. Confirmar que altas, cambios, bajas y pesos persisten después de reiniciar.
3. Rechazar duplicados, extremos ausentes y pesos inválidos; probar rollback ante fallos intermedios.
4. Probar cálculos decimales, proveedores alternativos, cantidades fraccionarias y precios faltantes.
5. Verificar registro Consulta, login/logout, expiración, CSRF, permisos, rechazo de elevación de perfil y protección del último administrador.
6. Probar navegación, formularios, cancelación de eliminación, zoom y consulta API en navegador real.
7. Comprobar escritorio/móvil, teclado y consola durante los flujos probados.
8. Ejecutar las 21 pruebas originales como referencia y nuevas pruebas de Python, API y SQL. Los registros de prueba se identificarán y limpiarán en AbastecePyme; no se usarán otras bases.
9. Entregar instrucciones de arranque, administrador, esquema, respaldo, convenciones, pesos sintéticos, skills y resultados reales.

## Estado de MariaDB

La tabla mysql.db estaba corrupta. Se respaldaron sus 158 archivos de datos y se verificaron sus hashes. El usuario autorizó descartar las cuatro filas dañadas de permisos por base y ejecutó la reparación desde su PowerShell.

Después del reinicio se comprobó directamente: autenticación correcta, CHECK TABLE mysql.db = OK y permisos SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX y ALTER sobre abastecepyme para usuario_python3@localhost. La nueva base todavía no existe. No se modifica gym_admin_management.

## A criterio del implementador

Organización de módulos y componentes, detalles de la distribución visual, valores sintéticos razonables y textos de ayuda, respetando las invariantes, el alcance y la paleta.

## Fuentes consultadas

- https://react.dev/learn/build-a-react-app-from-scratch
- https://fastapi.tiangolo.com/tutorial/security/oauth2-jwt/
- https://cheatsheetseries.owasp.org/cheatsheets/Password_Storage_Cheat_Sheet.html
- https://mariadb.com/docs/server/reference/sql-statements/account-management-sql-statements/grant

