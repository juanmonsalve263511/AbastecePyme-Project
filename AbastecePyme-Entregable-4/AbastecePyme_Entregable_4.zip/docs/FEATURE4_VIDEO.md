# Video de demostración — Feature 4

Fecha: **14 de noviembre de 2026**. Duración del video entregado: **2 minutos y 15 segundos**. Se conserva también un guion ampliado para una exposición de aproximadamente tres minutos.

## Archivos de entrega y estado

| Archivo | Función | Estado de verificación |
|---|---|---|
| [Feature4-Recorrido.webm](media/Feature4-Recorrido.webm) | Video del recorrido real por la aplicación. | Exportado, decodificado y reproducido completamente en el navegador, sin errores. |
| [Feature4-Recorrido.srt](media/Feature4-Recorrido.srt) | Textos y marcas de tiempo que acompañan el recorrido. | Incluido; termina en 00:02:15. |
| [Feature4-Pitch.html](media/Feature4-Pitch.html) | Presentación visual del problema, solución y alcance. | Seis diapositivas revisadas; ajuste comprobado a 720 px de altura y avance automático de la primera a la cuarta diapositiva. |
| [FEATURE4_PITCH.md](FEATURE4_PITCH.md) | Texto listo para presentar en 60–90 segundos. | Guion redactado. |

El video pesa **5.313.461 bytes**, usa **VP9**, resolución **1280 × 816** y salida de **25 fotogramas por segundo**. Se comprobaron los **3.375 fotogramas** mediante decodificación completa, sin errores. El navegador reprodujo los **135 segundos completos**, llegó al final y no registró error.

Es un **montaje de capítulos de interacción real**, capturados mediante el navegador integrado y computer-use/CUA a aproximadamente cuatro capturas por segundo. La salida repite **473 capturas originales**, incorpora títulos y es **sin voz**. Los 25 fotogramas por segundo del archivo no representan 25 capturas originales distintas por segundo. Playwright CLI no pudo iniciar Chrome/Chromium en este entorno y no fue la vía de captura.

### Contenido del archivo entregado

Rangos aproximados para localizar cada parte; el SRT conserva las marcas precisas:

| Tiempo | Contenido |
|---|---|
| 00:00–00:09 | Tablero y contexto de la instancia sintética. |
| 00:09–00:23 | Registro de Panel preparado → Estante modular. |
| 00:23–00:44 | Indisponibilidad simulada, consecuencias y camino hasta Estante. |
| 00:44–00:59 | Orden válido y requisitos antes de dependientes. |
| 00:59–01:35 | Cambio temporal, comparación, ciclo y resaltado en el grafo. |
| 01:35–01:49 | Vuelta a la red actual y descarte de la hipótesis. |
| 01:49–02:08 | Código inexistente `404` y dato inválido `422`. |
| 02:08–02:15 | Cierre del recorrido. |

## Preparación de la demostración

Se proporciona [SupplyBoardPreview.py](../tests/fixtures/SupplyBoardPreview.py), una instancia de demostración que usa la API y la autenticación de la aplicación con un adaptador SQL sobre **SQLite en memoria**. No sustituye el inicio de sesión mediante un acceso directo ni se conecta a MariaDB. Al detenerla, se descartan sus datos.

Con las dependencias del proyecto instaladas, ejecuta desde su carpeta:

```powershell
npm run build --prefix frontend
.\.venv\Scripts\python.exe -X utf8 tests/fixtures/SupplyBoardPreview.py --port 3014
```

Abre [la demostración local](http://127.0.0.1:3014/). La cuenta sintética es **demo_editor**, con contraseña **Feature4-Demo-Only!2026**. Estos datos solo existen en esa demostración temporal: **no son credenciales de la instalación real ni crean acceso a MariaDB**. El servidor escucha en la propia máquina. Detén su ventana con Ctrl+C para terminar; al iniciarlo otra vez, recupera su conjunto inicial.

Inicia sesión antes de grabar. No muestres contraseñas, cuentas personales, mensajes de contacto ni datos operativos. Las modificaciones que se vean en el video deben pertenecer a esta instancia.

| Código de prueba | Nombre | Estado inicial |
|---|---|---|
| `PROV-NORTE` | Maderas del Norte | Proveedor del tablero. |
| `INS-TABLERO` | Tablero de madera | Insumo requerido por el panel. |
| `PROD-PANEL` | Panel preparado | Producto que representa un componente. |
| `PROD-ESTANTE` | Estante modular | Producto inicialmente sin la dependencia del panel. |
| `PROD-AISLADO` | Producto independiente | Elemento existente sin conexiones, para distinguirlo de un código inexistente. |

La cadena inicial es **Maderas del Norte → Tablero de madera → Panel preparado**. La demostración registra **Panel preparado → Estante modular** y lee la frase «Para preparar Estante modular, necesito Panel preparado». Después compara temporalmente **Estante modular → Panel preparado**, que cierra un ciclo. El cambio temporal se descarta sin guardar. Este ejemplo mantiene separadas una dependencia registrada en la instancia de prueba y una hipótesis de análisis.

## Guion ampliado para una exposición de tres minutos

Este guion permite acompañar una demostración en vivo con más pausas. Sus tiempos no corresponden al montaje de 2:15 que se entrega arriba.

| Tiempo | Acción visible | Narración sugerida |
|---|---|---|
| 00:00–00:20 | Mostrar el tablero y los elementos de la instancia de demostración. | «Compras necesita saber qué cambia cuando falta un proveedor. Cada flecha va del requisito a lo que depende de él: para preparar B, necesito A.» |
| 00:20–00:55 | Registrar Panel → Estante y mostrar la relación guardada y su flecha. | «Cargamos una dependencia entre elementos existentes. El estante requiere este panel. La relación pertenece al catálogo de demostración.» |
| 00:55–01:30 | Elegir el proveedor como origen, analizar su indisponibilidad potencial y destacar el camino hasta Estante. | «El recorrido encuentra el tablero, el panel y el estante. El camino explica la conexión. Son consecuencias potenciales: otro proveedor o las existencias pueden cambiar la situación real.» |
| 01:30–01:55 | Mostrar el orden válido y sus etapas. | «La preparación respeta cada requisito antes de su dependiente. Esto organiza precedencias; no calcula plazos ni comprueba inventario.» |
| 01:55–02:25 | Añadir temporalmente Estante → Panel, comparar y destacar el ciclo. | «Probamos un requisito distinto sin guardarlo. Ahora el panel necesita el estante y el estante necesita el panel. El sistema identifica la contradicción y evita presentar un orden falso.» |
| 02:25–02:45 | En Explorador de API, elegir POST · Análisis del tablero y mostrar el rechazo de un código inexistente y de un dato inválido. | «Un código inexistente recibe una respuesta distinta de un dato mal formado. El rechazo no crea elementos ni relaciones parciales.» |
| 02:45–03:00 | Descartar la comparación, repetir la simulación base y cerrar con la matriz de aceptación y los entregables. | «Podemos volver a la red registrada, revisar lo que cambia y justificar cada resultado. La documentación y las pruebas acompañan esta demostración.» |

### Mostrar los dos errores desde la aplicación

En la instancia sintética, abre **Explorador de API**, elige **POST · Análisis del tablero** y sustituye **Datos de la solicitud (JSON)** por este cuerpo para el caso inexistente:

```json
{"ElementId":"MISSING","ProductId":null,"Change":null}
```

Pulsa **Analizar escenario**: se espera `404`. Después cambia únicamente el código a **bad!** y repite: se espera `422`. Ambas son consultas sin escritura. Para terminar, vuelve al código válido **PROV-NORTE**. Los selectores del tablero solo ofrecen elementos del catálogo; este editor permite mostrar explícitamente las entradas que el servidor debe rechazar.

## Cómo revisar o volver a entregar el video

1. Reproducir el archivo completo y confirmar que contiene movimiento e interacciones reales legibles.
2. Medir la duración real; anotarla en la tabla de estado en lugar de asumir los tres minutos previstos.
3. Verificar que se ve la dependencia registrada, la consulta de impacto, su camino y el orden o ciclo.
4. Identificar la instancia como demostración con datos sintéticos. No presentar una prueba aislada como una comprobación sobre MariaDB operativa.
5. Verificar que el video, el pitch visual y sus enlaces están incluidos en el paquete distribuible.

El video se entrega sin narración; este documento aporta el texto para acompañarlo. El [pitch](FEATURE4_PITCH.md) es una presentación separada de 60–90 segundos. Descarga o descomprime el proyecto para abrir los archivos localmente; los enlaces del repositorio pueden mostrar una vista de archivo en lugar de iniciar su reproducción.
