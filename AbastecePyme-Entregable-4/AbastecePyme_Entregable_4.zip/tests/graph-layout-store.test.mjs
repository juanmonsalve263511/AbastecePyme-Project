import test from 'node:test';
import assert from 'node:assert/strict';
import {GraphLayoutStore,LayoutDraftKey,NormalizeLayoutPayload} from '../frontend/src/GraphLayoutStore.js';

const Body=X=>({Positions:[{ElementId:'NODE-A',X,Y:40}]});
const MapOf=X=>new Map([['NODE-A',{X,Y:40}]]);
function MemoryStorage(){const Values=new Map();return {getItem:Key=>Values.get(Key)??null,setItem:(Key,Value)=>Values.set(Key,Value),removeItem:Key=>Values.delete(Key)};}
function Deferred(){let Resolve,Reject;const PromiseValue=new Promise((Yes,No)=>{Resolve=Yes;Reject=No;});return {Promise:PromiseValue,Resolve,Reject};}
const Tick=()=>new Promise(Resolve=>setImmediate(Resolve));
function Store(Request,Storage=MemoryStorage(),UserId='USER-A'){return new GraphLayoutStore({UserId,Request,Storage});}

test('initial loading cannot overwrite a stored layout with an empty initial map and loads once per view',async()=>{
  const Calls=[],Pending=Deferred();
  const Layouts=Store((Key,Options)=>{Calls.push({Key,...Options});return Pending.Promise;});
  const Load=Layouts.Load('Graph');
  assert.equal(Layouts.Commit('Graph',new Map()),false);
  assert.equal(Layouts.GetSnapshot('Graph').Ready,false);
  Pending.Resolve(Body(150));await Load;
  await Layouts.Load('Graph');
  assert.equal(Calls.length,1);assert.equal(Calls[0].method,'GET');
  assert.equal(Layouts.GetSnapshot('Graph').Positions.get('NODE-A').X,150);
  assert.equal(Layouts.GetSnapshot('Graph').Status,'Saved');
});

test('loading an unchanged automatic distribution keeps its position identity for exploration in progress',async()=>{
  const Layouts=Store(async()=>({Positions:[]}));
  const Before=Layouts.GetSnapshot('Graph').Positions;
  await Layouts.Load('Graph');
  assert.equal(Layouts.GetSnapshot('Graph').Positions,Before);
});

test('completed edits are serial and coalesce intermediate positions without an older acknowledgement winning',async()=>{
  const Storage=MemoryStorage(),Writes=[],Replies=[];
  const Layouts=Store((Key,Options)=>{
    if(Options.method==='GET')return Promise.resolve(Body(0));
    Writes.push(Options.body);const Reply=Deferred();Replies.push(Reply);return Reply.Promise;
  },Storage);
  await Layouts.Load('Graph');
  Layouts.Commit('Graph',MapOf(10));Layouts.Commit('Graph',MapOf(20));Layouts.Commit('Graph',MapOf(30));
  assert.equal(Writes.length,1);
  assert.equal(JSON.parse(Storage.getItem(LayoutDraftKey('USER-A','Graph'))).Positions[0].X,30);
  Replies[0].Resolve(Body(10));await Tick();
  assert.deepEqual(Writes,[Body(10),Body(30)]);
  assert.equal(Layouts.GetSnapshot('Graph').Positions.get('NODE-A').X,30);
  assert.ok(Storage.getItem(LayoutDraftKey('USER-A','Graph')));
  Replies[1].Resolve(Body(30));await Layouts.Flush();
  assert.equal(Layouts.GetSnapshot('Graph').Status,'Saved');
  assert.equal(Storage.getItem(LayoutDraftKey('USER-A','Graph')),null);
});

test('a failed save keeps its browser draft and retry saves the current positions',async()=>{
  const Storage=MemoryStorage();let Fail=true;const Writes=[];
  const Layouts=Store(async(Key,Options)=>{
    if(Options.method==='GET')return Body(0);
    Writes.push(Options.body);if(Fail)throw new Error('Offline');return Options.body;
  },Storage);
  await Layouts.Load('Impact');Layouts.Commit('Impact',MapOf(-25));await Layouts.Flush();
  assert.equal(Layouts.GetSnapshot('Impact').Status,'Error');
  assert.ok(Storage.getItem(LayoutDraftKey('USER-A','Impact')));
  Fail=false;await Layouts.Retry('Impact');
  assert.deepEqual(Writes,[Body(-25),Body(-25)]);
  assert.equal(Layouts.GetSnapshot('Impact').Status,'Saved');
  assert.equal(Storage.getItem(LayoutDraftKey('USER-A','Impact')),null);
});

test('an edit between acknowledgement and queue cleanup is sent without another gesture or retry',async()=>{
  const Reply=Deferred(),Writes=[];
  const Layouts=Store((Key,Options)=>{
    if(Options.method==='GET')return Promise.resolve(Body(0));
    Writes.push(Options.body);return Writes.length===1?Reply.Promise:Promise.resolve(Options.body);
  });
  await Layouts.Load('Graph');Layouts.Commit('Graph',MapOf(10));
  Reply.Promise.then(()=>Layouts.Commit('Graph',MapOf(20)));
  Reply.Resolve(Body(10));await Layouts.Flush();
  assert.deepEqual(Writes,[Body(10),Body(20)]);
  assert.equal(Layouts.GetSnapshot('Graph').Status,'Saved');
  assert.equal(Layouts.GetSnapshot('Graph').Positions.get('NODE-A').X,20);
});

test('a pending reset survives immediate reload and replays an explicit empty layout after reading the server',async()=>{
  const Storage=MemoryStorage(),Unfinished=Deferred();
  const First=Store((Key,Options)=>Options.method==='GET'?Promise.resolve(Body(200)):Unfinished.Promise,Storage);
  await First.Load('Production');First.Commit('Production',new Map());First.Dispose();
  const Calls=[];
  const Reloaded=Store(async(Key,Options)=>{Calls.push(Options);return Options.method==='GET'?Body(200):Options.body;},Storage);
  await Reloaded.Load('Production');await Reloaded.Flush();
  assert.deepEqual(Calls.map(Call=>Call.method),['GET','PUT']);
  assert.deepEqual(Calls[1].body,{Positions:[]});
  assert.equal(Reloaded.GetSnapshot('Production').Positions.size,0);
  Unfinished.Resolve({Positions:[]});await Tick();
});

test('hidden or deleted node positions remain in complete saved layouts across graph remounts',async()=>{
  const Initial={Positions:[{ElementId:'HIDDEN-NODE',X:12,Y:34},{ElementId:'NODE-A',X:0,Y:40}]};
  const Writes=[];const Layouts=Store(async(Key,Options)=>{if(Options.method==='GET')return Initial;Writes.push(Options.body);return Options.body;});
  await Layouts.Load('SupplyBoard');
  const Positions=new Map(Layouts.GetSnapshot('SupplyBoard').Positions);Positions.set('NODE-A',{X:50,Y:60});
  Layouts.Commit('SupplyBoard',Positions);await Layouts.Flush();
  await Layouts.Load('SupplyBoard');
  assert.equal(Writes[0].Positions.length,2);
  assert.deepEqual(Layouts.GetSnapshot('SupplyBoard').Positions.get('HIDDEN-NODE'),{X:12,Y:34});
});

test('account disposal ignores late responses and never sends queued positions with another account',async()=>{
  const Storage=MemoryStorage(),OldReply=Deferred(),OldWrites=[];
  const A=Store((Key,Options)=>{if(Options.method==='GET')return Promise.resolve(Body(0));OldWrites.push(Options.body);return OldReply.Promise;},Storage,'USER-A');
  await A.Load('Graph');A.Commit('Graph',MapOf(10));A.Commit('Graph',MapOf(20));A.Dispose();
  const BCalls=[];const B=Store(async(Key,Options)=>{BCalls.push(Options);return Body(900);},Storage,'USER-B');
  await B.Load('Graph');OldReply.Resolve(Body(10));await Tick();
  assert.equal(OldWrites.length,1);
  assert.equal(BCalls.length,1);
  assert.equal(B.GetSnapshot('Graph').Positions.get('NODE-A').X,900);
  assert.equal(JSON.parse(Storage.getItem(LayoutDraftKey('USER-A','Graph'))).Positions[0].X,20);
  assert.equal(Storage.getItem(LayoutDraftKey('USER-B','Graph')),null);
});

test('corrupt or cross-account drafts are discarded rather than replayed as empty positions',async()=>{
  for(const Draft of ['{bad',JSON.stringify({Version:1,UserId:'OTHER',LayoutKey:'Graph',ChangeId:'x',...Body(2)}),JSON.stringify({Version:1,UserId:'USER-A',LayoutKey:'Graph',ChangeId:'x',Positions:[{ElementId:'NODE-A',X:'2',Y:4}]})]){
    const Storage=MemoryStorage(),Calls=[];Storage.setItem(LayoutDraftKey('USER-A','Graph'),Draft);
    const Layouts=Store(async(Key,Options)=>{Calls.push(Options);return Body(88);},Storage);
    await Layouts.Load('Graph');await Layouts.Flush();
    assert.equal(Calls.length,1);assert.equal(Layouts.GetSnapshot('Graph').Positions.get('NODE-A').X,88);
  }
});

test('failed or malformed loading remains protected until a successful retry',async()=>{
  let Good=false;const Calls=[];
  const Layouts=Store(async(Key,Options)=>{Calls.push(Options);return Good?Body(77):{Positions:[{ElementId:'NODE-A',X:null,Y:0}]};});
  await Layouts.Load('Graph');
  assert.equal(Layouts.GetSnapshot('Graph').Ready,false);
  assert.equal(Layouts.GetSnapshot('Graph').Status,'Error');
  assert.equal(Layouts.Commit('Graph',MapOf(2)),false);
  Good=true;await Layouts.Retry('Graph');
  assert.equal(Layouts.GetSnapshot('Graph').Positions.get('NODE-A').X,77);
  assert.ok(Calls.every(Call=>Call.method==='GET'));
});

test('a synchronous transport failure can be retried instead of caching a finished loading promise',async()=>{
  let Fail=true;const Layouts=Store(()=>{if(Fail)throw new Error('Unavailable');return Promise.resolve(Body(5));});
  await Layouts.Load('Graph');assert.equal(Layouts.GetSnapshot('Graph').Ready,false);
  Fail=false;await Layouts.Retry('Graph');assert.equal(Layouts.GetSnapshot('Graph').Positions.get('NODE-A').X,5);
});

test('storage failure does not prevent a server save and an older tab cannot remove a newer draft',async()=>{
  const Throwing={getItem(){throw Error('disabled');},setItem(){throw Error('disabled');},removeItem(){throw Error('disabled');}};
  const Layouts=Store(async(Key,Options)=>Options.method==='GET'?Body(0):Options.body,Throwing);
  await Layouts.Load('Graph');Layouts.Commit('Graph',MapOf(5));await Layouts.Flush();
  assert.equal(Layouts.GetSnapshot('Graph').Status,'Saved');
  const Storage=MemoryStorage(),Reply=Deferred();
  const Other=Store((Key,Options)=>Options.method==='GET'?Promise.resolve(Body(0)):Reply.Promise,Storage);
  await Other.Load('Graph');Other.Commit('Graph',MapOf(1));
  const Newer=JSON.stringify({Version:1,UserId:'USER-A',LayoutKey:'Graph',ChangeId:'new-tab',...Body(10)});
  Storage.setItem(LayoutDraftKey('USER-A','Graph'),Newer);Reply.Resolve(Body(1));await Other.Flush();
  assert.equal(Storage.getItem(LayoutDraftKey('USER-A','Graph')),Newer);
});

test('position validation enforces the server limits, stable IDs and duplicate protection',()=>{
  assert.deepEqual(NormalizeLayoutPayload({Positions:[{ElementId:'NODE-B',X:1e6,Y:-1e6},{ElementId:'NODE-A',X:0,Y:0}]}).Positions.map(Item=>Item.ElementId),['NODE-A','NODE-B']);
  for(const Positions of [[{ElementId:'NODE-A',X:Infinity,Y:0}],[{ElementId:'NODE-A',X:1000001,Y:0}],[{ElementId:'__proto__',X:0,Y:0}],[...Body(0).Positions,...Body(1).Positions],Array.from({length:1001},(_,Index)=>({ElementId:'NODE-'+Index,X:0,Y:0}))])assert.throws(()=>NormalizeLayoutPayload({Positions}));
  assert.throws(()=>LayoutDraftKey('USER-A','Other'));
});
