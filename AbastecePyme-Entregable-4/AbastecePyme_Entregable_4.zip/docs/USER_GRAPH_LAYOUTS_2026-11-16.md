# Distribución por usuario y movimiento continuo

## Guardar el acomodo del grafo

Entra a tu cuenta y mueve los cuadros como prefieras. La aplicación guarda las posiciones al terminar el arrastre o mover con el teclado; no requiere pulsar un botón adicional. Espera la confirmación de guardado antes de cerrar la aplicación.

Cada usuario tiene una distribución independiente para **Grafo de abastecimiento**, **Análisis de impacto**, **Orden de producción** y **Tablero de abastecimiento**. Al recargar, regresar a esa sección o iniciar sesión otra vez se recupera el acomodo de esa cuenta. También se obtiene desde otro navegador conectado al mismo servidor. El enfoque, zoom y selección temporal no se guardan.

**Restaurar distribución** devuelve esa sección a sus posiciones automáticas y guarda el restablecimiento. **Restablecer** también elimina su acomodo manual, además de limpiar el enfoque y la selección. Ninguna de las dos acciones elimina proveedores, insumos, productos o relaciones.

Si se pierde la conexión, la interfaz informa que el guardado está pendiente y permite reintentar. El navegador conserva un borrador de coordenadas separado por usuario para recuperar cambios interrumpidos. Un error no se presenta como un guardado correcto. La cuenta de consulta también puede organizar sus propios grafos sin adquirir permisos de edición del catálogo.

Si la misma cuenta modifica la misma sección simultáneamente en dos navegadores, prevalece la última escritura recibida por el servidor. Los cambios entre pestañas no se sincronizan en tiempo real; recargar recupera la versión guardada. Cada distribución admite hasta 1000 cuadros con posición manual.

## Animación de la portada

Los puntos de la ilustración «Red de producción» recorren sus conexiones continuamente y con velocidad constante. El ciclo no se detiene tras la entrada a la página. **Pausar animación** permite detenerlo, y **Reanudar animación**, continuar. La preferencia **Reducir movimiento** de la aplicación o del sistema mantiene la ilustración estática.

## Instalación y datos

El guardado por cuenta incluye Python y una tabla de preferencias llamada `UserGraphLayouts`; requiere reiniciar AbastecePyme una vez al actualizar desde una versión anterior. Ese reinicio ya se confirmó en 3001. Para otra instalación anterior, con MySQL iniciado, detén sólo la consola de AbastecePyme con Ctrl+C, ejecuta `Iniciar.cmd --port 3001` e introduce la contraseña de MariaDB en el aviso oculto. Después recarga con Ctrl+F5. El último ajuste de velocidad solo cambia CSS: tras compilar, basta con Ctrl+F5, sin reiniciar.

La preparación del esquema crea únicamente la tabla faltante en una instalación actualizada. No sustituye tablas de negocio ni modifica precios, relaciones o la semilla original. Las preferencias se guardan con la cuenta autenticada; no se acepta un identificador de otro usuario en la solicitud. La lectura requiere sesión y la escritura conserva la validación de origen y CSRF.

## Implementación

React mantiene una cola de escrituras por cuenta y sección y separa las coordenadas terminadas del movimiento transitorio. FastAPI valida los identificadores, duplicados, cantidad de cuadros y coordenadas finitas. MariaDB conserva un documento de posiciones por usuario y vista. Los grafos siguen usando SVG y algoritmos propios, sin bibliotecas de grafos adicionales.

La animación del homepage utiliza un ciclo CSS lineal de **2,083333 segundos**: el desplazamiento de 86 unidades coincide con el patrón de trazo de 6 + 80, evitando un salto al reiniciar el ciclo. Después del primer ajuste de cuatro a 2,5 segundos, esta entrega aumenta la velocidad otro **20 %**: `2,5 / 1,20 = 2,083333` segundos. Se mantienen la repetición continua, la pausa y el movimiento reducido. Las mediciones de navegador siguientes documentan la validación inicial con el ciclo de cuatro segundos, no una nueva medición visual de esta velocidad.

## Verificación y activación

**Ajuste posterior de velocidad y documentación:** se recompiló la interfaz (61 módulos) y se comprobó en el CSS generado el ciclo de aproximadamente 2,08333 segundos, equivalente a otro 20 % de velocidad. Se conservan las reglas de pausa y movimiento reducido. Este ajuste no modifica Python ni datos y no repite las pruebas funcionales o el recorrido de navegador de la entrega inicial descritos a continuación.

El 16 de noviembre se aprobaron **141 pruebas Python y 117 JavaScript: 258 en total**, con compilación de **61 módulos**. Se añadieron pruebas de aislamiento por cuenta, validación, migración aditiva, guardado y restablecimiento, carga fallida, borradores y orden de escrituras. La revisión independiente detectó una carrera entre confirmación y cierre de la cola; se corrigió y se añadió una regresión que comprueba el envío del último cambio.

El recorrido de navegador usó cuentas sintéticas y SQLite en memoria en **3019**, separado de MariaDB:

| Comprobación | Resultado observado |
|---|---|
| Arrastre individual y de grupo con Ctrl | Posiciones actualizadas y confirmación de guardado. |
| Recarga | Las coordenadas de proveedor e insumo se recuperaron exactamente. |
| Cambio de cuenta | Consulta empezó con sus posiciones automáticas, guardó una posición distinta y no sobrescribió las del Editor. |
| Nueva sesión sin borrador compartido | En `localhost:3019`, con almacenamiento separado de `127.0.0.1:3019`, el Editor recuperó las coordenadas guardadas en el servidor. |
| Restaurar distribución | Volvió a las coordenadas automáticas y permaneció restaurada tras recargar. |
| Costos y selección | Se mantuvo la opción económica del producto durante los movimientos. |
| Animación continua | `4s linear infinite SupplyFlow`; el desplazamiento cambió después de 12,5 segundos, superando tres ciclos. |
| Pausa y reanudación | El desplazamiento permaneció exactamente constante al pausar y volvió a cambiar al reanudar. |
| Movimiento reducido | Al activar la preferencia del sitio, la animación pasó a `none` y el control de pausa se ocultó. La regla del sistema se conserva en CSS; no se cambió la preferencia del sistema operativo. |
| Pantalla pequeña | 390 × 844, con 375 px visibles y desplazables; controles sin desbordamiento horizontal. No se probó hardware táctil. |
| Consola | Cero errores en las dos sesiones de comprobación. |

El usuario confirmó el reinicio de **3001**. Después se verificó HTTP 200, `index.html` idéntico a la compilación final y la ruta de preferencias devolviendo **401 sin sesión**, conforme al control de acceso. No se efectuó una escritura autenticada de prueba en MariaDB; los resultados funcionales anteriores corresponden a la instancia sintética. La semilla conserva su huella original.

![Distribución y confirmación de guardado](media/user-layouts-2026-11-16/02-account-layout.jpg)

[Portada con control de animación](media/user-layouts-2026-11-16/01-home-continuous.jpg) · [Estado de guardado en pantalla pequeña](media/user-layouts-2026-11-16/03-mobile-save-status.jpg).
