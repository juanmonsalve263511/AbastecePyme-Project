"""Exercise actual response middleware without requiring a loopback socket."""
import gzip
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest
from fastapi.responses import Response
from starlette.routing import Route
from starlette.staticfiles import StaticFiles
from backend.Main import CreateApp


class StaticDeliveryTests(unittest.TestCase):
    def Request(self, PathValue, Reply=None, Method="GET", Headers=(), Body=b"", Failure=None):
        App = CreateApp(None)

        async def Endpoint(Request):
            if Failure is not None:
                raise Failure
            return Reply or Response("Success")

        App.router.routes.insert(0, Route("/{Resource:path}", Endpoint, methods=["GET", "HEAD", "POST"]))
        Scope = {"type": "http", "asgi": {"version": "3.0", "spec_version": "2.4"},
                 "method": Method, "path": PathValue, "raw_path": PathValue.encode(),
                 "root_path": "", "query_string": b"", "scheme": "http", "http_version": "1.1",
                 "server": ("127.0.0.1", 3000), "client": ("127.0.0.1", 1234),
                 "headers": [*([(b"host", b"127.0.0.1:3000")] if not any(Key == b"host" for Key, _ in Headers) else []), *Headers]}
        Messages = []

        async def Receive():
            return {"type": "http.request", "body": Body, "more_body": False}

        async def Send(Message):
            Messages.append(Message)

        # All test responses are ready in memory; advancing once runs the whole
        # ASGI chain, including FastAPI's registered middleware and error handler.
        RequestTask = App(Scope, Receive, Send)
        try:
            RequestTask.send(None)
        except StopIteration:
            pass
        except Exception as Error:
            if Error is not Failure:
                raise
        else:
            self.fail("The in-memory response unexpectedly required external I/O")
        finally:
            RequestTask.close()
        Start = next(Message for Message in Messages if Message["type"] == "http.response.start")
        ResultHeaders = dict(Start["headers"])
        self.assertEqual(sum(Key == b"cache-control" for Key, _ in Start["headers"]), 1)
        return Start["status"], ResultHeaders, b"".join(
            Message.get("body", b"") for Message in Messages if Message["type"] == "http.response.body")

    def test_successful_hashed_assets_are_immutable_and_replace_existing_cache_headers(self):
        for Name in ("index-Ab12_cd3.js", "Production-CO9t-S4u.js", "index-Ab12_cd3.css"):
            with self.subTest(Name=Name):
                Reply = Response("asset", media_type="text/javascript", headers={"Cache-Control": "private"})
                Reply.raw_headers.append((b"cache-control", b"max-age=5"))
                Status, Headers, _ = self.Request("/assets/" + Name, Reply)
                self.assertEqual(Status, 200)
                self.assertEqual(Headers[b"cache-control"], b"public, max-age=31536000, immutable")

    def test_api_html_unhashed_assets_and_missing_assets_are_not_stored(self):
        for PathValue, Status, MediaType in (
            ("/api/catalog", 200, "application/json"), ("/", 200, "text/html"),
            ("/assets/index.js", 200, "text/javascript"),
            ("/assets/index-Ab12_cd3.html", 200, "text/html"),
            ("/assets/missing-Ab12_cd3.js", 404, "application/json"),
            ("/images/missing.webp", 404, "application/json"),
        ):
            with self.subTest(Path=PathValue):
                _, Headers, _ = self.Request(PathValue, Response("body", status_code=Status, media_type=MediaType))
                self.assertEqual(Headers[b"cache-control"], b"no-store")

    def test_images_keep_etags_and_revalidate_unchanged_files(self):
        with TemporaryDirectory() as Folder:
            Image = Path(Folder) / "workshop.webp"
            Image.write_bytes(b"image fixture")
            Files = StaticFiles(directory=Folder)
            Reply = Files.file_response(Image, Image.stat(), {"headers": []})
            Status, Headers, _ = self.Request("/images/workshop.webp", Reply, Method="HEAD")
            self.assertEqual(Status, 200)
            self.assertEqual(Headers[b"cache-control"], b"public, max-age=0, must-revalidate")
            Etag = Headers[b"etag"]
            Unchanged = Files.file_response(Image, Image.stat(), {"headers": [(b"if-none-match", Etag)]})
            Status, Headers, Body = self.Request("/images/workshop.webp", Unchanged)
            self.assertEqual(Status, 304)
            self.assertEqual(Headers[b"etag"], Etag)
            self.assertEqual(Headers[b"cache-control"], b"public, max-age=0, must-revalidate")
            self.assertEqual(Body, b"")

    def test_boundary_rejections_and_server_errors_are_not_stored(self):
        for PathValue, Method, Headers, Body, Expected in (
            ("/api/catalog", "POST", (), b"", 403),
            ("/api/catalog", "POST", ((b"origin", b"http://127.0.0.1:3000"),), b"", 415),
            ("/assets/index-Ab12_cd3.js", "GET", (), b"x" * 32769, 413),
            ("/assets/index-Ab12_cd3.js", "GET", ((b"host", b"untrusted.example"),), b"", 400),
        ):
            with self.subTest(Expected=Expected):
                Status, ResponseHeaders, _ = self.Request(PathValue, Method=Method, Headers=Headers, Body=Body)
                self.assertEqual(Status, Expected)
                self.assertEqual(ResponseHeaders[b"cache-control"], b"no-store")
        Status, Headers, _ = self.Request("/assets/index-Ab12_cd3.js", Failure=RuntimeError("test failure"))
        self.assertEqual(Status, 500)
        self.assertEqual(Headers[b"cache-control"], b"no-store")

    def test_latin_one_request_headers_do_not_crash(self):
        Status, _, Body = self.Request("/api/catalog", Headers=((b"x-client-label", b"caf\xe9"),))
        self.assertEqual(Status, 200)
        self.assertEqual(Body, b"Success")

    def test_large_json_and_text_are_compressed_with_a_matching_length(self):
        Original = b"abcdefghij" * 200
        for MediaType in ("application/json", "text/css", "text/javascript"):
            with self.subTest(MediaType=MediaType):
                _, Headers, Body = self.Request("/api/catalog", Response(Original, media_type=MediaType),
                                                Headers=((b"accept-encoding", b"gzip"),))
                self.assertEqual(Headers[b"content-encoding"], b"gzip")
                self.assertIn(b"Accept-Encoding", Headers[b"vary"])
                self.assertEqual(int(Headers[b"content-length"]), len(Body))
                self.assertLess(len(Body), len(Original))
                self.assertEqual(gzip.decompress(Body), Original)

    def test_small_responses_images_and_clients_without_gzip_keep_original_bytes(self):
        for MediaType, Length, Encoding in (
            ("application/json", 999, b"gzip"), ("image/webp", 2000, b"gzip"),
            ("image/png", 2000, b"gzip"), ("image/svg+xml", 2000, b"gzip"),
            ("text/css", 2000, b"identity"),
        ):
            with self.subTest(MediaType=MediaType, Length=Length):
                Original = b"x" * Length
                _, Headers, Body = self.Request("/images/test", Response(Original, media_type=MediaType),
                                                Headers=((b"accept-encoding", Encoding),))
                self.assertNotIn(b"content-encoding", Headers)
                self.assertEqual(Body, Original)
