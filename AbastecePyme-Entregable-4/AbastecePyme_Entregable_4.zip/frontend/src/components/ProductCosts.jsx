import {useEffect,useRef,useState} from 'react';
import {Api,Money,Quantity} from '../Api.js';
import {LatestRequest} from '../LatestRequest.js';
import {Notice} from './Common.jsx';
import {GetSourcingOption} from './ProductCostSelection.js';
import './ProductCosts.css';

export default function ProductCosts({ProductId,Data,SelectedOption='',OnSelectOption}){
  const Gate=useRef(new LatestRequest());
  const [Response,SetResponse]=useState(null);
  const Current=Response?.ProductId===ProductId&&Response.Data===Data?Response:null;
  const Result=Current?.Result,Error=Current?.Error;
  useEffect(()=>{
    SetResponse(null);
    Gate.current.Run(Signal=>Api('/api/products/'+encodeURIComponent(ProductId)+'/estimate',{signal:Signal}),
      Value=>SetResponse({ProductId,Data,Result:Value}),Failure=>SetResponse({ProductId,Data,Error:Failure.message}));
    return()=>Gate.current.Cancel();
  },[ProductId,Data]);
  if(Error)return <Notice Text={Error} Error/>;
  if(!Result||Result.ProductId!==ProductId)return <p role="status">Comparando opciones de abastecimiento…</p>;
  return <section className="product-costs" aria-label="Opciones de costo de producción">
    <header className="costs-heading"><h3>Costo de producción</h3><p className="costs-description">Insumos y componentes para una unidad, según las ofertas registradas. Valores en COP.</p></header>
    {!Result.IsComplete&&<div className="costs-incomplete" role="status"><strong>{Result.Status==='Cycle'?'Dependencias con ciclo':'Cálculo incompleto'}</strong><p>Completa o corrige los requisitos para obtener un costo total y un precio de venta.</p>{Result.Issues?.length>0&&<ul>{Result.Issues.map((Issue,Index)=><li key={Issue.Code+'-'+Issue.ElementId+'-'+Index}>{Issue.Detail}</li>)}</ul>}</div>}
    <div className="calculated-sale-price"><span>Precio de venta</span><strong>{Result.SalePrice!=null?Money(Result.SalePrice)+' COP':'Pendiente de calcular'}</strong><small>Costo mínimo + 25 %</small></div>
    <div className="cost-options">
    {[['Minimum','Opción más económica',Result.MinimumCost],['Maximum','Opción más costosa',Result.MaximumCost]].map(([Kind,Label,Total])=>{const Option=GetSourcingOption(Result,Kind);return <article className={'cost-option '+Kind.toLowerCase()+(SelectedOption===Kind?' is-highlighted':'')} key={Kind} aria-label={Label}>
      <h4>{Label}</h4><strong className="cost-total">{Total!=null?Money(Total)+' COP':'Sin total completo'}</strong>
      {OnSelectOption&&<button type="button" className="cost-highlight-button" aria-pressed={SelectedOption===Kind} disabled={!Option} onClick={()=>OnSelectOption(Option)}>{Kind==='Minimum'?'Resaltar opción económica':'Resaltar opción costosa'}</button>}
      <details open={Kind==='Minimum'}><summary>Ver proveedores e insumos</summary><ul className="cost-materials">{Result.Materials?.map(Material=>{
        const Choice=Material[Kind];
        const SupplierName=Choice?.SupplierName||Material.Offers?.find(Offer=>Offer.SupplierId===Choice?.SupplierId)?.SupplierName||Choice?.SupplierId;
        return <li key={Material.MaterialId}><strong>{Material.Name}</strong><span className="cost-route">{SupplierName||'Sin oferta de proveedor'} → {Material.Name}</span><span>Cantidad: {Quantity(Material.Quantity)} {Material.UnitCode}</span>{Choice&&<><span>Precio unitario: {Money(Choice.UnitPrice)}</span><b>Subtotal: {Money(Choice.Subtotal)}</b></>}</li>;
      })}</ul>{!Result.Materials?.length&&<p>No hay insumos cuantificados.</p>}</details>
    </article>;})}
    </div>
    {OnSelectOption&&SelectedOption&&<button type="button" className="cost-clear-selection" onClick={()=>OnSelectOption(null)}>Quitar selección de costo</button>}
    {Result.Components?.length>0&&<details className="cost-components"><summary>Componentes incluidos</summary><ul>{Result.Components.map(Component=><li key={Component.ProductId}>{Component.Name} <strong>× {Quantity(Component.Quantity)}</strong></li>)}</ul><p>Una unidad por cada relación de componente. Los usos compartidos se suman.</p></details>}
    <p className="costs-footnote">{Result.IsDemo?'Incluye precios o cantidades de referencia. ':''}Costos de materiales; no incluyen mano de obra, transporte ni impuestos. No verifican inventario ni disponibilidad.</p>
  </section>;
}
