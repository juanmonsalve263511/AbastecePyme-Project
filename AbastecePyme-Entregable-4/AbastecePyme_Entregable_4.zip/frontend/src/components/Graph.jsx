import {useCallback,useEffect,useId,useLayoutEffect,useMemo,useRef,useState} from 'react';
import {Heading,Icon,ReferenceBadge,Empty} from './Common.jsx';
import {TypeLabels,Money,Quantity} from '../Api.js';
import {BuildLayout,ApplyNodePositions,EdgePath,EdgeLabelPosition,GraphGeometry,FitGraphView,InitialGraphView,ReadableGraphView,RevealGraphNode,ZoomGraphView,PathEdgeKeys} from './GraphLayout.js';
import ProductCosts from './ProductCosts.jsx';
import {GetCurrentSourcing} from './ProductCostSelection.js';
import useGraphInteraction from './useGraphInteraction.js';
import {useSavedGraphLayout} from '../GraphLayoutsContext.jsx';
import './Graph.css';
const EmptyPath=[];
export default function Graph({Data,InitialFocus='',WholeGraph=false,Embedded=false,ShowCosts=!Embedded,HighlightPath=EmptyPath,Direction='Consequences',SelectedId,OnSelect,InteractionKey=Data,LayoutKey}) {
  const [Focus,SetFocus]=useState(InitialFocus),[LocalSelected,SetLocalSelected]=useState(InitialFocus);
  const [Sourcing,SetSourcing]=useState(null);
  const Selected=SelectedId??LocalSelected;
  const ActiveSourcing=ShowCosts?GetCurrentSourcing(Sourcing,Selected,Data):null;
  const SourcingIds=ActiveSourcing?.Graph.ElementIds||EmptyPath;
  const SourcingNodes=useMemo(()=>new Set(SourcingIds),[SourcingIds]);
  const SourcingEdges=useMemo(()=>new Set((ActiveSourcing?.Graph.Relations||EmptyPath).map(Edge=>Edge.SourceId+'>'+Edge.TargetId)),[ActiveSourcing]);
  const SourcingLabel=ActiveSourcing?.Kind==='Minimum'?'Opción económica':'Opción costosa';
  const SetSelected=useCallback(Value=>{SetLocalSelected(Value);OnSelect?.(Value);},[OnSelect]);
  const [Weights,SetWeights]=useState(false),[View,SetView]=useState(null);
  const [Viewport,SetViewport]=useState({Width:800,Height:520});
  const [MotionPaused,SetMotionPaused]=useState(false),[ReducedMotion,SetReducedMotion]=useState(false);
  const Svg=useRef(null),ViewState=useRef(null);
  const Id=useId(),ArrowId=Id+'-arrow',GridId=Id+'-grid';
  const BaseLayout=useMemo(()=>BuildLayout(Data.Elements,Data.Relations,Focus,WholeGraph,SourcingIds),[Data.Elements,Data.Relations,Focus,WholeGraph,SourcingIds]);
  const UpdateView=useCallback(Update=>SetView(Previous=>{
    const State=ViewState.current;
    if(!State)return Previous;
    const CurrentBox=Previous?.Layout===State.Layout&&Previous.Viewport===State.Viewport?Previous.Box:State.Box;
    const Next=Update(CurrentBox);
    return Next===CurrentBox?Previous:{Layout:State.Layout,Viewport:State.Viewport,Box:Next};
  }),[]);
  const SavedLayout=useSavedGraphLayout(LayoutKey);
  const Interaction=useGraphInteraction({Svg,Context:ViewState,BaseLayout,Viewport,ResetKey:InteractionKey,UpdateView,OnActivate:SetSelected,SavedPositions:SavedLayout.Positions,PositionsReady:SavedLayout.Ready,OnPositionsCommit:SavedLayout.Commit});
  const Layout=useMemo(()=>ApplyNodePositions(BaseLayout,Interaction.Positions),[BaseLayout,Interaction.Positions]);
  const PathEdges=useMemo(()=>PathEdgeKeys(HighlightPath,Direction),[HighlightPath,Direction]);
  const PathNodes=useMemo(()=>new Set(HighlightPath),[HighlightPath]);
  const Fit=useMemo(()=>FitGraphView(Layout,Viewport),[Layout,Viewport]);
  const Anchor=ActiveSourcing?.ProductId||Focus||InitialFocus;
  const InitialView=useMemo(()=>InitialGraphView(Layout,Viewport,Anchor),[Layout,Viewport,Anchor]);
  const Box=View?.Layout===BaseLayout&&View.Viewport===Viewport?View.Box:InitialView;
  const Current=Layout.Map.get(Selected);
  const Linked=useMemo(()=>Selected?Layout.Edges.filter(Edge=>Edge.SourceId===Selected||Edge.TargetId===Selected):[],[Layout,Selected]);
  const SelectSourcing=useCallback(Option=>SetSourcing(Option?{...Option,Data}:null),[Data]);
  const Zoom=useCallback((Factor,Center)=>{if(!Interaction.IsPointerActive())UpdateView(Value=>ZoomGraphView(Value,Factor,Center,Math.max(8000,ViewState.current.Fit.Width*4)));},[UpdateView,Interaction.IsPointerActive]);
  const Reveal=useCallback(Node=>UpdateView(Value=>RevealGraphNode(Value,Node)),[UpdateView]);
  useLayoutEffect(()=>{ViewState.current={Box,Layout:BaseLayout,DisplayLayout:Layout,Viewport,Fit};},[Box,BaseLayout,Layout,Viewport,Fit]);
  useLayoutEffect(()=>{
    const Element=Svg.current;if(!Element)return;
    function Measure(){const Bounds=Element.getBoundingClientRect();const Width=Math.round(Bounds.width),Height=Math.round(Bounds.height);if(Width&&Height)SetViewport(Previous=>Previous.Width===Width&&Previous.Height===Height?Previous:{Width,Height});}
    Measure();
    const Observer=new ResizeObserver(Measure);Observer.observe(Element);
    return()=>Observer.disconnect();
  },[Boolean(Layout.Nodes.length)]);
  useEffect(()=>SetSourcing(null),[Selected,Data,ShowCosts]);
  useEffect(()=>{
    const Preference=window.matchMedia('(prefers-reduced-motion: reduce)'),Root=document.documentElement;
    function Update(){SetReducedMotion(Preference.matches||Root.dataset.reducedMotion==='true');}
    const Observer=new MutationObserver(Update);
    Observer.observe(Root,{attributes:true,attributeFilter:['data-reduced-motion']});
    Preference.addEventListener('change',Update);Update();
    return()=>{Observer.disconnect();Preference.removeEventListener('change',Update);};
  },[]);
  useEffect(()=>{
    if(MotionPaused||ReducedMotion)Svg.current?.pauseAnimations();
    else Svg.current?.unpauseAnimations();
  },[MotionPaused,ReducedMotion,Layout.Nodes.length]);
  function Point(Event){const Matrix=Svg.current?.getScreenCTM();return Matrix?new DOMPoint(Event.clientX,Event.clientY).matrixTransform(Matrix.inverse()):null;}
  useEffect(()=>{
    const Element=Svg.current;if(!Element)return;
    function Wheel(Event){if(Interaction.IsPointerActive()){Event.preventDefault();return;}const Center=Point(Event);if(!Center)return;Event.preventDefault();Zoom(Event.deltaY>0?1.12:.89,Center);}
    Element.addEventListener('wheel',Wheel,{passive:false});
    return()=>Element.removeEventListener('wheel',Wheel);
  },[Zoom,Boolean(Layout.Nodes.length),Interaction.IsPointerActive]);
  function ChangeFocus(Value){Interaction.CancelGesture();SetFocus(Value);SetSelected(Value);SetView(null);}
  function Keys(Event){
    if(Event.key==='Escape'){Event.preventDefault();Event.stopPropagation();Interaction.Escape();return;}
    if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(Event.key))return;
    Event.preventDefault();Event.stopPropagation();
    const Step=Event.altKey?(Event.shiftKey?40:10):40;
    const Dx=Event.key==='ArrowLeft'?-Step:Event.key==='ArrowRight'?Step:0,Dy=Event.key==='ArrowUp'?-Step:Event.key==='ArrowDown'?Step:0;
    if(Event.altKey)Interaction.MoveSelection({X:Dx,Y:Dy},Event.target.closest('[data-node-id]')?.getAttribute('data-node-id'),Selected);
    else if(!Interaction.IsPointerActive())UpdateView(Value=>({...Value,X:Value.X+Dx,Y:Value.Y+Dy}));
  }
  function FitAll(){Interaction.CancelGesture();UpdateView(()=>Fit);}
  function Readable(){Interaction.CancelGesture();UpdateView(()=>ReadableGraphView(Layout,Viewport,Selected||Anchor));}
  const VisibleSelection=Layout.Nodes.reduce((Count,Node)=>Count+(Interaction.Selection.has(Node.ElementId)?1:0),0);
  const HiddenSelection=Interaction.Selection.size-VisibleSelection;
  const Drawing=useMemo(()=><>
    <defs><marker id={ArrowId} viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse"><path d="M 0 0 L 10 5 L 0 10 z" fill="#557b99"/></marker><pattern id={GridId} width="24" height="24" patternUnits="userSpaceOnUse"><circle cx="1" cy="1" r="1" fill="#cbd7e1"/></pattern></defs>
    <rect x="-5000" y="-5000" width="12000" height="12000" fill={'url(#'+GridId+')'}/>
    {Layout.Columns.map(Column=><text className="graph-column" x={Column.X} y="34" key={Column.Label}>{Column.Label}</text>)}
    {Layout.Edges.map(Edge=>{
      const From=Layout.Map.get(Edge.SourceId),To=Layout.Map.get(Edge.TargetId),Curve=EdgePath(From,To),Key=Edge.SourceId+'>'+Edge.TargetId,Label=EdgeLabelPosition(From,To);
      const OnPath=PathEdges.has(Key),OnSourcing=SourcingEdges.has(Key);
      const Active=ActiveSourcing?OnSourcing:WholeGraph||!Selected||Edge.SourceId===Selected||Edge.TargetId===Selected;
      return <g key={Key} className={(OnPath?'edge impact-path':Active?'edge active':'edge muted')+(OnSourcing?' sourcing-edge':'')+(Edge.IsSimulation?' simulated':'')}><path d={Curve} markerEnd={'url(#'+ArrowId+')'}/><g className="edge-flow" aria-hidden="true" pointerEvents="none"><polygon points="-8,-5 2,0 -8,5 -5,0"/><animateMotion path={Curve} rotate="auto" dur="3.6s" repeatCount="indefinite"/></g>{Edge.Value!=null&&(Weights||(Selected&&Active))&&<g className="edge-label"><rect x={Label.X-72} y={Label.Y-15} width="144" height="30" rx="5"/><text x={Label.X} y={Label.Y+5} textAnchor="middle">{Edge.RelationType==='Offer'?Money(Edge.Value):Quantity(Edge.Value)+' '+From.UnitCode}</text></g>}<title>{From.Name+' → '+To.Name+(Edge.Value!=null?' · '+Edge.Value:'')+(OnSourcing?' · '+SourcingLabel:'')}</title></g>;
    })}
    {Layout.Nodes.map(Node=>{
      const InSourcing=SourcingNodes.has(Node.ElementId),InGroup=Interaction.Selection.has(Node.ElementId);
      return <g key={Node.ElementId} data-node="true" data-node-id={Node.ElementId} data-selected={InGroup?'true':'false'} role="button" aria-pressed={Selected===Node.ElementId} aria-label={Node.Name+', '+TypeLabels[Node.ElementType]+', '+Node.ElementId+(InSourcing?', incluido en la '+SourcingLabel.toLowerCase():'')+(InGroup?', seleccionado para mover':'')} tabIndex={0} className={'graph-node '+Node.ElementType+(Selected===Node.ElementId?' selected':'')+(PathNodes.has(Node.ElementId)?' on-path':'')+(WholeGraph&&Node.ElementId===InitialFocus?' impact-origin':'')+(InSourcing?' sourcing-node':ActiveSourcing?' outside-sourcing':'')+(InGroup?' move-selected':'')} transform={'translate('+Node.X+' '+Node.Y+')'} onClick={Event=>{if(Event.detail===0)Interaction.ActivateNode(Node.ElementId,Event.ctrlKey||Event.metaKey);}} onFocus={()=>{if(!Interaction.IsPointerActive())Reveal(Node);}} onKeyDown={Event=>{if(Event.key==='Enter'||Event.key===' '){Event.preventDefault();Event.stopPropagation();Interaction.ActivateNode(Node.ElementId,Event.ctrlKey||Event.metaKey);}}}><rect width={GraphGeometry.NodeWidth} height={GraphGeometry.NodeHeight} rx="9"/>{InGroup&&<rect className="graph-selection-outline" x="-6" y="-6" width={GraphGeometry.NodeWidth+12} height={GraphGeometry.NodeHeight+12} rx="13" aria-hidden="true"/>}<circle cx="16" cy="32" r="4"/><text x="30" y="26">{Node.Name.length>24?Node.Name.slice(0,23)+'…':Node.Name}</text><text className="node-code" x="30" y="47">{Node.ElementId.length>28?Node.ElementId.slice(0,27)+'…':Node.ElementId}</text>{InSourcing&&<text className="sourcing-tag" x="233" y="22" textAnchor="middle" aria-hidden="true">✓</text>}<title>{Node.Name+' · '+Node.ElementId+(InSourcing?' · '+SourcingLabel:'')+(InGroup?' · Seleccionado para mover':'')}</title></g>;
    })}
  </>,[Layout,Weights,Selected,PathEdges,PathNodes,WholeGraph,InitialFocus,ArrowId,GridId,Reveal,ActiveSourcing,SourcingEdges,SourcingNodes,SourcingLabel,Interaction.Selection,Interaction.ActivateNode,Interaction.IsPointerActive]);
  return <>{!Embedded&&<Heading Title="Tu red, a simple vista" Description="Explora conexiones, compara precios y descubre los requisitos de cada producto."/>}
    <section className="surface graph-surface"><div className="graph-toolbar">{WholeGraph?<p className="quiet">Cadena completa · flechas: requisito → dependiente</p>:<label>Explorar alrededor de<select aria-label="Filtrar grafo por elemento" value={Focus} onChange={Event=>ChangeFocus(Event.target.value)}><option value="">Toda la red</option>{Data.Elements.map(Item=><option key={Item.ElementId} value={Item.ElementId}>{Item.Name}</option>)}</select></label>}<div className="graph-tools"><button onClick={()=>Zoom(.8)} aria-label="Acercar grafo">+</button><span aria-live="polite">{Math.round(Viewport.Width/Box.Width*100)}%</span><button onClick={()=>Zoom(1.25)} aria-label="Alejar grafo">−</button><button onClick={FitAll}>Ajustar red</button><button onClick={Readable}>Tamaño legible</button><button disabled={!SavedLayout.Ready} onClick={()=>{Interaction.Reset();SetView(null);SetSelected('');SetFocus('');}}>Restablecer</button></div></div>
    <div className="graph-interaction-tools" role="group" aria-label="Mover y seleccionar nodos"><button type="button" aria-pressed={Interaction.AreaMode} onClick={Interaction.ToggleAreaMode}>Seleccionar área</button><button type="button" disabled={!Interaction.Selection.size} onClick={Interaction.ClearSelection}>Limpiar selección</button><button type="button" disabled={!SavedLayout.Ready||!Interaction.Positions.size} onClick={()=>{Interaction.RestorePositions();SetView(null);}}>Restaurar distribución</button><p role="status">{Interaction.Selection.size} {Interaction.Selection.size===1?'nodo seleccionado para mover':'nodos seleccionados para mover'}{HiddenSelection?' ('+HiddenSelection+' fuera de vista)':''}</p></div>
    {SavedLayout.Enabled&&<div className={"graph-layout-status"+(SavedLayout.Status==="Error"?" has-error":"")}><p role="status">{SavedLayout.Status==="Loading"?"Cargando tu distribución… Puedes explorar mientras se prepara el movimiento de nodos.":SavedLayout.Status==="Saving"?"Guardando tu distribución…":SavedLayout.Status==="Error"?SavedLayout.Error:"Distribución guardada en tu cuenta."}</p>{SavedLayout.CanRetry&&<button type="button" onClick={SavedLayout.Retry}>{SavedLayout.Ready?"Reintentar guardado":"Reintentar carga"}</button>}</div>}
    <div className="graph-legend"><span><i className="legend-dot Supplier"/>Proveedores</span><span><i className="legend-dot Material"/>Insumos</span><span><i className="legend-dot Product"/>Productos</span><label className="checkbox"><input type="checkbox" checked={Weights} onChange={Event=>SetWeights(Event.target.checked)}/>Mostrar todos los pesos</label><button type="button" className="graph-motion-control" disabled={ReducedMotion} aria-pressed={MotionPaused||ReducedMotion} onClick={()=>SetMotionPaused(Value=>!Value)}>{ReducedMotion?'Movimiento reducido':MotionPaused?'Reanudar flechas':'Pausar flechas'}</button></div>
    {ActiveSourcing&&<div className="graph-sourcing-legend" role="status"><strong><span aria-hidden="true">✓ </span>{SourcingLabel} resaltada</strong><span>Los nodos marcados con ✓ y las conexiones gruesas muestran los proveedores, insumos y componentes de {Current?.Name}.</span></div>}
    <div className="graph-workspace"><div className="graph-canvas">{Layout.Nodes.length?<svg ref={Svg} data-layout-ready={SavedLayout.Ready} className={(Interaction.AreaMode?'area-selection-mode ':'')+(Interaction.Dragging?'graph-dragging':'')} viewBox={[Box.X,Box.Y,Box.Width,Box.Height].join(' ')} aria-label="Grafo de abastecimiento. Arrastra nodos para moverlos y el fondo para desplazarte. Ctrl o Comando más clic alterna nodos; Shift más arrastre selecciona un área. Alt más flechas mueve la selección y Escape la limpia." tabIndex={0} onPointerDown={Interaction.OnPointerDown} onPointerMove={Interaction.OnPointerMove} onPointerUp={Interaction.OnPointerUp} onPointerCancel={Interaction.OnPointerCancel} onLostPointerCapture={Interaction.OnPointerCancel} onKeyDown={Keys}>{Drawing}{Interaction.Rectangle&&<rect className="graph-selection-area" x={Math.min(Interaction.Rectangle.Start.X,Interaction.Rectangle.End.X)} y={Math.min(Interaction.Rectangle.Start.Y,Interaction.Rectangle.End.Y)} width={Math.abs(Interaction.Rectangle.End.X-Interaction.Rectangle.Start.X)} height={Math.abs(Interaction.Rectangle.End.Y-Interaction.Rectangle.Start.Y)} aria-hidden="true" pointerEvents="none"/>}</svg>:<Empty/>}<p className="canvas-hint">Arrastra un nodo para moverlo; el fondo para explorar. Ctrl/Cmd + clic añade o quita nodos. Shift + arrastre selecciona un área; con Ctrl/Cmd se suma al grupo. Alt + flechas mueve la selección. Escape cancela el gesto y limpia la selección.</p></div>
    <aside className="graph-detail">{Current?<><div className="graph-detail-heading"><span className="badge">{TypeLabels[Current.ElementType]}</span><h2>{Current.Name}</h2><p className="quiet">{Current.ElementId}</p><p>{Current.Description||'Consulta sus conexiones y los valores registrados en la red.'}</p>{!WholeGraph&&<button onClick={()=>ChangeFocus(Current.ElementId)}>Enfocar conexiones</button>}</div>{ShowCosts&&Current.ElementType==='Product'&&<ProductCosts ProductId={Current.ElementId} Data={Data} SelectedOption={ActiveSourcing?.Kind||''} OnSelectOption={SelectSourcing}/>}<details className="graph-connections" open={!ShowCosts||Current.ElementType!=='Product'}><summary>{Linked.length} {Linked.length===1?'conexión visible':'conexiones visibles'}</summary><ul className="connection-list">{Linked.map(Edge=><li key={Edge.SourceId+'>'+Edge.TargetId}><strong>{Layout.Map.get(Edge.SourceId)?.Name}</strong><span>↓ {Layout.Map.get(Edge.TargetId)?.Name}</span>{Edge.Value!=null&&<><b>{Edge.RelationType==='Offer'?Money(Edge.Value):Quantity(Edge.Value)+' '+Layout.Map.get(Edge.SourceId)?.UnitCode}</b><ReferenceBadge Value={Edge.IsDemo} Kind={Edge.RelationType==='Offer'?'Price':'Quantity'}/></>}</li>)}</ul></details></>:<><Icon Name="graph" Size={36}/><h2>Descubre tu red</h2><p>Selecciona un elemento para ver sus conexiones y pesos.</p><div className="graph-note"><strong>¿Cómo leer el grafo?</strong><p>Las flechas van del requisito al elemento que lo necesita.</p><p>Proveedor → insumo: precio de compra.<br/>Insumo → producto: cantidad usada.</p></div></>}</aside></div>
    <div className="table-footer">{Layout.Nodes.length} elementos · {Layout.Edges.length} relaciones <span>Precios en COP · Cantidades por unidad de producto</span></div></section></>;
}
