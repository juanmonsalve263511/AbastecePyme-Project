"""Public contact intake and an administrator-only inbox; no external delivery."""
from uuid import uuid4
from fastapi import HTTPException
from backend.Database import Rows


def SubmitRequest(Database, Body):
    RequestId = str(uuid4())
    with Database.Transaction() as Connection:
        Connection.execute(
            "INSERT INTO ContactRequests(RequestId,FullName,Email,Phone,Company,Subject,Message,ConsentVersion,CreatedAt) "
            "VALUES (?,?,?,?,?,?,?, ?,UTC_TIMESTAMP())",
            RequestId, Body.FullName, Body.Email, Body.Phone, Body.Company, Body.Subject, Body.Message, "2026-11-02")
    return {"RequestId": RequestId, "Detail": "Tu solicitud quedó registrada. Gracias por conectar con AbastecePyme."}


def ReadRequests(Database, Limit, Offset):
    with Database.Transaction() as Connection:
        Total = Connection.execute("SELECT COUNT(*) FROM ContactRequests").fetchone()[0]
        Items = Rows(Connection.execute(
            "SELECT RequestId,FullName,Email,Phone,Company,Subject,Message,CreatedAt,ReadAt "
            "FROM ContactRequests ORDER BY CreatedAt DESC,RequestId DESC LIMIT ? OFFSET ?", Limit, Offset))
    for Item in Items:
        for Key in ("CreatedAt", "ReadAt"):
            Value = Item[Key]
            # Database times are UTC; expose an explicit timezone to the browser.
            Item[Key] = (Value.isoformat() if hasattr(Value, "isoformat") else str(Value).replace(" ", "T")) + "Z" if Value else None
    return {"Items": Items, "Total": Total, "Limit": Limit, "Offset": Offset}


def MarkRead(Database, RequestId):
    with Database.Transaction() as Connection:
        if not Connection.execute("SELECT RequestId FROM ContactRequests WHERE RequestId=?", RequestId).fetchone():
            raise HTTPException(404, "Solicitud no encontrada.")
        Connection.execute("UPDATE ContactRequests SET ReadAt=UTC_TIMESTAMP() WHERE RequestId=? AND ReadAt IS NULL", RequestId)
    return {"Detail": "Solicitud marcada como leída."}
