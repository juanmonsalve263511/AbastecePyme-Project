import { createConnection } from 'node:net';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('.', import.meta.url));
const url = 'http://127.0.0.1:3000/';
const occupied = await new Promise(resolve => {
  const socket = createConnection({host:'127.0.0.1',port:3000});
  socket.once('connect',()=>{socket.destroy();resolve(true)});
  socket.once('error',error=>{
    if(error.code === 'ECONNREFUSED') resolve(false);
    else {console.error('No se puede comprobar el puerto:', error.message);resolve(null);}
  });
});
if(occupied === null) process.exit(1);
if(occupied) {
  console.log('El puerto 3000 ya esta ocupado. No se iniciara otro servidor.');
  console.log('Si AbastecePyme ya esta abierta, visite '+url);
} else {
  const child = spawn(process.execPath,['src/server.js'],{cwd:root,stdio:'inherit',env:{...process.env,PORT:'3000'}});
  child.on('error',error=>{console.error(error.message);process.exitCode=1;});
  child.on('exit',code=>{process.exitCode=code??1;});
  process.on('SIGINT',()=>{child.kill('SIGINT');});
}
