import ResponsiveImage from './ResponsiveImage.jsx';
import Reveal from './Reveal.jsx';
import {Icon} from './Common.jsx';
export default function SectionVisual(){
  return <Reveal As="section" ClassName="section-visual"><div className="section-visual-image"><ResponsiveImage Name="materials" Alt="Materiales organizados para preparar la producción" Sizes="(max-width: 760px) 90vw, (max-width: 1600px) 34vw, 670px"/></div><div><p className="section-note">Una visión compartida</p><h2>Materiales conectados.<br/>Decisiones con dirección.</h2><p>Revisa tus alternativas de abastecimiento y prepara cada producto con claridad.</p><a href="#catalog-Supplier">Explorar proveedores <Icon Name="arrow" Size={18}/></a></div></Reveal>;
}
