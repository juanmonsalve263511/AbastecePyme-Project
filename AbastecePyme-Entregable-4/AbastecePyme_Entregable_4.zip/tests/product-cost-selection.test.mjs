import test from 'node:test';
import assert from 'node:assert/strict';
import {GetSourcingOption,GetCurrentSourcing} from '../frontend/src/components/ProductCostSelection.js';

const Minimum=Object.freeze({ElementIds:Object.freeze(['S1','M1','P1','P2']),Relations:Object.freeze([{SourceId:'S1',TargetId:'M1',RelationType:'Offer'},{SourceId:'M1',TargetId:'P1',RelationType:'Requirement'},{SourceId:'P1',TargetId:'P2',RelationType:'General'}])});
const Maximum={ElementIds:['S2','M1','P1','P2'],Relations:[{SourceId:'S2',TargetId:'M1',RelationType:'Offer'},...Minimum.Relations.slice(1)]};
const Result={ProductId:'P2',IsComplete:true,Status:'Ready',MinimumCost:'0.00',MaximumCost:'15.00',SourcingGraphs:{Minimum,Maximum}};

test('cost selection uses the exact server trace, including indirect components and valid zero costs',()=>{
  assert.deepEqual(GetSourcingOption(Result,'Minimum'),{ProductId:'P2',Kind:'Minimum',Graph:Minimum});
  assert.equal(GetSourcingOption(Result,'Maximum').Graph,Maximum);
  assert.equal(GetSourcingOption(Result,'Minimum').Graph,Minimum);
});

test('incomplete, cyclic or missing source traces cannot become selectable cost options',()=>{
  for(const Status of ['Incomplete','Cycle'])assert.equal(GetSourcingOption({...Result,IsComplete:false,Status},'Minimum'),null);
  assert.equal(GetSourcingOption({...Result,SourcingGraphs:undefined},'Minimum'),null);
  assert.equal(GetSourcingOption({...Result,SourcingGraphs:{Minimum:{ElementIds:[],Relations:[]}}},'Minimum'),null);
  assert.equal(GetSourcingOption(Result,'Other'),null);
  assert.equal(GetSourcingOption(null,'Minimum'),null);
});

test('a source trace is invalid as soon as its product or catalogue changes, and clearing removes it',()=>{
  const Data={Elements:[],Relations:[]};
  const Selection={...GetSourcingOption(Result,'Minimum'),Data};
  assert.equal(GetCurrentSourcing(Selection,'P2',Data),Selection);
  assert.equal(GetCurrentSourcing(Selection,'P1',Data),null);
  assert.equal(GetCurrentSourcing(Selection,'P2',{...Data}),null);
  assert.equal(GetCurrentSourcing(null,'P2',Data),null);
});
