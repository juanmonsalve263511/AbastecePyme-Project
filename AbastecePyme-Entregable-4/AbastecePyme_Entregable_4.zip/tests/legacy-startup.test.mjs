import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import * as Server from '../src/server.js';
import { fixture } from './helpers.js';

function legacyFixture(t) {
  const files = fixture();
  t.after(files.cleanup);
  mkdirSync(join(files.directory, 'data'));
  const seed = join(files.directory, 'data', 'catalogo.json');
  const original = '{"elementos": [], "dependencias": []}\n';
  writeFileSync(seed, original);
  return { ...files, seed, original };
}

test('legacy edits persist in a separate catalogue and preserve the import seed bytes', t => {
  const files = legacyFixture(t);
  const { store, dataFile } = Server.createLegacyStore({ projectRoot: files.directory, dataFile: null });
  store.addElement({ id: 'TEMP-MATERIAL', nombre: 'Material temporal', tipo: 'insumo' });
  assert.notEqual(dataFile, files.seed);
  assert.equal(readFileSync(files.seed, 'utf8'), files.original);
  const reopened = Server.createLegacyStore({ projectRoot: files.directory, dataFile: null }).store;
  assert.equal(reopened.elements()[0].id, 'TEMP-MATERIAL');
});

test('legacy startup refuses an explicit DATA_FILE pointing to the import seed', t => {
  const files = legacyFixture(t);
  assert.throws(() => Server.createLegacyStore({ projectRoot: files.directory, dataFile: files.seed }), /catálogo de origen/);
  assert.equal(readFileSync(files.seed, 'utf8'), files.original);
});

test('legacy startup keeps supporting an explicitly separate data file', t => {
  const files = legacyFixture(t);
  const destination = join(files.directory, 'custom', 'legacy.json');
  const { store } = Server.createLegacyStore({ projectRoot: files.directory, dataFile: destination });
  store.addElement({ id: 'TEMP-PRODUCT', nombre: 'Producto temporal', tipo: 'producto' });
  assert.equal(JSON.parse(readFileSync(destination, 'utf8')).elementos[0].id, 'TEMP-PRODUCT');
  assert.equal(readFileSync(files.seed, 'utf8'), files.original);
});
