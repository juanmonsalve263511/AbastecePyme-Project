"""Loopback browser fixture for cost comparisons; never connects to MariaDB."""
import argparse

from SupplyBoardPreview import CreatePreviewDatabase, CreateApp
from backend.Catalog import CreateElement
from backend.Models import ElementCreate, RelationCreate
from backend.Relations import ChangeRelation


def CreateCostDatabase():
    Database = CreatePreviewDatabase()
    CreateElement(Database, ElementCreate(ElementId="PROV-SUR", Name="Maderas del Sur",
                                          ElementType="Supplier", Description="Proveedor de aceptación aislada."))
    for SourceId, TargetId, Value in [
        ("PROV-SUR", "INS-TABLERO", "40000.00"),
        ("PROD-PANEL", "PROD-ESTANTE", None),
    ]:
        ChangeRelation(Database, RelationCreate(SourceId=SourceId, TargetId=TargetId,
                                                Value=Value, IsDemo=True), "create")
    return Database


if __name__ == "__main__":
    Parser = argparse.ArgumentParser(description=__doc__)
    Parser.add_argument("--port", type=int, default=3016)
    Arguments = Parser.parse_args()
    if not 1024 <= Arguments.port <= 65535:
        Parser.error("Puerto fuera de rango.")
    import uvicorn
    Database = CreateCostDatabase()
    try:
        print("Cost comparison preview uses synthetic SQLite data in memory.", flush=True)
        uvicorn.run(CreateApp(Database, Arguments.port), host="127.0.0.1", port=Arguments.port,
                    access_log=False, proxy_headers=False, log_level="warning")
    finally:
        Database.Close()
