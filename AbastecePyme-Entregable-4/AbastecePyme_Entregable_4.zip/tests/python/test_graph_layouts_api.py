"""Per-account layout persistence through the real API and isolated SQLite."""
import json
import unittest
from fastapi.testclient import TestClient
from backend import Auth
from backend.Main import CreateApp
from tests.fixtures.SupplyBoardPreview import PreviewDatabase


class GraphLayoutsApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.Password = "Layout-Test-Only!2026"
        cls.PasswordHash = Auth.Hasher.hash(cls.Password)

    def setUp(self):
        self.Database = PreviewDatabase()
        self.addCleanup(self.Database.Close)
        self.App = CreateApp(self.Database)
        self.Client = TestClient(self.App, base_url="http://127.0.0.1:3000")
        self.addCleanup(self.Client.close)
        self.Client.headers.update({"Origin": "http://127.0.0.1:3000"})
        self.Users = {}
        with self.Database.Transaction() as Connection:
            for Index, Role in enumerate(("Viewer", "Editor", "Administrator"), 1):
                UserId = f"00000000-0000-0000-0000-{Index:012d}"
                Token, Csrf = str(Index) * 64, f"layout-csrf-{Index}"
                Connection.execute("INSERT INTO Users(UserId,Username,DisplayName,PasswordHash,RoleId) VALUES (?,?,?,?,?)",
                                   UserId, Role.lower(), "Layout test " + Role, self.PasswordHash, Role)
                Connection.execute("INSERT INTO Sessions(TokenHash,UserId,CsrfToken,ExpiresAt) VALUES (?,?,?,?)",
                                   Auth.HashToken(Token), UserId, Csrf, "2099-01-01")
                self.Users[Role] = {"UserId": UserId, "Token": Token, "Csrf": Csrf}
        self.Url = "/api/account/graph-layouts/Graph"
        self.Body = {"Positions": [{"ElementId": "PROD-HIDDEN", "X": -42.125, "Y": 96}]}

    def SelectAccount(self, Role="Viewer"):
        User = self.Users[Role]
        self.Client.cookies.clear()
        self.Client.cookies.set(Auth.CookieName, User["Token"])
        self.Client.headers["X-CSRF-Token"] = User["Csrf"]

    def test_read_and_save_require_an_active_authenticated_account(self):
        self.assertEqual(self.Client.get(self.Url).status_code, 401)
        self.assertEqual(self.Client.put(self.Url, json=self.Body).status_code, 401)
        self.SelectAccount()
        with self.Database.Transaction() as Connection:
            Connection.execute("UPDATE Users SET IsActive=0 WHERE UserId=?", self.Users["Viewer"]["UserId"])
        self.assertEqual(self.Client.get(self.Url).status_code, 401)
        self.assertEqual(self.Client.put(self.Url, json=self.Body).status_code, 401)

    def test_all_roles_save_only_their_own_layout_and_views_are_independent(self):
        for Index, Role in enumerate(self.Users):
            with self.subTest(Role=Role):
                self.SelectAccount(Role)
                self.assertEqual(self.Client.get(self.Url).json(), {"Positions": []})
                Body = {"Positions": [{"ElementId": "PROD-HIDDEN", "X": Index, "Y": -Index}]}
                Saved = self.Client.put(self.Url, json=Body)
                self.assertEqual(Saved.status_code, 200, Saved.text)
                self.assertEqual(Saved.json(), Body)
                self.assertEqual(self.Client.get(self.Url).json(), Body)
                self.assertEqual(Saved.headers["cache-control"], "no-store")
                for Key in ("Impact", "Production", "SupplyBoard"):
                    Url = "/api/account/graph-layouts/" + Key
                    self.assertEqual(self.Client.get(Url).json(), {"Positions": []})
                    self.assertEqual(self.Client.put(Url, json=Body).status_code, 200)
        self.SelectAccount("Viewer")
        self.assertEqual(self.Client.get(self.Url).json()["Positions"][0]["X"], 0)
        self.assertEqual(self.Client.get(self.Url).headers["cache-control"], "no-store")

    def test_save_is_normalized_replaces_previous_positions_and_reset_stays_empty(self):
        self.SelectAccount()
        Body = {"Positions": [{"ElementId": "ZZ", "X": 1_000_000, "Y": -1_000_000},
                              {"ElementId": "AA", "X": 0, "Y": -2.75}]}
        Expected = {"Positions": [Body["Positions"][1], Body["Positions"][0]]}
        self.assertEqual(self.Client.put(self.Url, json=Body).json(), Expected)
        self.assertEqual(self.Client.put(self.Url, json=self.Body).json(), self.Body)
        self.assertEqual(self.Client.get(self.Url).json(), self.Body)
        self.assertEqual(self.Client.put(self.Url, json={"Positions": []}).json(), {"Positions": []})
        self.assertEqual(self.Client.get(self.Url).json(), {"Positions": []})
        Count = self.Database.execute("SELECT COUNT(*) FROM UserGraphLayouts WHERE UserId=? AND LayoutKey=?",
                                      self.Users["Viewer"]["UserId"], "Graph").fetchone()[0]
        self.assertLessEqual(Count, 1)

    def test_saved_layout_survives_logout_login_and_a_new_application_instance(self):
        self.SelectAccount()
        self.assertEqual(self.Client.put(self.Url, json=self.Body).status_code, 200)
        self.assertEqual(self.Client.post("/api/auth/logout").status_code, 200)
        self.assertEqual(self.Client.get(self.Url).status_code, 401)
        with TestClient(CreateApp(self.Database), base_url="http://127.0.0.1:3000") as Other:
            Other.headers["Origin"] = "http://127.0.0.1:3000"
            Response = Other.post("/api/auth/login", json={"Username": "viewer", "Password": self.Password})
            self.assertEqual(Response.status_code, 200, Response.text)
            self.assertEqual(Other.get(self.Url).json(), self.Body)

    def test_origin_csrf_and_body_cannot_change_the_account_scope(self):
        self.SelectAccount()
        for Headers in ({"Origin": "https://invalid.example"}, {"X-CSRF-Token": "wrong"}):
            with self.subTest(Headers=Headers):
                self.assertEqual(self.Client.put(self.Url, json=self.Body, headers=Headers).status_code, 403)
        del self.Client.headers["X-CSRF-Token"]
        self.assertEqual(self.Client.put(self.Url, json=self.Body).status_code, 403)
        self.SelectAccount()
        Forged = {**self.Body, "UserId": self.Users["Administrator"]["UserId"]}
        self.assertEqual(self.Client.put(self.Url, json=Forged).status_code, 422)
        self.assertEqual(self.Client.get(self.Url).json(), {"Positions": []})
        self.SelectAccount("Administrator")
        self.assertEqual(self.Client.get(self.Url).json(), {"Positions": []})

    def test_invalid_keys_and_positions_leave_the_saved_layout_unchanged(self):
        self.SelectAccount()
        self.assertEqual(self.Client.put(self.Url, json=self.Body).status_code, 200)
        for Key in ("graph", "Users", "Graph-extra"):
            with self.subTest(Key=Key):
                Url = "/api/account/graph-layouts/" + Key
                self.assertEqual(self.Client.get(Url).status_code, 422)
                self.assertEqual(self.Client.put(Url, json=self.Body).status_code, 422)
        Invalid = [{}, {"Positions": None}, {"Positions": {}, "Extra": 1},
                   {"Positions": self.Body["Positions"] * 2},
                   {"Positions": [{"ElementId": f"NODE-{Index}", "X": 1, "Y": 2} for Index in range(1001)]}]
        for Patch in ({"ElementId": "bad id"}, {"ElementId": "A"}, {"ElementId": 42},
                      {"X": True}, {"X": "1.5"}, {"Y": None}, {"Y": False},
                      {"X": 1_000_000.01}, {"Y": -1_000_000.01}, {"Extra": 1}):
            Invalid.append({"Positions": [{**self.Body["Positions"][0], **Patch}]})
        for Body in Invalid:
            with self.subTest(Body=str(Body)[:120]):
                Response = self.Client.put(self.Url, json=Body)
                self.assertEqual(Response.status_code, 422, Response.text)
        for Number in ("NaN", "Infinity", "-Infinity"):
            Raw = '{"Positions":[{"ElementId":"AA","X":' + Number + ',"Y":0}]}'
            Response = self.Client.put(self.Url, content=Raw, headers={"Content-Type": "application/json"})
            self.assertEqual(Response.status_code, 422, Response.text)
        self.assertEqual(self.Client.get(self.Url).json(), self.Body)

    def test_large_valid_layout_has_a_scoped_limit_and_other_requests_keep_the_original_limit(self):
        self.SelectAccount()
        Body = {"Positions": [{"ElementId": f"NODE-{Index:035d}", "X": -123456.123456, "Y": 654321.654321}
                              for Index in range(1000)]}
        Raw = json.dumps(Body).encode()
        self.assertGreater(len(Raw), 32768)
        self.assertLess(len(Raw), 131072)
        Response = self.Client.put(self.Url, content=Raw, headers={"Content-Type": "application/json"})
        self.assertEqual(Response.status_code, 200, Response.text)
        self.assertEqual(Response.json(), Body)
        self.assertEqual(self.Client.get(self.Url).json(), Body)
        for Method, Url, Payload in (("PUT", self.Url, b" " * 131073),
                                     ("PATCH", "/api/account", b" " * 32769),
                                     ("PUT", "/api/account/graph-layouts/Unknown", b" " * 32769),
                                     ("POST", self.Url, b" " * 32769)):
            with self.subTest(Method=Method, Url=Url):
                Result = self.Client.request(Method, Url, content=Payload, headers={"Content-Type": "application/json"})
                self.assertEqual(Result.status_code, 413, Result.text)

    def test_saving_preferences_leaves_catalogue_revisions_and_unrelated_rows_unchanged(self):
        self.SelectAccount()
        Tables = [Row[0] for Row in self.Database.Connection.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name<>'UserGraphLayouts'")]
        Before = {Table: self.Database.Connection.execute(f"SELECT * FROM {Table}").fetchall() for Table in Tables}
        self.assertEqual(self.Client.put(self.Url, json=self.Body).status_code, 200)
        After = {Table: self.Database.Connection.execute(f"SELECT * FROM {Table}").fetchall() for Table in Tables}
        self.assertEqual(After, Before)

    def test_deleting_an_account_cascades_its_layout_without_affecting_another_account(self):
        for Role in ("Viewer", "Editor"):
            self.SelectAccount(Role)
            self.assertEqual(self.Client.put(self.Url, json=self.Body).status_code, 200)
        with self.Database.Transaction() as Connection:
            Connection.execute("DELETE FROM Users WHERE UserId=?", self.Users["Viewer"]["UserId"])
        self.assertEqual(self.Database.execute("SELECT COUNT(*) FROM UserGraphLayouts WHERE UserId=?",
                                              self.Users["Viewer"]["UserId"]).fetchone()[0], 0)
        self.assertEqual(self.Client.get(self.Url).json(), self.Body)
