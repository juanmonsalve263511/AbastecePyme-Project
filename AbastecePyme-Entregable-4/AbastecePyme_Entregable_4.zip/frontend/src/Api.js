let CsrfToken = '';
export function SetSession(Session) { CsrfToken = Session?.CsrfToken || ''; }
export async function Api(Path, Options = {}) {
  const {ReturnMeta=false,...FetchOptions}=Options;
  if (!/^\/api\/[a-zA-Z0-9_/?=&%.-]+$/.test(Path)) throw new Error('Ruta de consulta inválida.');
  const RequestToken=CsrfToken;
  let Response;
  try {
    Response = await fetch(Path, {
      credentials: 'same-origin', redirect: 'error', ...FetchOptions,
      headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': RequestToken, ...Options.headers },
      body: Options.body === undefined ? undefined : JSON.stringify(Options.body)
    });
  } catch (Failure) {
    if(Failure.name==='AbortError')throw Failure;
    throw new Error('No se pudo conectar con AbastecePyme. Comprueba que el servidor esté abierto e inténtalo de nuevo.',{cause:Failure});
  }
  let Data=null;
  try { if(Response.status!==204)Data=await Response.json(); }
  catch(Failure) {
    if(Failure.name==='AbortError')throw Failure;
    if(Response.ok){const ErrorValue=new Error('El servidor devolvió una respuesta no válida. Recarga la página e inténtalo de nuevo.');ErrorValue.Status=Response.status;throw ErrorValue;}
  }
  if (!Response.ok) {
    const Detail = typeof Data?.Detail === 'string' ? Data.Detail : (typeof Data?.detail === 'string' ? Data.detail : '');
    const MissingEndpoint = Response.status === 404 && (!Detail || Detail === 'Not Found');
    const Message = MissingEndpoint
      ? 'Esta función no está disponible en el servidor abierto (HTTP 404). Cierra y vuelve a iniciar AbastecePyme con Iniciar.cmd; después recarga la página.'
      : Detail || `No se pudo completar la solicitud (HTTP ${Response.status}).`;
    const ErrorValue = new Error(Message);
    ErrorValue.Status = Response.status;
    if (Response.status === 401 && RequestToken===CsrfToken && !Path.includes('/auth/')) window.dispatchEvent(new Event('session-expired'));
    throw ErrorValue;
  }
  return ReturnMeta ? {Data,Status:Response.status} : Data;
}
export const TypeLabels = { Supplier: 'Proveedor', Material: 'Insumo', Product: 'Producto' };
export const RoleLabels = { Administrator: 'Administrador', Editor: 'Editor', Viewer: 'Consulta' };
export function Quantity(Value, MinimumFraction = 0) {
  const [Integer,Fraction=''] = String(Value).split('.');
  const Grouped = Integer.replace(/\B(?=(\d{3})+(?!\d))/g,'.');
  const Digits = Fraction.replace(/0+$/,'').padEnd(MinimumFraction,'0');
  return Grouped + (Digits ? ','+Digits : '');
}
export const Money = Value => '$\u00a0'+Quantity(Value,2);

