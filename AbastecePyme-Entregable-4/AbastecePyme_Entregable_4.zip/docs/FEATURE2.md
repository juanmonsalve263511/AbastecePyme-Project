# Feature 2 — Registro de implementación

Fecha: 26 de octubre de 2026.

## Alcance aprobado
Impacto potencial mediante recorrido propio; consulta inversa de requisitos. El usuario autorizó continuar sin más preguntas.

## Trazabilidad
| Requisito | Implementación | Verificación |
|---|---|---|
| Consultar desde proveedor/insumo o hacia producto | AnalyzeImpact + GET /api/impact + pantalla React | test_impact y test_impact_api |
| Recorrido propio y visitados entendibles | BFS Python con nombres, tipo, profundidad, padre y camino | cadena, ramas, diamante, ciclo, 1.100 nodos |
| Distinguir inexistente, sin dependencias y cadena | 404, 200 NoReachable, 200 Reached | contrato API y estados de pantalla |
| Explicar alcanzar en README | sección Feature 2 | revisión contra la guía |

## Archivos
backend/Impact.py; backend/Main.py; frontend/src/components/Impact.jsx; Graph.jsx; GraphLayout.js; ApiExplorer.jsx; Dashboard.jsx; frontend/src/App.jsx; Styles.css; tests/python/test_impact.py; test_impact_api.py; tests/graph-layout.test.mjs; README.md.

## Bitácora de asistencia
Se analizó la guía y el modelo existente; se planteó y aprobó el alcance potencial. Se escribieron pruebas antes del servicio, se observó la ausencia del módulo/ruta y el truncamiento del filtro de vecinos, y luego se implementaron. La interfaz conserva la dirección requisito a dependiente y no representa BFS como orden de producción.

Skills aplicadas: brainstorming (semántica y alcance, ya aprobados), writing-plans y executing-plans (plan y ejecución inline), test-driven-development (pruebas de casos y regresiones), vercel-react-best-practices (carga diferida y estados derivados), verification-before-completion y requesting-code-review (verificación y revisión final). Se reutilizaron las skills instaladas, sin instalar dependencias de grafos.

## Comandos reproducibles
Python: .venv/Scripts/python.exe -m unittest discover -s tests/python -v
Node: runtime/node.exe --test tests/*.test.js tests/*.test.mjs
Frontend: desde frontend, ../runtime/node.exe node_modules/vite/bin/vite.js build

En el entorno restringido, el directorio temporal predeterminado de Windows impidió renombrar/borrar los archivos temporales de pruebas antiguas. Se repitieron en work/test-temp dentro del proyecto, con éxito: 20 Python y 28 Node. Advertencia no bloqueante de Starlette: el TestClient con httpx está deprecado; no se cambiaron dependencias por esta función.

Detalles del contrato y límites del análisis: README.md, sección Feature 2.

## Resultado final
- 20 pruebas Python aprobadas (14 nuevas para recorrido/API y 6 existentes).
- 28 pruebas Node aprobadas (2 nuevas para cadena completa y sentido del camino, 26 existentes).
- Compilación Vite aprobada.
- Navegador, servidor separado 127.0.0.1:3012 con datos ficticios: proveedor S1 -> 4 alcanzados, 2 directos, 2 indirectos y 2 productos; 5 nodos/5 relaciones visibles; camino S1-M1-P1-P2 resaltado con 3 aristas.
- Consulta inversa P2 -> 5 requisitos, 6 visitados; camino P2-P1-M1-S2 con 3 aristas resaltadas en la dirección almacenada.
- Aislado ZZ -> estado explícito sin requisitos.
- Explorador API y pantalla -> mismos totales y orden de visita.
- Zoom 100% -> 125%; vista móvil 390 px sin desbordamiento horizontal de página; tabla con desplazamiento propio.
- Consola del navegador sin errores. Servidor y pestaña de prueba cerrados al terminar.
- Revisión independiente: ningún hallazgo crítico, importante o menor.
- El servidor de aplicación que permanecía activo en 3001 devolvió 404 al nuevo endpoint: debe reiniciarse para cargar el nuevo Python. La compilación React ya está guardada. No reiniciar MySQL por este cambio.
- No se validó esta función con una sesión real autenticada contra MariaDB. Las verificaciones de servidor/UI usaron fixtures; no se modificaron datos reales.

Capturas y entrega en la carpeta outputs del chat original.
