# AbastecePyme: inicio y uso

## En este equipo
El proyecto se encuentra en la carpeta del proyecto.
La nueva base se llama AbastecePyme (MariaDB en Windows puede mostrarla como abastecepyme).
La base gym_admin_management no se utiliza ni modifica.

1. Inicia MySQL desde XAMPP.
2. Ejecuta ConfigurarAdministrador.cmd una sola vez. Escribe la contraseña de MariaDB en la entrada oculta y elige tu usuario, nombre y contraseña del sitio (12–128 caracteres). Las contraseñas del sitio se almacenan con Argon2id; la contraseña de MariaDB no se guarda.
3. En esta instalación, ejecuta `Iniciar.cmd --port 3001`. Solicitará la contraseña de MariaDB cada vez que arranques.
4. Abre http://127.0.0.1:3001/ y entra con la cuenta del sitio, distinta de usuario_python3. Para conocer las funciones actuales, consulta la [guía de uso](GUIA_ACTUALIZACION_2026.md).

El puerto predeterminado de `Iniciar.cmd` sin argumentos es 3000. Para iniciar explícitamente la versión actual en 3001 desde Python, usa:
```powershell
.\.venv\Scripts\python.exe Start.py --port 3001
```
Usa siempre la dirección que muestra la consola de la instancia que acabas de iniciar. En este equipo, el acceso `Abrir.url` apunta a 3001.

### Si Orden de producción responde HTTP 404
Una interfaz recién compilada puede estar siendo servida por un proceso Python anterior a Feature 3. Recargar el navegador actualiza la interfaz, pero no carga las rutas nuevas en ese proceso.

En el equipo de desarrollo, la versión actual está en http://127.0.0.1:3001/#production. El acceso local Abrir.url apunta a ese puerto. Para volver a iniciarla en ese puerto, usa `Iniciar.cmd --port 3001` después de cerrar únicamente su servidor anterior con Ctrl+C. MySQL debe permanecer iniciado.

En una instalación nueva, el puerto predeterminado sigue siendo 3000. Después de actualizar el código, detén el servidor de AbastecePyme con Ctrl+C, compila la interfaz y vuelve a ejecutar Iniciar.cmd con el mismo puerto; luego recarga la página. No abras una instancia antigua que siga escuchando en otro puerto.

Un 404 con «Producto no encontrado» tiene otra causa: actualiza el catálogo y elige un producto existente. La aplicación conserva ese mensaje específico.

## Instalar en otro equipo
Se necesita Python 3.14, Node 22.12 o posterior (Node 24 es compatible), MySQL ODBC 26.7 Unicode Driver y MariaDB 10.4 o posterior. Instalar.cmd crea el entorno Python, instala requirements.txt, ejecuta npm ci con el lockfile y compila React. La configuración no secreta está en backend/Database.py.
La cuenta MariaDB requiere SELECT, INSERT, UPDATE, DELETE, CREATE, INDEX y ALTER en AbastecePyme.*. No requiere DROP.
Iniciar.cmd sirve únicamente frontend/dist y la API en 127.0.0.1; no expone la aplicación a la red local.
La contraseña viaja solo en memoria del proceso. No uses archivos .env para guardarla.

## Desarrollo local
El flujo completo admitido mantiene interfaz y API en el mismo origen:

1. Compila los cambios con `npm run build --prefix frontend`.
2. Inicia `Iniciar.cmd` o `Iniciar.cmd --port 3001`.
3. Recarga el navegador después de compilar. Si cambiaste Python, reinicia también ese servidor con Ctrl+C y vuelve a iniciarlo.

`npm run dev --prefix frontend` abre únicamente Vite: no conecta la API ni permite probar la sesión y las escrituras. Para probar la aplicación completa usa la compilación servida por Iniciar.cmd. No hace falta habilitar CORS.

La versión educativa anterior se ejecuta con `node src/server.js` y guarda una copia independiente en `data/catalogo-legacy.json`. La copia toma la semilla original una sola vez y conserva después sus propias ediciones. `iniciar-local.mjs` utiliza la misma separación. No edites `data/catalogo.json`: su huella protege la importación de la versión actual. La versión anterior sigue siendo una demostración separada; sus cambios no se sincronizan con MariaDB.

## Perfiles
- Consulta: catálogo, relaciones, grafo, impacto, orden de producción, estimaciones, API y sus propios datos.
- Editor: además altas, cambios y bajas de elementos y relaciones.
- Administrador: además crea cuentas, asigna perfiles, activa/desactiva accesos y consulta la bandeja de solicitudes de contacto.
Solo un administrador crea cuentas desde Usuarios y perfiles → Crear usuario y elige su perfil. No existe registro público. Cambiar el acceso cierra las sesiones de esa cuenta. No se puede quitar al último administrador activo. El cambio de contraseña cierra todas las sesiones.

## Catálogo y pesos
Los 40 elementos y 92 parejas dirigidas originales se importaron sin cambiar IDs, nombres ni tipos. El archivo original data/catalogo.json permanece intacto. La ampliación y las ediciones posteriores están en MariaDB y pueden cambiar esos totales.
Proveedor→insumo: precio COP por unidad del insumo. Insumo→producto: cantidad por unidad producida. Las demás relaciones, ciclos y autorrelaciones se conservan como dependencias generales.
Precios, cantidades y unidades iniciales son valores sintéticos de demostración, no cotizaciones. Las unidades iniciales son “unidad”. Corrige la unidad y revisa todos sus pesos asociados antes de usarlos.
Al introducir valores propios puedes desmarcar **Usar como valor de referencia** en las relaciones. El precio manual anterior se conserva por compatibilidad; el catálogo actual muestra **Costo de producción** mínimo y **Precio de venta** calculado como ese costo más 25 %. La estimación compara la oferta más económica y la más costosa de cada insumo, e incorpora una unidad por componente en las dependencias entre productos. No incluye mano de obra, impuestos ni transporte. Si faltan ofertas o requisitos interpretables, indica información incompleta; si hay ciclos, no devuelve un costo como válido. Consulta el [contrato de costos](GRAPH_COSTS_2026-11-16.md) para el desglose y las limitaciones.
El grafo se dibuja con SVG propio: enfoque, zoom, desplazamiento, ajuste, filtros, resaltado de opciones de costo y movimiento de cuadros individual o por selección múltiple. Las posiciones se guardan por usuario y sección al terminar el movimiento. **Restaurar distribución** guarda el regreso al acomodo automático. El zoom y la selección no se guardan. No se usan bibliotecas de grafos. La [guía de uso](GUIA_ACTUALIZACION_2026.md) explica los controles y el reintento de un guardado pendiente.

## API
Las rutas de catálogo, análisis y gestión bajo /api están protegidas. Usa el explorador integrado para consultas GET y operaciones POST, PATCH y DELETE revisadas antes de confirmarse. Las escrituras autenticadas requieren sesión, token X-CSRF-Token y Origin exacto de la aplicación. El inicio de sesión, Contacto y la suscripción tienen rutas públicas con validación de origen y datos; no existe registro público de usuarios.
Los números decimales viajan como cadenas. El código propio utiliza inglés y PascalCase siguiendo lo solicitado; se conservan nombres obligatorios de Python, React y HTML.
Las versiones de elementos y relaciones detectan ediciones concurrentes; si hay conflicto, recarga y revisa el dato antes de intentar guardar.
La aplicación está preparada para demostración HTTP local. Publicarla requiere HTTPS, cookie Secure, configuración de origen y revisión de operación/rate limiting compartido; no basta cambiar la dirección de escucha.

## Respaldo
Conserva el JSON original y, si dispones de ella, la copia local respaldos/pre-react-python-20261025-202930. Los respaldos privados no se incluyen en el paquete para GitHub.
Antes de futuras migraciones, exporta AbastecePyme desde phpMyAdmin usando SQL con estructura y datos. Protege la exportación: contiene hashes de contraseñas y sesiones.
No copies archivos del directorio de datos de MariaDB mientras el servidor esté activo.
La importación inicial usa Migrations y el SHA256 del JSON; ejecutarla nuevamente no sobrescribe los cambios hechos en la aplicación.

## Verificación
`Verificar.cmd` o `npm run check` ejecuta las comprobaciones de sintaxis, todas las pruebas Python sin MariaDB, las pruebas JavaScript y una compilación de React en carpeta temporal. No instala dependencias, no pide contraseñas y no requiere un servidor abierto. Las pruebas HTTP de la versión anterior levantan y cierran su propio servidor local temporal. La salida se muestra en consola; no depende de respaldos ni de la carpeta verificacion. La compilación de comprobación no reemplaza frontend/dist.

- `npm test`: pruebas Python y JavaScript, sin compilar.
- `npm run test:python`: solo pruebas Python sin MariaDB.
- `npm run test:node`: todas las pruebas JavaScript.
- `npm run test:legacy`: regresiones del servidor educativo y protección de la semilla.
- `node comprobar-instalacion.mjs`: entrada compatible al mismo verificador; el antiguo `--sin-http` sigue aceptándose.

Las pruebas usan archivos temporales y bases en memoria. La verificación de MariaDB es **separada y explícita**: `tests/RunChecks.py` recibe la contraseña por entrada estándar privada, crea registros de prueba y elimina sus propios registros. Ejecútala únicamente sobre una instalación de demostración destinada a pruebas; no está incluida en Verificar.cmd ni en npm test. La prueba de migración repetida conserva el catálogo vigente, incluyendo ampliaciones y ediciones, y comprueba su huella de importación. Las pruebas del último administrador se omiten si ya existe uno permanente. Estas comprobaciones no sustituyen probar una instalación inicial vacía y un respaldo/restauración en un entorno aislado.

No pongas contraseñas en argumentos ni archivos. Usa una consola con entrada oculta o un proceso que escriba en su entrada estándar. La revisión visual y la integración real deben registrarse por separado de las pruebas locales.

