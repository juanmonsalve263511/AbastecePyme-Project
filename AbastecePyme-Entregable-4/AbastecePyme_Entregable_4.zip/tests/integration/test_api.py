import concurrent.futures
import secrets
import unittest
from pathlib import Path
from fastapi.testclient import TestClient
from tests import IntegrationContext
from backend.Main import CreateApp
from backend.Schema import Migrate
from backend.Auth import CreateUser

class ApiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.Database = IntegrationContext.Database
        Migrate(cls.Database, Path("data/catalogo.json"))

    def setUp(self):
        self.Prefix = "TEST-" + secrets.token_hex(4).upper()
        self.Password = secrets.token_urlsafe(24)
        self.UserIds = []
        self.App = CreateApp(self.Database)
        self.Client = TestClient(self.App, base_url="http://127.0.0.1:3000")
        self.Client.headers["Origin"] = "http://127.0.0.1:3000"
        for Role in ("Administrator","Viewer","Editor"):
            User = CreateUser(self.Database, self.Prefix + Role, "Test account", self.Password, Role)
            self.UserIds.append(User["UserId"])
        self.Login("Administrator")

    def tearDown(self):
        self.Client.close()
        with self.Database.Transaction() as Connection:
            for Table, Left, Right in [("SupplierOffers","SupplierId","MaterialId"),
                    ("ProductRequirements","MaterialId","ProductId"),("GeneralDependencies","SourceId","TargetId")]:
                Connection.execute(f"DELETE FROM {Table} WHERE {Left} LIKE ? OR {Right} LIKE ?",self.Prefix+"%",self.Prefix+"%")
            for Table in ("ProductPrices","Suppliers","Materials","Products","Elements"):
                Connection.execute(f"DELETE FROM {Table} WHERE ElementId LIKE ?",self.Prefix+"%")
            Connection.execute("DELETE FROM Users WHERE Username LIKE ?",self.Prefix+"%")

    def Login(self, Role):
        Response = self.Client.post("/api/auth/login",json={"Username":self.Prefix+Role,"Password":self.Password})
        self.assertEqual(Response.status_code,200)
        self.Client.headers["X-CSRF-Token"] = Response.json()["CsrfToken"]
        return Response

    def Element(self, Suffix="M", Kind="Material"):
        Body = {"ElementId":self.Prefix+Suffix,"Name":"Test material","ElementType":Kind,"UnitCode":"unidad"}
        Response = self.Client.post("/api/elements",json=Body)
        self.assertEqual(Response.status_code,201,Response.text)
        return Response.json()

    def test_only_admin_can_create_user(self):
        Body={"Username":self.Prefix+"New","DisplayName":"Created colleague","Password":self.Password,"RoleName":"Editor","Email":"example@example.invalid"}
        self.assertEqual(self.Client.post("/api/auth/register",json=Body).status_code,404)
        Response=self.Client.post("/api/users",json=Body)
        self.assertEqual(Response.status_code,201,Response.text)
        self.UserIds.append(Response.json()["UserId"])
        self.assertEqual(Response.json()["RoleName"],"Editor")
        self.assertNotIn("Password",Response.text)
        self.assertEqual(self.Client.get("/api/auth/session").json()["UserId"],self.UserIds[0])
        self.assertEqual(self.Client.post("/api/users",json=Body).status_code,409)
        self.Login("Editor")
        self.assertEqual(self.Client.post("/api/users",json=Body).status_code,403)

    def test_sale_price_lifecycle_permissions_and_concurrency(self):
        Body={"ElementId":self.Prefix+"PRICE","Name":"Priced product","ElementType":"Product","SalePrice":"9999999999999999.99","IsPriceReference":True}
        Response=self.Client.post('/api/elements',json=Body)
        self.assertEqual(Response.status_code,201,Response.text)
        Item=Response.json()
        self.assertEqual(Item['SalePrice'],'9999999999999999.99')
        PathName='/api/elements/'+Item['ElementId']
        self.Login('Viewer')
        self.assertEqual(self.Client.patch(PathName,json={'Version':Item['Version'],'SalePrice':'10'}).status_code,403)
        self.Login('Editor')
        Response=self.Client.patch(PathName,json={'Version':Item['Version'],'SalePrice':'450000.50','IsPriceReference':False})
        self.assertEqual(Response.status_code,200,Response.text)
        Edited=Response.json()
        self.assertFalse(Edited['IsPriceReference'])
        self.assertEqual(self.Client.patch(PathName,json={'Version':Item['Version'],'SalePrice':'10'}).status_code,409)
        Response=self.Client.patch(PathName,json={'Version':Edited['Version'],'Name':'Renamed priced product'})
        self.assertEqual(Response.json()['SalePrice'],'450000.50')
        Response=self.Client.patch(PathName,json={'Version':Response.json()['Version'],'SalePrice':None})
        self.assertIsNone(Response.json()['SalePrice'])
        Response=self.Client.patch(PathName,json={'Version':Response.json()['Version'],'SalePrice':'0.00'})
        self.assertEqual(Response.json()['SalePrice'],'0.00')
        self.assertEqual(self.Client.delete(PathName+'?Version='+str(Response.json()['Version'])).status_code,200)
        with self.Database.Transaction() as Connection:
            self.assertEqual(Connection.execute('SELECT COUNT(*) FROM ProductPrices WHERE ElementId=?',Item['ElementId']).fetchone()[0],0)

    def test_production_order_and_cycle_acceptance(self):
        First=self.Element("FIRST","Product")
        Second=self.Element("SECOND","Product")
        Third=self.Element("THIRD","Product")
        for Source,Target in [(First,Second),(Second,Third)]:
            self.assertEqual(self.Client.post("/api/relations",json={"SourceId":Source["ElementId"],"TargetId":Target["ElementId"]}).status_code,201)
        PathName="/api/production?ProductId="+Third["ElementId"]
        Result=self.Client.get(PathName).json()
        self.assertEqual(Result["Status"],"Ready")
        self.assertEqual(Result["Order"],[First["ElementId"],Second["ElementId"],Third["ElementId"]])
        self.assertEqual(self.Client.post("/api/relations",json={"SourceId":Third["ElementId"],"TargetId":First["ElementId"]}).status_code,201)
        Result=self.Client.get(PathName).json()
        self.assertEqual(Result["Status"],"Cycle")
        self.assertEqual(Result["Order"],[])
        self.assertEqual(Result["Stages"],[])
        self.assertEqual(Result["Cycle"][0],Result["Cycle"][-1])
        self.assertEqual(len(Result["Cycle"]),4)

    def test_newsletter_records_consent_without_public_read_access(self):
        Address=self.Prefix.lower()+"@example.invalid"
        try:
            for Attempt in range(2):
                Response=self.Client.post("/api/subscriptions",json={"Email":Address,"Consent":True})
                self.assertEqual(Response.status_code,200,Response.text)
            with self.Database.Transaction() as Connection:
                Row=Connection.execute("SELECT Email,ConsentVersion FROM NewsletterSubscriptions WHERE Email=?",Address).fetchone()
                self.assertEqual(Row[0],Address)
                self.assertTrue(Row[1])
            self.assertEqual(self.Client.get("/api/subscriptions").status_code,405)
        finally:
            with self.Database.Transaction() as Connection:
                Connection.execute("DELETE FROM NewsletterSubscriptions WHERE Email=?",Address)

    def test_cookie_and_session_no_password(self):
        Response = self.Login("Viewer")
        Cookie = Response.headers["set-cookie"].lower()
        self.assertIn("httponly",Cookie)
        self.assertIn("samesite=lax",Cookie)
        Data = self.Client.get("/api/auth/session").json()
        self.assertNotIn("PasswordHash",Data)
        self.assertNotIn(self.Password,str(Data))

    def test_viewer_cannot_write_and_editor_cannot_manage_users(self):
        self.Login("Viewer")
        self.assertEqual(self.Client.post("/api/elements",json={"ElementId":self.Prefix,"Name":"Example","ElementType":"Product"}).status_code,403)
        self.Login("Editor")
        self.assertEqual(self.Client.get("/api/users").status_code,403)

    def test_csrf_and_origin(self):
        self.Client.headers.pop("X-CSRF-Token")
        self.assertEqual(self.Client.post("/api/auth/logout").status_code,403)
        self.Client.headers["Origin"]="https://evil.example"
        self.assertEqual(self.Client.post("/api/auth/login",json={"Username":"x","Password":self.Password}).status_code,403)

    def test_logout_and_expiry(self):
        self.assertEqual(self.Client.post("/api/auth/logout").status_code,200)
        self.assertEqual(self.Client.get("/api/catalog").status_code,401)
        self.Login("Viewer")
        with self.Database.Transaction() as Connection:
            Connection.execute("UPDATE Sessions SET ExpiresAt='2000-01-01' WHERE UserId=?",self.UserIds[1])
        self.assertEqual(self.Client.get("/api/catalog").status_code,401)

    def test_unknown_fields_and_duplicate_id(self):
        Item = self.Element()
        self.assertEqual(self.Client.post("/api/elements",json={"ElementId":Item["ElementId"],"Name":"Again","ElementType":"Material"}).status_code,409)
        self.assertEqual(self.Client.patch("/api/elements/"+Item["ElementId"],json={"Version":Item["Version"],"Name":"Changed","ElementType":"Supplier"}).status_code,422)

    def test_crud_persistence_and_version_conflict(self):
        Item = self.Element()
        PathName = "/api/elements/"+Item["ElementId"]
        Changed = self.Client.patch(PathName,json={"Version":Item["Version"],"Name":"Changed ' ; --","UnitCode":"kg"})
        self.assertEqual(Changed.status_code,200,Changed.text)
        self.assertGreater(Changed.json()["Version"],Item["Version"])
        self.assertEqual(self.Client.patch(PathName,json={"Version":Item["Version"],"Name":"Stale"}).status_code,409)
        with self.Database.Transaction() as Connection:
            self.assertEqual(Connection.execute("SELECT Name FROM Elements WHERE ElementId=?",Item["ElementId"]).fetchone()[0],"Changed ' ; --")
        self.assertEqual(self.Client.delete(PathName+"?Version="+str(Item["Version"])).status_code,409)
        self.assertEqual(self.Client.delete(PathName+"?Version="+str(Changed.json()["Version"])).status_code,200)
        self.assertFalse(any(E["ElementId"]==Item["ElementId"] for E in self.Client.get("/api/catalog").json()["Elements"]))

    def test_relations_and_atomic_delete(self):
        Supplier = self.Element("S","Supplier")
        Material = self.Element()
        Body = {"SourceId":Supplier["ElementId"],"TargetId":Material["ElementId"],"Value":"12.34","IsDemo":False}
        Response = self.Client.post("/api/relations",json=Body)
        self.assertEqual(Response.status_code,201,Response.text)
        self.assertEqual(Response.json()["Value"],"12.34")
        self.assertEqual(self.Client.post("/api/relations",json=Body).status_code,409)
        Preview = self.Client.get("/api/elements/"+Material["ElementId"]+"/deletion-preview").json()
        self.assertEqual(Preview["RelationshipCount"],1)
        self.assertEqual(self.Client.delete("/api/elements/"+Material["ElementId"]+"?Version="+str(Preview["Version"])).status_code,200)
        self.assertFalse(any(E["TargetId"]==Material["ElementId"] for E in self.Client.get("/api/catalog").json()["Relations"]))

    def test_invalid_weights_and_endpoints(self):
        Supplier = self.Element("S","Supplier")
        Material = self.Element()
        for Value in ["NaN","-1","1.001"]:
            Response = self.Client.post("/api/relations",json={"SourceId":Supplier["ElementId"],"TargetId":Material["ElementId"],"Value":Value})
            self.assertEqual(Response.status_code,422)
        self.assertEqual(self.Client.post("/api/relations",json={"SourceId":Supplier["ElementId"],"TargetId":"MISSING","Value":"1"}).status_code,404)

    def test_rate_limit_and_sanitized_validation(self):
        Body = {"Username":"unknown","Password":self.Password}
        Codes = [self.Client.post("/api/auth/login",json=Body).status_code for Index in range(12)]
        self.assertIn(429,Codes)
        Response = self.Client.post("/api/auth/register",json={"Username":"a","Password":"tiny","DisplayName":"A"})
        self.assertNotIn("tiny",Response.text)

    def test_unauthenticated_catalogue(self):
        with TestClient(self.App,base_url="http://127.0.0.1:3000") as Client:
            self.assertEqual(Client.get("/api/catalog").status_code,401)

    def test_account_password_change(self):
        Response = self.Client.post("/api/account/password",json={"CurrentPassword":"wrong","NewPassword":secrets.token_urlsafe(24)})
        self.assertEqual(Response.status_code,400)
        Response = self.Client.patch("/api/account",json={"DisplayName":"New name","Email":"me@example.com"})
        self.assertEqual(Response.json()["DisplayName"],"New name")

    def test_last_admin(self):
        # The test runs before any permanent administrator is configured.
        with self.Database.Transaction() as Connection:
            Count = Connection.execute("SELECT COUNT(*) FROM Users WHERE RoleId='Administrator' AND IsActive=1").fetchone()[0]
        if Count != 1:
            self.skipTest("Permanent administrator exists; last-admin fixture requires isolation.")
        Response = self.Client.patch("/api/users/"+self.UserIds[0],json={"RoleName":"Viewer","IsActive":True,"Version":1})
        self.assertEqual(Response.status_code,409)


