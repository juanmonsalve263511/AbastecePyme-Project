# AbastecePyme Modernization Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Deliver the approved React interface, Python API, authenticated roles and persistent weighted catalogue.
**Architecture:** FastAPI serves the React build and synchronous ODBC endpoints on one origin. MariaDB stores the catalogue and opaque sessions; Python Decimal calculates material estimates. React draws the graph with native SVG.
**Tech Stack:** React, Vite, FastAPI, pyodbc, MariaDB, Argon2id, Python unittest/HTTP integration tests.
**Spec:** ../specs/2026-10-25-abastecepyme-modernization-design.md (approved by user).

## Global Constraints
- English code/comments and PascalCase identifiers, except framework-required names; Spanish interface.
- No graph libraries for algorithms, layout or rendering.
- Preserve 40 element IDs, names/types and 92 directed pairs, including cycles and self-links.
- Independent AbastecePyme database only; never modify gym_admin_management.
- Dark/pale blue and gray palette; local Segoe UI; minimum 16 px body text.
- COP demonstration prices DECIMAL(18,2), positive quantities DECIMAL(18,4), editable units and demonstration markers.
- Parameterized SQL, InnoDB, utf8mb4, transactional multi-table writes.
- Database password in memory only; no default administrator password.
- Administrator, Editor, Viewer; public registration always Viewer.
- Windows launcher, isolated pinned Python dependencies, pinned frontend dependencies.
- Preserve legacy source/tests and JSON backup. No Git repository exists; use verified backups instead of pretending to commit.

## Review Focus
- Decimal overflow, NaN and precision loss must be rejected (Task 1).
- Failed partial imports and repeated migrations must preserve original IDs and pairs without duplicates (Task 1).
- Parallel edits/deletes must conflict clearly and never silently overwrite (Task 3).
- Forged roles, expired sessions and concurrent removal of the last administrator must fail (Task 2).
- Mobile graph gestures, keyboard focus and cancelled deletion must preserve usability/data (Task 4).

## File Structure and Shared Contracts
- backend/Database.py: connection factory and transaction context; backend/Schema.py: DDL and migration.
- backend/Models.py: strict PascalCase request models; backend/Estimates.py: pure Decimal calculation.
- backend/Auth.py: password hashing, sessions, CSRF, role guards; backend/Users.py: account administration.
- backend/Catalog.py, backend/Relations.py: parameterized repositories and validation.
- backend/Main.py: FastAPI routes and static build serving; backend/Setup.py: local administrator initialization.
- frontend/src/Api.js: credentialed same-origin client; App.jsx and components/: public/authenticated views; Graph.jsx: native SVG.
- tests/python/: unit and API tests; tests/integration/: isolated live SQL checks; original tests/ unchanged.
- Start.py, Iniciar.cmd, requirements.txt, frontend/package.json and lockfile: reproducible startup/build.
- docs/: schema, setup, roles, demo weights, test evidence and backup guide.

API prefix /api; PascalCase JSON. Errors use Detail; missing resources 404, conflicts 409, invalid fields 422, unauthenticated 401, unauthorized 403. Decimal values travel as strings. GET /api/catalog returns {Elements, Relations}; elements contain ElementId, Name, ElementType, Description, Version and subtype fields. Relations contain SourceId, TargetId, RelationType, Value (decimal string or null), IsDemo. Catalogue mutations return the updated resource. DELETE requires Version for elements. Routes use server authorization, never frontend-only checks.

## Task 1: Schema, Migration and Decimal Estimates
**Files:** backend/Database.py, Schema.py, Models.py, Estimates.py, requirements.txt; tests/python/test_migration.py, test_estimates.py.
**Interfaces:** Connect() returns a fresh ODBC connection; Transaction() commits/rolls back. Migrate(Connection, CatalogPath) creates schema and imports once. CalculateEstimate(ProductId, Elements, Relations) returns {Total, CurrencyCode, IsComplete, IsDemo, Choices, Missing}.
- [ ] Write tests named TestOriginalCatalogue (40 nodes/92 pairs, exact IDs/names/types), TestRepeatMigration (same counts), TestImportRollback (no partial catalogue), TestDecimalBounds (NaN, negative price, zero quantity, excess precision and overflow rejected).
- [ ] Run `python -m unittest discover -s tests/python -p test_migration.py -v`; verify failures reflect missing implementation.
- [ ] Implement normalized schema with all eleven approved tables, subtype FKs, role seeds and migration checksum. Use deterministic marked demo weights; classify only supplier-material and material-product edges as weighted. Keep general edges unchanged.
- [ ] Write TestCheapestAlternative: quantities 1.5 and 2, respective cheapest unit prices 10.20 and 3.10 give 21.50; supplier alternatives are not summed. TestMissingOffer returns IsComplete=false, TestGeneralDependency marks incompleteness.
- [ ] Run estimate tests to observe failure; implement Decimal calculation and finite/range validation, then rerun both suites successfully.
- [ ] Renew network permission, verify hostname Juan_Tavera, then create/import the independent DB. Verify original hash and all pairs, repeat migration, check rollback using uniquely identified test records and clean only those records.

## Task 2: Authentication and User Roles
**Files:** backend/Auth.py, Users.py, Setup.py; tests/python/test_auth.py.
**Interfaces:** CurrentUser(Request) returns UserId, Username, DisplayName, RoleName; RequireRole(Request, AllowedRoles) enforces active session and role. POST /api/auth/register, login, logout; GET /api/auth/session; PATCH /api/account; POST /api/account/password; GET /api/users; PATCH /api/users/{UserId}.
- [ ] Write TestRegistrationCannotChooseRole, TestViewerCannotWrite, TestCsrfRejected, TestExpiredSession, TestLogoutInvalidates, TestLastAdministrator and TestPasswordNotReturned. Assert status403/422 as applicable, no account/session mutation on failures and no password/hash keys in responses.
- [ ] Run `python -m unittest discover -s tests/python -p test_auth.py -v`; observe expected failures.
- [ ] Implement Argon2id, random opaque cookie sessions stored as hashes, expiry, CSRF token/origin verification, login attempt limiting and fixed Viewer registration. Lock relevant administrator rows transactionally for last-admin protection. Password changes revoke other sessions.
- [ ] Implement local hidden-input initial-admin command, refusing remote bootstrap and avoiding credentials in files/logs.
- [ ] Rerun auth tests including concurrent last-admin changes; confirm one active administrator remains.

## Task 3: Catalogue, Relationships and API
**Files:** backend/Catalog.py, Relations.py, Main.py; tests/python/test_api.py; tests/integration/test_database.py.
**Interfaces:** GET /api/catalog, POST /api/elements, PATCH/DELETE /api/elements/{ElementId}; GET /api/elements/{ElementId}/deletion-preview returns RelationshipCount and Version; POST/PATCH/DELETE /api/relations; GET /api/graph; GET /api/products/{ProductId}/estimate. Graph shares catalogue data shape. Relation writes identify both endpoints and validate their types.
- [ ] Write TestCrudPersists, TestDuplicateId, TestMissingEndpoint, TestStableType, TestVersionConflict, TestAtomicDelete, TestRelationWeights, TestSqlPayloadIsData, TestForbiddenWrites and TestUnknownFields. Assert valid persistence, expected409/422/403 and rollback on injected mid-operation failure.
- [ ] Run `python -m unittest discover -s tests/python -p test_api.py -v`; observe missing route/repository failures.
- [ ] Implement parameterized repositories, optimistic versions, deletion-preview and transactional deletion of relations/subtype/element. Integrate session/role guards, body size limits, strict request models and sanitized errors.
- [ ] Rerun API tests and live SQL tests with identified temporary records in AbastecePyme. Restart connection/server and verify persistence; clean temporary records only. No DROP privilege or destructive schema reset required.

## Task 4: React Interface and Native Graph
**Files:** frontend/package.json, vite.config.js, index.html, src/Api.js, App.jsx, Styles.css, components/{Home,Login,Dashboard,Catalog,Relations,Graph,ApiExplorer,Users,Account}.jsx.
**Interfaces:** Api(RequestPath, Options) manages same-origin cookies/CSRF and exposes sanitized Detail errors. Components consume the contracts above; navigation follows active role and handles401 centrally.
- [ ] Define browser acceptance checks before implementation: Viewer cannot see edit actions; Editor edits price and sees persisted result; cancelling deletion retains element; API resource selector cannot enter arbitrary URLs.
- [ ] Create pinned React/Vite frontend and implement public homepage, authentication, sidebar/workspace, searchable subtype tables, accessible validated forms and previews, user/account screens. Apply approved palette and demo labels.
- [ ] Implement SVG graph with own deterministic grouping/order, arrow edges, weights, selection/details, wheel/buttons zoom, pan, fit/reset, keyboard focus and reduced-motion handling. No graph dependency.
- [ ] Implement read-only API explorer with resource/parameter selectors, status, timing and formatted JSON. Show Python estimates with omissions and selected suppliers.
- [ ] Build via `npm run build`; use real-browser checks at desktop and mobile widths for login, role screens, CRUD, cancellation, graph zoom/pan and API query. Assert visible focus, labels, no horizontal page overflow and no browser console errors. Capture screenshots and fix observed issues.

## Task 5: Startup, End-to-End Validation and Delivery
**Files:** Start.py, Iniciar.cmd, docs/SETUP.md, docs/SCHEMA.md, docs/VALIDATION.md; outputs user guide copy.
**Interfaces:** launcher prompts database password with hidden input, performs port check, runs FastAPI serving frontend/dist at http://127.0.0.1:3000; setup requests an initial admin secret only when needed.
- [ ] Write launcher checks for missing build/driver, occupied port and bad DB authentication; verify clear Spanish diagnostics without secret leakage.
- [ ] Implement launcher and installation/setup documentation with explicit Python path, isolated environment, locked dependencies, backup and administrator procedures.
- [ ] Run original21 tests as baseline and all new unit/integration suites; report each separately with actual counts. Verify repeat migration, restart persistence and catalogue preservation.
- [ ] Perform a final real-browser run across Viewer, Editor and Administrator and review mobile/keyboard behavior. Verify no stored DB password or password/hash in client responses/logs/artifacts.
- [ ] Review complete changes against approved design; resolve material findings and rerun affected tests. Document remaining limits honestly.
- [ ] Deliver runnable project, startup instructions, schema and demo-weight explanation, validation evidence and names/functions of skills actually used. Initial administrator password remains user-chosen; request it only through hidden local setup.
