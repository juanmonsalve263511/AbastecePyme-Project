import test from 'node:test';
import assert from 'node:assert/strict';
import * as Geometry from '../frontend/src/components/GraphLayout.js';

const Elements=[['S','Supplier'],['M','Material'],['P','Product'],['P2','Product']].map(([ElementId,ElementType])=>({ElementId,ElementType,Name:ElementId}));
const Relations=[['S','M'],['M','P'],['P','P2'],['P2','P'],['P2','P2']].map(([SourceId,TargetId])=>({SourceId,TargetId,RelationType:'General'}));
const Network=()=>Geometry.BuildLayout(Elements,Relations,'',true);
function Contains(View,X,Y){assert.ok(X>=View.X-1e-8&&X<=View.X+View.Width+1e-8&&Y>=View.Y-1e-8&&Y<=View.Y+View.Height+1e-8,JSON.stringify({View,X,Y}));}
function ContainsNode(View,Node){Contains(View,Node.X,Node.Y);Contains(View,Node.X+248,Node.Y+64);}

test('fitting a complete network includes nodes, headings and curve control bounds',()=>{
  const Layout=Network(), View=Geometry.FitGraphView(Layout,{Width:880,Height:520});
  for(const Node of Layout.Nodes)ContainsNode(View,Node);
  for(const Column of Layout.Columns){Contains(View,Column.X,14);Contains(View,Column.X+248,40);}
  for(const Edge of Layout.Edges){
    const Coordinates=Geometry.EdgePath(Layout.Map.get(Edge.SourceId),Layout.Map.get(Edge.TargetId)).match(/-?\d+(?:\.\d+)?/g).map(Number);
    for(let Index=0;Index<Coordinates.length;Index+=2)Contains(View,Coordinates[Index],Coordinates[Index+1]);
  }
  assert.ok(Math.abs(View.Width/View.Height-880/520)<1e-8);
});

test('a compact single-column graph is not padded by missing types or a fixed 1100-unit canvas',()=>{
  const Layout=Geometry.BuildLayout(Elements.filter(Item=>Item.ElementType==='Product'),[],'',true);
  assert.equal(Layout.Columns.length,1);
  const View=Geometry.FitGraphView(Layout,{Width:800,Height:500});
  assert.ok(View.Width<800);
  assert.ok(800/View.Width<=1.2);
  for(const Node of Layout.Nodes)ContainsNode(View,Node);
});

test('the initial mobile view keeps the selected node readable and fully inside the viewport',()=>{
  const Layout=Network(), View=Geometry.InitialGraphView(Layout,{Width:320,Height:480},'P2');
  assert.equal(View.Width,320);
  assert.equal(View.Height,480);
  ContainsNode(View,Layout.Map.get('P2'));
  const Overview=Geometry.FitGraphView(Layout,{Width:320,Height:480});
  for(const Node of Layout.Nodes)ContainsNode(Overview,Node);
  assert.ok(Overview.Width>View.Width);
});

test('a readable view without a selection starts at the first actual node',()=>{
  const Layout=Network(), View=Geometry.ReadableGraphView(Layout,{Width:320,Height:480},'missing');
  ContainsNode(View,Layout.Nodes[0]);
  assert.equal(View.Width,320);
});

test('a wide initial viewport fits the whole small graph instead of cropping an arbitrary origin',()=>{
  const Layout=Network(), View=Geometry.InitialGraphView(Layout,{Width:1200,Height:680},'P');
  assert.deepEqual(View,Geometry.FitGraphView(Layout,{Width:1200,Height:680}));
  for(const Node of Layout.Nodes)ContainsNode(View,Node);
});

test('zoom keeps the pointer position fixed and clamps without changing the aspect ratio',()=>{
  const View={X:100,Y:50,Width:800,Height:500}, Center={x:360,y:220};
  const Zoomed=Geometry.ZoomGraphView(View,.8,Center,3200);
  assert.equal((Center.x-View.X)/View.Width,(Center.x-Zoomed.X)/Zoomed.Width);
  assert.equal((Center.y-View.Y)/View.Height,(Center.y-Zoomed.Y)/Zoomed.Height);
  assert.equal(Zoomed.Width/Zoomed.Height,View.Width/View.Height);
  assert.equal(Geometry.ZoomGraphView(View,100,Center,3200).Width,3200);
  assert.equal(Geometry.ZoomGraphView(View,.001,Center,3200).Width,160);
});

test('keyboard reveal moves a panned viewport to contain a node without changing readable zoom',()=>{
  const Node=Network().Map.get('P2'), View={X:-1200,Y:-500,Width:320,Height:480};
  const Revealed=Geometry.RevealGraphNode(View,Node);
  ContainsNode(Revealed,Node);
  assert.equal(Revealed.Width,View.Width);
  assert.equal(Revealed.Height,View.Height);
  assert.equal(Geometry.RevealGraphNode(Revealed,Node),Revealed);
});

test('keyboard reveal zooms out only enough to show a node after extreme zoom',()=>{
  const Node=Network().Map.get('P'), View={X:Node.X,Y:Node.Y,Width:160,Height:240};
  const Revealed=Geometry.RevealGraphNode(View,Node);
  ContainsNode(Revealed,Node);
  assert.equal(Revealed.Width/Revealed.Height,View.Width/View.Height);
});

test('empty layouts and unmeasured viewports always yield finite positive views',()=>{
  const Layout=Geometry.BuildLayout([],[],'',true);
  for(const View of [Geometry.FitGraphView(Layout,{Width:0,Height:0}),Geometry.InitialGraphView(Layout,{Width:0,Height:0}),Geometry.ReadableGraphView(Layout,{Width:0,Height:0})]){
    assert.ok(Object.values(View).every(Number.isFinite));
    assert.ok(View.Width>0&&View.Height>0);
  }
});

test('fitting includes zero-valued weight labels on same-column and self edges',()=>{
  const Edges=Relations.map(Edge=>({...Edge,Value:'0.00'}));
  const Layout=Geometry.BuildLayout(Elements,Edges,'',true),View=Geometry.FitGraphView(Layout,{Width:880,Height:520});
  for(const Edge of Layout.Edges){
    const Label=Geometry.EdgeLabelPosition(Layout.Map.get(Edge.SourceId),Layout.Map.get(Edge.TargetId));
    Contains(View,Label.X-72,Label.Y-15);
    Contains(View,Label.X+72,Label.Y+15);
  }
});
