# Feature 4 — Tablero de abastecimiento demostrable

Entrega original: **14 de noviembre de 2026**. Ampliación documental y funcional: **16 de noviembre de 2026**.

## Ampliación del 16 de noviembre — foco y flechas

El tablero ahora abre el grafo en **Enfocar conexiones**. Para impacto se muestra el origen y toda su cadena de consecuencias, incluidas las lejanas; para ciclo se muestran los elementos y relaciones del ciclo que informó el servidor. **Mostrar grafo completo** amplía la vista a toda la red actual o del escenario sin modificar el análisis.

Las flechas animadas se desplazan continuamente en sentido requisito → dependiente. Se pueden detener con **Pausar flechas** y activar con **Reanudar flechas**. La preferencia de movimiento reducido del sitio o del sistema detiene la animación y mantiene visibles las flechas estáticas.

La comparación de costos del mismo día se incorpora en Catálogo, Grafo de abastecimiento y Orden de producción: mínimo/máximo de materiales y componentes, con precio calculado igual al mínimo más 25 %. Los grafos del tablero no presentan un costo de la red guardada como si fuera el costo de una hipótesis temporal. El [documento del 16 de noviembre](GRAPH_COSTS_2026-11-16.md) detalla las reglas, las **172 pruebas aprobadas** y la revisión visual de foco, movimiento y actualización de costos. La comprobación TCP confirmó 3001 abierto, sin verificar la versión del backend activo; las instrucciones de reinicio se explican allí.

**La evidencia, capturas y video de las secciones siguientes corresponden al 14 de noviembre.** Se conservan como historia de Feature 4; no prueban el enfoque, la animación o los costos añadidos el día 16.

## Propósito y alcance

El tablero conecta las tres preguntas del brief: **qué depende de un elemento, qué podría verse afectado si falta y cómo organizar la preparación**. Integra catálogo, recorrido de impacto, orden o alerta de ciclo y una red que explica el resultado seleccionado.

La dirección se conserva: **requisito → dependiente**. Una flecha A → B significa «Para preparar B, necesito A».

La simulación de indisponibilidad plantea una hipótesis sobre el elemento seleccionado. No lo elimina del catálogo ni de las dependencias para producir artificialmente un orden válido. El recorrido sigue representando impacto potencial y el orden sigue representando precedencia estructural.

## Correspondencia con el brief

| Requisito de Feature 4 | Respuesta de la aplicación | Evidencia que debe acompañarla |
|---|---|---|
| Integrar catálogo, impacto y orden/alerta de ciclo | Un tablero parte del elemento seleccionado y presenta impacto y producción calculados sobre la misma lectura del catálogo. | Pantalla del tablero, contrato de análisis y aceptación de cadena/ciclo. |
| Visualizar dependencias y destacar la consulta relevante | La red destaca el camino hacia el resultado elegido o el ciclo que impide ordenar. | Grabación con selección y resaltado visibles. |
| Adaptar el cambio de requisitos | Comparar la red registrada con una dependencia añadida o retirada temporalmente. | Diferencias de alcanzados, estado de producción antes/después y comprobación de catálogo intacto. |
| Ejecutar aceptación para cadena válida, elemento inexistente, dato inválido y ciclo | Cuatro casos identificados y repetibles, con resultados distintos. | Matriz de aceptación y ejecución fechada, sin confundir pruebas aisladas con MariaDB operativa. |
| Entregar documentación, bitácora IA, video y pitch | Este documento, guía de uso, bitácora y archivos audiovisuales enlazados. | Existencia y reproducción del video, apertura del pitch visual y enlaces válidos en el paquete. |

El cambio de requisitos se concreta en esta pregunta: **«¿Qué pasaría si un elemento necesitara otro requisito, o dejara de necesitar uno de los actuales?»**. Se añade como análisis temporal y conserva las operaciones existentes del catálogo. No reemplaza el registro de una dependencia real.

## Comparar un cambio sin guardarlo

1. En **Elemento no disponible**, seleccionar un proveedor o insumo como origen del impacto potencial. La API también admite consultar otro elemento existente.
2. En **Alcance del orden estructural**, elegir toda la red o un producto con sus requisitos. Este filtro no limita el recorrido de impacto, que consulta toda la red.
3. Pulsar **Simular indisponibilidad** y revisar **Ver camino** en un elemento alcanzado.
4. En **Cambio de dependencia**, elegir **Agregar una dependencia general** o **Retirar una relación existente** y completar los campos.
5. Pulsar **Comparar escenario**. Revisar **Qué cambia en el escenario** y alternar **Red actual** / **Escenario temporal**.
6. Revisar **Ver impacto**, **Ver ciclo** o **Destacar ciclo en el grafo**. **Descartar cambio temporal** limpia el ensayo y sus resultados; después, **Simular indisponibilidad** vuelve a consultar la red base.

**Añadir** en la simulación admite dependencias generales, sin precio ni cantidad. Las parejas proveedor → insumo e insumo → producto requieren valores de compra o uso y deben gestionarse mediante **Relaciones**. El tablero rechaza esas altas temporales en lugar de inventar un peso. **Retirar** admite cualquier relación existente y conserva sus elementos.

Una autorrelación puede analizarse: produce un ciclo. Una pareja dirigida ya registrada no puede añadirse de nuevo. Retirar una relación inexistente es un error, no un cambio silencioso.

Consulta, Editor y Administrador pueden analizar y comparar. Las modificaciones persistentes del catálogo siguen reservadas a Editor y Administrador, con sus validaciones y confirmaciones habituales. Un ensayo no se convierte automáticamente en una modificación guardada.

## Contrato de análisis

**POST `/api/dashboard/analyze`**, con sesión válida, origen del sitio y token CSRF. Aunque usa POST para recibir los parámetros, el análisis no persiste cambios de negocio.

También se puede ejecutar desde **Explorador de API → POST · Análisis del tablero**. El editor de **Datos de la solicitud (JSON)** y el botón **Analizar escenario** están disponibles para los tres perfiles. No pide confirmar una escritura ni vuelve a cargar el catálogo como si se hubiera guardado un cambio.

Ejemplo de cuerpo; los códigos deben existir en el catálogo utilizado:

```json
{
  "ElementId": "PROV-NORTE",
  "ProductId": "PROD-ESTANTE",
  "Change": {
    "Operation": "Add",
    "SourceId": "PROD-ESTANTE",
    "TargetId": "PROD-PANEL"
  }
}
```

| Campo de entrada | Significado |
|---|---|
| `ElementId` | Código obligatorio del origen de la indisponibilidad potencial. |
| `ProductId` | Código de un producto, o `null` para toda la red. |
| `Change` | `null` para consultar sin modificación temporal, o el cambio que se quiere comparar. |
| `Change.Operation` | `Add` o `Remove`. |
| `Change.SourceId` / `TargetId` | Requisito y dependiente, respectivamente. Deben ser elementos existentes. |

Se rechazan campos adicionales e identificadores mal formados. No se envían precios ni cantidades en este contrato.

| Campo de salida | Significado |
|---|---|
| `Catalog` | Catálogo base utilizado, sin modificarlo con el escenario. |
| `Base.Impact` / `Base.Production` | Impacto y producción de la red registrada. |
| `Scenario.Impact` / `Scenario.Production` | Los mismos análisis después del cambio temporal. Sus grafos reflejan ese escenario. |
| `Change` | Cambio analizado, o ausencia de cambio. |
| `Comparison.AddedReached` / `RemovedReached` | Códigos que aparecen o dejan de aparecer entre los alcanzados desde el origen. |
| `Comparison.ProductionStatusBefore` / `ProductionStatusAfter` | Estado de producción antes y después. |
| `SnapshotId` | Huella SHA-256 que identifica los datos base usados en ese análisis. |

Una solicitud lee el catálogo una vez y calcula ambos resultados sobre esa lectura y su copia. La huella identifica el resultado; no bloquea futuras ediciones ni garantiza que la pantalla siga actualizada después de que otra persona cambie los datos. Al editar el catálogo, vuelve a analizar.

Se reutilizan los recorridos propios BFS para impacto, Kahn para orden y DFS iterativo para explicar ciclos. No se elimina el origen indisponible ni se implementa un segundo algoritmo de negocio en el navegador.

### Respuestas y errores

| Resultado | Interpretación |
|---|---|
| `200` y producción `Ready` | La consulta terminó y hay un orden estructural válido. |
| `200` y producción `Cycle` | La consulta terminó y encontró una contradicción. El resultado cíclico tiene `Order=[]` y `Stages=[]`. |
| `200` e impacto `NoReachable` | El origen existe, pero no hay otros elementos alcanzables en esa dirección. |
| `404` | Falta el elemento, producto, extremo o relación solicitados. |
| `422` | Datos mal formados, producto de tipo incorrecto o alta temporal de una pareja que requiere peso. |
| `409` | La dependencia que se intenta añadir ya existe. |
| `401` / `403` | Falta una sesión válida o falla la comprobación de origen/CSRF. |

## Matriz de aceptación

Los ejemplos siguientes son **datos sintéticos de prueba**. No son el catálogo operativo ni instrucciones para introducir ciclos en él.

| Caso | Preparación y acción | Resultado exigido |
|---|---|---|
| **F4-A1 — Cadena válida** | Registrar A → B → C y consultar impacto desde A y producción del alcance correspondiente. | B y C aparecen una vez, con camino explicable; la red destaca el recorrido; el orden coloca A antes de B y B antes de C. |
| **F4-A2 — Elemento inexistente** | Consultar un código bien formado que no está registrado. | `404` y mensaje comprensible. Se distingue de un elemento existente sin alcanzados; no cambia el catálogo. |
| **F4-A3 — Dato inválido** | Enviar un identificador mal formado, una operación no admitida o una dependencia temporal que necesita peso. | `422`, sin relaciones parciales ni cambios en el catálogo. La interfaz permite corregir el dato o volver a seleccionar. |
| **F4-A4 — Ciclo** | Sobre A → B → C, comparar temporalmente C → A. | `Cycle`, un camino cerrado cuyas aristas existen en el escenario, sin orden ni etapas parciales; la red base sigue intacta. |
| **F4-A5 — Cambio de requisitos** | Añadir una dependencia general válida o retirar una existente, y comparar con la red base. | Se calculan diferencias de alcanzados y estado de producción. Descartar el ensayo permite volver a consultar la red registrada. |
| **F4-A6 — Integración y permisos** | Consultar con los tres perfiles y revisar una escritura persistente con Consulta. | Todos pueden simular; Consulta no adquiere permiso de escritura. Base y escenario corresponden a una sola lectura por análisis. |
| **F4-A7 — Entrega demostrable** | Abrir documentación, video y pitch incluidos en el paquete. | Enlaces válidos y archivos reproducibles; el video muestra interacciones reales y los casos se vinculan a su evidencia. |

Los primeros cuatro casos responden a la aceptación exigida por el brief. Los restantes comprueban el cambio acordado, los permisos y la entrega completa.

La aceptación del recorrido está en [test_supply_board_journey.py](../tests/python/test_supply_board_journey.py). Usa la [instancia sintética](../tests/fixtures/SupplyBoardPreview.py), inicia sesión mediante la API real y registra una dependencia de prueba. Comprueba la cadena, el elemento ausente frente al aislado, el dato inválido, el ciclo temporal y la retirada temporal de un requisito. Sus operaciones pertenecen a SQLite en memoria, sin acceder a MariaDB. El resultado fechado se registra a continuación.

Comando para repetir ese conjunto desde la raíz, con las dependencias instaladas:

```powershell
.\.venv\Scripts\python.exe -X utf8 -m unittest discover -s tests/python -p test_supply_board_journey.py -v
```

## Evidencia y estado de verificación

El **14 de noviembre de 2026** se ejecutaron y aprobaron estos conjuntos:

| Conjunto | Resultado | Alcance |
|---|---|---|
| `Verify.py` completo | **88 pruebas Python + 59 JavaScript = 147 aprobadas**; compilación Vite de **49 módulos** correcta. | Sintaxis, suites del proyecto y compilación temporal; sin acceso a MariaDB. |
| [test_supply_board_journey.py](../tests/python/test_supply_board_journey.py) | **5 pruebas aprobadas**, 0,490 s. | Inicio de sesión real, registro de dependencia y los casos de aceptación sobre SQLite en memoria. |
| [test_supply_board_api.py](../tests/python/test_supply_board_api.py) | **4 pruebas aprobadas**, 0,370 s. | Sesión y tres perfiles, origen/CSRF, una lectura por análisis, ausencia de escrituras del escenario y rechazo de campos extra. |

Los conjuntos de cinco y cuatro casos están incluidos en las 88 pruebas Python; no deben sumarse de nuevo. Los tiempos describen sus ejecuciones específicas, no una garantía de rendimiento.

También se extrajo una copia de prueba del paquete en una carpeta nueva: **Verify.py --skip-build** aprobó de nuevo **88 pruebas Python y 59 JavaScript**. Se utilizaron el intérprete y las dependencias ya instalados del proyecto; no fue una instalación limpia ni una prueba de MariaDB. El código fuente coincidía con el que había superado la compilación.

La revisión independiente del frontend no encontró hallazgos accionables. En el navegador integrado, sobre la instancia sintética, se comprobó el registro de **Panel preparado → Estante modular** con respuesta `201`, el impacto y camino hasta Estante, sus cuatro etapas en ese conjunto de prueba, la comparación con ciclo, el ciclo resaltado en rojo, la vuelta a la red base válida y el descarte conservando el catálogo.

Desde **POST · Análisis del tablero** en el Explorador de API se observaron **MISSING → 404**, **bad! → 422** con indicación de `ElementId`, y **PROD-AISLADO → 200, NoReachable**. El catálogo de demostración conservó sus tres relaciones tras esas consultas. La comprobación global final incluyó esta nueva operación del Explorador, con **147 pruebas aprobadas y cero fallos**.

En móvil se revisó un viewport de **390 × 844**: el área de contenido y su ancho desplazable midieron **375 px**, sin desbordamiento horizontal en esa medición. Se comprobó zoom de **100 % a 125 %** y la consola no registró errores ni advertencias durante el recorrido. Esto no sustituye una auditoría completa de accesibilidad o de todos los dispositivos.

El [video entregado](media/Feature4-Recorrido.webm) dura **2:15**, tiene títulos y no tiene voz. Se decodificaron sus **3.375 fotogramas** sin errores y se reprodujo completo en el navegador hasta los 135 segundos. El [pitch visual](media/Feature4-Pitch.html) contiene **seis diapositivas** revisadas, con ajuste a 720 px de altura y avance automático comprobados. Los detalles y el [SRT](media/Feature4-Recorrido.srt) están enlazados en [la evidencia audiovisual](FEATURE4_VIDEO.md).

Las siguientes capturas corresponden a la **instancia sintética**, no a una consulta de la base operativa:

| Captura | Evidencia visual |
|---|---|
| [Tablero y consulta](media/Feature4-Tablero.jpg) | Integración del catálogo, impacto y orden de preparación. |
| [Comparación y ciclo](media/Feature4-Ciclo.jpg) | Contradicción temporal y ciclo destacado en la red. |
| [Vista móvil](media/Feature4-Movil.jpg) | Presentación de la misma función en la revisión móvil. |

La suite emitió avisos de deprecación de Starlette/httpx y del adaptador de fechas de SQLite utilizado por la prueba de Feature 3. No hubo fallos. Esos avisos quedan identificados para mantenimiento posterior.

Las **68 pruebas Python y 48 JavaScript**, compilación y revisión visual del [6 de noviembre](REVIEW_2026-11-06.md), y las **9 pruebas puras de producción del 7 de noviembre** documentadas en [Feature 3](FEATURE3.md), son antecedentes fechados. No demuestran por sí solas el nuevo tablero.

La aceptación nueva debe registrar fecha, comando o recorrido, resultado, entorno de datos y límites. Las pruebas aisladas no equivalen a una validación de la base operativa ni a una auditoría completa de accesibilidad.

[aceptacion.md](aceptacion.md) y [VALIDATION.md](VALIDATION.md) conservan evidencias históricas de las primeras entregas. Sus recuentos y ejemplos de la API anterior no sustituyen esta aceptación ni el contrato actual del README.

### Estado de la instalación operativa

El 14 de noviembre, el proceso operativo de **3001** todavía respondía `404` a `POST /api/dashboard/analyze`; seguía ejecutando el servidor anterior. En la instancia aislada de **3014**, la ruta estaba disponible y respondía `401` sin iniciar sesión. La comprobación del nuevo recorrido pertenece a esa instancia aislada, no a MariaDB operativa.

La interfaz nueva está compilada. Para cargar el servidor actualizado, detén únicamente la ventana anterior de AbastecePyme con **Ctrl+C**, ejecuta **Iniciar.cmd --port 3001**, introduce la contraseña de MariaDB en la entrada oculta y recarga el navegador. Ese reinicio queda pendiente de la persona que dispone de la credencial; no se realizó en esta entrega.

Los servidores temporales de demostración y apoyo en **3014 y 3015** se detuvieron después de la revisión. La instancia operativa de 3001 permaneció intacta. Para repetir la demostración aislada, inicia de nuevo el programa descrito en la guía del video.

## Límites del resultado

- Indisponibilidad significa una hipótesis de impacto potencial. No se consultan existencias, entregas ni disponibilidad real.
- Los proveedores de un insumo son alternativas; estar alcanzado no demuestra que no exista sustitución ni obliga a comprarles a todos.
- El orden representa requisitos previos; no calcula fechas, duración, capacidad o asignación de recursos.
- Los precios y cantidades no cambian el alcance del recorrido ni el orden topológico. Los valores de referencia conservan su identificación.
- Un ciclo ajeno a los requisitos del producto elegido puede no afectar ese análisis, aunque sí invalide el orden de toda la red.
- La lista de pendientes puede incluir dependientes del ciclo, además de sus integrantes. Corregir un ciclo no descarta que existan otros.
- El cambio temporal no se guarda, no reserva materiales ni crea una orden de producción persistente.

## Entregables relacionados

- [Guía completa de uso](GUIA_ACTUALIZACION_2026.md).
- [Bitácora de asistencia de IA](bitacora-ia.md).
- [Guion y evidencia del video](FEATURE4_VIDEO.md).
- [Video del recorrido](media/Feature4-Recorrido.webm).
- [Pitch listo para presentar](FEATURE4_PITCH.md).
- [Presentación visual del pitch](media/Feature4-Pitch.html).

Los criterios de diseño, React, diagnóstico y verificación parten de las guías de trabajo ya disponibles en el proyecto y de la [revisión anterior](REVIEW_2026-11-06.md). La bitácora registra su reutilización y separa el trabajo asistido de la revisión que corresponde al equipo.
