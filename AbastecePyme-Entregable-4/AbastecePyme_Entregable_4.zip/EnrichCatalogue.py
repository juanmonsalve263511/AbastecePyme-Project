"""Explicitly install the optional reference catalogue expansion once."""
import argparse
import getpass
import json
import sys
from pathlib import Path
from backend.Database import Database
from backend.Schema import Migrate
from backend.Enrichment import ApplyExpansion

def Main():
    Parser=argparse.ArgumentParser(description='Agregar proveedores, componentes y precios de referencia una sola vez.')
    Parser.add_argument('--password-stdin',action='store_true')
    Arguments=Parser.parse_args()
    Password=sys.stdin.readline().rstrip('\r\n') if Arguments.password_stdin else getpass.getpass('Contraseña MariaDB: ')
    Instance=Database(Password)
    del Password
    Migrate(Instance,Path(__file__).resolve().parent/'data/catalogo.json')
    print(json.dumps(ApplyExpansion(Instance),ensure_ascii=False))

if __name__=='__main__':
    Main()
