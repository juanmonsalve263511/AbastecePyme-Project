import {useState} from 'react';
import {Api} from '../Api.js';
import {Field,Notice,Icon} from './Common.jsx';
import ContactForm from './ContactForm.jsx';
import LocationCard from './LocationCard.jsx';
import Reveal from './Reveal.jsx';
import PublicLayout from './PublicLayout.jsx';

const Content={
  services:{Title:'Una red organizada cambia la forma de trabajar.',Intro:'Herramientas para entender tus dependencias, compartir información y preparar mejor cada producto.',Sections:[
    ['Catálogo compartido','Reúne proveedores, insumos y productos. Los administradores y editores pueden crear, actualizar y eliminar elementos, registrar precios en pesos colombianos y definir las cantidades de cada material.'],
    ['Análisis de impacto','Explora las consecuencias potenciales de un proveedor o insumo, o consulta todos los requisitos de un producto. Cada resultado muestra el camino que explica su conexión.'],
    ['Orden de producción','Organiza los elementos en etapas que respetan sus requisitos. Si existe un ciclo, la herramienta muestra la contradicción para que puedas revisar las relaciones.'],
    ['Un espacio para cada perfil','Consulta para quienes necesitan información, Editor para gestionar el catálogo y Administrador para controlar los accesos. Las cuentas se crean únicamente desde la administración.'],
    ['API para explorar y gestionar','Consulta datos, crea registros y actualiza o elimina elementos y relaciones. Las operaciones respetan los mismos permisos de tu cuenta.']
  ]},
  history:{Title:'Nacimos mirando de cerca cómo se hacen las cosas.',Intro:'Una idea con raíces en Medellín y vocación de acompañar a las pymes colombianas.',Sections:[
    ['El punto de partida','Un taller, varios proveedores y una pregunta esencial: si falta un material, ¿qué productos podrían verse afectados? AbastecePyme reúne esa información en un espacio compartido para convertir las conexiones en decisiones mejor informadas.'],
    ['Conectar antes de crecer','AbastecePyme surge como una propuesta para convertir esas relaciones en una red comprensible. Una mesa deja de ser solo un producto: es madera, tornillos, acabados y las personas que los suministran.'],
    ['Nuestro presente, 2026','Integramos el catálogo, los precios de venta, las alternativas de abastecimiento y el análisis de dependencias. Nuestro propósito es dar claridad a cada etapa: desde el insumo que se compra hasta el producto que se prepara.']
  ]},
  locations:{Title:'Conectados con las pymes de Colombia.',Intro:'Medellín es nuestra referencia principal. Bogotá y Cali amplían la perspectiva de una producción conectada.',Sections:[
    ['Medellín · Nuestra raíz','La cultura del trabajo y la transformación de materiales en el Valle de Aburrá inspiran nuestra propuesta para talleres, manufactureras y equipos de compras.'],
    ['Bogotá · Conexiones que crecen','Una mirada a las necesidades de empresas que articulan proveedores, materiales y productos en cadenas de abastecimiento diversas.'],
    ['Cali · Perspectiva regional','El suroccidente colombiano aporta una perspectiva de colaboración entre pequeños productores, comercios y redes de suministro.'],
    ['Atención y acceso','Visítanos en el Centro de Negocios One Plaza, Torre Norte, piso 3, Carrera 43A #5A-113, El Poblado, Medellín. Puedes contactarnos en el celular +57 311 335 2866 para conversar sobre tu solicitud.']
  ]},
  contact:{Title:'Una conversación también es una conexión.',Intro:'Encuentra el apoyo que necesitas para organizar tu información y aprovechar tu espacio de trabajo.',Sections:[
    ['Atención y soporte','Para consultas sobre el catálogo, los accesos o el funcionamiento de AbastecePyme, contacta al administrador de tu organización por su canal habitual.'],
    ['Cuéntanos qué necesitas','Indica la sección que estás utilizando, el producto o insumo relacionado y el resultado que esperabas. Esa información permite atender tu solicitud con mayor precisión.'],
    ['Acceso al aplicativo','Las cuentas son creadas por el administrador. Si necesitas ingresar, solicita un usuario y el perfil adecuado para tu trabajo. No existe registro público.'],
    ['Cómo te ayuda AbastecePyme','Organiza proveedores y materiales, consulta precios, interpreta dependencias y detecta ciclos de producción. Cada herramienta comparte la información de tu catálogo.']
  ]},
  terms:{Title:'Términos y condiciones de uso.',Intro:'Información para utilizar AbastecePyme y gestionar los datos de tu organización. Última actualización: 2 de noviembre de 2026.',Sections:[
    ['Alcance de la plataforma','AbastecePyme permite gestionar el catálogo y analizar sus relaciones de abastecimiento y producción. Los precios registrados sirven para consulta y planificación; la plataforma no procesa pagos, compras ni facturas.'],
    ['Acceso y responsabilidad','El administrador crea las cuentas y asigna perfiles. Usa credenciales propias y protege tu contraseña. Los cambios confirmados en el catálogo se guardan en la base de esta instalación.'],
    ['Interpretación de resultados','El alcance indica conexiones potenciales, no un bloqueo confirmado. El orden de producción respeta las dependencias registradas; no valida existencias, capacidad, tiempos ni selección de proveedores. Los valores de referencia deben validarse con las condiciones comerciales vigentes antes de utilizarlos.'],
    ['Datos y preferencias','Las contraseñas se almacenan mediante hash Argon2. La sesión usa una cookie local. Las preferencias de sonido y movimiento se conservan en el navegador. No se incluyen herramientas de publicidad ni se venden datos.'],
    ['Suscripción a novedades','Solo si autorizas el formulario se guarda tu correo y la fecha de la solicitud en la base local. Esta versión no envía correos. Para consultar o retirar ese registro, solicita ayuda al administrador de esta instalación.'],
    ['Solicitudes de contacto','Con tu autorización guardamos tu nombre, correo, los datos opcionales que compartas, tu mensaje y la fecha de envío para atender tu solicitud. Solo los administradores de esta instalación pueden consultarlos. Para solicitar la consulta, actualización o eliminación de tus datos, comunícate al +57 311 335 2866. El formulario no envía mensajes ni correos automáticos.'],
    ['Contenido y uso responsable','© 2026 AbastecePyme. Mantén actualizada la información de tu catálogo y utiliza únicamente datos que estés autorizado a gestionar.']
  ]}
};
function SubscriptionForm(){
  const [Busy,SetBusy]=useState(false);const [Error,SetError]=useState('');const [Message,SetMessage]=useState('');
  async function Submit(Event){
    Event.preventDefault();if(Busy)return;SetBusy(true);SetError('');SetMessage('');
    const Form=Event.currentTarget;const Values=new FormData(Form);
    try{const Result=await Api('/api/subscriptions',{method:'POST',body:{Email:Values.get('Email'),Consent:Values.get('Consent')==='on'}});SetMessage(Result.Detail);Form.reset();}
    catch(Failure){SetError(Failure.message);}finally{SetBusy(false);}
  }
  return <form className="subscription-form surface" onSubmit={Submit}><Icon Name="graph" Size={36}/><h2>Sigamos conectados.</h2><p>Deja tu correo para registrar tu interés en futuras novedades.</p><Notice Text={Error} Error/><Notice Text={Message}/><Field Label="Tu correo electrónico"><input name="Email" type="email" autoComplete="email" placeholder="tu@empresa.com" required maxLength={254}/></Field><label className="checkbox consent"><input name="Consent" type="checkbox" required/><span>Autorizo guardar mi correo en esta instalación según los <a href="#terms">términos y condiciones</a>.</span></label><button className="primary" disabled={Busy}>{Busy?'Registrando…':'Suscribirme'}<Icon Name="arrow"/></button><p className="quiet">Tu solicitud quedará registrada. El envío de boletines y confirmaciones aún no está habilitado.</p></form>;
}
export default function PublicPages({Route,Session}){
  const Page=Content[Route];
  return <PublicLayout Session={Session} Route={Route}><section className={'public-document'+(Route==='contact'?' contact-document':'')}><a className="back-link" href="#home">← Volver al inicio</a>
    <header><p className="section-note">AbastecePyme / {{services:'Servicios',history:'Nuestra historia',locations:'Locaciones',contact:'Contacto',terms:'Términos',updates:'Novedades'}[Route]}</p><h1>{Page?.Title||'Las buenas ideas merecen compartirse.'}</h1><p>{Page?.Intro||'Novedades de AbastecePyme, mejoras del aplicativo e ideas para conectar tu producción.'}</p></header>
    {Route==='locations'&&<Reveal ClassName="location-page-card"><LocationCard/></Reveal>}
    {Route==='contact'?<ContactForm/>:Route==='updates'?<SubscriptionForm/>:<div className="document-sections">{Page.Sections.map(([Title,Text])=><Reveal As="section" key={Title}><h2>{Title}</h2><p>{Text}</p></Reveal>)}</div>}
  </section></PublicLayout>;
}
