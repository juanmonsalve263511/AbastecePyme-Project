export class LatestRequest {
  constructor() { this.Generation = 0; this.Controller=null; }
  Cancel() { this.Generation += 1; this.Controller?.abort(); this.Controller=null; }
  async Run(Load, OnValue, OnError) {
    this.Cancel();
    const Generation = this.Generation;
    const Controller=new AbortController();this.Controller=Controller;
    try {
      const Value = await Load(Controller.signal);
      if (Generation === this.Generation) OnValue(Value);
    } catch (Error) {
      if (Generation === this.Generation) OnError(Error);
    } finally {
      if(this.Controller===Controller)this.Controller=null;
    }
  }
}

