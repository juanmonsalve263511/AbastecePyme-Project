import {BuildScenarioGraph} from './SupplyBoardModel.js';

export function GetSupplyGraph(Result,Version='Base',Focused=true,ShowingCycle=false){
  if(!Result)return null;
  if(!Focused)return Version==='Scenario'?BuildScenarioGraph(Result.Catalog,Result.Change):Result.Catalog;
  const {Impact,Production}=Result[Version];
  if(!ShowingCycle)return Impact.Graph;
  // Python supplies the closed cycle and its edges; this only chooses what to display.
  const CycleIds=new Set(Production.Cycle);
  return {Elements:Production.Graph.Elements.filter(Item=>CycleIds.has(Item.ElementId)),Relations:Production.CycleRelations};
}
