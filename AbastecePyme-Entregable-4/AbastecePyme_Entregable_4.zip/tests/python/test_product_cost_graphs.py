"""The selected sourcing option traces its complete recipe, not other offers."""
import copy
import unittest

from backend.ProductCosts import CalculateProductCosts
from test_product_costs import Element, Edge


class ProductCostGraphTests(unittest.TestCase):
    def Basic(self):
        Elements = [Element(Id, "Supplier") for Id in ("S1", "S2", "S3")]
        Elements += [Element(Id, "Material") for Id in ("M1", "M2")]
        Elements += [Element("PP", "Product")]
        Relations = [Edge("S1", "M1", "Offer", "10"), Edge("S2", "M1", "Offer", "20"),
                     Edge("S2", "M2", "Offer", "3"), Edge("S3", "M2", "Offer", "7"),
                     Edge("M1", "PP", "Requirement", "2"), Edge("M2", "PP", "Requirement", "1")]
        return Elements, Relations

    def Graph(self, Result, Kind):
        self.assertIn("SourcingGraphs", Result)
        return Result["SourcingGraphs"][Kind]

    def Edges(self, Graph):
        return {(Relation["SourceId"], Relation["TargetId"], Relation["RelationType"]) for Relation in Graph["Relations"]}

    def test_each_option_selects_exactly_one_offer_per_material_and_all_requirements(self):
        Elements, Relations = self.Basic()
        Result = CalculateProductCosts("PP", Elements, Relations)
        Minimum, Maximum = self.Graph(Result, "Minimum"), self.Graph(Result, "Maximum")
        self.assertEqual(Minimum["ElementIds"], ["M1", "M2", "PP", "S1", "S2"])
        self.assertEqual(Maximum["ElementIds"], ["M1", "M2", "PP", "S2", "S3"])
        Requirements = {("M1", "PP", "Requirement"), ("M2", "PP", "Requirement")}
        self.assertEqual(self.Edges(Minimum), Requirements | {("S1", "M1", "Offer"), ("S2", "M2", "Offer")})
        self.assertEqual(self.Edges(Maximum), Requirements | {("S2", "M1", "Offer"), ("S3", "M2", "Offer")})
        for Kind in ("Minimum", "Maximum"):
            Graph = self.Graph(Result, Kind)
            self.assertEqual(len(Graph["Relations"]), len(self.Edges(Graph)))
            for Material in Result["Materials"]:
                self.assertIn((Material[Kind]["SupplierId"], Material["MaterialId"], "Offer"), self.Edges(Graph))

    def test_shared_component_keeps_both_branches_without_duplicate_nodes_or_edges(self):
        Elements, Relations = self.Basic()
        Elements += [Element(Id, "Product") for Id in ("XX", "AA", "BB")]
        Relations += [Edge("M1", "XX", "Requirement", "0.5"), Edge("XX", "AA", "General"),
                      Edge("XX", "BB", "General"), Edge("AA", "PP", "General"), Edge("BB", "PP", "General")]
        Result = CalculateProductCosts("PP", Elements, Relations)
        Graph = self.Graph(Result, "Minimum")
        self.assertEqual(Graph["ElementIds"], ["AA", "BB", "M1", "M2", "PP", "S1", "S2", "XX"])
        self.assertEqual(len(Graph["Relations"]), 9)
        self.assertTrue({("XX", "AA", "General"), ("XX", "BB", "General"),
                         ("AA", "PP", "General"), ("BB", "PP", "General"),
                         ("M1", "XX", "Requirement")} <= self.Edges(Graph))
        self.assertEqual(Result["Materials"][0]["Quantity"], "3.0000")
        self.assertEqual(Result["MinimumCost"], "33.00")

    def test_tied_offers_and_input_order_give_the_same_deterministic_graph(self):
        Elements, Relations = self.Basic()
        Relations[1]["Value"] = "10"
        Relations[3]["Value"] = "3"
        Result = CalculateProductCosts("PP", Elements, Relations)
        Minimum, Maximum = self.Graph(Result, "Minimum"), self.Graph(Result, "Maximum")
        self.assertEqual(Minimum, Maximum)
        self.assertEqual(Result, CalculateProductCosts("PP", list(reversed(Elements)), list(reversed(Relations))))
        self.assertNotIn("S3", Minimum["ElementIds"])
        self.assertEqual(Minimum["Relations"], sorted(Minimum["Relations"], key=lambda Relation: (Relation["SourceId"], Relation["TargetId"])))

    def test_independent_products_offers_and_cycles_are_outside_selected_recipe(self):
        Elements, Relations = self.Basic()
        Elements += [Element("ZZ", "Product"), Element("M9", "Material"), Element("S9", "Supplier")]
        Relations += [Edge("S9", "M9", "Offer", "1"), Edge("M9", "ZZ", "Requirement", "1"), Edge("ZZ", "ZZ", "General")]
        Result = CalculateProductCosts("PP", Elements, Relations)
        self.assertTrue(Result["IsComplete"])
        for Kind in ("Minimum", "Maximum"):
            self.assertFalse({"ZZ", "M9", "S9"} & set(self.Graph(Result, Kind)["ElementIds"]))

    def test_focusing_a_component_excludes_consumers_and_their_materials(self):
        Elements, Relations = self.Basic()
        Elements.append(Element("CC", "Product"))
        Relations += [Edge("M1", "CC", "Requirement", "1"), Edge("CC", "PP", "General")]
        Parent = CalculateProductCosts("PP", Elements, Relations)
        Component = CalculateProductCosts("CC", Elements, Relations)
        self.assertIn("CC", self.Graph(Parent, "Minimum")["ElementIds"])
        Graph = self.Graph(Component, "Minimum")
        self.assertEqual(Graph["ElementIds"], ["CC", "M1", "S1"])
        self.assertEqual(self.Edges(Graph), {("S1", "M1", "Offer"), ("M1", "CC", "Requirement")})

    def test_missing_offer_empty_recipe_or_cycle_return_no_selectable_graph(self):
        Elements, Relations = self.Basic()
        Cases = [[], [Relation for Relation in Relations if Relation["TargetId"] != "M2"],
                 Relations + [Edge("PP", "PP", "General")]]
        for Edges in Cases:
            with self.subTest(Edges=Edges):
                Result = CalculateProductCosts("PP", Elements, Edges)
                self.assertFalse(Result["IsComplete"])
                for Kind in ("Minimum", "Maximum"):
                    self.assertEqual(self.Graph(Result, Kind), {"ElementIds": [], "Relations": []})

    def test_graphs_do_not_alias_each_other_or_mutate_catalogue_relations(self):
        Elements, Relations = self.Basic()
        Before = copy.deepcopy((Elements, Relations))
        Result = CalculateProductCosts("PP", Elements, Relations)
        Minimum, Maximum = self.Graph(Result, "Minimum"), self.Graph(Result, "Maximum")
        OtherBefore = copy.deepcopy(Maximum)
        Minimum["ElementIds"].append("UNRELATED")
        Minimum["Relations"][0]["SourceId"] = "CHANGED"
        self.assertEqual(Maximum, OtherBefore)
        self.assertEqual((Elements, Relations), Before)


if __name__ == "__main__":
    unittest.main()
