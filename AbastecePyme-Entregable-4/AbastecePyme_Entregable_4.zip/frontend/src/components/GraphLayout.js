export const GraphGeometry = Object.freeze({NodeWidth:248,NodeHeight:64,ColumnGap:320,RowGap:88,OriginX:48,OriginY:72});
const {NodeWidth,NodeHeight}=GraphGeometry;

export function BuildLayout(Elements, Relations, Focus, WholeGraph = false, IncludedIds = []) {
  let Visible = Elements;
  if (Focus && !WholeGraph) {
    const Ids = new Set([Focus]);
    Relations.forEach(Edge => { if (Edge.SourceId===Focus) Ids.add(Edge.TargetId); if(Edge.TargetId===Focus) Ids.add(Edge.SourceId); });
    Relations.forEach(Edge => { if (Edge.RelationType==='Offer' && Ids.has(Edge.TargetId)) Ids.add(Edge.SourceId); });
    IncludedIds.forEach(Id=>Ids.add(Id));
    Visible = Elements.filter(Item=>Ids.has(Item.ElementId));
  }
  const Groups = ['Supplier','Material','Product'].map(Type=>Visible.filter(Item=>Item.ElementType===Type));
  const Rank = new Map();
  Groups.forEach(Group=>Group.forEach((Item,Index)=>Rank.set(Item.ElementId,Index)));
  const Neighbors=new Map(Visible.map(Item=>[Item.ElementId,[]]));
  for(const Edge of Relations){
    if(!Rank.has(Edge.SourceId)||!Rank.has(Edge.TargetId))continue;
    Neighbors.get(Edge.SourceId).push(Edge.TargetId);
    if(Edge.SourceId!==Edge.TargetId)Neighbors.get(Edge.TargetId).push(Edge.SourceId);
  }
  for(let Pass=0;Pass<3;Pass++){
    Groups.forEach(Group=>{
      const Scores=new Map(Group.map(Item=>{
        const Linked=Neighbors.get(Item.ElementId);
        return [Item.ElementId,Linked.length?Linked.reduce((Sum,Id)=>Sum+Rank.get(Id),0)/Linked.length:Rank.get(Item.ElementId)];
      }));
      Group.sort((Left,Right)=>Scores.get(Left.ElementId)-Scores.get(Right.ElementId)||Left.Name.localeCompare(Right.Name));
      Group.forEach((Item,Index)=>Rank.set(Item.ElementId,Index));
    });
  }
  const Height=Math.max(1,...Groups.map(Group=>Group.length))*GraphGeometry.RowGap+112;
  const Nodes = Groups.flatMap((Group,Column)=>Group.map((Item,Index)=>({...Item,
    X:GraphGeometry.OriginX+Column*GraphGeometry.ColumnGap,
    Y:GraphGeometry.OriginY+Index*GraphGeometry.RowGap+(Height-112-Group.length*GraphGeometry.RowGap)/2})));
  const NodeLookup = new Map(Nodes.map(Item=>[Item.ElementId,Item]));
  const Edges=Relations.filter(Edge=>NodeLookup.has(Edge.SourceId)&&NodeLookup.has(Edge.TargetId));
  const Columns=Groups.flatMap((Group,Index)=>Group.length?[{X:GraphGeometry.OriginX+Index*GraphGeometry.ColumnGap,Label:['Proveedores','Insumos','Productos'][Index]}]:[]);
  const Layout={Nodes,Height,Edges,Map:NodeLookup,Columns};
  Layout.Bounds=GraphBounds(Layout);
  return Layout;
}

export function ApplyNodePositions(Layout,Positions){
  let HasManualPositions=false;
  const Nodes=Layout.Nodes.map(Node=>{
    const Position=Positions.get(Node.ElementId);
    if(!Number.isFinite(Position?.X)||!Number.isFinite(Position?.Y))return Node;
    HasManualPositions=true;
    return {...Node,X:Position.X,Y:Position.Y};
  });
  if(!HasManualPositions)return Layout;
  // Free positions do not imply that a node changed its type or dependencies.
  // Column labels would describe coordinates that no longer apply.
  const Result={...Layout,Nodes,Map:new Map(Nodes.map(Node=>[Node.ElementId,Node])),Columns:[]};
  Result.Bounds=GraphBounds(Result);
  return Object.values(Result.Bounds).every(Number.isFinite)?Result:Layout;
}

function EdgeCoordinates(From,To){
  if(From.ElementId===To.ElementId)return [From.X+NodeWidth-12,From.Y+10,From.X+NodeWidth+88,From.Y-36,From.X+NodeWidth+88,From.Y+NodeHeight+36,From.X+NodeWidth-12,From.Y+NodeHeight-10];
  if(From.X===To.X)return [From.X+NodeWidth,From.Y+NodeHeight/2,From.X+NodeWidth+96,From.Y+NodeHeight/2,To.X+NodeWidth+96,To.Y+NodeHeight/2,To.X+NodeWidth,To.Y+NodeHeight/2];
  const Forward=To.X>From.X,Start=From.X+(Forward?NodeWidth:0),End=To.X+(Forward?0:NodeWidth),Mid=(Start+End)/2;
  return [Start,From.Y+NodeHeight/2,Mid,From.Y+NodeHeight/2,Mid,To.Y+NodeHeight/2,End,To.Y+NodeHeight/2];
}

export function EdgePath(From,To){
  const [X1,Y1,X2,Y2,X3,Y3,X4,Y4]=EdgeCoordinates(From,To);
  return `M ${X1} ${Y1} C ${X2} ${Y2}, ${X3} ${Y3}, ${X4} ${Y4}`;
}

export function EdgeLabelPosition(From,To){
  return From.X===To.X?{X:From.X+NodeWidth+72,Y:(From.Y+To.Y)/2+NodeHeight/2}:{X:(From.X+To.X+NodeWidth)/2,Y:(From.Y+To.Y)/2+NodeHeight/2};
}

function GraphBounds(Layout){
  if(!Layout.Nodes.length)return {X:0,Y:0,Width:640,Height:400};
  let Left=Infinity,Top=Infinity,Right=-Infinity,Bottom=-Infinity;
  function Include(X,Y){Left=Math.min(Left,X);Top=Math.min(Top,Y);Right=Math.max(Right,X);Bottom=Math.max(Bottom,Y);}
  for(const Node of Layout.Nodes){Include(Node.X,Node.Y);Include(Node.X+NodeWidth,Node.Y+NodeHeight);}
  for(const Column of Layout.Columns){Include(Column.X,14);Include(Column.X+NodeWidth,40);}
  for(const Edge of Layout.Edges){
    const From=Layout.Map.get(Edge.SourceId),To=Layout.Map.get(Edge.TargetId),Coordinates=EdgeCoordinates(From,To);
    for(let Index=0;Index<Coordinates.length;Index+=2)Include(Coordinates[Index],Coordinates[Index+1]);
    if(Edge.Value!=null){const Label=EdgeLabelPosition(From,To);Include(Label.X-72,Label.Y-15);Include(Label.X+72,Label.Y+15);}
  }
  return {X:Left-28,Y:Top-28,Width:Right-Left+56,Height:Bottom-Top+56};
}

function ViewportSize(Viewport={}){return {Width:Viewport.Width>0?Viewport.Width:800,Height:Viewport.Height>0?Viewport.Height:520};}

export function FitGraphView(Layout,Viewport){
  const Size=ViewportSize(Viewport),Bounds=Layout.Bounds;
  // Match the rendered SVG aspect ratio; include curved edges, labels and headers.
  const UnitsPerPixel=Math.max(Bounds.Width/Size.Width,Bounds.Height/Size.Height,1/1.15);
  const Width=Size.Width*UnitsPerPixel,Height=Size.Height*UnitsPerPixel;
  return {X:Bounds.X+(Bounds.Width-Width)/2,Y:Bounds.Y+(Bounds.Height-Height)/2,Width,Height};
}

export function ReadableGraphView(Layout,Viewport,SelectedId){
  const Size=ViewportSize(Viewport),Node=Layout.Map.get(SelectedId)||Layout.Nodes[0];
  if(!Node)return FitGraphView(Layout,Size);
  const UnitsPerPixel=Math.max(1,(NodeWidth+40)/Size.Width,(NodeHeight+40)/Size.Height);
  const Width=Size.Width*UnitsPerPixel,Height=Size.Height*UnitsPerPixel;
  return {X:Node.X+(NodeWidth-Width)/2,Y:Node.Y+(NodeHeight-Height)/2,Width,Height};
}

export function InitialGraphView(Layout,Viewport,SelectedId){
  const Size=ViewportSize(Viewport),Fit=FitGraphView(Layout,Size);
  return Size.Width/Fit.Width>=.78?Fit:ReadableGraphView(Layout,Size,SelectedId);
}

export function ZoomGraphView(View,Factor,Center,MaximumWidth=8000){
  const Width=Math.max(160,Math.min(MaximumWidth,View.Width*Factor)),Ratio=Width/View.Width;
  const Pivot=Center||{x:View.X+View.Width/2,y:View.Y+View.Height/2};
  return {X:Pivot.x+(View.X-Pivot.x)*Ratio,Y:Pivot.y+(View.Y-Pivot.y)*Ratio,Width,Height:View.Height*Ratio};
}

export function RevealGraphNode(View,Node){
  if(!Node)return View;
  const Padding=18,Ratio=Math.max(1,(NodeWidth+Padding*2)/View.Width,(NodeHeight+Padding*2)/View.Height);
  const Width=View.Width*Ratio,Height=View.Height*Ratio;
  const X=Math.min(Node.X-Padding,Math.max(View.X,Node.X+NodeWidth+Padding-Width));
  const Y=Math.min(Node.Y-Padding,Math.max(View.Y,Node.Y+NodeHeight+Padding-Height));
  return X===View.X&&Y===View.Y&&Ratio===1?View:{X,Y,Width,Height};
}

export function PanView(View, Fallback, DeltaX, DeltaY) {
  const Current=View||Fallback;
  return {...Current,X:Current.X-DeltaX,Y:Current.Y-DeltaY};
}

export function PathEdgeKeys(Path, Direction) {
  return new Set(Path.slice(1).map((Target,Index)=>Direction==='Requirements'?Target+'>'+Path[Index]:Path[Index]+'>'+Target));
}
