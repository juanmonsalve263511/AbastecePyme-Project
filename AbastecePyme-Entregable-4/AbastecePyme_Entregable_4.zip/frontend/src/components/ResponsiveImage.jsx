const Widths=[640,960,1536];

export default function ResponsiveImage({Name,Alt,Sizes='(max-width: 760px) 88vw, (max-width: 1400px) 48vw, 650px'}){
  return <img src={'/images/'+Name+'-960.webp'} srcSet={Widths.map(Width=>'/images/'+Name+'-'+Width+'.webp '+Width+'w').join(', ')} sizes={Sizes} width="1536" height="1024" loading="lazy" decoding="async" alt={Alt}/>;
}
