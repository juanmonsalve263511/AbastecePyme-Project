import ResponsiveImage from './ResponsiveImage.jsx';
import {useRef,useState} from 'react';
import {Api} from '../Api.js';
import {Field,Notice,Icon} from './Common.jsx';
import LocationCard from './LocationCard.jsx';
import Reveal from './Reveal.jsx';

const EmptyValues={FullName:'',Email:'',Phone:'',Company:'',Subject:'',Message:'',Consent:false};
export default function ContactForm(){
  const [Values,SetValues]=useState(EmptyValues);
  const [Busy,SetBusy]=useState(false);
  const [Error,SetError]=useState('');
  const [Receipt,SetReceipt]=useState(null);
  const ReceiptRef=useRef(null);
  const ContactReady=Values.FullName.trim().length>=2&&/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(Values.Email.trim());
  const RequestReady=Values.Subject!==''&&Values.Message.trim().length>=20;
  const Steps=[ContactReady,RequestReady,Values.Consent];
  function Change(Event){const {name:Name,value:Value,type:Type,checked:Checked}=Event.target;SetValues(Current=>({...Current,[Name]:Type==='checkbox'?Checked:Value}));}
  async function Submit(Event){
    Event.preventDefault();if(Busy)return;
    SetBusy(true);SetError('');
    try{
      const Result=await Api('/api/contact-requests',{method:'POST',body:Values});
      SetReceipt(Result);SetValues(EmptyValues);
      requestAnimationFrame(()=>ReceiptRef.current?.focus());
    }catch(Failure){SetError(Failure.message);}finally{SetBusy(false);}
  }
  return <div className="contact-layout"><Reveal ClassName="contact-aside"><LocationCard/><div className="contact-photo"><ResponsiveImage Name="workshop" Alt="Trabajo de precisión en un taller de mobiliario" Sizes="(max-width: 760px) 1px, (max-width: 1400px) 36vw, 490px"/><p>Las buenas ideas empiezan<br/>con una conversación.</p></div></Reveal><Reveal ClassName="contact-form-wrap">
    {Receipt?<section className="contact-receipt surface" ref={ReceiptRef} tabIndex={-1} aria-labelledby="ContactReceiptTitle"><span className="receipt-check" aria-hidden="true">✓</span><p className="section-note">Conexión recibida</p><h2 id="ContactReceiptTitle">Gracias por escribirnos.</h2><p>{Receipt.Detail}</p><p className="quiet">El equipo administrador puede consultar tu mensaje y los datos que compartiste.</p><p className="receipt-reference">Referencia: <code>{Receipt.RequestId}</code></p><button type="button" onClick={()=>SetReceipt(null)}>Enviar otra solicitud <Icon Name="arrow"/></button></section>:
    <form className="contact-form surface" onSubmit={Submit} aria-busy={Busy}><header><p className="section-note">Hablemos de tu próxima idea</p><h2>¿Cómo podemos ayudarte?</h2><p>Déjanos tus datos y cuéntanos qué necesitas.</p></header>
      <ol className="contact-progress" aria-label="Avance del formulario">{['Tus datos','Tu solicitud','Autorización'].map((Label,Index)=><li key={Label} className={Steps[Index]?'complete':''}><span aria-hidden="true">{Steps[Index]?'✓':Index+1}</span>{Label}<span className="visually-hidden">: {Steps[Index]?'completo':'pendiente'}</span></li>)}</ol>
      <Notice Text={Error} Error/>
      <fieldset disabled={Busy}><legend className="visually-hidden">Datos de tu solicitud</legend><div className="contact-fields">
        <Field Label="Nombre completo *"><input name="FullName" value={Values.FullName} onChange={Change} autoComplete="name" required minLength={2} maxLength={80} placeholder="¿Cómo te llamas?"/></Field>
        <Field Label="Correo electrónico *"><input type="email" name="Email" value={Values.Email} onChange={Change} autoComplete="email" required maxLength={254} placeholder="tu@empresa.com"/></Field>
        <Field Label="Celular (opcional)"><input type="tel" name="Phone" value={Values.Phone} onChange={Change} autoComplete="tel" maxLength={25} placeholder="Tu número de contacto"/></Field>
        <Field Label="Empresa (opcional)"><input name="Company" value={Values.Company} onChange={Change} autoComplete="organization" maxLength={100} placeholder="El nombre de tu negocio"/></Field>
      </div><Field Label="¿Sobre qué quieres conversar? *"><select name="Subject" value={Values.Subject} onChange={Change} required><option value="">Selecciona un tema</option><option>Organizar mi producción</option><option>Proveedores y abastecimiento</option><option>Accesos y soporte</option><option>Alianzas y otras consultas</option></select></Field>
      <Field Label="Tu solicitud *"><textarea name="Message" value={Values.Message} onChange={Change} required minLength={20} maxLength={2000} rows={5} placeholder="Cuéntanos un poco sobre tu necesidad…" aria-describedby="ContactMessageHint"/></Field><div id="ContactMessageHint" className="message-count"><span>Entre 20 y 2.000 caracteres.</span><span>{Values.Message.length}/2.000</span></div>
      <label className="checkbox consent"><input type="checkbox" name="Consent" checked={Values.Consent} onChange={Change} required/><span>Autorizo guardar mis datos y mi solicitud para que el equipo pueda atenderme, según los <a href="#terms" target="_blank" rel="noopener noreferrer">términos y condiciones<span className="visually-hidden"> (abre otra pestaña)</span></a>.</span></label>
      <button className="primary contact-submit" disabled={Busy}>{Busy?'Guardando solicitud…':'Enviar solicitud'}<Icon Name="arrow"/></button><p className="quiet contact-form-note">* Campos obligatorios. Tu mensaje se recibe en la bandeja privada del equipo.</p></fieldset>
    </form>}
  </Reveal></div>;
}
