# Catalog prices and professional copy implementation plan

**Goal:** Apply the user's requested copy changes, expand supplier alternatives and production dependencies, and expose editable product sale prices.
**Architecture:** Keep React + FastAPI + MariaDB. Add a one-to-one ProductPrices table without altering existing rows or seed bytes. Preserve IsDemo API compatibility while presenting reference values professionally.
**Spec:** User request of 2026-11-02 and its three reference screenshots.
**Execution:** Continue the authorized implementation in this session; no new architecture or design approval is needed.

- [x] Read the live catalogue and save a catalogue-only snapshot before modifications.
- [x] Add price validation and API persistence tests: decimal precision, null versus omitted, product-only prices, version conflicts, deletion, role enforcement.
- [x] Implement ProductPrices, SalePrice and IsPriceReference fields through the existing catalogue API and UI.
- [x] Replace academic/demo UI wording with brand and reference-value copy. Preserve accurate limitations and avoid invented operational offices or contact channels.
- [x] Add repeatable explicit catalogue enrichment with additional suppliers (at least two per material), meaningful intermediate products and general edges, and synthetic reference sale prices. Preserve all existing data and verify acyclicity before commit.
- [x] Run Python/Node and MariaDB integration checks, build React, restart only the owned current server, and inspect the app.
- [x] Update documentation and the source package for sharing.

**Review focus:** exact decimal strings; clear-price semantics; no price on materials/suppliers; idempotent enrichment that preserves subsequent edits; no newly introduced production cycle; old server processes must load the updated API before serving the rebuilt UI.

## Execution evidence

100 automated tests passed (48 Python, 37 Node, 15 MariaDB); one last-admin integration case intentionally skipped. Live HTTP authentication and catalogue/production reads passed on port 3001; viewer price writes rejected with 403. Isolated browser price editing and relation labels verified. Independent review found no blocking defect; general-dependency helper copy clarified. Existing data preserved; repeated expansion was a no-op. Source and catalogue snapshots remain under work/ and are excluded from sharing.
