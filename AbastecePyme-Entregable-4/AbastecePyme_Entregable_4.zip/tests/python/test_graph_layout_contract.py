"""Layout validation and transaction failures without a network event loop."""
from contextlib import contextmanager
import json
import unittest
from fastapi import Request
from fastapi.exceptions import RequestValidationError
from pydantic import ValidationError
from backend.GraphLayouts import ReadLayout, SaveLayout
from backend.Main import CreateApp
from backend.Models import GraphLayoutBody
from tests.fixtures.SupplyBoardPreview import PreviewDatabase


class GraphLayoutContractTests(unittest.TestCase):
    def test_normalizes_order_without_mutating_input_or_requiring_catalogue_membership(self):
        Positions = [{"ElementId": "ZZ-HIDDEN", "X": 1_000_000, "Y": -1_000_000},
                     {"ElementId": "AA", "X": -42.125, "Y": 0}]
        Before = json.dumps(Positions)
        Result = GraphLayoutBody(Positions=Positions).model_dump()
        self.assertEqual(Result, {"Positions": [Positions[1], Positions[0]]})
        self.assertEqual(json.dumps(Positions), Before)
        self.assertEqual(GraphLayoutBody(Positions=[]).model_dump(), {"Positions": []})

    def test_rejects_coercion_nonfinite_coordinates_unknown_fields_and_duplicate_ids(self):
        Position = {"ElementId": "AA", "X": 1, "Y": 2}
        for Value in (True, False, "1", None, float("nan"), float("inf"), -float("inf"), 1_000_000.01, -1_000_000.01):
            for Axis in ("X", "Y"):
                with self.subTest(Value=Value, Axis=Axis), self.assertRaises(ValidationError):
                    GraphLayoutBody(Positions=[{**Position, Axis: Value}])
        for Body in ({"Positions": [Position, Position]}, {"Positions": [Position], "UserId": "other"},
                     {"Positions": [{**Position, "Label": "extra"}]}, {"Positions": (Position,)},
                     {"Positions": [{**Position, "ElementId": "lowercase"}]}):
            with self.subTest(Body=Body), self.assertRaises(ValidationError):
                GraphLayoutBody.model_validate(Body)

    def test_accepts_1000_positions_and_returns_a_clear_api_error_above_the_limit(self):
        Positions = [{"ElementId": f"NODE-{Index:04d}", "X": 0, "Y": 0} for Index in range(1001)]
        self.assertEqual(len(GraphLayoutBody(Positions=Positions[:1000]).Positions), 1000)
        with self.assertRaises(ValidationError) as Failure:
            GraphLayoutBody(Positions=Positions)
        RequestValue = Request({"type": "http", "method": "PUT", "path": "/api/account/graph-layouts/Graph",
                                "scheme": "http", "query_string": b"", "headers": []})
        Handler = CreateApp(None).exception_handlers[RequestValidationError]
        Task = Handler(RequestValue, RequestValidationError(Failure.exception.errors()))
        try:
            with self.assertRaises(StopIteration) as Finished:
                Task.send(None)
        finally:
            Task.close()
        Response = Finished.exception.value
        self.assertEqual(Response.status_code, 422)
        self.assertIn("1000", json.loads(Response.body)["Detail"])

    def test_failed_transaction_preserves_the_previous_layout(self):
        Database = PreviewDatabase()
        self.addCleanup(Database.Close)
        with Database.Transaction() as Connection:
            Connection.execute("INSERT INTO Users(UserId,Username) VALUES (?,?)", "owner", "owner")
        Before = GraphLayoutBody(Positions=[{"ElementId": "AA", "X": 1, "Y": 2}])
        After = GraphLayoutBody(Positions=[{"ElementId": "BB", "X": 3, "Y": 4}])
        SaveLayout(Database, "owner", "Graph", Before)

        class FailingTransaction:
            @contextmanager
            def Transaction(self):
                with Database.Transaction() as Connection:
                    yield Connection
                    raise OSError("Synthetic failure before commit")

        with self.assertRaises(OSError):
            SaveLayout(FailingTransaction(), "owner", "Graph", After)
        self.assertEqual(ReadLayout(Database, "owner", "Graph"), Before.model_dump())
        self.assertEqual(ReadLayout(Database, "owner", "Impact"), {"Positions": []})
