import test from 'node:test';
import assert from 'node:assert/strict';
import { LatestRequest } from '../frontend/src/LatestRequest.js';
test('late product response cannot replace the latest product estimate',async()=>{
 const Gate=new LatestRequest();let ResolveA,ResolveB;const Results=[];
 const A=Gate.Run(()=>new Promise(Resolve=>{ResolveA=Resolve;}),Value=>Results.push(Value),()=>{});
 Gate.Cancel();
 const B=Gate.Run(()=>new Promise(Resolve=>{ResolveB=Resolve;}),Value=>Results.push(Value),()=>{});
 ResolveB('estimate B');await B;ResolveA('estimate A');await A;
 assert.deepEqual(Results,['estimate B']);
});
test('closing a modal ignores late errors, active errors are displayed',async()=>{
 const Gate=new LatestRequest();let Reject;const Errors=[];
 const A=Gate.Run(()=>new Promise((Resolve,Fail)=>{Reject=Fail;}),()=>{},Error=>Errors.push(Error.message));
 Gate.Cancel();Reject(new Error('old'));await A;
 assert.deepEqual(Errors,[]);
 await Gate.Run(()=>Promise.reject(new Error('unavailable')),()=>{},Error=>Errors.push(Error.message));
 assert.deepEqual(Errors,['unavailable']);
});

test('replacing a read aborts its transport and only publishes the current result',async()=>{
 const Gate=new LatestRequest();const Results=[];const Signals=[];
 let CompleteFirst;
 const First=Gate.Run(Signal=>{Signals.push(Signal);return new Promise(Resolve=>{CompleteFirst=Resolve;});},Value=>Results.push(Value),()=>{});
 await Gate.Run(Signal=>{Signals.push(Signal);return Promise.resolve('new catalogue');},Value=>Results.push(Value),()=>{});
 assert.equal(Signals[0]?.aborted,true);
 assert.equal(Signals[1]?.aborted,false);
 CompleteFirst('old catalogue');await First;
 assert.deepEqual(Results,['new catalogue']);
});

test('canceling a catalogue load prevents late data and abort errors after sign-out',async()=>{
 const Gate=new LatestRequest();const Results=[];let Signal,Reject;
 const Pending=Gate.Run(Value=>{Signal=Value;return new Promise((Resolve,Fail)=>{Reject=Fail;});},Value=>Results.push(Value),Failure=>Results.push(Failure));
 Gate.Cancel();
 assert.equal(Signal?.aborted,true);
 Reject(new DOMException('Canceled','AbortError'));await Pending;
 assert.deepEqual(Results,[]);
});
