import test from 'node:test';
import assert from 'node:assert/strict';
import {BuildSupplyRequest,BuildScenarioGraph,IsGeneralDependency} from '../frontend/src/components/SupplyBoardModel.js';

const Catalog=Object.freeze({
  Elements:Object.freeze([
    {ElementId:'SUP-A',Name:'Supplier A',ElementType:'Supplier'},
    {ElementId:'MAT-A',Name:'Material A',ElementType:'Material'},
    {ElementId:'PROD-A',Name:'Product A',ElementType:'Product'},
    {ElementId:'PROD-B',Name:'Product B',ElementType:'Product'}
  ].map(Object.freeze)),
  Relations:Object.freeze([
    {SourceId:'SUP-A',TargetId:'MAT-A',RelationType:'Offer',Value:'20.00',IsDemo:true,Version:2},
    {SourceId:'MAT-A',TargetId:'PROD-A',RelationType:'Requirement',Value:'2.0000',IsDemo:false,Version:3},
    {SourceId:'PROD-A',TargetId:'PROD-B',RelationType:'General',Value:null,IsDemo:false,Version:4}
  ].map(Object.freeze))
});
const Selection={ElementId:'SUP-A',ProductId:'',Operation:'None',SourceId:'',TargetId:''};

test('the unmodified analysis sends an explicit optional scope and no catalogue data',()=>{
  assert.deepEqual(BuildSupplyRequest(Selection,Catalog),{ElementId:'SUP-A',ProductId:null,Change:null});
  assert.deepEqual(BuildSupplyRequest({...Selection,ElementId:'MAT-A',ProductId:'PROD-B'},Catalog),{ElementId:'MAT-A',ProductId:'PROD-B',Change:null});
});

test('availability simulations reject missing or product origins and non-product scopes',()=>{
  for(const ElementId of ['', 'UNKNOWN', 'PROD-A'])assert.throws(()=>BuildSupplyRequest({...Selection,ElementId},Catalog));
  for(const ProductId of ['UNKNOWN','MAT-A'])assert.throws(()=>BuildSupplyRequest({...Selection,ProductId},Catalog));
});

test('adding a temporary general dependency permits a cycle without creating a persistent edit',()=>{
  assert.deepEqual(BuildSupplyRequest({...Selection,Operation:'Add',SourceId:'PROD-B',TargetId:'PROD-A'},Catalog),{
    ElementId:'SUP-A',ProductId:null,Change:{Operation:'Add',SourceId:'PROD-B',TargetId:'PROD-A'}
  });
  assert.deepEqual(BuildSupplyRequest({...Selection,Operation:'Add',SourceId:'PROD-A',TargetId:'PROD-A'},Catalog).Change,{
    Operation:'Add',SourceId:'PROD-A',TargetId:'PROD-A'
  });
});

test('the scenario form rejects unknown endpoints, duplicate edges and weighted additions',()=>{
  for(const [SourceId,TargetId] of [['UNKNOWN','PROD-A'],['PROD-A','UNKNOWN'],['PROD-A','PROD-B'],['SUP-A','MAT-A'],['MAT-A','PROD-B']]){
    assert.throws(()=>BuildSupplyRequest({...Selection,Operation:'Add',SourceId,TargetId},Catalog));
  }
  assert.equal(IsGeneralDependency(Catalog.Elements[0],Catalog.Elements[1]),false);
  assert.equal(IsGeneralDependency(Catalog.Elements[1],Catalog.Elements[2]),false);
  assert.equal(IsGeneralDependency(Catalog.Elements[2],Catalog.Elements[1]),true);
  assert.throws(()=>BuildSupplyRequest({...Selection,Operation:'Patch'},Catalog));
});

test('a removal accepts an existing weighted relation and requires its stored direction',()=>{
  assert.deepEqual(BuildSupplyRequest({...Selection,Operation:'Remove',SourceId:'SUP-A',TargetId:'MAT-A'},Catalog).Change,{
    Operation:'Remove',SourceId:'SUP-A',TargetId:'MAT-A'
  });
  assert.throws(()=>BuildSupplyRequest({...Selection,Operation:'Remove',SourceId:'MAT-A',TargetId:'SUP-A'},Catalog));
});

test('the scenario graph keeps every element and original edge weight without mutating the catalogue',()=>{
  const Change={Operation:'Add',SourceId:'PROD-B',TargetId:'PROD-A'};
  const Graph=BuildScenarioGraph(Catalog,Change);
  assert.equal(Graph.Elements.length,4);
  assert.equal(Graph.Relations.length,4);
  assert.deepEqual(Graph.Relations.at(-1),{SourceId:'PROD-B',TargetId:'PROD-A',RelationType:'General',Value:null,IsDemo:false,Version:null,IsSimulation:true});
  assert.equal(Graph.Relations[0].Value,'20.00');
  assert.equal(Catalog.Relations.length,3);
  assert.equal(BuildScenarioGraph(Catalog,null),Catalog);
});

test('removing an offer from the rendered scenario never removes its endpoints or unrelated dependencies',()=>{
  const Graph=BuildScenarioGraph(Catalog,{Operation:'Remove',SourceId:'SUP-A',TargetId:'MAT-A'});
  assert.deepEqual(Graph.Elements.map(Item=>Item.ElementId),['SUP-A','MAT-A','PROD-A','PROD-B']);
  assert.deepEqual(Graph.Relations.map(Edge=>[Edge.SourceId,Edge.TargetId]),[['MAT-A','PROD-A'],['PROD-A','PROD-B']]);
  assert.equal(Catalog.Relations.length,3);
});
