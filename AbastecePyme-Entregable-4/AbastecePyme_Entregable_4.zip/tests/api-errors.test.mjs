import test from 'node:test';
import assert from 'node:assert/strict';
import {Api,SetSession} from '../frontend/src/Api.js';

test('a missing endpoint explains how to reload the server instead of hiding its 404',async Context=>{
  Context.mock.method(globalThis,'fetch',async()=>new Response(JSON.stringify({detail:'Not Found'}),{status:404}));
  await assert.rejects(Api('/api/production?ProductId=PROD-ESTANTE'),Failure=>{
    assert.equal(Failure.Status,404);
    assert.match(Failure.message,/404/);
    assert.match(Failure.message,/Iniciar\.cmd/);
    return true;
  });
});

test('a missing product retains its specific message instead of suggesting a server restart',async Context=>{
  Context.mock.method(globalThis,'fetch',async()=>new Response(JSON.stringify({Detail:'Producto no encontrado. Actualiza el catálogo.'}),{status:404}));
  await assert.rejects(Api('/api/production?ProductId=DELETED'),{
    Status:404,message:'Producto no encontrado. Actualiza el catálogo.'
  });
});

test('standard lowercase detail errors retain the reason returned by the server',async Context=>{
  Context.mock.method(globalThis,'fetch',async()=>new Response(JSON.stringify({detail:'Acceso denegado.'}),{status:403}));
  await assert.rejects(Api('/api/production'),{Status:403,message:'Acceso denegado.'});
});

test('successful production responses preserve the plan and optional status metadata',async Context=>{
  Context.mock.method(globalThis,'fetch',async()=>new Response(JSON.stringify({Status:'Ready',Order:['AA','BB']}),{status:200}));
  assert.deepEqual(await Api('/api/production',{ReturnMeta:true}),{
    Data:{Status:'Ready',Order:['AA','BB']},Status:200
  });
});

test('non-JSON server failures retain their HTTP status and a useful message',async Context=>{
  Context.mock.method(globalThis,'fetch',async()=>new Response('<html>Service unavailable</html>',{status:503}));
  await assert.rejects(Api('/api/catalog'),Failure=>Failure.Status===503&&Failure.message.includes('503'));
});

test('empty successful responses are accepted without a JSON parsing failure',async Context=>{
  Context.mock.method(globalThis,'fetch',async()=>new Response(null,{status:204}));
  assert.deepEqual(await Api('/api/elements/AA?Version=1',{method:'DELETE',ReturnMeta:true}),{Data:null,Status:204});
});

test('malformed successful JSON produces an actionable response error',async Context=>{
  Context.mock.method(globalThis,'fetch',async()=>new Response('<html>Wrong server</html>',{status:200}));
  await assert.rejects(Api('/api/catalog'),Failure=>Failure.Status===200&&/respuesta.*válida/i.test(Failure.message));
});

test('a late unauthorized response from an old session cannot expire the new session',async Context=>{
  const Events=[];let Resolve;
  Context.mock.method(globalThis,'fetch',()=>new Promise(Complete=>{Resolve=Complete;}));
  const PreviousWindow=globalThis.window;globalThis.window={dispatchEvent:Event=>Events.push(Event.type)};
  Context.after(()=>{globalThis.window=PreviousWindow;SetSession(null);});
  SetSession({CsrfToken:'old-session'});
  const Pending=Api('/api/catalog');
  SetSession({CsrfToken:'new-session'});
  Resolve(new Response(JSON.stringify({Detail:'Sesión vencida.'}),{status:401}));
  await assert.rejects(Pending,{Status:401});
  assert.deepEqual(Events,[]);
});

test('an HTML unauthorized response still expires the current session',async Context=>{
  const Events=[];
  const PreviousWindow=globalThis.window;globalThis.window={dispatchEvent:Event=>Events.push(Event.type)};
  Context.after(()=>{globalThis.window=PreviousWindow;SetSession(null);});
  SetSession({CsrfToken:'current-session'});
  Context.mock.method(globalThis,'fetch',async()=>new Response('<html>Unauthorized</html>',{status:401}));
  await assert.rejects(Api('/api/catalog'),{Status:401});
  assert.deepEqual(Events,['session-expired']);
});

test('network failure explains connection loss and cancellation stays silent for callers',async Context=>{
  Context.mock.method(globalThis,'fetch',async()=>{throw new TypeError('Failed to fetch');});
  await assert.rejects(Api('/api/catalog'),/conectar/i);
  Context.mock.method(globalThis,'fetch',async()=>{throw new DOMException('Canceled','AbortError');});
  await assert.rejects(Api('/api/catalog'),{name:'AbortError'});
});
