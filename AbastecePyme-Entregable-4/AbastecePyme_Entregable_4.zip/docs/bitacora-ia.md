# Ampliación de catálogo y presentación — 2026-11-02

Se aplicaron textos de marca profesionales y etiquetas de referencia en lugar de demostración. Se añadió ProductPrices con importes exactos, validación, control de versiones y edición por catálogo/API. La ampliación autorizada agregó 5 proveedores, 3 componentes, 21 ofertas, 7 requisitos y 8 dependencias generales: 48 elementos y 128 relaciones, sin ciclos. Todos los insumos tienen al menos dos proveedores y los 17 productos tienen precio. Los datos anteriores se conservaron y la repetición no duplica ni sobrescribe registros. Respaldo de catálogo y fuentes en work/, excluido del paquete público. Ver docs/CATALOG_UPDATE_2026.md para uso, contrato y pruebas.

# Bitácora de asistencia de IA — Feature 1

Fecha: 6 de octubre de 2026. Herramienta: Codex. Alcance: análisis y construcción de la primera entrega del caso AbastecePyme.

## Solicitudes del usuario

1. Analizar el brief completo desde la aplicación práctica de teoría de grafos, considerando entregas parciales.
2. Inicialmente limitarse al análisis y al plan para el Feature 1.
3. Tras revisar el plan, proceder con su ejecución.

## Trabajo realizado con asistencia

- Lectura del brief proporcionado por el usuario.
- Propuesta de dirección requisito → dependiente y listas de adyacencia.
- Implementación de catálogo, API HTTP, persistencia local, interfaz SVG y datos sintéticos.
- Elaboración y ejecución de 21 pruebas automáticas de dominio, persistencia y API.
- Verificación de interacciones reales en el navegador y revisión del estado vacío y de diferentes tamaños de pantalla.
- Preparación de README, trazabilidad de requisitos, casos de aceptación y paquete de entrega.

## Decisiones y límites declarados

Se eligió Node.js sin dependencias externas. Los datos se conservan en un archivo JSON local, con un solo proceso por archivo. Se normalizan ID a mayúsculas. Se admiten ciclos y autorrelaciones para su tratamiento en el Feature 3. No se implementaron recorridos de impacto ni ordenamiento topológico.

La IA produjo el código y los documentos iniciales y ejecutó las comprobaciones registradas. No se atribuye al estudiante una revisión o una ejecución que no haya realizado. No se consultaron fuentes externas para definir requisitos: se trabajó con el brief entregado y las decisiones explícitas del plan.

## Por completar por el equipo antes de entregar

- Integrantes y responsabilidades.
- Revisión personal del código y comprensión del modelo.
- Cambios propios sobre esta versión y su justificación.
- Resultados de la ejecución en el equipo del estudiante.
- Declaración de uso de IA conforme a las reglas del curso.

Esta bitácora se incluye como base para mantener trazabilidad desde la primera entrega; la documentación integral de IA se solicita expresamente en el Feature 4.

## Ampliación solicitada del catálogo

A petición del usuario se añadieron doce productos acordes con un fabricante de muebles, cinco proveedores, doce insumos y 83 relaciones. Se preservaron los registros existentes, incluido «Metro 20 M», y se actualizó el ejemplo distribuible. Se verificaron integridad del grafo, persistencia y consulta en la interfaz. Los nombres de proveedores y las dependencias constituyen un escenario sintético para el taller.


## 2 de noviembre de 2026 — Feature 3 y acceso administrado

Se leyó la guía completa y se implementaron Kahn y DFS iterativos propios en Python. La dirección requisito → dependiente se conservó. Las pruebas se escribieron antes del código: inicialmente fallaron por funciones/rutas ausentes y luego pasaron. Se eliminó el registro público y se añadió creación de cuentas por administradores. Se amplió el explorador API con mutaciones revisables y se renovaron portada, subpáginas, preferencias y suscripción local.

La conexión SQL funcionaba, pero SHOW GRANTS no incluía UPDATE; el usuario volvió a concederlo y se verificó antes de las pruebas reales. Se agregó solo la tabla de suscripciones. No se intervinieron las tablas del sistema ni gym_admin_management.

Validación: 40 pruebas Python y 33 JavaScript; 15 pruebas MariaDB aprobadas y 1 omitida para proteger la cuenta administradora permanente. Revisión independiente sin hallazgos accionables. Los casos de navegador con cambios usaron una base temporal en memoria. Referencias y skills en GUIA_ACTUALIZACION_2026.md; detalle de aceptación en FEATURE3.md.
# Corrección de acceso a Orden de producción — 2026-11-02

- Incidente: la interfaz mostraba «No se pudo completar la solicitud» al consultar Estante modular.
- Evidencia: GET /api/production en el puerto 3000 devolvía 404 con `detail: Not Found`; en 3001 devolvía 401 sin sesión, por lo que la ruta sí estaba registrada. La instancia anterior seguía ejecutando rutas antiguas.
- Corrección operativa: acceso local Abrir.url dirigido a 3001. El usuario inició sesión allí y confirmó que el orden se muestra. La instancia antigua de 3000 no fue detenida desde esta sesión.
- Corrección del cliente: reconoce Detail y detail, explica el reinicio necesario cuando falta una ruta y conserva los mensajes de productos inexistentes.
- Validación de cálculo: lectura del catálogo real y pruebas de rutas en un cliente aislado, con identidad de prueba, para los 14 productos y toda la red. Estante modular devuelve 7 elementos, 6 relaciones y 3 etapas. Esa comprobación aislada no prueba autenticación HTTP real; el funcionamiento en el navegador fue confirmado por el usuario.
- No se modificaron registros ni permisos de MariaDB. Se añadieron cuatro pruebas de respuesta del cliente; dos reproducían el error antes de la corrección.

## 14 de noviembre de 2026 — Feature 4 y entrega demostrable

### Solicitud y alcance autorizado

Se revisó el brief completo, con atención a Feature 4: integrar catálogo, impacto y orden o ciclo; destacar la consulta en la red; adaptar un cambio de requisitos; aceptar cadena válida, elemento inexistente, dato inválido y ciclo; entregar documentación, bitácora, video y pitch. El usuario aprobó continuar con el alcance propuesto.

El cambio acordado permite **comparar una dependencia añadida o retirada temporalmente**, sin convertir esa hipótesis en una edición guardada. Se conserva la dirección requisito → dependiente y el comportamiento de las funciones anteriores.

### Decisiones y trabajo asistido

- Se definió un análisis del tablero que lee el catálogo una vez y calcula la red base y el escenario sobre una copia. Se reutilizan los algoritmos propios de impacto y producción.
- Se mantuvo el elemento de la indisponibilidad simulada dentro del grafo. Eliminarlo podía hacer parecer viable una producción que todavía lo necesita.
- La comparación admite añadir dependencias generales sin peso y retirar relaciones existentes. Las altas proveedor → insumo e insumo → producto se rechazan porque requieren precio o cantidad; no se inventan esos valores.
- Se separaron los permisos: todos los perfiles pueden analizar; solo Editor y Administrador mantienen su capacidad de modificar el catálogo real.
- Se definieron respuestas distintas para ausencia de un elemento, dato inválido y contradicción cíclica. Un ciclo es un análisis correcto con contradicción, no un fallo interno del servidor.
- Se preparó una instancia de demostración que usa la API y la autenticación de la aplicación contra SQLite en memoria. No usa MariaDB ni sustituye el inicio de sesión por una identidad impuesta.
- Se preparó la aceptación del recorrido completo: registrar una dependencia, consultar impacto y orden, rechazar entradas incorrectas y comparar cambios sin persistirlos. La comprobación inicial detectó la ruta nueva ausente; ese fallo inicial no se presenta como resultado final.
- Se redactaron el documento de Feature 4, la guía actualizada, la matriz de requisitos, el guion de tres minutos y el pitch terminado de 60–90 segundos. Se actualizaron los enlaces y el contrato del README.

La IA asistió en el análisis, implementación, pruebas, documentación y preparación de la demostración. No se atribuye al equipo una exposición oral, revisión personal ni ejecución que no haya realizado.

### Herramientas y guías reutilizadas

Se reutilizaron las guías existentes de planificación, diseño de interfaz, React, pruebas, diagnóstico y verificación descritas en [SKILLS.md](SKILLS.md) y en el [informe del 6 de noviembre](REVIEW_2026-11-06.md). La interfaz mantiene la marca azul y gris. Las recomendaciones sirven para apoyar decisiones; no sustituyen las pruebas ni constituyen una certificación de accesibilidad.

Para preparar la grabación se comprobó la disponibilidad de Playwright CLI y sus operaciones de video, pero Chrome/Chromium no pudo iniciarse mediante esa vía en este entorno. Se continuó con el navegador integrado y la captura de fotogramas reales por capítulos. La disponibilidad de una herramienta o la existencia de un guion no se considera evidencia de una grabación terminada.

### Evidencia y límites de esta entrega

La evidencia de pruebas y demostración se registra en [FEATURE4.md](FEATURE4.md) y [FEATURE4_VIDEO.md](FEATURE4_VIDEO.md). El 14 de noviembre, `Verify.py` completo aprobó **88 pruebas Python y 59 JavaScript**, con compilación Vite de **49 módulos**. Dentro de ese total están cinco casos de aceptación del recorrido y cuatro pruebas del contrato API del tablero. La revisión independiente del frontend no encontró hallazgos accionables.

Se observó en el navegador el alta de Panel preparado → Estante modular con respuesta `201`, impacto y camino hasta Estante, cuatro etapas del conjunto sintético, comparación con ciclo rojo, vuelta a la red base y descarte conservando el catálogo. En móvil se comprobó viewport de 390 × 844, contenido y ancho desplazable de 375 px, zoom de 100 % a 125 % y consola sin errores ni advertencias. Estas comprobaciones tienen evidencia nueva del 14 de noviembre. Se registraron avisos preexistentes de Starlette/httpx y del adaptador de fechas de SQLite de la prueba de Feature 3, sin fallos de la suite.

Se entregó un video WebM de **2:15**, construido con capítulos de interacción real, títulos y sin voz, junto con sus textos SRT. La decodificación completa terminó sin errores y el navegador lo reprodujo hasta el final de sus 135 segundos sin error. El pitch visual reúne seis diapositivas revisadas, con ajuste a 720 px de altura y avance automático comprobados. El guion escrito de tres minutos es una versión ampliada para exposición, no la duración atribuida al archivo. Los datos técnicos y enlaces están en [FEATURE4_VIDEO.md](FEATURE4_VIDEO.md).

Se añadió al Explorador de API la operación analítica del tablero, disponible para todos los perfiles, con un editor de parámetros y sin confirmación de escritura. La verificación global descrita incluye esa ampliación y sus pruebas nuevas.

La instalación operativa de 3001 conservaba el servidor anterior y respondía 404 a la ruta nueva. No se reinició desde esta entrega; la persona que dispone de la contraseña de MariaDB debe detener esa ventana con Ctrl+C y ejecutar Iniciar.cmd --port 3001, introduciendo la contraseña en la entrada oculta. La interfaz está compilada. Las pruebas de la función nueva se hicieron en la instancia aislada de 3014.

Los datos de la demostración son sintéticos y descartables. Su cuenta publicada solo existe en esa instancia y no sirve para la instalación normal. Registrar una dependencia allí modifica únicamente el catálogo de prueba; comparar un escenario no guarda el cambio ni siquiera en ese catálogo.

La simulación no consulta inventario, disponibilidad real, capacidad ni fechas. Las ofertas alternativas y los precios de referencia conservan su significado. Las pruebas con un adaptador en memoria no equivalen a una nueva integración con MariaDB.

### Revisión que corresponde al equipo

Conservar la identificación de integrantes y responsabilidades, revisar personalmente el código y el sentido de las flechas, practicar la presentación y declarar el uso de IA según las reglas del curso. Este registro documenta el trabajo asistido y no afirma que esas tareas personales estén completadas.

## 16 de noviembre de 2026 — enfoque, flechas y comparación de costos

### Solicitud y decisiones confirmadas

El usuario solicitó que el tablero empiece enfocado, conserve una opción de grafo completo, muestre flechas con movimiento continuo y permita comparar costos mínimo/máximo al seleccionar productos. También pidió las columnas de costo de producción y precio de venta calculado. Confirmó **mínimo más 25 %** y **una unidad por cada dependencia producto → producto** para incorporar componentes.

Se fijó una regla de cálculo revisable: agregar las cantidades de cada material procedentes de todos sus usos; redondear cada subtotal a dos decimales con HALF_UP; sumar las filas publicadas; aplicar 1,25 al mínimo y redondear de nuevo. Una rama compartida no elimina usos del componente. El mínimo y máximo incluyen todos los materiales y corresponden a ofertas alternativas, no al costo de una sola ruta.

### Trabajo asistido y controles de regresión

- Se revisaron el cálculo anterior, la persistencia del precio manual, los ciclos y los componentes compartidos antes de ampliar el modelo.
- Se incorporó un cálculo derivado con estados Ready, Incomplete y Cycle. Un cálculo incompleto o cíclico conserva mínimo, máximo y venta como null; no transforma un subtotal conocido en un total completo.
- Se preservaron los precios manuales y versiones existentes para compatibilidad API. La nueva interfaz muestra valores calculados y el formulario de producto deja de editar el precio manual. Las consultas no guardan precios ni cambian el esquema.
- Se reutilizó un panel de costos en catálogo, grafo de abastecimiento y grafo de producción. La vista de escenarios del tablero no atribuye a una hipótesis un costo calculado sobre la red guardada.
- Se añadió el enfoque con los datos de alcance/ciclo que ya entrega Python; se conservaron selección, caminos y opción de grafo completo.
- Se añadió movimiento nativo de las flechas, con pausa y respeto por las preferencias de movimiento reducido. Se revisó la dirección también para conexiones inversas, de la misma columna y autorrelaciones.
- Se definieron casos de aceptación de cantidades compartidas, redondeo por material, ofertas de cero, datos faltantes, ciclos por alcance, precios guardados intactos y actualización tras cambiar ofertas.

La revisión de lectura no identificó un fallo nuevo en el modelo de costos o el enfoque. La verificación completa del día 16 aprobó **108 pruebas Python y 64 JavaScript (172)** y compiló **53 módulos**. El resultado y el alcance se registran en [GRAPH_COSTS_2026-11-16.md](GRAPH_COSTS_2026-11-16.md); no se atribuyen a esta ampliación las cifras ni el video del 14 de noviembre.

En la instancia sintética de 3016 se comprobaron costos coherentes en catálogo, grafo y producción: Estante mostró inicialmente 70.000 COP mínimo, 80.000 máximo y 87.500 de venta. Al cambiar la oferta de Norte de 35.000 a 36.000, el cálculo indirecto se actualizó a 72.000 mínimo y 90.000 de venta. Las dos capturas documentan el antes y después, no el mismo estado.

Se revisaron foco de cuatro nodos/tres relaciones frente a grafo completo de seis/cuatro, conservación de selección/camino, movimiento continuo mediante posiciones visibles, pausa, movimiento reducido y móvil de 390 × 844 sin desbordamiento de página en la medición de 375 px. La consola no registró errores. No se accedió a MariaDB operativa ni se necesitaron sus credenciales para esas pruebas.

Tras compilar la interfaz, el usuario confirmó el reinicio el día 16. La aplicación de 3001 respondió HTTP 200 y su index.html coincidió byte por byte con frontend/dist/index.html. La estimación sin sesión devolvió 401, conforme al control de acceso. No se dispuso de sesión autenticada para consultar los costos de MariaDB operativa: su validación funcional sigue siendo la de los datos sintéticos. El servidor de prueba de 3016 se detuvo después de la revisión.

El reinicio no queda pendiente. El procedimiento Ctrl+C e Iniciar.cmd --port 3001, con MySQL iniciado y contraseña en la entrada oculta, se conserva para futuras actualizaciones del servidor. Esta confirmación del día 16 es posterior al estado operativo documentado el 14; no cambia ni reatribuye las pruebas históricas.

El modelo sigue limitado a materiales calculables: no incluye mano de obra, transporte, impuestos, inventario, capacidad ni disponibilidad real. La IA asistió en análisis, implementación, pruebas y documentación; la revisión personal y exposición del equipo se mantienen como responsabilidades humanas.



## 16 de noviembre de 2026 — resaltado e investigación

Solicitud: seleccionar la opción de costo para destacarla en el grafo y presentar mejoras de mercado antes de aplicarlas. Se implementó únicamente el resaltado autorizado: trazas completas en Python, selección accesible, foco ampliado y limpieza de respuestas obsoletas. No cambió la fórmula de precios ni la base de datos. 183 pruebas pasaron; recorrido visual y móvil con datos sintéticos. Usuario confirmó reinicio; entrega HTTP verificada.

Las propuestas estéticas, funcionales y de rendimiento se reúnen en [la investigación de 2026](RECOMMENDATIONS_2026-11-16.md); siguen pendientes de aprobación. Incluye fuentes oficiales, evidencia visual y una línea base sintética reproducible. No se aplicaron sus optimizaciones ni se publicaron datos o servicios en Internet.


## 2026-11-16 — Legibilidad, filtros y rendimiento aprobados

El usuario autorizó aplicar las recomendaciones de legibilidad, filtros y rendimiento conservando paleta y funciones. Se dividió la implementación en catálogo/resumen, geometría y detalle del grafo, cálculo de costos y entrega compacta del tablero. Se conservaron las fórmulas y el contrato expandido por defecto; la página solicita el formato compacto opcional. No hubo cambios de datos reales, credenciales, esquema o dependencias instaladas.

La revisión visual detectó acciones de la tabla recortadas a ancho de escritorio; se corrigió la distribución y se comprobó que la tabla cabe sin recorte. Se verificó móvil, filtros, escenarios, pausa y resaltados con datos sintéticos. Resultado: 213 pruebas aprobadas. Se preservaron los benchmarks originales y se publicaron comparaciones nuevas, distinguiendo tiempos sintéticos de uso real. El usuario reinició 3001; HTTP 200 y build coincidente. [Entrega y límites](READABILITY_PERFORMANCE_2026-11-16.md).

## 2026-11-16 — Movimiento libre y selección múltiple del grafo

El usuario autorizó mover nodos libremente y seleccionar grupos en el grafo compartido. Se incorporaron arrastre individual y de grupo, **Ctrl/Cmd + clic** para añadir o retirar nodos, **Seleccionar área** o **Shift + arrastre sobre el fondo** para seleccionar por rectángulo y **Ctrl/Cmd** para sumar el área al grupo. El grupo conserva las distancias entre sus nodos al moverlo.

Se añadieron **Alt + flechas** para mover 10 unidades del dibujo y **Alt + Shift + flechas** para mover 40, además de **Escape** para cancelar el gesto y limpiar la selección. **Restaurar distribución** recupera las posiciones automáticas. El fondo sigue desplazando la vista cuando el modo de área está desactivado y no se mantiene Shift.

Las posiciones se mantienen solo en la vista abierta. Enfocar conexiones o cambiar la opción de costo conserva el acomodo; el tablero lo conserva entre enfoque y grafo completo de la misma instantánea y versión analizada. Recargar, navegar a otra sección o actualizar el catálogo restablece la distribución. No se guardan coordenadas en MariaDB ni se alteran dependencias, precios, cantidades o algoritmos de negocio. El grupo de movimiento permanece separado del producto inspeccionado y de los caminos y costos resaltados.

La IA asistió en el diseño de interacción, implementación, pruebas y revisión independiente. Se revisaron coordenadas y límites, filtros, ausencia de mutación, captura y cancelación del puntero y conservación del encuadre. La revisión detectó que **Alt + flechas** desde el fondo podía mover el producto inspeccionado en vez del grupo elegido por área; se separó el foco real del detalle y se comprobaron tres regresiones específicas. La verificación completa y la compilación final aprobaron antes de esta actualización documental. La evidencia y los límites de la entrega se enlazan en [Movimiento libre y selección múltiple](FREE_GRAPH_LAYOUT_2026-11-16.md), sin sustituir las cifras históricas de esta bitácora.

Esta entrega cambia solo la interfaz. Una vez compilada, se activa con **Ctrl+F5** en el navegador; no requiere reiniciar AbastecePyme ni MariaDB, introducir una nueva contraseña ni ejecutar migraciones. Esta edición de documentación se limitó al README, la guía y la bitácora; no repitió pruebas de código ni accedió a la base operativa.


## 2026-11-16 — Distribución por cuenta y portada continua

El usuario solicitó recuperar posiciones después de recargar o iniciar sesión y mantener el movimiento de la ilustración principal. Se añadieron preferencias autenticadas por usuario y sección en UserGraphLayouts, una cola de guardado por cuenta y borradores de coordenadas para recuperarse de una interrupción. Los perfiles de consulta sólo modifican su presentación. La migración valida la semilla y añade únicamente la tabla nueva en instalaciones ya actualizadas.

La animación anterior se ejecutaba una vez durante cuatro segundos. Ahora repite un ciclo CSS lineal y continuo; dispone de pausa/reanudación y respeta movimiento reducido. La revisión independiente corrigió una carrera al guardar movimientos sucesivos y se añadió una regresión. La verificación completa aprobó 258 pruebas, build de 61 módulos y recorrido con cuentas sintéticas en 3019, sin errores de consola. Se probó recuperación desde otro origen local sin borrador compartido, aislamiento, reset persistente y móvil. El usuario reinició 3001; respondió 200 con build coincidente y la nueva ruta pidió autenticación. No se escribieron datos de prueba en MariaDB. [Guía y evidencia](USER_GRAPH_LAYOUTS_2026-11-16.md).


## 2026-11-16 — Velocidad adicional y documentación consolidada

Después del ajuste de cuatro a 2,5 segundos, el usuario pidió otro 20 % de velocidad. Se cambió únicamente la duración a 2,083333 segundos (2,5 / 1,20), conservando repetición infinita, pausa y movimiento reducido. La compilación de 61 módulos terminó correctamente y se verificó el CSS generado; no se repitió el recorrido visual ni la batería funcional de la entrega anterior.

Se actualizaron el README, la guía, las instrucciones de instalación y el documento de distribución por usuario. Se corrigió la antigua indicación de posiciones temporales, se añadieron las rutas de preferencias al inventario de API y se distinguió el reinicio ya confirmado de la simple recarga requerida por este ajuste. La documentación histórica y su evidencia conservan las fechas originales. Se prepara una nueva copia completa del código para GitHub sin reemplazar los paquetes anteriores ni incluir datos operativos privados.
