# Compartir esta versión — 7 de noviembre de 2026
Descomprime el ZIP y sube el contenido de AbastecePyme/ a un repositorio nuevo.
No subas el ZIP como sustituto de los archivos fuente.
Incluye data/catalogo.json sin modificar sus bytes: .gitattributes preserva su huella.
No se incluyen bases reales, cuentas, sesiones, correos, contraseñas ni copias de seguridad.
Cada instalación debe configurar su propia cuenta MariaDB y administrador del sitio.
Lee README.md, docs/SETUP.md y docs/GUIA_ACTUALIZACION_2026.md.
docs/FEATURE3.md explica el cumplimiento de los cuatro requisitos de Feature 3 y sus pruebas.
Instalar.cmd instala las dependencias fijadas y construye la interfaz.
El proyecto no está publicado en Internet; el arranque escucha solo en 127.0.0.1.
