"""Loopback QA fixture for catalogue filters and graph readability.

Extends the cost comparison sample in SQLite memory. It never uses MariaDB
or writes a database file. The synthetic editor account is inherited.
"""
import argparse

from CostComparisonPreview import CreateCostDatabase, CreateApp
from backend.Catalog import CreateElement
from backend.Models import ElementCreate, RelationCreate
from backend.Relations import ChangeRelation


def CreateReadabilityDatabase():
    Database = CreateCostDatabase()
    for ElementId, Name, ElementType in [
        ("INS-SIN-OFERTA", "Insumo sin oferta registrada", "Material"),
        ("PROD-CICLO-A", "Producto con ciclo A", "Product"),
        ("PROD-CICLO-B", "Producto con ciclo B", "Product"),
        ("INS-CERO", "Insumo de costo cero", "Material"),
        ("PROD-CERO", "Producto de costo cero", "Product"),
    ]:
        CreateElement(Database, ElementCreate(ElementId=ElementId, Name=Name, ElementType=ElementType,
                                              Description="Dato sintético para revisar filtros y legibilidad."))
    for SourceId, TargetId, Value in [
        ("PROD-CICLO-A", "PROD-CICLO-B", None),
        ("PROD-CICLO-B", "PROD-CICLO-A", None),
        ("PROV-NORTE", "INS-CERO", "0.00"),
        ("INS-CERO", "PROD-CERO", "1.0000"),
    ]:
        ChangeRelation(Database, RelationCreate(SourceId=SourceId, TargetId=TargetId,
                                                Value=Value, IsDemo=False), "create")
    return Database


def Main():
    Parser = argparse.ArgumentParser(description=__doc__)
    Parser.add_argument("--port", type=int, default=3018)
    Arguments = Parser.parse_args()
    if not 1024 <= Arguments.port <= 65535:
        Parser.error("Puerto fuera de rango.")
    import uvicorn
    Database = CreateReadabilityDatabase()
    try:
        print(f"QA aislada de legibilidad: http://127.0.0.1:{Arguments.port}/ — SQLite en memoria.", flush=True)
        uvicorn.run(CreateApp(Database, Arguments.port), host="127.0.0.1", port=Arguments.port,
                    access_log=False, proxy_headers=False, log_level="warning")
    finally:
        Database.Close()


if __name__ == "__main__":
    Main()
