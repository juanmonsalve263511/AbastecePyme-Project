# Línea base sintética para propuestas de optimización

Fecha de observación: **16 de noviembre de 2026**. Estos hallazgos forman parte de una investigación; **las optimizaciones propuestas no se han aplicado**.

## Método y límites

Se usó Python **3.14.7** en el equipo de desarrollo y grafos sintéticos deterministas. Costos, recorridos, serialización y compresión se midieron tres veces y se informa la mediana. La exploración SQL usó una medición por tamaño sobre SQLite en memoria. No se accedió a credenciales, catálogos reales ni MariaDB operativa.

Los tiempos no son Core Web Vitals ni latencias de usuarios reales. Son observaciones locales que permiten identificar trabajo repetido; no prometen una aceleración determinada después de modificar el código. Un catálogo pequeño puede no mostrar una demora perceptible.

El [script reproducible](../tests/benchmarks/BenchmarkResearch2026.py) se ejecuta sólo con `--run`; importarlo no inicia mediciones. Los [resultados originales](research/benchmark-research-2026.json) se conservan separados para no sustituirlos al repetir el experimento.

Desde la carpeta del proyecto:

```powershell
.\.venv\Scripts\python.exe -B -X utf8 tests/benchmarks/BenchmarkResearch2026.py --run
```

No es una prueba contra la base real ni forma parte del verificador rutinario de aceptación. La duración depende del equipo y de la carga concurrente.

## 1. Cálculo de resúmenes de productos

Cada escenario contiene un proveedor, un insumo y una cadena de productos conectados como componentes. Se compara la cadena normal con la misma cadena más una dependencia general entre dos proveedores ajenos a ella. Los costos resultantes de ambos escenarios fueron idénticos.

| Productos | Cadena normal, ms | Con dependencia general ajena, ms |
|---:|---:|---:|
| 100 | 0,911 | 8,686 |
| 300 | 2,449 | 69,806 |
| 1.000 | 8,050 | 944,791 |

En [ProductCosts.py](../backend/ProductCosts.py), la existencia de cualquier dependencia general no cuantificada activa la revisión de requisitos para cada producto. Propuesta: identificar una sola vez qué alcances necesitan esa revisión y reutilizar los índices, manteniendo las comprobaciones de ciclos y las mismas cifras. **No sustituir la validación por omitir dependencias.**

## 2. Tamaño de respuesta del tablero

Una cadena de 1.000 productos sin cambio temporal produjo:

| Medida | Observado |
|---|---:|
| Identificadores materializados en caminos | 502.503 |
| JSON del tablero, sin comprimir | 18.592.323 bytes |
| JSON comprimido con gzip nivel 5 | 336.660 bytes |
| Serialización JSON | 82,744 ms |
| Compresión | 26,058 ms |

[Impact.py](../backend/Impact.py) devuelve caminos completos para los alcanzados; [SupplyBoard.py](../backend/SupplyBoard.py) devuelve los escenarios base y alternativo incluso cuando no hay cambio. Propuesta: representar el catálogo una vez, reutilizar el resultado sin cambio y pedir o reconstruir el camino explicativo seleccionado cuando se necesita. Cambiar ese contrato exige pruebas de conservación de impactos, ciclos, explicaciones y resaltados.

La compresión ya existe y reduce la descarga. No elimina la construcción del objeto, su serialización ni el trabajo de interpretación posterior.

## 3. Consulta de una receta pequeña en un catálogo grande

Una receta de tres nodos dentro de un catálogo con 10.000 productos independientes requirió **5 SELECT, 2 transacciones y 20.004 filas materializadas**, incluyendo autenticación; la medición única sobre SQLite en memoria fue de **59,87 ms**.

La lectura de [Catalog.py](../backend/Catalog.py) carga el catálogo entero antes de calcular el producto seleccionado. Propuesta: consultas por alcance y por lotes dentro de una lectura consistente, después de contrastarlas con MariaDB en un entorno desechable. No añadir índices o cachés sin medir.

Una caché basada solamente en `Product.Version` sería incorrecta: una oferta indirecta puede cambiar el costo sin modificar esa versión. Esa situación ya tiene una prueba de regresión.

## 4. Verificación operativa pendiente

La inspección encontró 26 métodos declarados de integración separados de la suite habitual; no equivale a 26 ejecuciones nuevas en esta investigación. El adaptador SQLite elimina `FOR UPDATE`, por lo que no verifica los bloqueos reales de MariaDB. Se propone automatizar integración y restauración en un entorno aislado.

Para una futura publicación en Internet, el límite de intentos actual es por proceso. Dos instancias independientes aceptaron diez intentos cada una del mismo cliente: veinte en conjunto. HTTPS, cookies seguras y límites compartidos serían requisitos de una publicación, no un cambio aplicado al servicio local.

La [investigación y prioridades](RECOMMENDATIONS_2026-11-16.md) contrasta estos hallazgos con las recomendaciones oficiales. Las cifras anteriores sirven para elegir qué medir y mejorar primero; no certifican rendimiento de producción.
