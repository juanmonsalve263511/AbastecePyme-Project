"""Compact delivery must preserve the expanded dashboard's explanations."""
import copy
import json
import unittest
from unittest.mock import patch
from backend.Models import SupplyBoardRequest
from backend.SupplyBoard import BuildSupplyBoard, AnalyzeScenario
from tests.python.test_supply_board import Fixture


def Expand(Result):
    Result = copy.deepcopy(Result)
    Mapping = {Item['ElementId']: Item for Item in Result['Catalog']['Elements']}
    for Version in ('Base', 'Scenario'):
        if Result[Version] is None:
            Result[Version] = copy.deepcopy(Result['Base'])
            continue
        Current = Result[Version]
        Impact = Current['Impact']
        Lookup = {Row['ElementId']: Row for Row in Impact['Visited']}
        for Row in Impact['Visited']:
            Path, Step = [], Row['ElementId']
            while Step is not None:
                Path.append(Step)
                Step = Lookup[Step]['ParentId']
            Row['Path'] = Path[::-1]
        Impact['Origin'] = Impact['Visited'][0]
        Impact['Reached'] = Impact['Visited'][1:]
        for Analysis in (Impact, Current['Production']):
            Graph = Analysis['Graph']
            Graph['Elements'] = [Mapping[Id] for Id in Graph.pop('ElementIds')]
    Result.pop('ResponseFormat')
    return Result


class CompactSupplyTests(unittest.TestCase):
    def test_paths_scopes_cycles_and_scenarios_match_expanded(self):
        Data = Fixture()
        Before = copy.deepcopy(Data)
        for ProductId in (None, 'PROD', 'FREE'):
            for Change in (None,
                           {'Operation':'Add','SourceId':'PROD','TargetId':'FREE'},
                           {'Operation':'Add','SourceId':'PROD','TargetId':'SUP'},
                           {'Operation':'Remove','SourceId':'SUP','TargetId':'MAT'}):
                with self.subTest(ProductId=ProductId, Change=Change):
                    Body = dict(ElementId='SUP', ProductId=ProductId, Change=Change)
                    Full = BuildSupplyBoard(Data, SupplyBoardRequest(**Body))
                    Small = BuildSupplyBoard(Data, SupplyBoardRequest(**Body, ResponseFormat='Compact'))
                    self.assertEqual(Expand(Small), Full)
        self.assertEqual(Data, Before)

    def test_no_change_calculates_one_scenario_and_has_no_duplicate_paths(self):
        with patch('backend.SupplyBoard.AnalyzeScenario', wraps=AnalyzeScenario) as Analyze:
            Result = BuildSupplyBoard(Fixture(), SupplyBoardRequest(ElementId='SUP', ResponseFormat='Compact'))
        self.assertEqual(Analyze.call_count, 1)
        self.assertIsNone(Result['Scenario'])
        self.assertNotIn('Reached', Result['Base']['Impact'])
        self.assertTrue(all('Path' not in Row for Row in Result['Base']['Impact']['Visited']))

    def test_payload_growth_is_linear_in_a_long_chain(self):
        from tests.benchmarks.BenchmarkResearch2026 import SyntheticChain
        Sizes = []
        for Count in (100, 200):
            Data = SyntheticChain(Count)
            Full = BuildSupplyBoard(Data, SupplyBoardRequest(ElementId='S1'))
            Small = BuildSupplyBoard(Data, SupplyBoardRequest(ElementId='S1', ResponseFormat='Compact'))
            self.assertEqual(Expand(Small), Full)
            Sizes.append(len(json.dumps(Small)))
            self.assertLess(Sizes[-1], len(json.dumps(Full)) / 3)
        self.assertLess(Sizes[1], Sizes[0] * 2.1)
