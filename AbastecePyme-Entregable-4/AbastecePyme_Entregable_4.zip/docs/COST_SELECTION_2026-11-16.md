# Resaltar opciones de abastecimiento — 16 de noviembre de 2026

Esta actualización implementa la selección visual solicitada. Las demás mejoras de la [investigación de 2026](RECOMMENDATIONS_2026-11-16.md) son propuestas pendientes de aprobación.

## Cómo usarla

1. En **Grafo de abastecimiento**, selecciona un producto. También puedes generar su **Orden de producción**, abrir **Ver el orden completo y la red analizada** y seleccionar el producto en ese grafo.
2. En el panel derecho, pulsa **Resaltar opción económica** o **Resaltar opción costosa**.
3. Los proveedores elegidos, insumos, componentes y producto final reciben una marca **✓**. Sus conexiones se muestran con mayor grosor y una leyenda identifica la opción activa. Las demás conexiones pierden énfasis. Si el grafo estaba enfocado, aparecen también los elementos indirectos necesarios para explicar la opción.
4. Pulsa **Quitar selección de costo** para volver a la vista anterior. Cambiar de producto o actualizar el catálogo también elimina la selección anterior.

El botón de la opción activa indica su estado y funciona con teclado. El movimiento de las flechas, la pausa y la preferencia de movimiento reducido se conservan. Los controles de resaltado sólo aparecen donde hay un grafo asociado; el detalle modal del catálogo conserva la comparación numérica.

No se habilita el resaltado de una opción si faltan datos o existe un ciclo que impide obtener su costo completo. Los escenarios temporales del tablero siguen mostrando su impacto y orden, sin atribuirles los costos de la red guardada.

## Qué representa la selección

Representa una **combinación completa de abastecimiento**, no un único camino corto. Incluye una oferta elegida por cada material agregado, todas sus relaciones de uso y todas las dependencias de los componentes que necesita el producto.

Se mantienen las [reglas de costos aprobadas](GRAPH_COSTS_2026-11-16.md): una unidad por componente, cantidades agregadas por insumo, redondeo por subtotal y venta igual al costo mínimo más 25 %. No cambian precios guardados, cantidades, relaciones ni tablas de MariaDB.

El detalle de `/api/products/{ProductId}/estimate` añade `SourcingGraphs.Minimum` y `SourcingGraphs.Maximum`. Cada uno contiene `ElementIds` y `Relations` con `SourceId`, `TargetId` y `RelationType`. Python construye las trazas de la misma receta y respuesta que las cifras. JavaScript muestra esos identificadores, sin recalcular recorridos ni decisiones de compra. En estados incompletos o cíclicos las trazas están vacías.

## Verificación

- **115 pruebas Python + 68 JavaScript = 183 aprobadas**; compilación de **54 módulos**.
- Pruebas nuevas: elección correcta de oferta por material, ramas y componentes compartidos, empate determinista, ausencia de elementos ajenos, estados incompletos/ciclos y limpieza al cambiar producto o datos.
- Navegador integrado con SQLite en memoria: mínimo **70.000 COP** resalta Maderas del Norte; máximo **80.000 COP** resalta Maderas del Sur. Cada opción incluye Tablero de madera, Panel preparado y Estante modular: cuatro nodos y tres relaciones.
- En la red completa permanecen seis nodos: cuatro resaltados y dos atenuados. Al quitar la selección, el foco previo vuelve a dos nodos.
- La selección funciona también en Orden de producción. Para Producto independiente, sin receta, los botones están deshabilitados.
- Móvil de 390 × 844: ancho disponible y desplazable de 375 px, sin desbordamiento horizontal observado; selección conservada. No hubo errores en la consola durante el recorrido.

Estas pruebas funcionales usan datos sintéticos, no la base MariaDB operativa. El usuario confirmó el reinicio del servidor habitual para esta actualización; la comprobación de entrega HTTP se registra en [VALIDATION](VALIDATION.md).

### Opción económica

![Opción económica con proveedor, insumo y componente resaltados](media/review-2026-11-16/05-economic-highlight.jpg)

### Opción costosa

![Opción costosa con el proveedor alternativo resaltado](media/review-2026-11-16/06-expensive-highlight.jpg)
