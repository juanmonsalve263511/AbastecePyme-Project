# Grafos y costos de producción — 16 de noviembre de 2026

## Qué cambia

- El **Tablero de abastecimiento** empieza con **Enfocar conexiones**: muestra el origen y toda su cadena de consecuencias. **Mostrar grafo completo** permite volver al conjunto de la red elegida.
- Al revisar un ciclo, el enfoque muestra sus elementos y relaciones. Se conserva la posibilidad de mostrar la red completa.
- Las conexiones tienen una flecha animada continua en dirección **requisito → dependiente**, con controles para pausar y reanudar y respeto por el movimiento reducido.
- **Catálogo → Productos** muestra **Costo de producción (COP)** y **Precio de venta (COP)** calculados. Al abrir un producto, se comparan la opción más económica y la más costosa.
- La misma comparación aparece al seleccionar un producto en el grafo de abastecimiento y en el grafo de **Orden de producción**.

Esta entrega conserva las funciones y la evidencia anteriores. El [video del 14 de noviembre](FEATURE4_VIDEO.md) corresponde a aquella versión y no demuestra las novedades del día 16.

## Reglas confirmadas del cálculo

El cálculo corresponde a **una unidad del producto seleccionado** y usa los datos actuales del catálogo.

1. Una relación **insumo → producto** aporta su cantidad registrada, expresada en la unidad del insumo.
2. Cada dependencia general **producto → producto** significa que el dependiente consume **una unidad del producto de origen como componente**. Esta regla se aplica también a componentes anidados.
3. Si un componente se utiliza en varias ramas, se suman todos sus usos. Se suman también los requisitos directos del producto final.
4. Antes de calcular importes, se agrupan todas las cantidades de un mismo material, tanto directas como procedentes de componentes.
5. Para cada material se comparan sus ofertas de proveedores. La opción mínima usa el menor precio unitario registrado; la máxima, el mayor. Los empates se resuelven de forma reproducible por código de proveedor.
6. Cada subtotal de material se redondea a dos decimales con **ROUND_HALF_UP**. Los totales son la suma de esos subtotales publicados.
7. El **precio de venta calculado = costo mínimo publicado × 1,25**, redondeado de nuevo a dos decimales con ROUND_HALF_UP.

ROUND_HALF_UP significa que un valor exactamente a mitad entre dos centavos se redondea hacia el centavo superior para estos importes no negativos: **0,025 → 0,03**.

### Combinaciones completas de abastecimiento

El mínimo y el máximo incluyen **todos los materiales necesarios**. Cada extremo representa una combinación completa: una oferta elegida para cada material, con toda su cantidad requerida. No es el costo de una sola ruta del grafo ni el camino de menor número de relaciones que muestra el análisis de impacto.

Como los precios por unidad son independientes y no se modelan descuentos, capacidades ni costos conjuntos, elegir el menor precio de cada material minimiza la suma; elegir el mayor maximiza la suma entre las ofertas registradas. No hace falta enumerar todas las combinaciones.

El máximo es el extremo de las **ofertas guardadas**, no una predicción del precio de mercado ni un límite de gasto futuro. Los proveedores de un mismo material siguen siendo alternativas de compra; no se suman todas sus ofertas como si hubiera que comprarlas juntas.

### Componentes compartidos y redondeo

Supón que un componente X requiere dos unidades de un material. A necesita una unidad de X y B también; el producto P necesita A y B. Para una unidad de P hacen falta **dos X y cuatro unidades del material**. Una visita única de X en el grafo no reduce esa necesidad a una unidad.

Los componentes del panel son una explicación de los usos incluidos. Sus materiales **ya forman parte del desglose**; no deben sumarse otra vez como costos adicionales.

| Ejemplo | Resultado |
|---|---|
| Tres unidades de un material con ofertas de 2,00 y 5,00 COP | Mínimo 6,00; máximo 15,00; venta 7,50. |
| Tres unidades directas y un componente que requiere otras dos del mismo material | Cantidad agregada cinco; costos 10,00 y 25,00; venta 12,50. |
| Dos usos del mismo material, cada uno con importe bruto 0,005 | Se agrupan antes del redondeo: una fila de 0,01. |
| Dos materiales distintos con importe bruto 0,005 cada uno | Cada fila se redondea a 0,01; total 0,02; venta 0,03. |
| Cantidad 0,3333 y ofertas de 10,01 y 12,34 | Subtotales 3,34 y 4,11; venta 4,18. |

Los ejemplos son aritméticos y no representan cotizaciones comerciales.

## Cuándo no se presenta un total

| Estado | Significado y presentación |
|---|---|
| `Ready` | Hay requisitos cuantificados y ofertas válidas para completar el cálculo. Se publican mínimo, máximo y venta. Un precio válido de cero se conserva como cero. |
| `Incomplete` | Falta una oferta, un producto/componente no tiene requisitos definidos, hay datos inválidos o existe una dependencia general sin una cantidad/costo interpretable por estas reglas. Los tres importes finales son `null`. |
| `Cycle` | Un ciclo afecta los requisitos del producto seleccionado. No se propone un costo ni precio de venta; los tres importes finales son `null` y se identifica el ciclo. |

Una dependencia general **de tipos distintos a producto → producto** no recibe una cantidad inventada. El cálculo explica por qué queda incompleto. Un ciclo ajeno a los requisitos del producto no bloquea su estimación.

El panel puede mostrar materiales y ofertas conocidos cuando el cálculo está incompleto, pero los importes parciales no se presentan como un total completo. En el catálogo aparecen **Pendiente de calcular** o **Revisar ciclo**, según corresponda.

## Usar la interfaz

### Catálogo

1. Abre **Catálogo → Productos**.
2. Compara **Costo de producción (COP)** —el mínimo— y **Precio de venta (COP)** —mínimo más 25 %—.
3. Pulsa el nombre de un producto o **Ver detalles**.
4. Revisa **Opción más económica**, que aparece primero, y despliega **Opción más costosa** mediante **Ver proveedores e insumos**.
5. Compara proveedor, cantidad, precio unitario y subtotal de cada material. Abre **Componentes incluidos** para conocer los usos incorporados.

El formulario de producto ya no solicita un precio manual. Para modificar el cálculo, un Editor o Administrador debe revisar las ofertas, cantidades y dependencias correspondientes en **Relaciones**. Crear un producto sin sus requisitos deja el cálculo pendiente.

### Grafo de abastecimiento

Selecciona un nodo de tipo **Producto** para abrir el mismo panel de costos en el lateral. El cálculo utiliza los datos completos del catálogo, aunque el dibujo esté enfocado y no muestre todos los proveedores alternativos.

**Pausar flechas** detiene la animación; **Reanudar flechas** la activa de nuevo. Si el sitio o el sistema tiene movimiento reducido, el control muestra **Movimiento reducido** y la animación permanece detenida. Las flechas estáticas siguen indicando la dirección.

### Orden de producción

Genera el orden, abre **Ver el orden completo y la red analizada** y selecciona el producto en el grafo. El panel compara sus costos. Si se muestra un ciclo en la pantalla de producción, seleccionar un producto afectado permite consultar el motivo por el que su costo no está completo.

El precio no cambia las etapas ni determina qué requisito va primero. El orden sigue siendo estructural y no optimiza compras ni tiempos.

### Tablero y escenarios temporales

El enfoque inicial incluye toda la cadena de consecuencias, también las conexiones lejanas. **Mostrar grafo completo** amplía el dibujo sin cambiar el análisis; **Enfocar conexiones** recupera el alcance relevante. En modo ciclo, el enfoque se limita al ciclo señalado por el servidor.

Los grafos de escenarios del tablero no presentan el panel de costos de la red guardada como si fuera una cotización del escenario. La comparación temporal conserva su alcance de impacto y orden; para consultar costos del catálogo registrado usa Catálogo, Grafo de abastecimiento u Orden de producción.

## Contrato de datos y compatibilidad

**GET `/api/products/{ProductId}/estimate`**, disponible para cualquier perfil autenticado, devuelve el cálculo detallado:

| Campo | Contenido |
|---|---|
| `ProductId`, `Status`, `IsComplete` | Producto y estado del cálculo. |
| `MinimumCost`, `MaximumCost`, `SalePrice` | Importes derivados como cadenas decimales COP con dos decimales, o `null`. Aquí `SalePrice` es mínimo × 1,25. |
| `CurrencyCode`, `MarkupRate` | `COP` y `"0.25"`. |
| `Materials` | Materiales con nombre, unidad, cantidad agregada, todas las `Offers` válidas y las selecciones `Minimum` / `Maximum`. |
| `Materials[].Offers[]` | Proveedor, nombre, precio unitario, subtotal redondeado e indicador `IsDemo`. |
| `Components` | Productos usados como componentes y sus cantidades agregadas. Es trazabilidad, no una segunda suma de costos. |
| `Missing`, `Issues`, `Cycle` | Insumos sin oferta válida, motivos que impiden completar el cálculo y ciclo, cuando exista. |
| `IsDemo` | Advierte que la comparación incluye precios o cantidades de referencia. No certifica cotizaciones vigentes. |

El catálogo añade un resumen **`Elements[i].ProductCosts`** para cada producto, con `Status`, `IsComplete`, `MinimumCost`, `MaximumCost`, `SalePrice`, `CurrencyCode`, `MarkupRate` e `IsDemo`. Se deriva de una misma lectura de elementos y relaciones y no se guarda en una tabla.

Los identificadores mal formados reciben `422`; un producto inexistente o un elemento de otro tipo recibe `404`; sin sesión se mantiene el control de acceso. La interfaz cancela o descarta respuestas sustituidas al cambiar de producto o datos.

### Precio guardado anteriormente

**`Elements[i].SalePrice`** e **`IsPriceReference`** siguen siendo campos de compatibilidad del precio manual almacenado en `ProductPrices`. No alimentan el cálculo, no se sobrescriben al consultar y no se muestran como el precio calculado de la nueva interfaz.

La API conserva sus operaciones anteriores para clientes compatibles: omitir `SalePrice` al editar lo mantiene; enviar `null` lo retira; una edición explícita requiere permisos y `Version`. Eso es distinto de **`Elements[i].ProductCosts.SalePrice`** y del `SalePrice` devuelto por `/estimate`, que se calculan y no se persisten.

El helper histórico `CalculateEstimate` permanece para su compatibilidad aislada. El endpoint actual utiliza `CalculateProductCosts`; sus campos `Materials`, `MinimumCost` y `MaximumCost` sustituyen el desglose directo anterior de `Choices` y `Total`.

## Límites y actualización

- Se calculan materiales directos y materiales de los componentes definidos. No se incorporan mano de obra, transporte, impuestos, capacidad, inventario o disponibilidad real.
- Las unidades de cada insumo, sus cantidades y precios deben ser compatibles. La aplicación no convierte automáticamente entre kg, metros u otras unidades.
- Las cotizaciones y cantidades de referencia conservan su advertencia. Los valores registrados tampoco son verificados contra fuentes externas.
- Una consulta no crea órdenes, reservas, compras ni precios guardados. No cambia versiones del catálogo.
- Si cambia una oferta o un componente, vuelve a cargar los datos y consulta otra vez. Una oferta puede afectar a un producto indirecto aunque no cambie la versión individual de ese producto.

## Aceptación del 16 de noviembre

La revisión de lectura contrastó las reglas con [ProductCosts.py](../backend/ProductCosts.py), el [panel compartido](../frontend/src/components/ProductCosts.jsx) y los controles de grafo. Las pruebas específicas están en [test_product_costs.py](../tests/python/test_product_costs.py), [test_product_costs_catalog.py](../tests/python/test_product_costs_catalog.py) y [supply-graph.test.mjs](../tests/supply-graph.test.mjs).

La verificación completa aprobó **108 pruebas Python y 64 JavaScript: 172 en total**, con compilación Vite de **53 módulos**. La compilación distribuible de la interfaz se actualizó.

Los casos específicos cubren mínimo/máximo, componentes anidados y compartidos, agregación y redondeo, oferta cero, ofertas ausentes, datos inválidos, ciclos dentro/fuera del alcance y conservación del precio manual. La verificación del catálogo comprueba el resumen derivado y su actualización sin escrituras del cálculo. La revisión visual utilizó una instancia sintética con datos en memoria en el puerto 3016; **no accedió a MariaDB operativa**.

| Comprobación visual | Resultado observado |
|---|---|
| Costo inicial de Estante modular | Mínimo **70.000 COP** con Maderas del Norte, máximo **80.000 COP** con el proveedor alternativo y venta **87.500 COP**. Incluye una unidad de Panel preparado. |
| Consistencia entre pantallas | Catálogo, Grafo de abastecimiento y Orden de producción mostraron el mismo cálculo y desglose. |
| Enfoque del tablero | Inicialmente **4 nodos y 3 relaciones**; grafo completo **6 nodos y 4 relaciones**. Se conservó la selección de Estante y el camino de tres relaciones. |
| Movimiento continuo y pausa | Las posiciones de las flechas cambiaron después de varios ciclos; al pausar, se mantuvieron idénticas entre lecturas. La comprobación utilizó posiciones visibles en el navegador. |
| Movimiento reducido | Las flechas animadas quedaron ocultas y el control de animación inhabilitado; se mantuvo la dirección estática. |
| Edición de oferta indirecta | Cambiar la oferta de Maderas del Norte de **35.000 a 36.000 COP** recalculó Estante: mínimo **72.000 COP** y venta **90.000 COP**. La relación con el componente propagó el cambio. |
| Móvil | Viewport **390 × 844**, ancho de contenido y ancho desplazable de **375 px**, sin desbordamiento horizontal en esa medición. |
| Consola | Sin errores durante el recorrido observado. |

Las capturas corresponden a dos momentos distintos de la misma demostración:

- [Grafo y costos iniciales](media/graph-costs-2026-11-16.jpg): **70.000 / 80.000 / 87.500 COP**.
- [Catálogo después de editar la oferta](media/catalog-costs-2026-11-16.jpg): mínimo **72.000 COP** y venta **90.000 COP**.

Son datos sintéticos de referencia, no cotizaciones actuales ni cambios en el catálogo operativo. Las cifras de la [entrega del 14](FEATURE4.md) y su video se conservan como historia. La comprobación visual del día 16 está limitada al recorrido y tamaños indicados; no constituye una auditoría completa de accesibilidad ni de carga de producción.

## Activación confirmada en la instalación habitual

El **16 de noviembre**, el usuario confirmó que había reiniciado la aplicación. Después se comprobó **HTTP 200** en [la aplicación local de 3001](http://127.0.0.1:3001/) y que los bytes de su `index.html` coincidían exactamente con los de `frontend/dist/index.html`. La consulta de estimación sin sesión respondió **401**, conforme al requisito de autenticación.

No había una sesión autenticada disponible para comprobar costos sobre MariaDB operativa. Por tanto, la validación funcional de los importes sigue siendo la realizada en la instancia sintética; estas comprobaciones adicionales acreditan el acceso a la interfaz actual y la respuesta de autenticación, no un cálculo sobre datos SQL reales. El servidor temporal de **3016** se detuvo al terminar la revisión.

El reinicio no queda pendiente. Para futuras actualizaciones de Python, detén la instancia anterior de AbastecePyme con **Ctrl+C** y ejecuta **Iniciar.cmd --port 3001** con MySQL iniciado, introduciendo su contraseña en la entrada oculta; después recarga la página.
