import ResponsiveImage from './ResponsiveImage.jsx';
import {BusinessInfo} from '../BusinessInfo.js';
import {Icon} from './Common.jsx';
export default function LocationCard({ShowImage=false}){
  return <div className={'location-card'+(ShowImage?' location-card-with-image':'')}>
    {ShowImage&&<div className="editorial-image location-cover"><ResponsiveImage Name="medellin-business" Alt="Vista urbana conceptual inspirada en Medellín, con edificios empresariales y montañas"/></div>}
    <div className="location-details"><span className="location-symbol"><Icon Name="pin" Size={28}/></span><p className="section-note">Nuestro punto de encuentro</p><h2>Medellín, Colombia.</h2><address><strong>{BusinessInfo.Building}</strong><span>{BusinessInfo.Office}</span><span>{BusinessInfo.Street}</span><span>{BusinessInfo.City}</span></address><a className="contact-phone" href={BusinessInfo.PhoneLink}>{BusinessInfo.Phone}<span>Celular de contacto</span></a><a className="location-map" href={BusinessInfo.MapLink} target="_blank" rel="noopener noreferrer">Ver ubicación en el mapa <Icon Name="arrow" Size={18}/><span className="visually-hidden"> (abre otra pestaña)</span></a></div>
  </div>;
}
