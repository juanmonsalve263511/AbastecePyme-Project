"""Exact, read-only material costs and component multiplicities."""
import copy
import unittest
from decimal import Decimal, localcontext

from backend.ProductCosts import CalculateProductCosts


def Element(Id, Kind, **Fields):
    return {"ElementId": Id, "ElementType": Kind, "Name": "Name " + Id, "UnitCode": "unidad", **Fields}


def Edge(Source, Target, Kind, Value=None, Demo=False):
    return {"SourceId": Source, "TargetId": Target, "RelationType": Kind, "Value": Value, "IsDemo": Demo}


class ProductCostTests(unittest.TestCase):
    def Calculate(self, ProductId, Elements, Relations):
        return CalculateProductCosts(ProductId, Elements, Relations)

    def Basic(self):
        Elements = [Element("S1", "Supplier"), Element("S2", "Supplier"), Element("M1", "Material"),
                    Element("M2", "Material"), Element("PP", "Product", SalePrice="999.99", IsPriceReference=False)]
        Relations = [Edge("S1", "M1", "Offer", "12.00"), Edge("S2", "M1", "Offer", "10.20", True),
                     Edge("S1", "M2", "Offer", "3.10"), Edge("M1", "PP", "Requirement", "1.5"),
                     Edge("M2", "PP", "Requirement", "2")]
        return Elements, Relations

    def test_all_alternative_offers_minimum_maximum_and_derived_sale(self):
        Elements, Relations = self.Basic()
        Result = self.Calculate("PP", Elements, Relations)
        self.assertEqual((Result["Status"], Result["MinimumCost"], Result["MaximumCost"], Result["SalePrice"]),
                         ("Ready", "21.50", "24.20", "26.88"))
        self.assertEqual(Result["MarkupRate"], "0.25")
        self.assertTrue(Result["IsComplete"])
        self.assertTrue(Result["IsDemo"])
        Material = Result["Materials"][0]
        self.assertEqual(Material["Quantity"], "1.5000")
        self.assertEqual([Offer["SupplierId"] for Offer in Material["Offers"]], ["S2", "S1"])
        self.assertEqual(Material["Minimum"]["SupplierName"], "Name S2")
        self.assertEqual(Material["Maximum"]["Subtotal"], "18.00")

    def test_zero_price_is_complete_and_equal_price_ties_are_stable(self):
        Elements, Relations = self.Basic()
        Relations = [Edge("S2", "M1", "Offer", "0"), Edge("S1", "M1", "Offer", "0"),
                     Edge("M1", "PP", "Requirement", "1")]
        Result = self.Calculate("PP", Elements, Relations)
        self.assertEqual((Result["MinimumCost"], Result["MaximumCost"], Result["SalePrice"]), ("0.00", "0.00", "0.00"))
        self.assertTrue(Result["IsComplete"])
        self.assertEqual(Result["Materials"][0]["Minimum"]["SupplierId"], "S1")
        self.assertEqual(Result["Materials"][0]["Maximum"]["SupplierId"], "S1")

    def test_diamond_counts_shared_component_twice_and_adds_direct_material(self):
        Elements = [Element("S1", "Supplier"), Element("S2", "Supplier"), Element("M1", "Material")]
        Elements += [Element(Id, "Product") for Id in ("XX", "AA", "BB", "PP")]
        Relations = [Edge("S1", "M1", "Offer", "5"), Edge("S2", "M1", "Offer", "7"),
                     Edge("M1", "XX", "Requirement", "2"), Edge("XX", "AA", "General"),
                     Edge("XX", "BB", "General"), Edge("AA", "PP", "General"),
                     Edge("BB", "PP", "General"), Edge("M1", "PP", "Requirement", "3")]
        Result = self.Calculate("PP", Elements, Relations)
        self.assertEqual(Result["Materials"][0]["Quantity"], "7.0000")
        self.assertEqual((Result["MinimumCost"], Result["MaximumCost"], Result["SalePrice"]), ("35.00", "49.00", "43.75"))
        self.assertEqual({Item["ProductId"]: Item["Quantity"] for Item in Result["Components"]},
                         {"AA": "1.0000", "BB": "1.0000", "XX": "2.0000"})

    def test_rounds_after_shared_material_aggregation_but_before_total(self):
        Elements, Relations = self.Basic()
        Elements += [Element("AA", "Product"), Element("BB", "Product")]
        Relations = [Edge("S1", "M1", "Offer", "0.01"), Edge("M1", "AA", "Requirement", "0.5"),
                     Edge("M1", "BB", "Requirement", "0.5"), Edge("AA", "PP", "General"), Edge("BB", "PP", "General")]
        Result = self.Calculate("PP", Elements, Relations)
        self.assertEqual(Result["MinimumCost"], "0.01")
        self.assertEqual(Result["Materials"][0]["Quantity"], "1.0000")
        Relations = [Edge("S1", "M1", "Offer", "0.01"), Edge("S1", "M2", "Offer", "0.01"),
                     Edge("M1", "PP", "Requirement", "0.5"), Edge("M2", "PP", "Requirement", "0.5")]
        Result = self.Calculate("PP", Elements, Relations)
        self.assertEqual([Item["Minimum"]["Subtotal"] for Item in Result["Materials"]], ["0.01", "0.01"])
        self.assertEqual((Result["MinimumCost"], Result["SalePrice"]), ("0.02", "0.03"))

    def test_fractional_quantity_and_sale_use_half_up(self):
        Elements, Relations = self.Basic()
        Relations = [Edge("S1", "M1", "Offer", "10.01"), Edge("S2", "M1", "Offer", "12.34"),
                     Edge("M1", "PP", "Requirement", "0.3333")]
        Result = self.Calculate("PP", Elements, Relations)
        self.assertEqual((Result["MinimumCost"], Result["MaximumCost"], Result["SalePrice"]), ("3.34", "4.11", "4.18"))

    def test_missing_offer_does_not_publish_a_partial_total(self):
        Elements, Relations = self.Basic()
        Relations = [Relation for Relation in Relations if Relation["TargetId"] != "M2"]
        Result = self.Calculate("PP", Elements, Relations)
        self.assertEqual(Result["Status"], "Incomplete")
        self.assertEqual(Result["Missing"], ["M2"])
        self.assertIsNone(Result["MinimumCost"])
        self.assertIsNone(Result["MaximumCost"])
        self.assertIsNone(Result["SalePrice"])
        self.assertIsNone(Result["Materials"][1]["Minimum"])

    def test_component_without_recipe_is_not_free_despite_legacy_price(self):
        Elements, Relations = self.Basic()
        Elements.append(Element("CC", "Product", SalePrice="500.00"))
        Relations.append(Edge("CC", "PP", "General"))
        Result = self.Calculate("PP", Elements, Relations)
        self.assertEqual(Result["Status"], "Incomplete")
        self.assertIsNone(Result["SalePrice"])
        self.assertTrue(any(Issue["Code"] == "MissingRequirements" and Issue["ElementId"] == "CC" for Issue in Result["Issues"]))

    def test_cycle_and_downstream_products_have_no_definitive_totals(self):
        Elements, Relations = self.Basic()
        Elements += [Element("AA", "Product"), Element("BB", "Product")]
        Relations += [Edge("AA", "BB", "General"), Edge("BB", "AA", "General"), Edge("AA", "PP", "General")]
        Result = self.Calculate("PP", Elements, Relations)
        self.assertEqual(Result["Status"], "Cycle")
        self.assertIsNone(Result["MinimumCost"])
        self.assertIsNone(Result["MaximumCost"])
        self.assertIsNone(Result["SalePrice"])
        self.assertEqual(Result["Cycle"][0], Result["Cycle"][-1])
        self.assertEqual(set(Result["Cycle"]), {"AA", "BB"})

    def test_unrelated_cycle_does_not_block_a_healthy_product(self):
        Elements, Relations = self.Basic()
        Elements += [Element("AA", "Product"), Element("BB", "Product")]
        Relations += [Edge("AA", "BB", "General"), Edge("BB", "AA", "General")]
        self.assertEqual(self.Calculate("PP", Elements, Relations)["Status"], "Ready")

    def test_unquantified_dependencies_and_empty_products_are_incomplete(self):
        Elements, Relations = self.Basic()
        for Extra in ([Edge("S1", "PP", "General")], [Edge("M2", "M1", "General")]):
            with self.subTest(Extra=Extra):
                Result = self.Calculate("PP", Elements, Relations + Extra)
                self.assertEqual(Result["Status"], "Incomplete")
                self.assertTrue(any(Issue["Code"] == "UnquantifiedDependency" for Issue in Result["Issues"]))
        Result = self.Calculate("PP", Elements, [])
        self.assertEqual(Result["Status"], "Incomplete")
        self.assertIsNone(Result["MinimumCost"])

    def test_deep_components_are_iterative(self):
        Elements = [Element("S1", "Supplier"), Element("M1", "Material")]
        Elements += [Element(f"P{Index}", "Product") for Index in range(1200)]
        Relations = [Edge("S1", "M1", "Offer", "2"), Edge("M1", "P0", "Requirement", "1")]
        Relations += [Edge(f"P{Index}", f"P{Index + 1}", "General") for Index in range(1199)]
        Result = self.Calculate("P1199", Elements, Relations)
        self.assertEqual(Result["MinimumCost"], "2.00")
        self.assertEqual(len(Result["Components"]), 1199)

    def test_large_valid_values_are_exact_without_default_decimal_rounding(self):
        Elements, Relations = self.Basic()
        Relations = [Edge("S1", "M1", "Offer", "9999999999999999.99"),
                     Edge("M1", "PP", "Requirement", "99999999999999.9999")]
        Result = self.Calculate("PP", Elements, Relations)
        with localcontext() as Context:
            Context.prec = 60
            Expected = Decimal("9999999999999999.99") * Decimal("99999999999999.9999")
            self.assertEqual(Result["MinimumCost"], f"{Expected:.2f}")

    def test_deterministic_output_and_no_input_mutation(self):
        Elements, Relations = self.Basic()
        Before = copy.deepcopy((Elements, Relations))
        Result = self.Calculate("PP", Elements, Relations)
        self.assertEqual(Result, self.Calculate("PP", list(reversed(Elements)), list(reversed(Relations))))
        self.assertEqual((Elements, Relations), Before)
        self.assertEqual(Elements[-1]["SalePrice"], "999.99")

    def test_unknown_or_nonproduct_id_is_rejected(self):
        Elements, Relations = self.Basic()
        with self.assertRaises(KeyError):
            CalculateProductCosts("UNKNOWN", Elements, Relations)
        with self.assertRaises(ValueError):
            CalculateProductCosts("M1", Elements, Relations)


if __name__ == "__main__":
    unittest.main()
