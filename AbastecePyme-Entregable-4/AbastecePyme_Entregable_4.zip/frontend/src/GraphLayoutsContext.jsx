import {createContext,useCallback,useContext,useEffect,useSyncExternalStore} from 'react';

const LayoutsContext=createContext(null);
const LocalSnapshot=Object.freeze({Ready:true,Positions:undefined,Status:'Local',Error:'',CanRetry:false});
export function GraphLayoutsProvider({Store,children}){return <LayoutsContext.Provider value={Store}>{children}</LayoutsContext.Provider>;}

export function useSavedGraphLayout(LayoutKey){
  const Store=useContext(LayoutsContext),Enabled=!!Store&&!!LayoutKey;
  const Subscribe=useCallback(Listener=>Enabled?Store.Subscribe(LayoutKey,Listener):()=>{},[Store,LayoutKey,Enabled]);
  const Read=useCallback(()=>Enabled?Store.GetSnapshot(LayoutKey):LocalSnapshot,[Store,LayoutKey,Enabled]);
  const Snapshot=useSyncExternalStore(Subscribe,Read,Read);
  useEffect(()=>{if(Enabled)Store.Load(LayoutKey);},[Store,LayoutKey,Enabled]);
  const Commit=useCallback(Positions=>Enabled?Store.Commit(LayoutKey,Positions):true,[Store,LayoutKey,Enabled]);
  const Retry=useCallback(()=>{if(Enabled)return Store.Retry(LayoutKey);},[Store,LayoutKey,Enabled]);
  return {...Snapshot,Enabled,Commit,Retry};
}
