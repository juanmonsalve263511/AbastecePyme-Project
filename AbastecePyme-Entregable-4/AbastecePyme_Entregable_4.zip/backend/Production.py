"""Prerequisite-first Kahn traversal and an iterative DFS cycle witness.

All graph logic is implemented here without a graph library. A dependency is
SourceId (prerequisite) -> TargetId (dependent), regardless of monetary weight.
"""


def FindCycle(Adjacency, Remaining):
    """Return one closed directed path, never downstream-only blocked nodes."""
    Finished = set()
    for Start in sorted(Remaining):
        if Start in Finished:
            continue
        Path = [Start]
        Active = {Start: 0}
        Stack = [iter(Adjacency[Start])]
        while Stack:
            Target = next(Stack[-1], None)
            if Target is None:
                Completed = Path.pop()
                Finished.add(Completed)
                del Active[Completed]
                Stack.pop()
            elif Target in Active:
                return Path[Active[Target]:] + [Target]
            elif Target in Remaining and Target not in Finished:
                Active[Target] = len(Path)
                Path.append(Target)
                Stack.append(iter(Adjacency[Target]))
    return []


def BuildProductionPlan(Elements, Relations, ProductId=None):
    Mapping = {Item["ElementId"]: Item for Item in Elements}
    if len(Mapping) != len(Elements):
        raise ValueError("Duplicate element identifiers")
    Adjacency = {Id: set() for Id in Mapping}
    Incoming = {Id: set() for Id in Mapping}
    Edges = {}
    for Relation in Relations:
        Source, Target = Relation["SourceId"], Relation["TargetId"]
        if Source not in Mapping or Target not in Mapping:
            raise ValueError("Dependency references a missing element")
        Adjacency[Source].add(Target)
        Incoming[Target].add(Source)
        Edges[(Source, Target)] = Relation

    Included = set(Mapping)
    if ProductId is not None:
        if ProductId not in Mapping:
            raise KeyError(ProductId)
        if Mapping[ProductId]["ElementType"] != "Product":
            raise ValueError("Select a product for a scoped production plan")
        Included, Pending = {ProductId}, [ProductId]
        while Pending:
            Current = Pending.pop()
            for Source in Incoming[Current]:
                if Source not in Included:
                    Included.add(Source)
                    Pending.append(Source)

    OrderedIds = sorted(Included)
    Adjacency = {Id: sorted(Adjacency[Id] & Included) for Id in OrderedIds}
    Degrees = {Id: len(Incoming[Id] & Included) for Id in OrderedIds}
    Ready = [Id for Id in OrderedIds if Degrees[Id] == 0]
    Order, Stages = [], []
    while Ready:
        Stages.append(Ready)
        Next = []
        for Current in Ready:
            Order.append(Current)
            for Target in Adjacency[Current]:
                Degrees[Target] -= 1
                if Degrees[Target] == 0:
                    Next.append(Target)
        Ready = sorted(Next)

    Remaining = {Id for Id in OrderedIds if Degrees[Id] > 0}
    Cycle = FindCycle(Adjacency, Remaining) if Remaining else []
    Graph = {"Elements": [dict(Mapping[Id]) for Id in OrderedIds],
             "Relations": [dict(Edges[Key]) for Key in sorted(Edges)
                           if Key[0] in Included and Key[1] in Included]}
    return {
        "Status": "Cycle" if Remaining else "Ready" if Included else "Empty",
        "Scope": "Product" if ProductId is not None else "Network",
        "ProductId": ProductId,
        "Algorithm": "KahnWithIterativeCycleSearch",
        "Order": [] if Remaining else Order,
        "Stages": [] if Remaining else Stages,
        "Cycle": Cycle,
        "CycleRelations": [dict(Edges[(Source, Target)]) for Source, Target in zip(Cycle, Cycle[1:])],
        "Unresolved": sorted(Remaining),
        "Summary": {"Elements": len(Included), "Relations": len(Graph["Relations"]),
                    "Stages": 0 if Remaining else len(Stages)},
        "Graph": Graph,
    }
