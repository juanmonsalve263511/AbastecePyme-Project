import unittest
import hashlib
from pathlib import Path
from tests import IntegrationContext
from backend.Schema import Migrate, ImportCatalogue
from backend.Catalog import ReadCatalogue

class MigrationTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        Migrate(IntegrationContext.Database, Path('data/catalogo.json'))

    def test_repeated_migration_preserves_current_catalogue(self):
        Database = IntegrationContext.Database
        PathToCatalogue = Path("data/catalogo.json")
        Before = ReadCatalogue(Database)
        Migrate(Database, PathToCatalogue)
        Migrate(Database, PathToCatalogue)
        self.assertEqual(ReadCatalogue(Database), Before)
        with Database.Transaction() as Connection:
            SourceHash = Connection.execute(
                "SELECT SourceHash FROM Migrations WHERE MigrationId='InitialCatalogue'").fetchone()[0]
        self.assertEqual(SourceHash, hashlib.sha256(PathToCatalogue.read_bytes()).hexdigest())

    def test_transaction_rollback(self):
        Database = IntegrationContext.Database
        try:
            with Database.Transaction() as Connection:
                Connection.execute("INSERT INTO Elements(ElementId,Name,ElementType) VALUES (?,?,?)",
                                   "TEST-ROLLBACK","Temporary","Material")
                raise RuntimeError("Injected failure")
        except RuntimeError:
            pass
        with Database.Transaction() as Connection:
            self.assertEqual(Connection.execute("SELECT COUNT(*) FROM Elements WHERE ElementId=?","TEST-ROLLBACK").fetchone()[0],0)

    def test_failed_import_rolls_back(self):
        Invalid = {"elementos":[{"id":"TEST-IMPORT","nombre":"Temporary","tipo":"proveedor"}],
                   "dependencias":[{"origen":"TEST-IMPORT","destino":"MISSING"}]}
        with self.assertRaises(ValueError):
            with IntegrationContext.Database.Transaction() as Connection:
                ImportCatalogue(Connection, Invalid)
        with IntegrationContext.Database.Transaction() as Connection:
            self.assertEqual(Connection.execute("SELECT COUNT(*) FROM Elements WHERE ElementId=?","TEST-IMPORT").fetchone()[0],0)


