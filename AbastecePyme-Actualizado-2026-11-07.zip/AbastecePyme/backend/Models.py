"""Strict public request contracts."""
import re
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator
from backend.Estimates import ParseDecimal

class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid")

class SalePriceFields(StrictModel):
    SalePrice: str | None = Field(default=None,max_length=40,strict=True)
    IsPriceReference: bool = Field(default=True,strict=True)

    @field_validator("SalePrice")
    @classmethod
    def CheckSalePrice(cls, Value):
        return str(ParseDecimal(Value,2,False)) if Value is not None else None

class ElementCreate(SalePriceFields):
    ElementId: str = Field(pattern=r"^[A-Z][A-Z0-9_-]{1,39}$")
    Name: str = Field(min_length=2,max_length=80)
    ElementType: Literal["Supplier","Material","Product"]
    Description: str = Field(default="",max_length=1000)
    Contact: str = Field(default="",max_length=160)
    UnitCode: str = Field(default="unidad",min_length=1,max_length=30)

    @model_validator(mode="after")
    def CheckProductPrice(self):
        if self.ElementType != "Product" and {"SalePrice","IsPriceReference"} & self.model_fields_set:
            raise ValueError("El precio de venta corresponde únicamente a productos.")
        return self

    @field_validator("Name","UnitCode",mode="before")
    @classmethod
    def CleanText(cls, Value):
        Value = Value.strip() if isinstance(Value,str) else Value
        if not Value:
            raise ValueError("Campo vacío.")
        return Value

class ElementEdit(SalePriceFields):
    Version: int = Field(ge=1,strict=True)
    Name: str | None = Field(default=None,min_length=2,max_length=80)
    Description: str | None = Field(default=None,max_length=1000)
    Contact: str | None = Field(default=None,max_length=160)
    UnitCode: str | None = Field(default=None,min_length=1,max_length=30)

    @field_validator("Name","UnitCode",mode="before")
    @classmethod
    def CleanText(cls, Value):
        if isinstance(Value,str) and not Value.strip():
            raise ValueError("Campo vacío.")
        return Value.strip() if isinstance(Value,str) else Value

class RelationCreate(StrictModel):
    SourceId: str = Field(pattern=r"^[A-Z][A-Z0-9_-]{1,39}$")
    TargetId: str = Field(pattern=r"^[A-Z][A-Z0-9_-]{1,39}$")
    Value: str | None = Field(default=None,max_length=40)
    IsDemo: bool = Field(default=False,strict=True)

class RelationEdit(RelationCreate):
    Version: int = Field(ge=1,strict=True)

class LoginBody(StrictModel):
    Username: str = Field(min_length=1,max_length=40)
    Password: str = Field(min_length=1,max_length=128)

class Registration(StrictModel):
    Username: str = Field(pattern=r"^[A-Za-z0-9_-]{3,40}$")
    DisplayName: str = Field(min_length=2,max_length=80)
    Password: str = Field(min_length=12,max_length=128)

    @field_validator("DisplayName",mode="before")
    @classmethod
    def CleanName(cls, Value):
        return Value.strip() if isinstance(Value,str) else Value

class AccountEdit(StrictModel):
    DisplayName: str = Field(min_length=2,max_length=80)
    Email: str = Field(default="",max_length=254)

    @field_validator("DisplayName","Email",mode="before")
    @classmethod
    def CleanText(cls, Value):
        return Value.strip() if isinstance(Value,str) else Value

    @field_validator("Email")
    @classmethod
    def CheckEmail(cls, Value):
        if Value and not re.fullmatch(r"[^\s@]+@[^\s@]+\.[^\s@]+",Value):
            raise ValueError("Correo inválido.")
        return Value

class PasswordEdit(StrictModel):
    CurrentPassword: str = Field(min_length=1,max_length=128)
    NewPassword: str = Field(min_length=12,max_length=128)

class UserEdit(StrictModel):
    RoleName: Literal["Administrator","Editor","Viewer"]
    IsActive: bool = Field(strict=True)
    Version: int = Field(ge=1,strict=True)


class UserCreate(Registration):
    RoleName: Literal["Administrator", "Editor", "Viewer"] = "Viewer"
    Email: str = Field(default="", max_length=254)

    @field_validator("Email", mode="before")
    @classmethod
    def CleanEmail(cls, Value):
        return Value.strip() if isinstance(Value, str) else Value

    @field_validator("Email")
    @classmethod
    def CheckEmail(cls, Value):
        return AccountEdit.CheckEmail(Value)


class SubscriptionCreate(StrictModel):
    Email: str = Field(min_length=3, max_length=254)
    Consent: bool = Field(strict=True)

    @field_validator("Email", mode="before")
    @classmethod
    def CleanEmail(cls, Value):
        return Value.strip().lower() if isinstance(Value, str) else Value

    @field_validator("Email")
    @classmethod
    def CheckEmail(cls, Value):
        return AccountEdit.CheckEmail(Value)

    @field_validator("Consent")
    @classmethod
    def CheckConsent(cls, Value):
        if not Value:
            raise ValueError("Se requiere autorización para guardar el correo.")
        return Value


class ContactCreate(StrictModel):
    FullName: str = Field(min_length=2, max_length=80)
    Email: str = Field(min_length=3, max_length=254)
    Phone: str = Field(default="", max_length=25)
    Company: str = Field(default="", max_length=100)
    Subject: str = Field(min_length=3, max_length=80)
    Message: str = Field(min_length=20, max_length=2000)
    Consent: bool = Field(strict=True)

    @field_validator("FullName", "Email", "Phone", "Company", "Subject", "Message", mode="before")
    @classmethod
    def CleanText(cls, Value):
        return Value.strip() if isinstance(Value, str) else Value

    @field_validator("Email")
    @classmethod
    def CheckEmail(cls, Value):
        return AccountEdit.CheckEmail(Value).lower()

    @field_validator("Phone")
    @classmethod
    def CheckPhone(cls, Value):
        if Value and (not re.fullmatch(r"[+()0-9 .-]+", Value) or not 7 <= sum(Character.isdigit() for Character in Value) <= 15):
            raise ValueError("Teléfono inválido.")
        return Value

    @field_validator("Consent")
    @classmethod
    def CheckConsent(cls, Value):
        if not Value:
            raise ValueError("Se requiere autorización para guardar la solicitud.")
        return Value


