"""Focused R09 measurements; retain the original research script and evidence.

Run explicitly with --output and a NEW JSON path. Nothing runs on import.
Uses the original deterministic chain and median-of-three implementation.
Timing and planner instrumentation are separate; the instrumented run is not
part of the median. No database, HTTP, credentials or source changes occur.
"""
import argparse
import hashlib
import json
from pathlib import Path
import sys


Root = Path(__file__).resolve().parents[2]


def Main():
    Parser = argparse.ArgumentParser(description=__doc__)
    Parser.add_argument("--output", type=Path, required=True)
    Parser.add_argument("--label", required=True)
    Arguments = Parser.parse_args()
    Output = Arguments.output.resolve()
    if not Output.is_relative_to(Root) or Output.exists():
        raise ValueError("Choose a new output file inside the project; existing evidence is never overwritten.")
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(Root))
    from unittest.mock import patch
    from BenchmarkResearch2026 import SyntheticChain, Measure, JsonBytes, ReadEnvironment
    from backend.ProductCosts import CalculateCatalogueCosts, CalculateProductCosts
    from backend.Production import BuildProductionPlan
    Results = []
    for Count in (100, 300, 1000):
        Digests = []
        for Scenario in ("Typed", "DisconnectedGeneral"):
            Data = SyntheticChain(Count, Other=Scenario == "DisconnectedGeneral")
            Elapsed, Summary = Measure(lambda: CalculateCatalogueCosts(**Data))
            with patch("backend.ProductCosts.BuildProductionPlan", wraps=BuildProductionPlan) as Planner:
                Instrumented = CalculateCatalogueCosts(**Data)
            assert Summary == Instrumented
            Detail = CalculateProductCosts(f"P{Count - 1:04}", **Data)
            Digest = hashlib.sha256(JsonBytes({"Summaries": Summary, "LastProductDetail": Detail})).hexdigest()
            Digests.append(Digest)
            Results.append({"Products": Count, "Scenario": Scenario, "MedianMilliseconds": Elapsed,
                            "FullProductionPlanCalls": Planner.call_count, "SummaryAndDetailSha256": Digest})
        assert Digests[0] == Digests[1], "A disconnected dependency must not change any product summary or selected detail."
    Evidence = {"Label": Arguments.label, "Environment": ReadEnvironment(),
                "Method": "Original SyntheticChain and Measure; median of 3 timed runs, separate untimed call instrumentation.",
                "OriginalEvidence": "docs/research/benchmark-research-2026.json",
                "OriginalFixtureScript": "tests/benchmarks/BenchmarkResearch2026.py",
                "ProductCostsSha256": hashlib.sha256((Root / "backend/ProductCosts.py").read_bytes()).hexdigest(),
                "Results": Results,
                "Limitations": ["Synthetic in-process timings, not MariaDB/network or actual customer latency.",
                                "The full check is deliberately retained for products reached by non-quantified dependencies."]}
    Output.parent.mkdir(parents=True, exist_ok=True)
    Output.write_text(json.dumps(Evidence, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"Output": str(Output), "Results": Results}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    Main()
