"""Isolated fixtures; never loaded by the production launcher."""
