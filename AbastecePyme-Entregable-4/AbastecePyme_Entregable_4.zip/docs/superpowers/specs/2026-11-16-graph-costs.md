# Grafo y costos — alcance del 16 de noviembre de 2026

El usuario solicita foco predeterminado para el tablero, flechas continuas, comparación de abastecimiento mínimo/máximo y columnas de costo/venta.

Confirmación recibida: usar el costo mínimo +25% y una unidad por componente. Los datos disponibles no incluyen mano de obra, transporte ni impuestos.

- El foco del tablero usa el subgrafo completo de impacto calculado por Python, incluyendo todos los saltos. Se puede alternar con la red completa. El ciclo conserva su testigo real.
- Las flechas se desplazan del requisito a su dependiente indefinidamente; permiten pausa y respetan movimiento reducido.
- Python agrega materiales directos e indirectos. Cada arista producto-componente aporta una unidad; un componente usado en dos ramas cuenta dos veces.
- Para cada material agregado se elige una oferta mínima y máxima, con desempate determinista. Se redondea cada subtotal a dos decimales HALF_UP y se suman los subtotales. Venta = mínimo publicado ×1.25, HALF_UP.
- Ciclos o requisitos sin precio/cantidad impiden publicar totales y venta definitivos. Cero es válido cuando las ofertas son gratuitas.
- Las columnas usan costos derivados actuales; los precios históricos guardados permanecen por compatibilidad, fuera de las vistas nuevas. No hay migración ni escritura masiva.
- El detalle compara proveedores, materiales, cantidades y componentes del catálogo completo, aunque el grafo visual esté enfocado. No se mezcla con un escenario temporal del tablero.

Validación: pruebas de mínimos/máximos, componentes compartidos, ciclos, ausencia de ofertas, redondeo, permisos, foco, animación, navegación real y pantallas pequeñas. Se reutilizan skills instaladas y datos de prueba aislados.
