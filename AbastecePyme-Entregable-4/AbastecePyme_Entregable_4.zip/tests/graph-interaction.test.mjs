import test from 'node:test';
import assert from 'node:assert/strict';
import {SelectNodeIds,NodesInRectangle,MoveNodePositions} from '../frontend/src/components/GraphInteraction.js';
import {BuildLayout,ApplyNodePositions,EdgePath,EdgeLabelPosition,FitGraphView} from '../frontend/src/components/GraphLayout.js';

const Elements=[['S','Supplier'],['M','Material'],['P','Product'],['P2','Product']].map(([ElementId,ElementType])=>Object.freeze({ElementId,ElementType,Name:ElementId}));
const Relations=[['S','M','Offer','0.00'],['M','P','Requirement','2.0000'],['P','P2','General',null],['P2','P','General',null],['P2','P2','General',null]].map(([SourceId,TargetId,RelationType,Value])=>Object.freeze({SourceId,TargetId,RelationType,Value}));
const Network=()=>BuildLayout(Elements,Relations,'',true);
const Point=(X,Y)=>Object.freeze({X,Y});
function Contains(View,X,Y){assert.ok(X>=View.X&&X<=View.X+View.Width&&Y>=View.Y&&Y<=View.Y+View.Height,JSON.stringify({View,X,Y}));}

test('plain node selection replaces the group without mutating the previous selection',()=>{
  const Before=new Set(['S','M']),After=SelectNodeIds(Before,'P');
  assert.deepEqual([...After],['P']);assert.deepEqual([...Before],['S','M']);assert.notEqual(After,Before);
});

test('toggle selection adds and removes nodes, including the last one',()=>{
  const Start=new Set(['S']),Added=SelectNodeIds(Start,'M',true),Removed=SelectNodeIds(Added,'S',true);
  assert.deepEqual([...Added],['S','M']);assert.deepEqual([...Removed],['M']);
  assert.equal(SelectNodeIds(Removed,'M',true).size,0);assert.deepEqual([...Start],['S']);
  assert.deepEqual([...SelectNodeIds(Start,'',true)],['S']);
});

test('rectangle selection intersects the full node box inclusively in every drag direction',()=>{
  const Nodes=[{ElementId:'A',X:10,Y:20},{ElementId:'B',X:400,Y:20},{ElementId:'C',X:10,Y:200}];
  for(const [Start,End] of [[Point(258,84),Point(300,120)],[Point(300,120),Point(258,84)],[Point(258,120),Point(300,84)],[Point(300,84),Point(258,120)]]){
    assert.deepEqual([...NodesInRectangle(Nodes,Start,End)],['A']);
  }
  assert.deepEqual([...NodesInRectangle(Nodes,Point(15,25),Point(15,25))],['A']);
  assert.equal(NodesInRectangle(Nodes,Point(259,85),Point(300,120)).size,0);
});

test('rectangle selection supports negative coordinates and skips malformed geometry',()=>{
  const Nodes=[{ElementId:'NEGATIVE',X:-400,Y:-300},{ElementId:'INVALID',X:NaN,Y:0}];
  assert.deepEqual([...NodesInRectangle(Nodes,Point(-200,-250),Point(-190,-245))],['NEGATIVE']);
  assert.equal(NodesInRectangle(Nodes,Point(NaN,0),Point(20,20)).size,0);
  assert.equal(NodesInRectangle(Nodes,Point(0,0),Point(Infinity,20)).size,0);
});

test('moving a group translates saved and automatic positions by the same SVG delta',()=>{
  const Layout=Network(),Positions=new Map([['S',Point(-200,-100)],['HIDDEN',Point(900,800)]]),Before=structuredClone(Layout);
  const Delta=Point(31.5,-44.25),Moved=MoveNodePositions(Layout,new Set(['S','M']),Delta,Positions);
  assert.deepEqual(Moved.get('S'),{X:-168.5,Y:-144.25});
  assert.deepEqual(Moved.get('M'),{X:Layout.Map.get('M').X+31.5,Y:Layout.Map.get('M').Y-44.25});
  assert.equal(Moved.get('M').X-Moved.get('S').X,Layout.Map.get('M').X-Positions.get('S').X);
  assert.equal(Moved.get('M').Y-Moved.get('S').Y,Layout.Map.get('M').Y-Positions.get('S').Y);
  assert.deepEqual([...Positions],[['S',{X:-200,Y:-100}],['HIDDEN',{X:900,Y:800}]]);
  assert.equal(Moved.get('HIDDEN'),Positions.get('HIDDEN'));assert.deepEqual(Layout,Before);
});

test('drag updates use the captured starting positions instead of accumulating previous deltas',()=>{
  const Layout=Network(),Positions=new Map([['P',Point(500,200)]]),Ids=new Set(['P','M']);
  const First=MoveNodePositions(Layout,Ids,Point(10,5),Positions),Second=MoveNodePositions(Layout,Ids,Point(20,7),Positions);
  assert.deepEqual(First.get('P'),{X:510,Y:205});assert.deepEqual(Second.get('P'),{X:520,Y:207});
  assert.equal(Second.get('M').X,Layout.Map.get('M').X+20);
});

test('hidden and unknown selected IDs keep their positions without becoming visible movement targets',()=>{
  const Layout=BuildLayout(Elements,Relations,'S'),Positions=new Map([['P2',Point(-100,300)]]);
  const Moved=MoveNodePositions(Layout,new Set(['S','P2','MISSING']),Point(-20,30),Positions);
  assert.deepEqual(Moved.get('P2'),{X:-100,Y:300});assert.equal(Moved.has('MISSING'),false);
  assert.deepEqual(Moved.get('S'),{X:Layout.Map.get('S').X-20,Y:Layout.Map.get('S').Y+30});
});

test('invalid or zero deltas do not create positions and finite overflow cannot partially move a group',()=>{
  const Layout=Network(),Positions=new Map([['S',Point(Number.MAX_VALUE,0)]]);
  for(const Delta of [Point(NaN,2),Point(2,Infinity),Point(0,0),Point(Number.MAX_VALUE,0)]){
    assert.equal(MoveNodePositions(Layout,new Set(['S','M']),Delta,Positions),Positions);
  }
  assert.equal(MoveNodePositions(Layout,new Set(['MISSING']),Point(10,10),Positions),Positions);
});

test('applying visible manual positions rebuilds node lookup without mutating the catalogue or base layout',()=>{
  const Base=Network(),Before=structuredClone(Base),Positions=new Map([['P',Point(-500,-300)]]);
  const Applied=ApplyNodePositions(Base,Positions);
  assert.notEqual(Applied,Base);assert.notEqual(Applied.Nodes,Base.Nodes);assert.notEqual(Applied.Map,Base.Map);
  assert.deepEqual(Applied.Map.get('P'),{...Base.Map.get('P'),X:-500,Y:-300});
  assert.equal(Applied.Map.get('S'),Base.Map.get('S'));assert.equal(Applied.Edges,Base.Edges);
  assert.deepEqual(Applied.Columns,[]);assert.deepEqual(Base,Before);assert.equal(Positions.size,1);
});

test('invisible or invalid positions retain the automatic layout and its headings',()=>{
  const Base=Network();
  for(const Positions of [new Map(),new Map([['MISSING',Point(10,20)]]),new Map([['P',Point(NaN,20)],['M',Point(0,Infinity)]])]){
    assert.equal(ApplyNodePositions(Base,Positions),Base);
  }
});

test('absolute positions survive hiding and restoring nodes even when automatic coordinates change',()=>{
  const Full=Network(),Positions=new Map([['P2',Point(-350,625)]]);
  const Focused=BuildLayout(Elements,Relations,'S');
  assert.equal(ApplyNodePositions(Focused,Positions),Focused);
  const Restored=ApplyNodePositions(Network(),Positions);
  assert.deepEqual({X:Restored.Map.get('P2').X,Y:Restored.Map.get('P2').Y},{X:-350,Y:625});
  const OtherFocus=ApplyNodePositions(BuildLayout(Elements,Relations,'P2'),Positions);
  assert.equal(OtherFocus.Map.get('P2').X,Restored.Map.get('P2').X);
  assert.equal(OtherFocus.Map.get('P2').Y,Restored.Map.get('P2').Y);
  assert.deepEqual(ApplyNodePositions(Full,new Map()).Columns,Full.Columns);
});

test('free positions keep edge direction and fit bounds contain moved nodes, curves, self-links and zero weights',()=>{
  const Base=Network(),Positions=new Map([['S',Point(1300,-500)],['M',Point(700,-200)],['P',Point(-300,300)],['P2',Point(-300,500)]]);
  const Layout=ApplyNodePositions(Base,Positions),View=FitGraphView(Layout,{Width:900,Height:500});
  assert.equal(Layout.Edges,Base.Edges);
  for(const Node of Layout.Nodes){Contains(View,Node.X,Node.Y);Contains(View,Node.X+248,Node.Y+64);}
  for(const Edge of Layout.Edges){
    const From=Layout.Map.get(Edge.SourceId),To=Layout.Map.get(Edge.TargetId);
    const Points=EdgePath(From,To).match(/-?\d+(?:\.\d+)?/g).map(Number);
    for(let Index=0;Index<Points.length;Index+=2)Contains(View,Points[Index],Points[Index+1]);
    if(Edge.SourceId==='S'){assert.deepEqual(Points.slice(0,2),[1300,-468]);assert.deepEqual(Points.slice(-2),[948,-168]);}
    if(Edge.Value!=null){const Label=EdgeLabelPosition(From,To);Contains(View,Label.X-72,Label.Y-15);Contains(View,Label.X+72,Label.Y+15);}
  }
  assert.ok(Object.values(Layout.Bounds).every(Number.isFinite));
});

test('positions that overflow the complete bounds cannot introduce an infinite viewport',()=>{
  const Base=Network(),Positions=new Map([['S',Point(-Number.MAX_VALUE,0)],['P',Point(Number.MAX_VALUE,0)]]);
  assert.equal(ApplyNodePositions(Base,Positions),Base);
});

import * as Interaction from '../frontend/src/components/GraphInteraction.js';

test('keyboard movement from the canvas preserves the area-selected group instead of the detail node',()=>{
  const Layout=Network(),Group=new Set(['P','P2']);
  const Ids=Interaction.KeyboardMoveIds(Group,undefined,'S');
  assert.equal(Ids,Group);
  const Moved=MoveNodePositions(Layout,Ids,Point(20,0));
  assert.equal(Moved.has('S'),false);
  assert.equal(Moved.get('P').X,Layout.Map.get('P').X+20);
  assert.equal(Moved.get('P2').X,Layout.Map.get('P2').X+20);
  assert.equal(ApplyNodePositions(Layout,Moved).Map.get('S'),Layout.Map.get('S'));
  assert.deepEqual([...Group],['P','P2']);
});

test('a real focused node moves its current group or replaces an unrelated group',()=>{
  const Group=new Set(['P','P2']);
  assert.equal(Interaction.KeyboardMoveIds(Group,'P2','S'),Group);
  assert.deepEqual([...Interaction.KeyboardMoveIds(Group,'M','S')],['M']);
  assert.deepEqual([...Group],['P','P2']);
});

test('keyboard detail fallback applies only when there is neither a focused node nor a selected group',()=>{
  const Empty=new Set();
  assert.deepEqual([...Interaction.KeyboardMoveIds(Empty,undefined,'S')],['S']);
  assert.deepEqual([...Interaction.KeyboardMoveIds(Empty,'M','S')],['M']);
  assert.equal(Interaction.KeyboardMoveIds(Empty,undefined,undefined).size,0);
  assert.equal(Empty.size,0);
});
