export const Operations={
  Catalog:['Catálogo y relaciones','GET'],Graph:['Datos del grafo','GET'],
  Impact:['Análisis de impacto','GET'],Estimate:['Estimación de materiales','GET'],Production:['Orden y ciclos de producción','GET'],
  SupplyBoard:['Análisis del tablero','POST'],
  CreateElement:['Crear un elemento','POST'],EditElement:['Actualizar un elemento','PATCH'],DeleteElement:['Eliminar un elemento','DELETE'],
  CreateRelation:['Crear una relación','POST'],EditRelation:['Actualizar una relación','PATCH'],DeleteRelation:['Eliminar una relación','DELETE']
};
export function GetOperationSettings(Operation){
  if(!Object.hasOwn(Operations,Operation))throw new Error('Selecciona una operación válida.');
  const Method=Operations[Operation][1];
  return {Method,Writes:Method!=='GET'&&Operation!=='SupplyBoard',HasBody:Method!=='GET'&&Operation!=='DeleteElement'};
}
export function BuildApiRequest(Operation,Selection={},Text=''){
  const {Method,Writes}=GetOperationSettings(Operation);
  const Id=Selection.ElementId;let Path;let Body;
  if(['Impact','EditElement','DeleteElement'].includes(Operation)&&!Id)throw new Error('Selecciona un elemento.');
  if(Operation==='Catalog'||Operation==='Graph')Path='/api/'+Operation.toLowerCase();
  else if(Operation==='Production')Path='/api/production'+(Selection.ProductId?'?ProductId='+encodeURIComponent(Selection.ProductId):'');
  else if(Operation==='Estimate'){if(!Selection.ProductId)throw new Error('Selecciona un producto.');Path='/api/products/'+encodeURIComponent(Selection.ProductId)+'/estimate';}
  else if(Operation==='Impact')Path='/api/impact/'+encodeURIComponent(Id)+'?Direction='+(Selection.Direction==='Requirements'?'Requirements':'Consequences');
  else if(Operation==='DeleteElement'){
    if(!Number.isSafeInteger(Selection.Version)||Selection.Version<1)throw new Error('Recarga el catálogo para obtener su versión.');
    Path='/api/elements/'+encodeURIComponent(Id)+'?Version='+Selection.Version;
  }else{
    try{Body=JSON.parse(Text);}catch{throw new Error('Revisa el JSON: usa comillas dobles y separa los campos con comas.');}
    if(!Body||Array.isArray(Body)||typeof Body!=='object')throw new Error('El cuerpo debe ser un objeto JSON.');
    Path=Operation==='SupplyBoard'?'/api/dashboard/analyze':Operation.endsWith('Relation')?'/api/relations':Operation==='CreateElement'?'/api/elements':'/api/elements/'+encodeURIComponent(Id);
  }
  return {Method,Path,...(Body!==undefined?{Body}:{}),Writes};
}
