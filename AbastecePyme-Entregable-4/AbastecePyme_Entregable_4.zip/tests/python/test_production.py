"""Acceptance cases for prerequisite-first production planning."""
import copy
import importlib
import unittest


def Element(Id, Kind="Product"):
    return {"ElementId": Id, "Name": "Name " + Id, "ElementType": Kind}


def Edge(Source, Target):
    return {"SourceId": Source, "TargetId": Target, "RelationType": "General", "Value": None}


class ProductionTests(unittest.TestCase):
    def Plan(self, Elements, Relations, ProductId=None):
        try:
            Module = importlib.import_module("backend.Production")
        except ModuleNotFoundError:
            self.fail("The production planning implementation is missing")
        return Module.BuildProductionPlan(Elements, Relations, ProductId)

    def test_acyclic_diamond_respects_every_prerequisite(self):
        Elements = [Element("AA"), Element("BB"), Element("CC"), Element("DD")]
        Relations = [Edge("AA", "BB"), Edge("AA", "CC"), Edge("BB", "DD"), Edge("CC", "DD")]
        Before = copy.deepcopy((Elements, Relations))
        Result = self.Plan(Elements, Relations)
        self.assertEqual(Result["Status"], "Ready")
        self.assertEqual(Result["Order"], ["AA", "BB", "CC", "DD"])
        self.assertEqual(Result["Stages"], [["AA"], ["BB", "CC"], ["DD"]])
        self.assertEqual(Result["Cycle"], [])
        self.assertEqual((Elements, Relations), Before)

    def test_cycle_has_a_closed_real_path_and_no_partial_order(self):
        Elements = [Element(Id) for Id in ["AA", "BB", "CC", "DD", "FREE"]]
        Relations = [Edge("AA", "BB"), Edge("BB", "CC"), Edge("CC", "AA"), Edge("CC", "DD")]
        Result = self.Plan(Elements, Relations)
        self.assertEqual(Result["Status"], "Cycle")
        self.assertEqual(Result["Order"], [])
        self.assertEqual(Result["Stages"], [])
        self.assertEqual(Result["Cycle"], ["AA", "BB", "CC", "AA"])
        self.assertEqual(Result["Unresolved"], ["AA", "BB", "CC", "DD"])
        self.assertEqual(len(Result["CycleRelations"]), 3)
        self.assertNotIn("DD", Result["Cycle"])

    def test_target_scope_ignores_unrelated_cycle_but_not_its_requirements(self):
        Elements = [Element("SUP", "Supplier"), Element("MAT", "Material"), Element("PROD"), Element("XX"), Element("YY")]
        Relations = [Edge("SUP", "MAT"), Edge("MAT", "PROD"), Edge("XX", "YY"), Edge("YY", "XX")]
        self.assertEqual(self.Plan(Elements, Relations)["Status"], "Cycle")
        Result = self.Plan(Elements, Relations, "PROD")
        self.assertEqual(Result["Order"], ["SUP", "MAT", "PROD"])
        Relations.append(Edge("YY", "MAT"))
        self.assertEqual(self.Plan(Elements, Relations, "PROD")["Status"], "Cycle")

    def test_empty_and_isolated_elements_are_valid(self):
        self.assertEqual(self.Plan([], [])["Status"], "Empty")
        Result = self.Plan([Element("ZZ"), Element("AA")], [])
        self.assertEqual(Result["Stages"], [["AA", "ZZ"]])
        self.assertEqual(Result["Order"], ["AA", "ZZ"])

    def test_self_cycle_is_reported(self):
        self.assertEqual(self.Plan([Element("AA")], [Edge("AA", "AA")])["Cycle"], ["AA", "AA"])

    def test_long_graph_and_cycle_do_not_depend_on_recursion_limit(self):
        Elements = [Element(f"N{Index:04}") for Index in range(1500)]
        Relations = [Edge(f"N{Index:04}", f"N{Index+1:04}") for Index in range(1499)]
        self.assertEqual(len(self.Plan(Elements, Relations)["Order"]), 1500)
        Relations.append(Edge("N1499", "N0000"))
        self.assertEqual(len(self.Plan(Elements, Relations)["Cycle"]), 1501)

    def test_invalid_graph_and_target_fail_explicitly(self):
        with self.assertRaises(ValueError):
            self.Plan([Element("AA")], [Edge("AA", "MISSING")])
        with self.assertRaises(ValueError):
            self.Plan([Element("AA"), Element("AA")], [])
        with self.assertRaises(KeyError):
            self.Plan([Element("AA")], [], "MISSING")
        with self.assertRaises(ValueError):
            self.Plan([Element("SUP", "Supplier")], [], "SUP")

    def test_duplicate_edges_do_not_create_false_cycles(self):
        Result = self.Plan([Element("AA"), Element("BB")], [Edge("AA", "BB"), Edge("AA", "BB")])
        self.assertEqual(Result["Order"], ["AA", "BB"])

    def test_result_is_deterministic_when_input_order_changes(self):
        Elements = [Element(Id) for Id in ["AA", "BB", "CC", "DD"]]
        Relations = [Edge("AA", "BB"), Edge("BB", "CC"), Edge("CC", "AA"), Edge("AA", "DD")]
        self.assertEqual(self.Plan(Elements, Relations), self.Plan(list(reversed(Elements)), list(reversed(Relations))))
