"""Run isolated Python/JavaScript checks and compile without a live database."""
import argparse
import os
from pathlib import Path
import shutil
import subprocess
import sys
from tempfile import TemporaryDirectory

Root = Path(__file__).resolve().parent


def RunSteps(Steps, WorkingDirectory, Environment=None):
    for Label, Command in Steps:
        print(f"\n{Label}", flush=True)
        Result = subprocess.run(Command, cwd=WorkingDirectory, env=Environment, check=False)
        if Result.returncode:
            print(f"La verificación se detuvo: {Label}.", file=sys.stderr, flush=True)
            return Result.returncode
    return 0


def Main():
    Parser = argparse.ArgumentParser(description="Verificar el proyecto sin MySQL ni un servidor abierto.")
    Parser.add_argument("--skip-build", action="store_true", help="Ejecutar las pruebas sin recompilar la interfaz.")
    Arguments = Parser.parse_args()
    Node = shutil.which("node")
    if not Node and (Root / "runtime" / "node.exe").is_file():
        Node = str(Root / "runtime" / "node.exe")
    if not Node:
        print("Falta Node.js 22.12 o posterior. Instálalo y ejecuta Instalar.cmd.", file=sys.stderr)
        return 1
    Vite = Root / "frontend" / "node_modules" / "vite" / "bin" / "vite.js"
    if not Arguments.skip_build and not Vite.is_file():
        print("Faltan dependencias de la interfaz. Ejecuta Instalar.cmd.", file=sys.stderr)
        return 1
    print("Sintaxis Python", flush=True)
    try:
        for File in sorted({*Root.glob("*.py"), *Root.glob("backend/*.py"), *Root.glob("tests/**/*.py")}):
            compile(File.read_text(encoding="utf-8-sig"), str(File), "exec")
    except (OSError, SyntaxError) as Error:
        print(f"No se pudo comprobar la sintaxis Python: {Error}", file=sys.stderr)
        return 1
    # Keep test files and build output away from the working catalogue and dist.
    with TemporaryDirectory(prefix=".verify-", dir=Root) as Folder:
        Environment = os.environ.copy()
        Environment.update(TEMP=Folder, TMP=Folder, TMPDIR=Folder, PYTHONDONTWRITEBYTECODE="1")
        SyntaxFiles = sorted({*Root.glob("*.mjs"), *Root.glob("src/*.js"),
                              *Root.glob("public/*.js"), *Root.glob("frontend/src/**/*.js")})
        NodeTests = sorted({*Root.glob("tests/*.test.js"), *Root.glob("tests/*.test.mjs")})
        Steps = [("Sintaxis: " + str(File.relative_to(Root)), [Node, "--check", str(File)]) for File in SyntaxFiles]
        Steps.extend([
            ("Pruebas Python sin MariaDB", [sys.executable, "-m", "unittest", "discover", "-s", "tests/python", "-v"]),
            ("Pruebas JavaScript y regresión de la versión anterior", [Node, "--test", *map(str, NodeTests)]),
        ])
        if not Arguments.skip_build:
            Steps.append(("Compilación de la interfaz en carpeta temporal", [
                Node, str(Vite), "build", str(Root / "frontend"),
                "--outDir", str(Path(Folder) / "build"), "--emptyOutDir",
            ]))
        try:
            Result = RunSteps(Steps, Root, Environment)
        except OSError as Error:
            print(f"No se pudo ejecutar una comprobación: {Error}", file=sys.stderr)
            return 1
        if Result:
            return Result
    print("\nVerificación correcta. La integración MariaDB y la revisión visual se ejecutan por separado.")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(Main())
    except KeyboardInterrupt:
        print("\nVerificación cancelada.", file=sys.stderr)
        sys.exit(130)
