"""Transactional catalogue operations with optimistic versions."""
from fastapi import HTTPException
from backend.Database import Rows
from backend.Revisions import NextRevision
from backend.ProductCosts import CalculateCatalogueCosts

ElementQuery = """SELECT e.ElementId,e.Name,e.ElementType,e.Description,e.Version,
COALESCE(s.Contact,'') AS Contact,COALESCE(m.UnitCode,'') AS UnitCode,
p.SalePrice,COALESCE(p.IsPriceReference,1) AS IsPriceReference
FROM Elements e LEFT JOIN Suppliers s ON s.ElementId=e.ElementId
LEFT JOIN Materials m ON m.ElementId=e.ElementId
LEFT JOIN ProductPrices p ON p.ElementId=e.ElementId"""

RelationTables = (("SupplierOffers", "SupplierId", "MaterialId"),
                  ("ProductRequirements", "MaterialId", "ProductId"),
                  ("GeneralDependencies", "SourceId", "TargetId"))

def ElementRows(Cursor):
    Items = Rows(Cursor)
    for Item in Items:
        Item["SalePrice"] = str(Item["SalePrice"]) if Item["SalePrice"] is not None else None
        Item["IsPriceReference"] = bool(Item["IsPriceReference"])
    return Items

def SetSalePrice(Connection, ElementId, SalePrice, IsPriceReference):
    # Caller holds the element lock and updates its optimistic revision.
    Connection.execute("DELETE FROM ProductPrices WHERE ElementId=?",ElementId)
    if SalePrice is not None:
        Connection.execute("INSERT INTO ProductPrices(ElementId,SalePrice,IsPriceReference) VALUES (?,?,?)",
                           ElementId,SalePrice,int(IsPriceReference))

def GetElement(Connection, ElementId):
    Items = ElementRows(Connection.execute(ElementQuery+" WHERE e.ElementId=?",ElementId))
    if not Items:
        raise HTTPException(404,"Elemento no encontrado.")
    return Items[0]

def LockElement(Connection, ElementId, Version=None):
    Item = Connection.execute("SELECT ElementType,Version FROM Elements WHERE ElementId=? FOR UPDATE",ElementId).fetchone()
    if not Item:
        raise HTTPException(404,"Elemento no encontrado.")
    if Version is not None and Version != Item[1]:
        raise HTTPException(409,"El elemento o sus relaciones cambiaron. Recarga antes de continuar.")
    return Item[0]

def ReadRelations(Connection, ElementId=None):
    Queries = [
        "SELECT SupplierId AS SourceId,MaterialId AS TargetId,'Offer' AS RelationType,UnitPrice AS Value,IsDemo,Version FROM SupplierOffers",
        "SELECT MaterialId AS SourceId,ProductId AS TargetId,'Requirement' AS RelationType,Quantity AS Value,IsDemo,Version FROM ProductRequirements",
        "SELECT SourceId,TargetId,'General' AS RelationType,NULL AS Value,0 AS IsDemo,Version FROM GeneralDependencies"]
    Result = []
    for Query, (_, Left, Right) in zip(Queries, RelationTables):
        Arguments = ()
        if ElementId is not None:
            Query += f" WHERE {Left}=? OR {Right}=?"
            Arguments = (ElementId, ElementId)
        for Item in Rows(Connection.execute(Query, *Arguments)):
            Item["Value"] = str(Item["Value"]) if Item["Value"] is not None else None
            Item["IsDemo"] = bool(Item["IsDemo"])
            Result.append(Item)
    return sorted(Result,key=lambda Item:(Item["SourceId"],Item["TargetId"]))

def ReadCatalogue(Database, IncludeProductCosts=True):
    with Database.Transaction() as Connection:
        Data = {"Elements":ElementRows(Connection.execute(ElementQuery+" ORDER BY e.ElementType,e.Name,e.ElementId")),
                "Relations":ReadRelations(Connection)}
    # Derive from the same read snapshot, after releasing the transaction. The
    # manual SalePrice remains a separate historical field and is never an input.
    if IncludeProductCosts:
        Costs = CalculateCatalogueCosts(Data["Elements"], Data["Relations"])
        for Item in Data["Elements"]:
            if Item["ElementType"] == "Product":
                Item["ProductCosts"] = Costs[Item["ElementId"]]
    return Data

def CreateElement(Database, Body):
    with Database.Transaction() as Connection:
        Revision = NextRevision(Connection)
        Connection.execute("INSERT INTO Elements(ElementId,Name,ElementType,Description,Version) VALUES (?,?,?,?,?)",
                           Body.ElementId,Body.Name,Body.ElementType,Body.Description,Revision)
        if Body.ElementType == "Supplier":
            Connection.execute("INSERT INTO Suppliers(ElementId,Contact) VALUES (?,?)",Body.ElementId,Body.Contact)
        elif Body.ElementType == "Material":
            Connection.execute("INSERT INTO Materials(ElementId,UnitCode) VALUES (?,?)",Body.ElementId,Body.UnitCode)
        else:
            Connection.execute("INSERT INTO Products(ElementId) VALUES (?)",Body.ElementId)
            SetSalePrice(Connection,Body.ElementId,Body.SalePrice,Body.IsPriceReference)
        return GetElement(Connection,Body.ElementId)

def EditElement(Database, ElementId, Body):
    with Database.Transaction() as Connection:
        Revision = NextRevision(Connection)
        Kind = LockElement(Connection,ElementId,Body.Version)
        Existing = GetElement(Connection,ElementId)
        PriceFields = {"SalePrice","IsPriceReference"} & Body.model_fields_set
        if PriceFields and Kind != "Product":
            raise HTTPException(422,"El precio de venta corresponde únicamente a productos.")
        Data = Body.model_dump(exclude_none=True)
        Connection.execute("UPDATE Elements SET Name=?,Description=?,Version=? WHERE ElementId=?",
                           Data.get("Name",Existing["Name"]),Data.get("Description",Existing["Description"]),Revision,ElementId)
        if Kind == "Supplier" and "Contact" in Data:
            Connection.execute("UPDATE Suppliers SET Contact=? WHERE ElementId=?",Data["Contact"],ElementId)
        if Kind == "Material" and "UnitCode" in Data:
            Connection.execute("UPDATE Materials SET UnitCode=? WHERE ElementId=?",Data["UnitCode"],ElementId)
        if PriceFields:
            SalePrice = Body.SalePrice if "SalePrice" in PriceFields else Existing["SalePrice"]
            IsReference = Body.IsPriceReference if "IsPriceReference" in PriceFields else Existing["IsPriceReference"]
            SetSalePrice(Connection,ElementId,SalePrice,IsReference)
        return GetElement(Connection,ElementId)

def DeletePreview(Database, ElementId):
    with Database.Transaction() as Connection:
        Item = GetElement(Connection,ElementId)
        Count = sum(Connection.execute(f"SELECT COUNT(*) FROM {Table} WHERE {Left}=? OR {Right}=?",
                                      ElementId,ElementId).fetchone()[0]
                    for Table,Left,Right in RelationTables)
        return {"ElementId":ElementId,"Name":Item["Name"],"Version":Item["Version"],"RelationshipCount":Count}

def DeleteElement(Database, ElementId, Version):
    with Database.Transaction() as Connection:
        Revision = NextRevision(Connection)
        Kind = LockElement(Connection,ElementId,Version)
        Neighbors = {Edge["TargetId"] if Edge["SourceId"] == ElementId else Edge["SourceId"]
                     for Edge in ReadRelations(Connection,ElementId)}
        for Neighbor in sorted(Neighbors - {ElementId}):
            Connection.execute("UPDATE Elements SET Version=? WHERE ElementId=?",Revision,Neighbor)
        for Table, Left, Right in RelationTables:
            Connection.execute(f"DELETE FROM {Table} WHERE {Left}=? OR {Right}=?",ElementId,ElementId)
        Table = {"Supplier":"Suppliers","Material":"Materials","Product":"Products"}[Kind]
        if Kind == "Product":
            Connection.execute("DELETE FROM ProductPrices WHERE ElementId=?",ElementId)
        Connection.execute(f"DELETE FROM {Table} WHERE ElementId=?",ElementId)
        Connection.execute("DELETE FROM Elements WHERE ElementId=?",ElementId)
    return {"Detail":"Elemento eliminado."}

