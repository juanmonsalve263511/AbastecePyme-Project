# Feature 4 — Tablero de abastecimiento demostrable

Fecha: 14 de noviembre de 2026. El usuario autorizó el alcance propuesto y continuar con criterio propio, sin más preguntas.

## Objetivo y alcance

Integrar catálogo, impacto potencial y orden/ciclo en una pantalla comprensible para compras y producción. El brief exige además resaltar la consulta, adaptar un cambio de requisitos, aceptar cadena válida/elemento inexistente/dato inválido/ciclo, y entregar documentación, bitácora, video y pitch.

No se especificó otro cambio del instructor. El cambio acordado consiste en comparar la red guardada con una dependencia añadida o retirada temporalmente. La selección de un elemento representa una indisponibilidad hipotética: no elimina ese nodo ni confirma falta de inventario. El orden sigue siendo de precedencia estructural. Los proveedores alternativos no constituyen disponibilidad garantizada.

## Decisiones

Se conserva React, FastAPI, MariaDB y los algoritmos Python propios. Una nueva pantalla `#supply-board` evita duplicar los formularios especializados y complementa Resumen. Un único POST lee el catálogo una vez y calcula los resultados base y del escenario sobre copias. Todos los perfiles autenticados pueden simular; solo Editor/Administrador guardan relaciones mediante el flujo existente.

Se consideró montar Impact y Production completos juntos: duplicaría consultas, selecciones y grafos. Se descartó persistir escenarios o crear tablas nuevas porque este requisito se resuelve sin modificar el modelo de almacenamiento.

## Contrato

`POST /api/dashboard/analyze`: `{ElementId, ProductId:null, Change:null|{Operation:"Add"|"Remove",SourceId,TargetId}}`.

Respuesta: `{Catalog,Base:{Impact,Production},Scenario:{Impact,Production},Change,Comparison:{AddedReached,RemovedReached,ProductionStatusBefore,ProductionStatusAfter},SnapshotId}`. `Catalog` es la red guardada, nunca una red modificada. `Scenario` contiene los grafos del escenario. Sin cambio ambos resultados coinciden.

Añadir admite dependencias generales sin pesos; las parejas que requieren precio/cantidad se gestionan en Relaciones. Retirar puede simular la eliminación de cualquier relación existente. Validación estricta: IDs incorrectos 422, ausentes 404, duplicados 409; no se escribe en el catálogo. Se conserva autenticación, Origin y CSRF. Una contradicción produce resultado Cycle sin Order ni Stages.

## Interfaz

Selección y alcance, botón de análisis, comparación actual/temporal, resumen de consecuencias y preparación, caminos seleccionables y un grafo SVG reutilizado. Azul/gris existente, ámbar para impacto y rojo para ciclos. Adaptación móvil, foco visible y movimiento reducido. Las consultas sustituidas se cancelan y una actualización del catálogo invalida resultados anteriores.

## Entrega y verificación

Aceptación Python/API reproducible con datos aislados, validación visual de escritorio/móvil, video real de la aplicación con datos preparados y pitch breve. Se distingue la evidencia de pruebas en memoria de cualquier consulta MariaDB. No se insertan ciclos de prueba en el catálogo del usuario.

Se actualizan README, guía, FEATURE4 y bitácora. Se entrega un paquete GitHub sin contraseñas ni datos privados. Los medios identifican su conjunto de demostración para no presentarlo como inventario real.
