"""The additive layout migration must leave existing business data alone."""
import hashlib
from pathlib import Path
import re
import sqlite3
from tempfile import TemporaryDirectory
import unittest
from backend.Schema import Migrate
from test_initialized_startup import ReadOnlyConnection, ReadOnlyDatabase


class LayoutMigrationConnection(ReadOnlyConnection):
    def __init__(self, Digest, Failure=None):
        super().__init__(Digest)
        self.Tables = [Name for Name in self.Tables if Name != "usergraphlayouts"]
        self.Failure = Failure
        self.Writes = []
        self.Commits = 0
        self.Storage = sqlite3.connect(":memory:")
        self.Storage.executescript("""
            PRAGMA foreign_keys=ON;
            CREATE TABLE Users(UserId CHAR(36) PRIMARY KEY, DisplayName TEXT);
            INSERT INTO Users VALUES('owner','Existing account');
            CREATE TABLE RevisionClock(ClockId INT PRIMARY KEY,CurrentValue INT);
            INSERT INTO RevisionClock VALUES(1,713);
            CREATE TABLE Elements(ElementId TEXT PRIMARY KEY,Name TEXT,Version INT);
            INSERT INTO Elements VALUES('EXISTING','Existing product',711);
        """)

    def execute(self, Query, *Arguments):
        if Query.startswith("SELECT "):
            return super().execute(Query, *Arguments)
        self.Writes.append(Query)
        if not Query.startswith("CREATE TABLE IF NOT EXISTS AbastecePyme.UserGraphLayouts ("):
            raise AssertionError("Layout migration attempted unrelated SQL: " + Query)
        if self.Failure:
            raise self.Failure
        Sql = Query.replace("AbastecePyme.", "")
        Sql = re.sub(r" CHARACTER SET ascii COLLATE ascii_bin", "", Sql)
        Sql = Sql.split(" ENGINE=")[0]
        self.Storage.execute(Sql)
        self.Tables.append("usergraphlayouts")
        return self.Storage.cursor()

    def commit(self):
        self.Commits += 1
        self.Storage.commit()


class GraphLayoutMigrationTests(unittest.TestCase):
    def setUp(self):
        self.Folder = TemporaryDirectory()
        self.addCleanup(self.Folder.cleanup)
        self.Path = Path(self.Folder.name) / "catalogue.json"
        self.Path.write_bytes(b'{"elementos":[],"dependencias":[]}')
        self.Digest = hashlib.sha256(self.Path.read_bytes()).hexdigest()

    def Connection(self, Digest=None, Failure=None):
        Connection = LayoutMigrationConnection(Digest or self.Digest, Failure)
        self.addCleanup(Connection.Storage.close)
        return Connection

    def test_existing_installation_adds_only_layout_table_then_starts_without_writes(self):
        Connection = self.Connection()
        Before = list(Connection.Storage.iterdump())
        Migrate(ReadOnlyDatabase(Connection), self.Path)
        self.assertTrue(Connection.Closed)
        self.assertEqual(len(Connection.Writes), 1)
        self.assertEqual(Connection.Commits, 1)
        After = [Line for Line in Connection.Storage.iterdump() if "UserGraphLayouts" not in Line]
        self.assertEqual(After, Before)
        # Real SQLite executes the translated table definition and enforces its FK.
        Connection.Storage.execute("INSERT INTO UserGraphLayouts(UserId,LayoutKey,PositionsJson) VALUES('owner','Graph','[]')")
        Connection.Storage.execute("DELETE FROM Users WHERE UserId='owner'")
        self.assertEqual(Connection.Storage.execute("SELECT COUNT(*) FROM UserGraphLayouts").fetchone()[0], 0)
        Migrate(ReadOnlyDatabase(Connection), self.Path)
        self.assertEqual(len(Connection.Writes), 1)
        self.assertEqual(Connection.Commits, 1)

    def test_changed_seed_rejects_before_creating_preferences_table(self):
        Connection = self.Connection(Digest="f" * 64)
        with self.assertRaises(ValueError):
            Migrate(ReadOnlyDatabase(Connection), self.Path)
        self.assertEqual(Connection.Writes, [])
        self.assertTrue(Connection.Closed)

    def test_table_creation_error_is_not_suppressed_or_recorded_as_complete(self):
        Failure = PermissionError("Synthetic DDL denial")
        Connection = self.Connection(Failure=Failure)
        with self.assertRaises(PermissionError) as Error:
            Migrate(ReadOnlyDatabase(Connection), self.Path)
        self.assertIs(Error.exception, Failure)
        self.assertNotIn("usergraphlayouts", Connection.Tables)
        self.assertEqual(Connection.Commits, 0)
        self.assertTrue(Connection.Closed)
