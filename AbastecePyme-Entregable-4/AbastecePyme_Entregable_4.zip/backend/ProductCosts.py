"""Fresh material costs, never persisted sale prices.

Each Product -> Product dependency consumes one unit of its source component.
Exact quantities from every use are aggregated before rounding each material
subtotal HALF_UP to COP2. Totals sum those published subtotals; sale is minimum
cost times 1.25. Components are usage traceability, not additional cost lines.
"""
from decimal import Decimal, ROUND_HALF_UP, localcontext

from backend.Estimates import ParseDecimal
from backend.Production import BuildProductionPlan


SummaryFields = ("Status", "IsComplete", "MinimumCost", "MaximumCost", "SalePrice",
                 "CurrencyCode", "MarkupRate", "IsDemo")
Cent = Decimal("0.01")
Zero = Decimal("0")


def Money(Value):
    return format(Value.quantize(Cent, rounding=ROUND_HALF_UP), ".2f")


def Issue(Code, ElementId, Detail):
    return {"Code": Code, "ElementId": ElementId, "Detail": Detail}


def UniqueIssues(Issues):
    Mapping = {(Item["Code"], Item["ElementId"], Item["Detail"]): Item for Item in Issues}
    return [Mapping[Key] for Key in sorted(Mapping)]


class ProductCostCalculator:
    """One ephemeral index and memoized material recipes per catalogue read."""

    def __init__(self, Elements, Relations):
        self.Elements = Elements
        self.Relations = Relations
        self.Mapping = {Item["ElementId"]: Item for Item in Elements}
        if len(self.Mapping) != len(Elements):
            raise ValueError("Duplicate element identifiers")
        self.ProductIds = sorted(Id for Id, Item in self.Mapping.items() if Item["ElementType"] == "Product")
        self.ComponentSources = {Id: set() for Id in self.ProductIds}
        self.Dependents = {Id: set() for Id in self.ProductIds}
        self.Requirements = {Id: [] for Id in self.ProductIds}
        self.Offers = {}
        self.OtherDependencies = []
        Seen = set()
        for Relation in sorted(Relations, key=lambda Item: (Item["SourceId"], Item["TargetId"])):
            Source, Target = Relation["SourceId"], Relation["TargetId"]
            if Source not in self.Mapping or Target not in self.Mapping:
                raise ValueError("Dependency references a missing element")
            if (Source, Target) in Seen:
                raise ValueError("Duplicate dependency")
            Seen.add((Source, Target))
            Pair = (self.Mapping[Source]["ElementType"], self.Mapping[Target]["ElementType"])
            Kind = Relation["RelationType"]
            if Kind == "Offer" and Pair == ("Supplier", "Material"):
                self.Offers.setdefault(Target, []).append(Relation)
            elif Kind == "Requirement" and Pair == ("Material", "Product"):
                self.Requirements[Target].append(Relation)
            elif Kind == "General":
                if Pair == ("Product", "Product"):
                    self.ComponentSources[Target].add(Source)
                    self.Dependents[Source].add(Target)
                else:
                    self.OtherDependencies.append(Relation)
            else:
                raise ValueError("Relation type does not match its endpoints")
        self.OtherDependencyProducts = self.FindOtherDependencyProducts()
        # A DAG has fewer than 2**P paths. P extra decimal digits comfortably
        # cover multiplicity, input DECIMAL(18,*), sums and the 25% markup.
        self.Precision = 64 + len(self.ProductIds)
        self.Bills = {}
        self.Order = []
        with localcontext() as Context:
            Context.prec = self.Precision
            self.BuildBills()

    def FindOtherDependencyProducts(self):
        """Index affected products once within this catalogue snapshot.

        A general edge is an ancestor of a product exactly when its target can
        reach that product. Follow every edge kind, including offers, so that
        supplier/material chains and mixed cycles retain full validation.
        """
        if not self.OtherDependencies:
            return set()
        Adjacency = {}
        for Relation in self.Relations:
            Adjacency.setdefault(Relation["SourceId"], []).append(Relation["TargetId"])
        Affected = {Relation["TargetId"] for Relation in self.OtherDependencies}
        Pending = list(Affected)
        while Pending:
            Current = Pending.pop()
            for Target in Adjacency.get(Current, ()):
                if Target not in Affected:
                    Affected.add(Target)
                    Pending.append(Target)
        return Affected.intersection(self.ProductIds)

    def BuildBills(self):
        Degrees = {Id: len(Sources) for Id, Sources in self.ComponentSources.items()}
        Ready = [Id for Id in self.ProductIds if Degrees[Id] == 0]
        while Ready:
            Next = []
            for ProductId in Ready:
                Quantities, Issues, Demo = {}, [], False
                for Requirement in self.Requirements[ProductId]:
                    MaterialId = Requirement["SourceId"]
                    Demo = Demo or bool(Requirement.get("IsDemo", False))
                    try:
                        Quantity = ParseDecimal(Requirement["Value"], 4, True)
                    except ValueError:
                        Issues.append(Issue("InvalidQuantity", MaterialId,
                                            f"Revisa la cantidad del insumo {MaterialId} en {ProductId}."))
                        continue
                    Quantities[MaterialId] = Quantities.get(MaterialId, Zero) + Quantity
                for Source in sorted(self.ComponentSources[ProductId]):
                    Component = self.Bills[Source]
                    for MaterialId, Quantity in Component["Quantities"].items():
                        Quantities[MaterialId] = Quantities.get(MaterialId, Zero) + Quantity
                    Issues.extend(Component["Issues"])
                    Demo = Demo or Component["IsDemo"]
                if not self.Requirements[ProductId] and not self.ComponentSources[ProductId]:
                    Issues.append(Issue("MissingRequirements", ProductId,
                                        f"El producto {ProductId} no tiene insumos ni componentes definidos."))
                self.Bills[ProductId] = {"Quantities": Quantities, "Issues": UniqueIssues(Issues), "IsDemo": Demo}
                self.Order.append(ProductId)
                for Target in sorted(self.Dependents[ProductId]):
                    Degrees[Target] -= 1
                    if Degrees[Target] == 0:
                        Next.append(Target)
            Ready = sorted(Next)

    def Components(self, ProductId):
        Counts = {ProductId: 1}
        for Current in reversed(self.Order):
            Count = Counts.get(Current, 0)
            if not Count:
                continue
            for Source in self.ComponentSources[Current]:
                Counts[Source] = Counts.get(Source, 0) + Count
        return [{"ProductId": Id, "Name": self.Mapping[Id]["Name"], "Quantity": f"{Count}.0000"}
                for Id, Count in sorted(Counts.items()) if Id != ProductId]

    def BuildSourcingGraphs(self, Result):
        """Trace all recipe branches with only the already chosen offers.

        Shared components keep every connection but appear once in the graph;
        their multiplicities remain in the quantities of the cost breakdown.
        No path enumeration or additional business traversal is needed in JS.
        """
        ProductIds = {Result["ProductId"]} | {Item["ProductId"] for Item in Result["Components"]}
        RecipeRelations = set()
        for ProductId in ProductIds:
            RecipeRelations.update((Edge["SourceId"], ProductId, "Requirement")
                                   for Edge in self.Requirements[ProductId])
            RecipeRelations.update((Source, ProductId, "General") for Source in self.ComponentSources[ProductId])
        Graphs = {}
        for Kind in ("Minimum", "Maximum"):
            SelectedRelations = RecipeRelations | {(Material[Kind]["SupplierId"], Material["MaterialId"], "Offer")
                                                   for Material in Result["Materials"]}
            ElementIds = set(ProductIds)
            for Source, Target, RelationType in SelectedRelations:
                ElementIds.update((Source, Target))
            Graphs[Kind] = {"ElementIds": sorted(ElementIds),
                            "Relations": [{"SourceId": Source, "TargetId": Target, "RelationType": RelationType}
                                          for Source, Target, RelationType in sorted(SelectedRelations)]}
        return Graphs

    def Calculate(self, ProductId, Detail=True):
        if ProductId not in self.Mapping:
            raise KeyError(ProductId)
        if self.Mapping[ProductId]["ElementType"] != "Product":
            raise ValueError("Select a product for its material costs")
        Result = {"ProductId": ProductId, "Status": "Incomplete", "IsComplete": False,
                  "CurrencyCode": "COP", "MinimumCost": None, "MaximumCost": None, "SalePrice": None,
                  "MarkupRate": "0.25", "IsDemo": False, "Materials": [], "Components": [],
                  "Missing": [], "Issues": [], "Cycle": [],
                  "SourcingGraphs": {Kind: {"ElementIds": [], "Relations": []} for Kind in ("Minimum", "Maximum")}}
        # The common typed catalogue needs only the memoized component DAG.
        # Only products downstream of an unquantified dependency need the full
        # ancestor check. Component cycles still require their existing witness.
        if ProductId not in self.Bills or ProductId in self.OtherDependencyProducts:
            Plan = BuildProductionPlan(self.Elements, self.Relations, ProductId)
            if Plan["Status"] == "Cycle":
                Result["Status"] = "Cycle"
                Result["Cycle"] = Plan["Cycle"]
                Result["Issues"] = [Issue("Cycle", ProductId, "Hay un ciclo entre los requisitos del producto. Revisa sus dependencias.")]
                return Result
            for Relation in Plan["Graph"]["Relations"]:
                Source, Target = Relation["SourceId"], Relation["TargetId"]
                Pair = (self.Mapping[Source]["ElementType"], self.Mapping[Target]["ElementType"])
                if Relation["RelationType"] == "General" and Pair != ("Product", "Product"):
                    Result["Issues"].append(Issue("UnquantifiedDependency", Source,
                        f"La dependencia {Source} → {Target} no define un costo ni una cantidad de insumo."))
        Bill = self.Bills[ProductId]
        Result["Issues"].extend(Bill["Issues"])
        Result["IsDemo"] = Bill["IsDemo"]
        if Detail:
            Result["Components"] = self.Components(ProductId)
        Minimum, Maximum = Zero, Zero
        with localcontext() as Context:
            Context.prec = self.Precision
            for MaterialId, Quantity in sorted(Bill["Quantities"].items()):
                Material = self.Mapping[MaterialId]
                Offers = []
                for Offer in self.Offers.get(MaterialId, []):
                    SupplierId = Offer["SourceId"]
                    Result["IsDemo"] = Result["IsDemo"] or bool(Offer.get("IsDemo", False))
                    try:
                        Price = ParseDecimal(Offer["Value"], 2, False)
                    except ValueError:
                        Result["Issues"].append(Issue("InvalidOffer", MaterialId,
                            f"Revisa el precio del proveedor {SupplierId} para el insumo {MaterialId}."))
                        continue
                    Offers.append({"SupplierId": SupplierId, "SupplierName": self.Mapping[SupplierId]["Name"],
                                   "UnitPrice": Money(Price), "Subtotal": Money(Quantity * Price),
                                   "IsDemo": bool(Offer.get("IsDemo", False))})
                Offers.sort(key=lambda Item: (Decimal(Item["UnitPrice"]), Item["SupplierId"]))
                Least = Offers[0] if Offers else None
                Most = min(Offers, key=lambda Item: (-Decimal(Item["UnitPrice"]), Item["SupplierId"])) if Offers else None
                if Least is None:
                    Result["Missing"].append(MaterialId)
                    Result["Issues"].append(Issue("MissingOffer", MaterialId, f"El insumo {MaterialId} no tiene una oferta válida."))
                else:
                    Minimum += Decimal(Least["Subtotal"])
                    Maximum += Decimal(Most["Subtotal"])
                if Detail:
                    Result["Materials"].append({"MaterialId": MaterialId, "Name": Material["Name"],
                        "UnitCode": Material.get("UnitCode", "unidad"), "Quantity": format(Quantity, ".4f"),
                        "Offers": Offers, "Minimum": dict(Least) if Least else None, "Maximum": dict(Most) if Most else None})
            Result["Issues"] = UniqueIssues(Result["Issues"])
            if not Result["Issues"] and Bill["Quantities"]:
                Result.update({"Status": "Ready", "IsComplete": True, "MinimumCost": Money(Minimum),
                               "MaximumCost": Money(Maximum), "SalePrice": Money(Minimum * Decimal("1.25"))})
        if Detail and Result["IsComplete"]:
            Result["SourcingGraphs"] = self.BuildSourcingGraphs(Result)
        return Result


def CalculateProductCosts(ProductId, Elements, Relations):
    return ProductCostCalculator(Elements, Relations).Calculate(ProductId)


def CalculateCatalogueCosts(Elements, Relations):
    Calculator = ProductCostCalculator(Elements, Relations)
    Results = {}
    for ProductId in Calculator.ProductIds:
        Detail = Calculator.Calculate(ProductId, Detail=False)
        Results[ProductId] = {Field: Detail[Field] for Field in SummaryFields}
    return Results
