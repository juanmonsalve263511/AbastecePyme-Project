"""Catalogue mutations must not materialize unrelated graph records."""
import unittest
from backend.Catalog import CreateElement, DeleteElement, DeletePreview, ReadCatalogue
from backend.Models import ElementCreate, RelationCreate, RelationEdit
from backend.Relations import ChangeRelation
from test_feature3_api import SqlAdapter


class CountingCursor:
    def __init__(self, Cursor, Database):
        self.Cursor = Cursor
        self.Database = Database

    @property
    def description(self):
        return self.Cursor.description

    def fetchone(self):
        return self.Cursor.fetchone()

    def fetchall(self):
        Result = self.Cursor.fetchall()
        self.Database.MaterializedRows += len(Result)
        return Result


class CountingDatabase(SqlAdapter):
    def __init__(self):
        super().__init__()
        self.MaterializedRows = 0

    def execute(self, Query, *Args):
        return CountingCursor(super().execute(Query, *Args), self)


class CatalogAccessTests(unittest.TestCase):
    def setUp(self):
        self.Database = CountingDatabase()
        self.addCleanup(self.Database.Connection.close)
        self.Database.Connection.executescript("""
            CREATE TABLE RevisionClock(ClockId INTEGER PRIMARY KEY,CurrentValue INTEGER);
            INSERT INTO RevisionClock VALUES(1,1);
            CREATE TABLE Elements(ElementId TEXT PRIMARY KEY,Name TEXT,ElementType TEXT,Description TEXT,Version INTEGER);
            CREATE TABLE Suppliers(ElementId TEXT PRIMARY KEY,Contact TEXT);
            CREATE TABLE Materials(ElementId TEXT PRIMARY KEY,UnitCode TEXT);
            CREATE TABLE Products(ElementId TEXT PRIMARY KEY);
            CREATE TABLE ProductPrices(ElementId TEXT PRIMARY KEY,SalePrice TEXT,IsPriceReference INTEGER);
            CREATE TABLE SupplierOffers(SupplierId TEXT,MaterialId TEXT,UnitPrice TEXT,IsDemo INTEGER,Version INTEGER);
            CREATE TABLE ProductRequirements(MaterialId TEXT,ProductId TEXT,Quantity TEXT,IsDemo INTEGER,Version INTEGER);
            CREATE TABLE GeneralDependencies(SourceId TEXT,TargetId TEXT,Version INTEGER);
        """)
        for Id, Kind in (("SUP", "Supplier"), ("MAT", "Material"), ("PROD", "Product")):
            CreateElement(self.Database, ElementCreate(ElementId=Id, Name=Id, ElementType=Kind))
        # A disconnected component makes accidental whole-network reads observable.
        self.Database.Connection.executemany(
            "INSERT INTO Elements VALUES(?,?,'Product','',1)",
            [(f"OTHER-{Index}", f"Other {Index}") for Index in range(201)])
        self.Database.Connection.executemany(
            "INSERT INTO GeneralDependencies VALUES(?,?,1)",
            [(f"OTHER-{Index}", f"OTHER-{Index+1}") for Index in range(200)])
        self.Database.Connection.commit()
        self.Database.MaterializedRows = 0

    def CreateRelation(self, Source, Target, Value=None):
        return ChangeRelation(self.Database, RelationCreate(SourceId=Source, TargetId=Target, Value=Value), "create")

    def test_relation_changes_return_exact_values_without_loading_other_edges(self):
        for Source, Target, Value, ExpectedType, ExpectedValue in (
            ("SUP", "MAT", "4.5", "Offer", "4.50"),
            ("MAT", "PROD", "1.25", "Requirement", "1.2500"),
            ("PROD", "PROD", None, "General", None),
        ):
            with self.subTest(RelationType=ExpectedType):
                self.Database.MaterializedRows = 0
                Created = self.CreateRelation(Source, Target, Value)
                self.assertEqual(Created["RelationType"], ExpectedType)
                self.assertEqual(Created["Value"], ExpectedValue)
                self.assertLessEqual(self.Database.MaterializedRows, 1)
                self.Database.MaterializedRows = 0
                Edited = ChangeRelation(self.Database, RelationEdit(
                    SourceId=Source, TargetId=Target, Value=Value,
                    Version=Created["Version"], IsDemo=True), "edit")
                self.assertEqual(Edited["Value"], ExpectedValue)
                self.assertIs(Edited["IsDemo"], ExpectedType != "General")
                self.assertGreater(Edited["Version"], Created["Version"])
                self.assertLessEqual(self.Database.MaterializedRows, 1)
                Stored = next(Edge for Edge in ReadCatalogue(self.Database)["Relations"]
                              if Edge["SourceId"] == Source and Edge["TargetId"] == Target)
                self.assertEqual(Edited, Stored)

    def test_deletion_preview_counts_self_edges_once_without_loading_graph(self):
        self.CreateRelation("SUP", "MAT", "4")
        self.CreateRelation("MAT", "PROD", "2")
        self.CreateRelation("MAT", "MAT")
        self.Database.MaterializedRows = 0
        Preview = DeletePreview(self.Database, "MAT")
        self.assertEqual(Preview["RelationshipCount"], 3)
        self.assertLessEqual(self.Database.MaterializedRows, 4)

    def test_deletion_updates_only_neighbors_without_loading_disconnected_edges(self):
        self.CreateRelation("SUP", "MAT", "4")
        self.CreateRelation("MAT", "PROD", "2")
        self.CreateRelation("MAT", "MAT")
        Before = {Item["ElementId"]: Item["Version"] for Item in ReadCatalogue(self.Database)["Elements"]}
        self.Database.MaterializedRows = 0
        DeleteElement(self.Database, "MAT", Before["MAT"])
        self.assertLessEqual(self.Database.MaterializedRows, 3)
        Result = ReadCatalogue(self.Database)
        After = {Item["ElementId"]: Item["Version"] for Item in Result["Elements"]}
        self.assertNotIn("MAT", After)
        self.assertGreater(After["SUP"], Before["SUP"])
        self.assertGreater(After["PROD"], Before["PROD"])
        self.assertEqual(After["OTHER-0"], Before["OTHER-0"])
        self.assertEqual(len(Result["Relations"]), 200)
