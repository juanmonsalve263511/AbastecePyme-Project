import {BusinessInfo} from '../BusinessInfo.js';
import {Brand,Icon} from './Common.jsx';
import {Preferences} from './Preferences.jsx';

export const PublicRoutes=['home','services','history','locations','contact','terms','updates'];
export default function PublicLayout({Session,Route,children}){
  return <div className="site-shell"><a className="skip-link site-skip" href="#main" onClick={Event=>{Event.preventDefault();document.getElementById('main').focus();}}>Saltar al contenido</a>
    <header className="site-header"><Brand/><nav aria-label="Navegación pública"><a href="#services" aria-current={Route==='services'?'page':undefined}>Servicios</a><a href="#history" aria-current={Route==='history'?'page':undefined}>Nuestra historia</a><a href="#contact" aria-current={Route==='contact'?'page':undefined}>Contacto</a><a className="button primary" href={Session?'#dashboard':'#login'}>{Session?'Abrir mi espacio':'Iniciar sesión'}</a></nav></header>
    <main id="main" tabIndex={-1}>{children}</main>
    <footer className="site-footer"><div className="footer-top"><div className="footer-brand"><Brand/><p>Hecho para quienes transforman materiales en oportunidades.</p><address className="footer-address"><strong>{BusinessInfo.Building}</strong><span>{BusinessInfo.Office}</span><span>{BusinessInfo.Street}</span><span>{BusinessInfo.City}</span><a href={BusinessInfo.PhoneLink}>Celular: {BusinessInfo.Phone}</a></address></div><div><h2>AbastecePyme</h2><a href="#history">Nuestra historia</a><a href="#services">Nuestros servicios</a><a href="#locations">Locaciones</a></div><div><h2>Conversemos</h2><a href="#contact">Contáctanos</a><a href="#updates">Suscríbete a novedades</a><a href="#terms">Términos y condiciones</a></div><div className="footer-invite"><h2>Ideas para conectar mejor.</h2><p>Conoce las próximas mejoras de tu espacio de trabajo.</p><a className="button footer-button" href="#updates">Quiero recibir novedades<Icon Name="arrow"/></a></div></div>
    <div className="footer-bottom"><a href="#terms">© 2026 AbastecePyme</a><p>Abastecimiento conectado. Decisiones con perspectiva.</p><Preferences/></div></footer>
  </div>;
}
