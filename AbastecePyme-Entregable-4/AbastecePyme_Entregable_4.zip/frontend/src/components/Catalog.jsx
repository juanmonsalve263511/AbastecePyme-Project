import { LatestRequest } from '../LatestRequest.js';
import { useState, useRef, useEffect, useMemo } from 'react';
import { Api, TypeLabels, Money } from '../Api.js';
import { Heading, Icon, Field, Modal, Notice, Empty, ReferenceBadge } from './Common.jsx';
import ProductCosts from './ProductCosts.jsx';
import {BuildCatalogIndex,CatalogFilterOptions,CatalogSortOptions,ReadCatalogOptions,SelectCatalogItems,WriteCatalogOptions} from './CatalogFilters.js';
import './Catalog.css';

function ElementForm({ Item, Type, OnClose, OnSaved }) {
  const [Error, SetError] = useState(''); const [Busy, SetBusy] = useState(false);
  async function Submit(Event) {
    Event.preventDefault(); if(Busy)return; SetBusy(true); SetError('');
    const Form = new FormData(Event.currentTarget);
    const Body = {Name:Form.get('Name'),Description:Form.get('Description')};
    if(Type==='Material') Body.UnitCode=Form.get('UnitCode');
    if(Type==='Supplier') Body.Contact=Form.get('Contact');
    if(Item) Body.Version=Item.Version; else {Body.ElementId=Form.get('ElementId').toUpperCase();Body.ElementType=Type;}
    try {await Api(Item?'/api/elements/'+Item.ElementId:'/api/elements',{method:Item?'PATCH':'POST',body:Body}); await OnSaved();OnClose();}
    catch(Failure){SetError(Failure.message);} finally{SetBusy(false);}
  }
  return <Modal Title={(Item?'Editar ':'Agregar ')+TypeLabels[Type].toLowerCase()} OnClose={()=>!Busy&&OnClose()}><form onSubmit={Submit}><Notice Text={Error} Error/><div className="form-grid"><Field Label="Código" Hint="El código identifica al elemento y no se puede cambiar."><input name="ElementId" defaultValue={Item?.ElementId} disabled={!!Item} required pattern="[A-Za-z][A-Za-z0-9_\-]{1,39}" maxLength={40} placeholder="Ej. INS-MADERA"/></Field><Field Label="Nombre"><input name="Name" defaultValue={Item?.Name} required minLength={2} maxLength={80} autoFocus/></Field></div>
    {Type==='Supplier' && <Field Label="Datos de contacto" Hint="Nombre de contacto, teléfono o correo (opcional)."><input name="Contact" defaultValue={Item?.Contact} maxLength={160}/></Field>}
    {Type==='Material' && <Field Label="Unidad de compra y uso" Hint="Usa la misma unidad para los precios y las cantidades de este insumo."><input name="UnitCode" defaultValue={Item?.UnitCode||'unidad'} required maxLength={30}/></Field>}
    {Type==='Product' && <p className="catalog-price-auto">El costo de producción se calcula con los insumos, componentes y ofertas registrados. El precio de venta se calcula automáticamente: costo mínimo + 25 %. Agrega sus relaciones para obtener ambos valores.</p>}
    <Field Label="Descripción (opcional)"><textarea name="Description" defaultValue={Item?.Description} rows={3} maxLength={1000}/></Field><div className="form-actions"><button type="button" onClick={OnClose} disabled={Busy}>Cancelar</button><button className="primary" disabled={Busy}>{Busy?'Guardando…':'Guardar cambios'}</button></div></form></Modal>;
}
export default function Catalog({Data,Type,CanEdit,OnChange,QueryString='',OnQueryChange}) {
  const PreviewRequest=useRef(new LatestRequest());
  useEffect(()=>()=>PreviewRequest.current.Cancel(),[]);
  function CloseDetail(){SetDetail(null);}
  const [Search,SetSearch]=useState(''); const [Editing,SetEditing]=useState(null); const [Deleting,SetDeleting]=useState(null);
  const [Detail,SetDetail]=useState(null);const [Error,SetError]=useState('');const [Busy,SetBusy]=useState(false);
  const {Filter,Sort}=ReadCatalogOptions(Type,QueryString);
  const Index=useMemo(()=>BuildCatalogIndex(Data),[Data]);
  const Items=useMemo(()=>SelectCatalogItems(Index,Type,{Filter,Sort,Search}),[Index,Type,Filter,Sort,Search]);
  const RelationCounts=Index.RelationCounts,Total=Index.ByType[Type].length;
  const HasFilters=!!Search.trim()||Filter!=='All'||Sort!=='NameAsc';
  function ChangeOptions(Patch){OnQueryChange(WriteCatalogOptions(Type,{Filter,Sort,...Patch}));}
  function ClearFilters(){SetSearch('');OnQueryChange('');}
  function Preview(Item){SetError('');PreviewRequest.current.Run(Signal=>Api('/api/elements/'+Item.ElementId+'/deletion-preview',{signal:Signal}),SetDeleting,Failure=>SetError(Failure.message));}
  async function Remove(){SetBusy(true);try{await Api('/api/elements/'+Deleting.ElementId+'?Version='+Deleting.Version,{method:'DELETE'});SetDeleting(null);await OnChange();}catch(Failure){SetError(Failure.message);SetDeleting(null);}finally{SetBusy(false);}}
  function ShowDetail(Item){SetDetail(Item);SetError('');}
  const Plural={Supplier:'Proveedores',Material:'Insumos',Product:'Productos'};
  const EmptyText=Total?'No hay coincidencias con esta búsqueda y estos filtros.':
    'Todavía no hay '+Plural[Type].toLowerCase()+'. '+(CanEdit?'Agrega el primer elemento para organizar tu catálogo.':'Un administrador o editor puede incorporarlos al catálogo.');
  return <><Heading Title="Catálogo" Description="Cada elemento en su lugar, con la información que necesitas." Children={CanEdit?<button className="primary" onClick={()=>SetEditing({New:true})}><Icon Name="plus"/>Agregar {TypeLabels[Type].toLowerCase()}</button>:<span className="badge">Acceso de consulta</span>}/>
    <div className="subnav" aria-label="Tipos de elementos">{Object.keys(Plural).map(Key=><a className={Key===Type?'active':''} aria-current={Key===Type?'page':undefined} key={Key} href={'#catalog-'+Key}>{Plural[Key]}<span>{Index.ByType[Key].length}</span></a>)}</div>
    <Notice Text={Error} Error/><section className={"surface catalog-table"+(Type==='Product'?' catalog-products':'')}><div className="table-toolbar"><h2>{Plural[Type]} <span className="count">{Items.length}</span></h2><label className="search"><Icon Name="search"/><input type="search" aria-label="Buscar en catálogo" placeholder="Buscar por nombre o código" value={Search} onChange={Event=>SetSearch(Event.target.value)}/></label></div>
    <div className="catalog-filter-bar">{CatalogFilterOptions[Type].length>1&&<Field Label="Mostrar"><select value={Filter} onChange={Event=>ChangeOptions({Filter:Event.target.value})}>{CatalogFilterOptions[Type].map(([Value,Label])=><option value={Value} key={Value}>{Label}</option>)}</select></Field>}<Field Label="Ordenar por"><select value={Sort} onChange={Event=>ChangeOptions({Sort:Event.target.value})}>{CatalogSortOptions(Type).map(([Value,Label])=><option value={Value} key={Value}>{Label}</option>)}</select></Field><button type="button" disabled={!HasFilters} onClick={ClearFilters}>Limpiar filtros</button></div>
    {Items.length?<div className="table-scroll" tabIndex={0} role="region" aria-label={'Tabla de '+Plural[Type].toLowerCase()+'. Desplázate horizontalmente si necesitas ver más columnas.'}><table><thead><tr><th scope="col" aria-sort={Sort.startsWith('Name')?(Sort==='NameAsc'?'ascending':'descending'):undefined}>Nombre</th><th scope="col">Código</th><th scope="col">{Type==='Material'?'Unidad':Type==='Supplier'?'Contacto':'Relaciones'}</th>{Type==='Product'&&<><th scope="col" aria-sort={Sort.startsWith('Cost')?(Sort==='CostAsc'?'ascending':'descending'):undefined}>Costo de producción <span className="quiet">(COP)</span></th><th scope="col" aria-sort={Sort.startsWith('Sale')?(Sort==='SaleAsc'?'ascending':'descending'):undefined}>Precio de venta <span className="quiet">(COP)</span></th></>}<th scope="col"><span className="sr-only">Acciones</span></th></tr></thead><tbody>{Items.map(Item=><tr key={Item.ElementId}><td><button className="row-title" onClick={()=>ShowDetail(Item)}><span className={'type-symbol '+Type}><Icon Name={Type==='Supplier'?'users':'box'}/></span>{Item.Name}</button></td><td className="quiet">{Item.ElementId}</td><td>{Type==='Material'?Item.UnitCode:Type==='Supplier'?(Item.Contact||'Sin registrar'):(RelationCounts.get(Item.ElementId)||0)+((RelationCounts.get(Item.ElementId)||0)===1?' conexión':' conexiones')}</td>{Type==='Product'&&<>{['MinimumCost','SalePrice'].map(Key=><td className="sale-price-cell" key={Key}>{Item.ProductCosts?.[Key]!=null?<><strong>{Money(Item.ProductCosts[Key])}</strong>{Item.ProductCosts.IsDemo&&<ReferenceBadge Value Kind="Price"/>}</>:<span className="quiet">{Item.ProductCosts?.Status==='Cycle'?'Revisar ciclo':'Pendiente de calcular'}</span>}</td>)}</>}<td><div className="row-actions">{CanEdit?<><button onClick={()=>SetEditing(Item)} aria-label={'Editar '+Item.Name}>Editar</button><button className="danger-text" onClick={()=>Preview(Item)} aria-label={'Eliminar '+Item.Name}>Eliminar</button></>:<button onClick={()=>ShowDetail(Item)}>Ver detalles</button>}</div></td></tr>)}</tbody></table></div>:<div className="catalog-empty"><Empty Text={EmptyText}/>{!Total&&CanEdit&&<button type="button" className="primary" onClick={()=>SetEditing({New:true})}>Agregar {TypeLabels[Type].toLowerCase()}</button>}</div>}
    {Type==='Product'&&<p className="catalog-pricing-note">Costo mínimo de insumos y componentes por unidad. Precio de venta = costo mínimo + 25 %. Selecciona un producto para comparar proveedores y revisar el desglose.</p>}
    <div className="table-footer"><p role="status">{Items.length} de {Total} {Plural[Type].toLowerCase()}</p><span>Selecciona un nombre para ver sus detalles.</span></div></section>
    {Editing && <ElementForm Item={Editing.New?null:Editing} Type={Type} OnClose={()=>SetEditing(null)} OnSaved={OnChange}/>}
    {Deleting && <Modal Title="Eliminar elemento" OnClose={()=>!Busy&&SetDeleting(null)}><p>Se eliminará <strong>{Deleting.Name}</strong> y sus <strong>{Deleting.RelationshipCount} relaciones</strong>. Esta acción no se puede deshacer.</p><div className="form-actions"><button onClick={()=>SetDeleting(null)} disabled={Busy}>Cancelar</button><button className="danger" onClick={Remove} disabled={Busy}>{Busy?'Eliminando…':'Confirmar eliminación'}</button></div></Modal>}
    {Detail && <Modal Title={Detail.Name} OnClose={CloseDetail}><p className="quiet">{Detail.ElementId} · {TypeLabels[Type]}</p><p>{Detail.Description||'Este elemento no tiene descripción todavía.'}</p>{Detail.UnitCode&&<p>Unidad: {Detail.UnitCode}</p>}{Detail.Contact&&<p>Contacto: {Detail.Contact}</p>}
      {Type==='Product'&&<ProductCosts ProductId={Detail.ElementId} Data={Data}/>}
      <a className="button" href={'#graph?focus='+encodeURIComponent(Detail.ElementId)} onClick={CloseDetail}>Ver conexiones en el grafo</a></Modal>}
  </>;
}

