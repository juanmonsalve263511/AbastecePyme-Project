"""Visual preferences owned by the authenticated account, separate from catalogue data."""
import json
from backend.Models import GraphLayoutBody


def ReadLayout(Database, UserId, LayoutKey):
    with Database.Transaction() as Connection:
        Row = Connection.execute(
            "SELECT PositionsJson FROM UserGraphLayouts WHERE UserId=? AND LayoutKey=?",
            UserId, LayoutKey).fetchone()
    if Row is None:
        return {"Positions": []}
    return GraphLayoutBody.model_validate({"Positions": json.loads(Row[0])}).model_dump()


def SaveLayout(Database, UserId, LayoutKey, Body):
    Result = Body.model_dump()
    Serialized = json.dumps(Result["Positions"], separators=(",", ":"), allow_nan=False)
    with Database.Transaction() as Connection:
        # One atomic statement serializes concurrent saves for this account/view.
        # The latest completed save wins; no catalogue revision is consumed.
        Connection.execute(
            "INSERT INTO UserGraphLayouts(UserId,LayoutKey,PositionsJson) VALUES (?,?,?) "
            "ON DUPLICATE KEY UPDATE PositionsJson=VALUES(PositionsJson)",
            UserId, LayoutKey, Serialized)
    return Result
