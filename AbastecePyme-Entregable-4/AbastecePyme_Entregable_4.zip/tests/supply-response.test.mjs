import test from 'node:test';
import assert from 'node:assert/strict';
import {ExpandSupplyResponse,GetImpactPath} from '../frontend/src/components/SupplyResponse.js';

const Elements=[{ElementId:'S',Name:'Supplier'},{ElementId:'M',Name:'Material'},{ElementId:'P',Name:'Product'}];
const Relations=[{SourceId:'S',TargetId:'M'},{SourceId:'M',TargetId:'P'}];
const Visited=[{ElementId:'S',ParentId:null,Depth:0},{ElementId:'M',ParentId:'S',Depth:1},{ElementId:'P',ParentId:'M',Depth:2}];
function Response(){return {ResponseFormat:'Compact',Catalog:{Elements,Relations},Change:null,SnapshotId:'snapshot',Base:{Impact:{Origin:Visited[0],Visited,Graph:{ElementIds:['S','M','P'],Relations}},Production:{Status:'Ready',Graph:{ElementIds:['S','M','P'],Relations}}},Scenario:null};}

test('compact response shares catalog bodies and unchanged scenarios without expanding every path',()=>{
  const Raw=Response(),Result=ExpandSupplyResponse(Raw);
  assert.equal(Result.Scenario,Result.Base);
  assert.deepEqual(Result.Base.Impact.Reached,Visited.slice(1));
  assert.equal(Result.Base.Impact.Graph.Elements[0],Elements[0]);
  assert.equal(Result.Base.Production.Graph.Elements[2],Elements[2]);
  assert.equal(Result.Base.Impact.Visited[2].Path,undefined);
  assert.equal(Raw.Scenario,null);
  assert.equal(Raw.Base.Impact.Reached,undefined);
});
test('only selected paths are formatted from the predecessors chosen by Python',()=>{
  const Lookup=new Map(Visited.map(Item=>[Item.ElementId,Item]));
  assert.deepEqual(GetImpactPath(Lookup,'P'),['S','M','P']);
  assert.deepEqual(GetImpactPath(Lookup,'S'),['S']);
  assert.deepEqual(GetImpactPath(Lookup,'unknown'),[]);
});
test('independent scenarios retain temporary edges and no base membership leaks',()=>{
  const Raw=Response();
  Raw.Change={Operation:'Remove',SourceId:'M',TargetId:'P'};
  Raw.Scenario={Impact:{Origin:Visited[0],Visited:Visited.slice(0,2),Graph:{ElementIds:['S','M'],Relations:Relations.slice(0,1)}},Production:{Status:'Ready',Graph:{ElementIds:['P'],Relations:[]}}};
  const Result=ExpandSupplyResponse(Raw);
  assert.notEqual(Result.Base,Result.Scenario);
  assert.deepEqual(Result.Scenario.Impact.Graph.Elements.map(Item=>Item.ElementId),['S','M']);
  assert.deepEqual(Result.Scenario.Production.Graph.Relations,[]);
  assert.equal(Result.Base.Impact.Graph.Relations.length,2);
});
test('invalid predecessor chains never loop or display a fabricated path',()=>{
  for(const Rows of [[{ElementId:'P',ParentId:'P',Depth:1}],[{ElementId:'P',ParentId:'missing',Depth:1}],[{ElementId:'P',ParentId:null,Depth:2}]])
    assert.deepEqual(GetImpactPath(new Map(Rows.map(Item=>[Item.ElementId,Item])),'P'),[]);
});
test('legacy expanded responses remain usable without a new server',()=>{
  const Legacy={Base:{Impact:{Visited:[{...Visited[0],Path:['S']}]}}};
  assert.equal(ExpandSupplyResponse(Legacy),Legacy);
  assert.deepEqual(GetImpactPath(new Map([['S',Legacy.Base.Impact.Visited[0]]]),'S'),['S']);
});
