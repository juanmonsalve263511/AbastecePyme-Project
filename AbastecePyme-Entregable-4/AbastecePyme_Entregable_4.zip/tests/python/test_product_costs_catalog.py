"""Cost summaries use one fresh isolated catalogue and never persist prices."""
import unittest
from unittest.mock import patch

from fastapi import HTTPException
from backend.Catalog import CreateElement, ReadCatalogue
from backend.Main import CreateApp
from backend.Models import ElementCreate, RelationCreate, RelationEdit
from backend.ProductCosts import CalculateProductCosts, SummaryFields
from backend.Relations import ChangeRelation
from test_feature3_api import SqlAdapter


class ProductCostCatalogTests(unittest.TestCase):
    def setUp(self):
        self.Database = SqlAdapter()
        self.addCleanup(self.Database.Connection.close)
        self.Database.Connection.executescript("""
            CREATE TABLE RevisionClock(ClockId INTEGER PRIMARY KEY,CurrentValue INTEGER);
            INSERT INTO RevisionClock VALUES(1,1);
            CREATE TABLE Elements(ElementId TEXT PRIMARY KEY,Name TEXT,ElementType TEXT,Description TEXT,Version INTEGER);
            CREATE TABLE Suppliers(ElementId TEXT PRIMARY KEY,Contact TEXT);
            CREATE TABLE Materials(ElementId TEXT PRIMARY KEY,UnitCode TEXT);
            CREATE TABLE Products(ElementId TEXT PRIMARY KEY);
            CREATE TABLE ProductPrices(ElementId TEXT PRIMARY KEY,SalePrice TEXT,IsPriceReference INTEGER);
            CREATE TABLE SupplierOffers(SupplierId TEXT,MaterialId TEXT,UnitPrice TEXT,IsDemo INTEGER,Version INTEGER);
            CREATE TABLE ProductRequirements(MaterialId TEXT,ProductId TEXT,Quantity TEXT,IsDemo INTEGER,Version INTEGER);
            CREATE TABLE GeneralDependencies(SourceId TEXT,TargetId TEXT,Version INTEGER);
        """)
        for Id, Kind in (("S1", "Supplier"), ("S2", "Supplier"), ("M1", "Material"), ("CC", "Product"), ("PP", "Product")):
            Fields = {"SalePrice": "999.99", "IsPriceReference": False} if Kind == "Product" else {}
            CreateElement(self.Database, ElementCreate(ElementId=Id, Name=Id, ElementType=Kind, **Fields))
        for Source, Target, Value in (("S1", "M1", "10"), ("S2", "M1", "15"), ("M1", "CC", "2"), ("M1", "PP", "1")):
            ChangeRelation(self.Database, RelationCreate(SourceId=Source, TargetId=Target, Value=Value), "create")

    def Product(self, Data, Id="PP"):
        return next(Item for Item in Data["Elements"] if Item["ElementId"] == Id)

    def Relation(self, Data, Source, Target):
        return next(Item for Item in Data["Relations"] if (Item["SourceId"], Item["TargetId"]) == (Source, Target))

    def test_catalogue_summary_matches_detail_without_changing_stored_prices_or_versions(self):
        Before = self.Database.Connection.total_changes
        Data = ReadCatalogue(self.Database)
        Product = self.Product(Data)
        self.assertIn("ProductCosts", Product)
        Detail = CalculateProductCosts("PP", Data["Elements"], Data["Relations"])
        self.assertEqual(Product["ProductCosts"], {Field: Detail[Field] for Field in SummaryFields})
        self.assertEqual(Product["ProductCosts"]["SalePrice"], "12.50")
        self.assertEqual(Product["SalePrice"], "999.99")
        self.assertFalse(Product["IsPriceReference"])
        self.assertEqual(ReadCatalogue(self.Database), Data)
        self.assertEqual(self.Database.Connection.total_changes, Before)

    def test_offer_edit_refreshes_parent_cost_even_when_product_version_does_not_change(self):
        ChangeRelation(self.Database, RelationCreate(SourceId="CC", TargetId="PP"), "create")
        Before = ReadCatalogue(self.Database)
        Offer = self.Relation(Before, "S1", "M1")
        ChangeRelation(self.Database, RelationEdit(SourceId="S1", TargetId="M1", Value="20", Version=Offer["Version"]), "edit")
        After = ReadCatalogue(self.Database)
        Product = self.Product(After)
        self.assertEqual(Product["Version"], self.Product(Before)["Version"])
        self.assertIn("ProductCosts", Product)
        self.assertEqual((Product["ProductCosts"]["MinimumCost"], Product["ProductCosts"]["MaximumCost"], Product["ProductCosts"]["SalePrice"]),
                         ("45.00", "60.00", "56.25"))

    def test_component_addition_and_removal_recalculate_material_quantities(self):
        Created = ChangeRelation(self.Database, RelationCreate(SourceId="CC", TargetId="PP"), "create")
        WithComponent = self.Product(ReadCatalogue(self.Database))
        self.assertIn("ProductCosts", WithComponent)
        self.assertEqual(WithComponent["ProductCosts"]["MinimumCost"], "30.00")
        ChangeRelation(self.Database, RelationEdit(SourceId="CC", TargetId="PP", Version=Created["Version"]), "delete")
        self.assertEqual(self.Product(ReadCatalogue(self.Database))["ProductCosts"]["MinimumCost"], "10.00")

    def test_removing_last_offer_invalidates_both_component_and_parent_prices(self):
        ChangeRelation(self.Database, RelationCreate(SourceId="CC", TargetId="PP"), "create")
        Data = ReadCatalogue(self.Database)
        for Supplier in ("S1", "S2"):
            Offer = self.Relation(Data, Supplier, "M1")
            ChangeRelation(self.Database, RelationEdit(SourceId=Supplier, TargetId="M1", Version=Offer["Version"]), "delete")
        After = ReadCatalogue(self.Database)
        for Id in ("CC", "PP"):
            Product = self.Product(After, Id)
            self.assertIn("ProductCosts", Product)
            self.assertEqual(Product["ProductCosts"]["Status"], "Incomplete")
            self.assertIsNone(Product["ProductCosts"]["SalePrice"])
            self.assertEqual(Product["SalePrice"], "999.99")

    def test_estimate_route_returns_new_contract_from_one_read_snapshot(self):
        App = CreateApp(self.Database)
        Endpoint = next(Route.endpoint for Route in App.routes if Route.path == "/api/products/{ProductId}/estimate")
        Before = self.Database.Connection.total_changes
        with patch("backend.Catalog.ReadCatalogue", wraps=ReadCatalogue) as ReadSnapshot:
            Result = Endpoint(ProductId="PP", User={"RoleName": "Viewer"})
        self.assertEqual(ReadSnapshot.call_count, 1)
        self.assertIn("MinimumCost", Result)
        self.assertEqual(Result["SalePrice"], "12.50")
        self.assertEqual(len(Result["Materials"][0]["Offers"]), 2)
        self.assertEqual(self.Database.Connection.total_changes, Before)

    def test_estimate_route_rejects_missing_and_nonproduct_ids_and_documents_pattern(self):
        App = CreateApp(self.Database)
        Endpoint = next(Route.endpoint for Route in App.routes if Route.path == "/api/products/{ProductId}/estimate")
        for Id in ("NOT-FOUND", "M1"):
            with self.subTest(Id=Id), self.assertRaises(HTTPException) as Failure:
                Endpoint(ProductId=Id, User={})
            self.assertEqual(Failure.exception.status_code, 404)
        Parameter = App.openapi()["paths"]["/api/products/{ProductId}/estimate"]["get"]["parameters"][0]
        self.assertEqual(Parameter["schema"].get("pattern"), r"^[A-Z][A-Z0-9_-]{1,39}$")


if __name__ == "__main__":
    unittest.main()
