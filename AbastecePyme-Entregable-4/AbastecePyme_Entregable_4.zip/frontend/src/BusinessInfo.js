export const BusinessInfo=Object.freeze({
  Building:'Centro de Negocios One Plaza',
  Office:'Torre Norte, piso 3',
  Street:'Carrera 43A #5A-113',
  City:'El Poblado, Medellín, Colombia',
  Phone:'+57 311 335 2866',
  PhoneLink:'tel:+573113352866',
  MapLink:'https://www.google.com/maps/search/?api=1&query=One%20Plaza%20Carrera%2043A%205A-113%20Medellin%20Colombia'
});
