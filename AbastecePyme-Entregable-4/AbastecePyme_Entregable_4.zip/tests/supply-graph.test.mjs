import test from 'node:test';
import assert from 'node:assert/strict';
import {GetSupplyGraph} from '../frontend/src/components/SupplyGraph.js';
import {BuildLayout} from '../frontend/src/components/GraphLayout.js';

const Elements=['S','M','P1','P2','P3','ISOLATED','C1','C2'].map((ElementId,Index)=>Object.freeze({ElementId,Name:ElementId,ElementType:Index===0?'Supplier':Index===1?'Material':'Product'}));
const Relations=[['S','M'],['M','P1'],['P1','P2'],['P2','P3'],['C1','C2'],['C2','C1']].map(([SourceId,TargetId])=>Object.freeze({SourceId,TargetId,RelationType:'General',Value:null}));
const Catalog=Object.freeze({Elements:Object.freeze(Elements),Relations:Object.freeze(Relations)});
const ImpactGraph=Object.freeze({Elements:Elements.slice(0,5),Relations:Relations.slice(0,4)});
const Production=Object.freeze({Status:'Cycle',Graph:Catalog,Cycle:['C1','C2','C1'],CycleRelations:Relations.slice(4)});
const Result=Object.freeze({Catalog,Base:{Impact:{Graph:ImpactGraph},Production},Scenario:{Impact:{Graph:{Elements:Elements.slice(0,3),Relations:Relations.slice(0,2)}},Production},Change:{Operation:'Remove',SourceId:'P1',TargetId:'P2'}});

test('default supply focus uses the complete server reachability graph, including distant consequences',()=>{
  const Graph=GetSupplyGraph(Result,'Base');
  assert.equal(Graph,ImpactGraph);
  const Layout=BuildLayout(Graph.Elements,Graph.Relations,'S',true);
  assert.deepEqual(new Set(Layout.Nodes.map(Item=>Item.ElementId)),new Set(['S','M','P1','P2','P3']));
  assert.equal(Layout.Edges.length,4);
});

test('full and focused views switch without altering the analysis or dropping scenario edge changes',()=>{
  assert.equal(GetSupplyGraph(Result,'Base',false),Catalog);
  const Scenario=GetSupplyGraph(Result,'Scenario',false);
  assert.equal(Scenario.Elements,Elements);
  assert.equal(Scenario.Relations.length,5);
  assert.equal(Scenario.Relations.some(Edge=>Edge.SourceId==='P1'&&Edge.TargetId==='P2'),false);
  assert.equal(GetSupplyGraph(Result,'Scenario'),Result.Scenario.Impact.Graph);
  assert.equal(GetSupplyGraph(Result,'Base'),ImpactGraph);
  assert.equal(Catalog.Relations.length,6);
});

test('cycle focus follows the server witness even when it is disconnected from the impact origin',()=>{
  const Graph=GetSupplyGraph(Result,'Base',true,true);
  assert.deepEqual(Graph.Elements.map(Item=>Item.ElementId),['C1','C2']);
  assert.equal(Graph.Relations,Production.CycleRelations);
  assert.equal(GetSupplyGraph(Result,'Base',false,true),Catalog);
});

test('isolated impact origins and self-cycles remain visible without borrowing unrelated nodes',()=>{
  const Isolated={Elements:[Elements[5]],Relations:[]};
  const Self={SourceId:'ISOLATED',TargetId:'ISOLATED',RelationType:'General',Value:null};
  const Response={Catalog,Base:{Impact:{Graph:Isolated},Production:{Status:'Cycle',Graph:Catalog,Cycle:['ISOLATED','ISOLATED'],CycleRelations:[Self]}}};
  assert.equal(GetSupplyGraph(Response,'Base'),Isolated);
  assert.deepEqual(GetSupplyGraph(Response,'Base',true,true),{Elements:[Elements[5]],Relations:[Self]});
  assert.equal(GetSupplyGraph(null),null);
});
