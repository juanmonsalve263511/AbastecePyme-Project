import json
import unittest
from pathlib import Path
from backend.Enrichment import BuildExpansion
from backend.Production import BuildProductionPlan

class ExpansionTests(unittest.TestCase):
    def Data(self):
        Source=json.loads((Path(__file__).resolve().parents[2]/'data/catalogo.json').read_text(encoding='utf-8-sig'))
        Types={'proveedor':'Supplier','insumo':'Material','producto':'Product'}
        Elements=[{'ElementId':Item['id'],'Name':Item['nombre'],'ElementType':Types[Item['tipo']],'SalePrice':None} for Item in Source['elementos']]
        Mapping={Item['ElementId']:Item['ElementType'] for Item in Elements}
        Relations=[]
        for Edge in Source['dependencias']:
            Pair=(Mapping[Edge['origen']],Mapping[Edge['destino']])
            Kind='Offer' if Pair==('Supplier','Material') else 'Requirement' if Pair==('Material','Product') else 'General'
            Relations.append({'SourceId':Edge['origen'],'TargetId':Edge['destino'],'RelationType':Kind,'Value':None if Kind=='General' else '1000.00','IsDemo':True})
        return {'Elements':Elements,'Relations':Relations}

    def test_expansion_covers_every_material_and_has_acyclic_general_dependencies(self):
        Data=self.Data()
        Plan=BuildExpansion(Data)
        Elements=Data['Elements']+Plan['Elements']
        Edges=Data['Relations']+Plan['Relations']
        for Item in Elements:
            if Item['ElementType']=='Material':
                Suppliers={Edge['SourceId'] for Edge in Edges if Edge['RelationType']=='Offer' and Edge['TargetId']==Item['ElementId']}
                self.assertGreaterEqual(len(Suppliers),2,Item['ElementId'])
        self.assertEqual(len([Edge for Edge in Plan['Relations'] if Edge['RelationType']=='General']),8)
        self.assertEqual(BuildProductionPlan(Elements,Edges)['Status'],'Ready')
        self.assertEqual(len({(Edge['SourceId'],Edge['TargetId']) for Edge in Edges}),len(Edges))
        self.assertTrue(all(Price['IsPriceReference'] for Price in Plan['Prices']))

    def test_existing_prices_and_graph_are_preserved(self):
        Data=self.Data()
        Product=next(Item for Item in Data['Elements'] if Item['ElementType']=='Product')
        Product['SalePrice']='765432.10'
        Before=json.dumps(Data,sort_keys=True)
        Plan=BuildExpansion(Data)
        self.assertNotIn(Product['ElementId'],{Price['ElementId'] for Price in Plan['Prices']})
        self.assertEqual(json.dumps(Data,sort_keys=True),Before)

    def test_id_collision_stops_instead_of_overwriting_existing_record(self):
        Data=self.Data()
        Data['Elements'].append({'ElementId':'COMP-CAJON','Name':'User-owned item','ElementType':'Product'})
        with self.assertRaises(ValueError): BuildExpansion(Data)
